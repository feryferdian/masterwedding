

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-24 09:24:05 --> Config Class Initialized
INFO - 2018-10-24 09:24:05 --> Hooks Class Initialized
DEBUG - 2018-10-24 09:24:05 --> UTF-8 Support Enabled
INFO - 2018-10-24 09:24:05 --> Utf8 Class Initialized
INFO - 2018-10-24 09:24:05 --> URI Class Initialized
INFO - 2018-10-24 09:24:05 --> Router Class Initialized
INFO - 2018-10-24 09:24:05 --> Output Class Initialized
INFO - 2018-10-24 09:24:05 --> Security Class Initialized
DEBUG - 2018-10-24 09:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 09:24:05 --> Input Class Initialized
INFO - 2018-10-24 09:24:05 --> Language Class Initialized
INFO - 2018-10-24 09:24:05 --> Loader Class Initialized
INFO - 2018-10-24 09:24:05 --> Helper loaded: url_helper
INFO - 2018-10-24 09:24:05 --> Database Driver Class Initialized
INFO - 2018-10-24 09:24:05 --> Helper loaded: form_helper
INFO - 2018-10-24 09:24:05 --> Form Validation Class Initialized
INFO - 2018-10-24 09:24:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-24 09:24:05 --> Pagination Class Initialized
DEBUG - 2018-10-24 09:24:05 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-24 09:24:05 --> Email Class Initialized
INFO - 2018-10-24 09:24:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-24 09:24:05 --> Helper loaded: cookie_helper
INFO - 2018-10-24 09:24:05 --> Helper loaded: language_helper
DEBUG - 2018-10-24 09:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 09:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 09:24:05 --> Helper loaded: date_helper
INFO - 2018-10-24 09:24:05 --> Database Driver Class Initialized
INFO - 2018-10-24 09:24:05 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-24 09:24:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-24 09:24:05 --> Controller Class Initialized
INFO - 2018-10-24 09:24:05 --> Model "Item_model" initialized
INFO - 2018-10-24 09:24:05 --> Model "Jenis_model" initialized
INFO - 2018-10-24 09:24:05 --> Model "Vendor_model" initialized
INFO - 2018-10-24 09:24:05 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-24 09:24:06 --> Final output sent to browser
DEBUG - 2018-10-24 09:24:06 --> Total execution time: 0.7524
INFO - 2018-10-24 09:24:09 --> Config Class Initialized
INFO - 2018-10-24 09:24:09 --> Hooks Class Initialized
DEBUG - 2018-10-24 09:24:09 --> UTF-8 Support Enabled
INFO - 2018-10-24 09:24:09 --> Utf8 Class Initialized
INFO - 2018-10-24 09:24:09 --> URI Class Initialized
INFO - 2018-10-24 09:24:09 --> Router Class Initialized
INFO - 2018-10-24 09:24:09 --> Output Class Initialized
INFO - 2018-10-24 09:24:09 --> Security Class Initialized
DEBUG - 2018-10-24 09:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 09:24:09 --> Input Class Initialized
INFO - 2018-10-24 09:24:09 --> Language Class Initialized
INFO - 2018-10-24 09:24:09 --> Loader Class Initialized
INFO - 2018-10-24 09:24:09 --> Helper loaded: url_helper
INFO - 2018-10-24 09:24:09 --> Database Driver Class Initialized
INFO - 2018-10-24 09:24:09 --> Helper loaded: form_helper
INFO - 2018-10-24 09:24:09 --> Form Validation Class Initialized
INFO - 2018-10-24 09:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-24 09:24:09 --> Pagination Class Initialized
DEBUG - 2018-10-24 09:24:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-24 09:24:09 --> Email Class Initialized
INFO - 2018-10-24 09:24:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-24 09:24:09 --> Helper loaded: cookie_helper
INFO - 2018-10-24 09:24:09 --> Helper loaded: language_helper
DEBUG - 2018-10-24 09:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 09:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 09:24:09 --> Helper loaded: date_helper
INFO - 2018-10-24 09:24:10 --> Database Driver Class Initialized
INFO - 2018-10-24 09:24:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-24 09:24:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-24 09:24:10 --> Controller Class Initialized
INFO - 2018-10-24 09:24:10 --> Model "Item_model" initialized
INFO - 2018-10-24 09:24:10 --> Model "Jenis_model" initialized
INFO - 2018-10-24 09:24:10 --> Model "Vendor_model" initialized
INFO - 2018-10-24 09:24:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-24 09:24:10 --> Final output sent to browser
DEBUG - 2018-10-24 09:24:10 --> Total execution time: 0.7399
INFO - 2018-10-24 09:24:10 --> Config Class Initialized
INFO - 2018-10-24 09:24:10 --> Hooks Class Initialized
DEBUG - 2018-10-24 09:24:10 --> UTF-8 Support Enabled
INFO - 2018-10-24 09:24:10 --> Utf8 Class Initialized
INFO - 2018-10-24 09:24:10 --> URI Class Initialized
INFO - 2018-10-24 09:24:10 --> Router Class Initialized
INFO - 2018-10-24 09:24:10 --> Output Class Initialized
INFO - 2018-10-24 09:24:10 --> Security Class Initialized
DEBUG - 2018-10-24 09:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 09:24:10 --> Input Class Initialized
INFO - 2018-10-24 09:24:10 --> Language Class Initialized
ERROR - 2018-10-24 09:24:10 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-24 09:24:19 --> Config Class Initialized
INFO - 2018-10-24 09:24:19 --> Hooks Class Initialized
DEBUG - 2018-10-24 09:24:19 --> UTF-8 Support Enabled
INFO - 2018-10-24 09:24:19 --> Utf8 Class Initialized
INFO - 2018-10-24 09:24:19 --> URI Class Initialized
INFO - 2018-10-24 09:24:19 --> Router Class Initialized
INFO - 2018-10-24 09:24:19 --> Output Class Initialized
INFO - 2018-10-24 09:24:19 --> Security Class Initialized
DEBUG - 2018-10-24 09:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 09:24:19 --> Input Class Initialized
INFO - 2018-10-24 09:24:19 --> Language Class Initialized
INFO - 2018-10-24 09:24:19 --> Loader Class Initialized
INFO - 2018-10-24 09:24:19 --> Helper loaded: url_helper
INFO - 2018-10-24 09:24:19 --> Database Driver Class Initialized
INFO - 2018-10-24 09:24:19 --> Helper loaded: form_helper
INFO - 2018-10-24 09:24:19 --> Form Validation Class Initialized
INFO - 2018-10-24 09:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-24 09:24:19 --> Pagination Class Initialized
DEBUG - 2018-10-24 09:24:19 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-24 09:24:19 --> Email Class Initialized
INFO - 2018-10-24 09:24:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-24 09:24:19 --> Helper loaded: cookie_helper
INFO - 2018-10-24 09:24:19 --> Helper loaded: language_helper
DEBUG - 2018-10-24 09:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 09:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 09:24:19 --> Helper loaded: date_helper
INFO - 2018-10-24 09:24:19 --> Database Driver Class Initialized
INFO - 2018-10-24 09:24:19 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-24 09:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-24 09:24:19 --> Controller Class Initialized
INFO - 2018-10-24 09:24:19 --> Model "Nota_model" initialized
INFO - 2018-10-24 09:24:19 --> Model "Notadetail_model" initialized
INFO - 2018-10-24 09:24:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-24 09:24:19 --> Severity: Notice --> Undefined variable: records D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 53
ERROR - 2018-10-24 09:24:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 53
ERROR - 2018-10-24 09:24:20 --> Severity: Notice --> Undefined variable: records D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 57
ERROR - 2018-10-24 09:24:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 57
INFO - 2018-10-24 09:24:20 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-24 09:24:20 --> Final output sent to browser
DEBUG - 2018-10-24 09:24:20 --> Total execution time: 0.8577
INFO - 2018-10-24 09:24:20 --> Config Class Initialized
INFO - 2018-10-24 09:24:20 --> Hooks Class Initialized
DEBUG - 2018-10-24 09:24:20 --> UTF-8 Support Enabled
INFO - 2018-10-24 09:24:20 --> Utf8 Class Initialized
INFO - 2018-10-24 09:24:20 --> URI Class Initialized
INFO - 2018-10-24 09:24:20 --> Router Class Initialized
INFO - 2018-10-24 09:24:20 --> Output Class Initialized
INFO - 2018-10-24 09:24:20 --> Security Class Initialized
DEBUG - 2018-10-24 09:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 09:24:20 --> Input Class Initialized
INFO - 2018-10-24 09:24:20 --> Language Class Initialized
ERROR - 2018-10-24 09:24:20 --> 404 Page Not Found: Transaksi/%3C
INFO - 2018-10-24 09:26:17 --> Config Class Initialized
INFO - 2018-10-24 09:26:17 --> Hooks Class Initialized
DEBUG - 2018-10-24 09:26:17 --> UTF-8 Support Enabled
INFO - 2018-10-24 09:26:17 --> Utf8 Class Initialized
INFO - 2018-10-24 09:26:17 --> URI Class Initialized
INFO - 2018-10-24 09:26:17 --> Router Class Initialized
INFO - 2018-10-24 09:26:17 --> Output Class Initialized
INFO - 2018-10-24 09:26:17 --> Security Class Initialized
DEBUG - 2018-10-24 09:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 09:26:17 --> Input Class Initialized
INFO - 2018-10-24 09:26:17 --> Language Class Initialized
INFO - 2018-10-24 09:26:17 --> Loader Class Initialized
INFO - 2018-10-24 09:26:17 --> Helper loaded: url_helper
INFO - 2018-10-24 09:26:17 --> Database Driver Class Initialized
INFO - 2018-10-24 09:26:17 --> Helper loaded: form_helper
INFO - 2018-10-24 09:26:17 --> Form Validation Class Initialized
INFO - 2018-10-24 09:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-24 09:26:17 --> Pagination Class Initialized
DEBUG - 2018-10-24 09:26:17 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-24 09:26:17 --> Email Class Initialized
INFO - 2018-10-24 09:26:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-24 09:26:17 --> Helper loaded: cookie_helper
INFO - 2018-10-24 09:26:17 --> Helper loaded: language_helper
DEBUG - 2018-10-24 09:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 09:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 09:26:18 --> Helper loaded: date_helper
INFO - 2018-10-24 09:26:18 --> Database Driver Class Initialized
INFO - 2018-10-24 09:26:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-24 09:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-24 09:26:18 --> Controller Class Initialized
INFO - 2018-10-24 09:26:18 --> Model "Item_model" initialized
INFO - 2018-10-24 09:26:18 --> Model "Jenis_model" initialized
INFO - 2018-10-24 09:26:18 --> Model "Vendor_model" initialized
INFO - 2018-10-24 09:26:18 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-24 09:26:18 --> Final output sent to browser
DEBUG - 2018-10-24 09:26:18 --> Total execution time: 0.7194
INFO - 2018-10-24 09:26:24 --> Config Class Initialized
INFO - 2018-10-24 09:26:24 --> Hooks Class Initialized
DEBUG - 2018-10-24 09:26:24 --> UTF-8 Support Enabled
INFO - 2018-10-24 09:26:24 --> Utf8 Class Initialized
INFO - 2018-10-24 09:26:24 --> URI Class Initialized
INFO - 2018-10-24 09:26:24 --> Router Class Initialized
INFO - 2018-10-24 09:26:24 --> Output Class Initialized
INFO - 2018-10-24 09:26:24 --> Security Class Initialized
DEBUG - 2018-10-24 09:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 09:26:24 --> Input Class Initialized
INFO - 2018-10-24 09:26:24 --> Language Class Initialized
INFO - 2018-10-24 09:26:24 --> Loader Class Initialized
INFO - 2018-10-24 09:26:24 --> Helper loaded: url_helper
INFO - 2018-10-24 09:26:24 --> Database Driver Class Initialized
INFO - 2018-10-24 09:26:24 --> Helper loaded: form_helper
INFO - 2018-10-24 09:26:24 --> Form Validation Class Initialized
INFO - 2018-10-24 09:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-24 09:26:24 --> Pagination Class Initialized
DEBUG - 2018-10-24 09:26:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-24 09:26:24 --> Email Class Initialized
INFO - 2018-10-24 09:26:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-24 09:26:24 --> Helper loaded: cookie_helper
INFO - 2018-10-24 09:26:24 --> Helper loaded: language_helper
DEBUG - 2018-10-24 09:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 09:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 09:26:24 --> Helper loaded: date_helper
INFO - 2018-10-24 09:26:24 --> Database Driver Class Initialized
INFO - 2018-10-24 09:26:24 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-24 09:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-24 09:26:24 --> Controller Class Initialized
INFO - 2018-10-24 09:26:24 --> Model "Item_model" initialized
INFO - 2018-10-24 09:26:24 --> Model "Jenis_model" initialized
INFO - 2018-10-24 09:26:24 --> Model "Vendor_model" initialized
INFO - 2018-10-24 09:26:24 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-24 09:26:24 --> Final output sent to browser
DEBUG - 2018-10-24 09:26:24 --> Total execution time: 0.4446
INFO - 2018-10-24 09:26:24 --> Config Class Initialized
INFO - 2018-10-24 09:26:24 --> Hooks Class Initialized
DEBUG - 2018-10-24 09:26:24 --> UTF-8 Support Enabled
INFO - 2018-10-24 09:26:24 --> Utf8 Class Initialized
INFO - 2018-10-24 09:26:24 --> URI Class Initialized
INFO - 2018-10-24 09:26:24 --> Router Class Initialized
INFO - 2018-10-24 09:26:24 --> Output Class Initialized
INFO - 2018-10-24 09:26:24 --> Security Class Initialized
DEBUG - 2018-10-24 09:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 09:26:24 --> Input Class Initialized
INFO - 2018-10-24 09:26:25 --> Language Class Initialized
ERROR - 2018-10-24 09:26:25 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-24 09:26:43 --> Config Class Initialized
INFO - 2018-10-24 09:26:43 --> Hooks Class Initialized
DEBUG - 2018-10-24 09:26:43 --> UTF-8 Support Enabled
INFO - 2018-10-24 09:26:43 --> Utf8 Class Initialized
INFO - 2018-10-24 09:26:43 --> URI Class Initialized
INFO - 2018-10-24 09:26:43 --> Router Class Initialized
INFO - 2018-10-24 09:26:43 --> Output Class Initialized
INFO - 2018-10-24 09:26:43 --> Security Class Initialized
DEBUG - 2018-10-24 09:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 09:26:43 --> Input Class Initialized
INFO - 2018-10-24 09:26:43 --> Language Class Initialized
INFO - 2018-10-24 09:26:44 --> Loader Class Initialized
INFO - 2018-10-24 09:26:44 --> Helper loaded: url_helper
INFO - 2018-10-24 09:26:44 --> Database Driver Class Initialized
INFO - 2018-10-24 09:26:44 --> Helper loaded: form_helper
INFO - 2018-10-24 09:26:44 --> Form Validation Class Initialized
INFO - 2018-10-24 09:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-24 09:26:44 --> Pagination Class Initialized
DEBUG - 2018-10-24 09:26:44 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-24 09:26:44 --> Email Class Initialized
INFO - 2018-10-24 09:26:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-24 09:26:44 --> Helper loaded: cookie_helper
INFO - 2018-10-24 09:26:44 --> Helper loaded: language_helper
DEBUG - 2018-10-24 09:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 09:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 09:26:44 --> Helper loaded: date_helper
INFO - 2018-10-24 09:26:44 --> Database Driver Class Initialized
INFO - 2018-10-24 09:26:44 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-24 09:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-24 09:26:44 --> Controller Class Initialized
INFO - 2018-10-24 09:26:44 --> Model "Item_model" initialized
INFO - 2018-10-24 09:26:44 --> Model "Jenis_model" initialized
INFO - 2018-10-24 09:26:44 --> Model "Vendor_model" initialized
INFO - 2018-10-24 09:26:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-24 09:26:44 --> Final output sent to browser
DEBUG - 2018-10-24 09:26:44 --> Total execution time: 0.4826
INFO - 2018-10-24 09:26:46 --> Config Class Initialized
INFO - 2018-10-24 09:26:46 --> Hooks Class Initialized
DEBUG - 2018-10-24 09:26:46 --> UTF-8 Support Enabled
INFO - 2018-10-24 09:26:46 --> Utf8 Class Initialized
INFO - 2018-10-24 09:26:46 --> URI Class Initialized
INFO - 2018-10-24 09:26:46 --> Router Class Initialized
INFO - 2018-10-24 09:26:46 --> Output Class Initialized
INFO - 2018-10-24 09:26:46 --> Security Class Initialized
DEBUG - 2018-10-24 09:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 09:26:46 --> Input Class Initialized
INFO - 2018-10-24 09:26:46 --> Language Class Initialized
INFO - 2018-10-24 09:26:46 --> Loader Class Initialized
INFO - 2018-10-24 09:26:46 --> Helper loaded: url_helper
INFO - 2018-10-24 09:26:46 --> Database Driver Class Initialized
INFO - 2018-10-24 09:26:46 --> Helper loaded: form_helper
INFO - 2018-10-24 09:26:46 --> Form Validation Class Initialized
INFO - 2018-10-24 09:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-24 09:26:46 --> Pagination Class Initialized
DEBUG - 2018-10-24 09:26:46 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-24 09:26:46 --> Email Class Initialized
INFO - 2018-10-24 09:26:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-24 09:26:46 --> Helper loaded: cookie_helper
INFO - 2018-10-24 09:26:46 --> Helper loaded: language_helper
DEBUG - 2018-10-24 09:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 09:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 09:26:46 --> Helper loaded: date_helper
INFO - 2018-10-24 09:26:46 --> Database Driver Class Initialized
INFO - 2018-10-24 09:26:46 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-24 09:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-24 09:26:46 --> Controller Class Initialized
INFO - 2018-10-24 09:26:46 --> Model "Nota_model" initialized
INFO - 2018-10-24 09:26:46 --> Model "Notadetail_model" initialized
INFO - 2018-10-24 09:26:46 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-24 09:26:46 --> Final output sent to browser
DEBUG - 2018-10-24 09:26:46 --> Total execution time: 0.7864
INFO - 2018-10-24 10:02:21 --> Config Class Initialized
INFO - 2018-10-24 10:02:21 --> Hooks Class Initialized
DEBUG - 2018-10-24 10:02:21 --> UTF-8 Support Enabled
INFO - 2018-10-24 10:02:21 --> Utf8 Class Initialized
INFO - 2018-10-24 10:02:21 --> URI Class Initialized
DEBUG - 2018-10-24 10:02:21 --> No URI present. Default controller set.
INFO - 2018-10-24 10:02:21 --> Router Class Initialized
INFO - 2018-10-24 10:02:21 --> Output Class Initialized
INFO - 2018-10-24 10:02:21 --> Security Class Initialized
DEBUG - 2018-10-24 10:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-24 10:02:21 --> Input Class Initialized
INFO - 2018-10-24 10:02:21 --> Language Class Initialized
INFO - 2018-10-24 10:02:21 --> Loader Class Initialized
INFO - 2018-10-24 10:02:21 --> Helper loaded: url_helper
INFO - 2018-10-24 10:02:21 --> Database Driver Class Initialized
INFO - 2018-10-24 10:02:21 --> Helper loaded: form_helper
INFO - 2018-10-24 10:02:21 --> Form Validation Class Initialized
INFO - 2018-10-24 10:02:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-24 10:02:21 --> Pagination Class Initialized
DEBUG - 2018-10-24 10:02:21 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-24 10:02:21 --> Email Class Initialized
INFO - 2018-10-24 10:02:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-24 10:02:21 --> Helper loaded: cookie_helper
INFO - 2018-10-24 10:02:21 --> Helper loaded: language_helper
DEBUG - 2018-10-24 10:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-24 10:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-24 10:02:21 --> Helper loaded: date_helper
INFO - 2018-10-24 10:02:21 --> Database Driver Class Initialized
INFO - 2018-10-24 10:02:21 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-24 10:02:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-24 10:02:21 --> Controller Class Initialized
INFO - 2018-10-24 10:02:21 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-24 10:02:21 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\index.php
INFO - 2018-10-24 10:02:21 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-10-24 10:02:21 --> Final output sent to browser
DEBUG - 2018-10-24 10:02:21 --> Total execution time: 0.7409
