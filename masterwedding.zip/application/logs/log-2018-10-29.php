<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-29 07:38:27 --> Config Class Initialized
INFO - 2018-10-29 07:38:27 --> Hooks Class Initialized
DEBUG - 2018-10-29 07:38:27 --> UTF-8 Support Enabled
INFO - 2018-10-29 07:38:27 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:27 --> URI Class Initialized
DEBUG - 2018-10-29 07:38:27 --> No URI present. Default controller set.
INFO - 2018-10-29 07:38:27 --> Router Class Initialized
INFO - 2018-10-29 07:38:27 --> Output Class Initialized
INFO - 2018-10-29 07:38:27 --> Security Class Initialized
DEBUG - 2018-10-29 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 07:38:27 --> Input Class Initialized
INFO - 2018-10-29 07:38:27 --> Language Class Initialized
INFO - 2018-10-29 07:38:28 --> Loader Class Initialized
INFO - 2018-10-29 07:38:28 --> Helper loaded: url_helper
INFO - 2018-10-29 07:38:28 --> Database Driver Class Initialized
INFO - 2018-10-29 07:38:28 --> Helper loaded: form_helper
INFO - 2018-10-29 07:38:28 --> Form Validation Class Initialized
INFO - 2018-10-29 07:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-29 07:38:28 --> Pagination Class Initialized
DEBUG - 2018-10-29 07:38:28 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-29 07:38:28 --> Email Class Initialized
INFO - 2018-10-29 07:38:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-29 07:38:28 --> Helper loaded: cookie_helper
INFO - 2018-10-29 07:38:28 --> Helper loaded: language_helper
DEBUG - 2018-10-29 07:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 07:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 07:38:28 --> Helper loaded: date_helper
INFO - 2018-10-29 07:38:28 --> Database Driver Class Initialized
INFO - 2018-10-29 07:38:28 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-29 07:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-29 07:38:28 --> Controller Class Initialized
INFO - 2018-10-29 07:38:28 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-29 07:38:28 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\index.php
INFO - 2018-10-29 07:38:28 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-10-29 07:38:28 --> Final output sent to browser
DEBUG - 2018-10-29 07:38:28 --> Total execution time: 1.0961
INFO - 2018-10-29 07:38:28 --> Config Class Initialized
INFO - 2018-10-29 07:38:28 --> Config Class Initialized
INFO - 2018-10-29 07:38:28 --> Config Class Initialized
INFO - 2018-10-29 07:38:28 --> Hooks Class Initialized
INFO - 2018-10-29 07:38:28 --> Hooks Class Initialized
INFO - 2018-10-29 07:38:28 --> Hooks Class Initialized
DEBUG - 2018-10-29 07:38:28 --> UTF-8 Support Enabled
DEBUG - 2018-10-29 07:38:28 --> UTF-8 Support Enabled
DEBUG - 2018-10-29 07:38:28 --> UTF-8 Support Enabled
INFO - 2018-10-29 07:38:28 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:28 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:28 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:28 --> URI Class Initialized
INFO - 2018-10-29 07:38:28 --> URI Class Initialized
INFO - 2018-10-29 07:38:28 --> URI Class Initialized
INFO - 2018-10-29 07:38:28 --> Router Class Initialized
INFO - 2018-10-29 07:38:28 --> Router Class Initialized
INFO - 2018-10-29 07:38:28 --> Router Class Initialized
INFO - 2018-10-29 07:38:28 --> Output Class Initialized
INFO - 2018-10-29 07:38:28 --> Output Class Initialized
INFO - 2018-10-29 07:38:28 --> Output Class Initialized
INFO - 2018-10-29 07:38:28 --> Security Class Initialized
INFO - 2018-10-29 07:38:28 --> Security Class Initialized
INFO - 2018-10-29 07:38:28 --> Security Class Initialized
DEBUG - 2018-10-29 07:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-29 07:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-29 07:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 07:38:28 --> Input Class Initialized
INFO - 2018-10-29 07:38:28 --> Input Class Initialized
INFO - 2018-10-29 07:38:28 --> Input Class Initialized
INFO - 2018-10-29 07:38:28 --> Language Class Initialized
INFO - 2018-10-29 07:38:28 --> Language Class Initialized
INFO - 2018-10-29 07:38:28 --> Language Class Initialized
ERROR - 2018-10-29 07:38:28 --> 404 Page Not Found: Application/views
ERROR - 2018-10-29 07:38:28 --> 404 Page Not Found: Application/views
ERROR - 2018-10-29 07:38:28 --> 404 Page Not Found: Application/views
INFO - 2018-10-29 07:38:31 --> Config Class Initialized
INFO - 2018-10-29 07:38:31 --> Hooks Class Initialized
DEBUG - 2018-10-29 07:38:31 --> UTF-8 Support Enabled
INFO - 2018-10-29 07:38:31 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:31 --> URI Class Initialized
INFO - 2018-10-29 07:38:31 --> Router Class Initialized
INFO - 2018-10-29 07:38:31 --> Output Class Initialized
INFO - 2018-10-29 07:38:31 --> Security Class Initialized
DEBUG - 2018-10-29 07:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 07:38:31 --> Input Class Initialized
INFO - 2018-10-29 07:38:31 --> Language Class Initialized
INFO - 2018-10-29 07:38:31 --> Loader Class Initialized
INFO - 2018-10-29 07:38:31 --> Helper loaded: url_helper
INFO - 2018-10-29 07:38:31 --> Database Driver Class Initialized
INFO - 2018-10-29 07:38:31 --> Helper loaded: form_helper
INFO - 2018-10-29 07:38:31 --> Form Validation Class Initialized
INFO - 2018-10-29 07:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-29 07:38:31 --> Pagination Class Initialized
DEBUG - 2018-10-29 07:38:31 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-29 07:38:31 --> Email Class Initialized
INFO - 2018-10-29 07:38:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-29 07:38:31 --> Helper loaded: cookie_helper
INFO - 2018-10-29 07:38:31 --> Helper loaded: language_helper
DEBUG - 2018-10-29 07:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 07:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 07:38:31 --> Helper loaded: date_helper
INFO - 2018-10-29 07:38:31 --> Database Driver Class Initialized
INFO - 2018-10-29 07:38:31 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-29 07:38:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-29 07:38:31 --> Controller Class Initialized
INFO - 2018-10-29 07:38:31 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-29 07:38:31 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\login.php
INFO - 2018-10-29 07:38:31 --> Final output sent to browser
DEBUG - 2018-10-29 07:38:31 --> Total execution time: 0.3830
INFO - 2018-10-29 07:38:31 --> Config Class Initialized
INFO - 2018-10-29 07:38:31 --> Config Class Initialized
INFO - 2018-10-29 07:38:31 --> Config Class Initialized
INFO - 2018-10-29 07:38:31 --> Hooks Class Initialized
INFO - 2018-10-29 07:38:31 --> Hooks Class Initialized
INFO - 2018-10-29 07:38:31 --> Hooks Class Initialized
DEBUG - 2018-10-29 07:38:31 --> UTF-8 Support Enabled
DEBUG - 2018-10-29 07:38:31 --> UTF-8 Support Enabled
DEBUG - 2018-10-29 07:38:31 --> UTF-8 Support Enabled
INFO - 2018-10-29 07:38:31 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:31 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:31 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:31 --> URI Class Initialized
INFO - 2018-10-29 07:38:31 --> URI Class Initialized
INFO - 2018-10-29 07:38:31 --> URI Class Initialized
INFO - 2018-10-29 07:38:31 --> Router Class Initialized
INFO - 2018-10-29 07:38:31 --> Router Class Initialized
INFO - 2018-10-29 07:38:31 --> Router Class Initialized
INFO - 2018-10-29 07:38:31 --> Output Class Initialized
INFO - 2018-10-29 07:38:31 --> Output Class Initialized
INFO - 2018-10-29 07:38:31 --> Output Class Initialized
INFO - 2018-10-29 07:38:31 --> Security Class Initialized
INFO - 2018-10-29 07:38:31 --> Security Class Initialized
INFO - 2018-10-29 07:38:31 --> Security Class Initialized
DEBUG - 2018-10-29 07:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-29 07:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-29 07:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 07:38:31 --> Input Class Initialized
INFO - 2018-10-29 07:38:31 --> Input Class Initialized
INFO - 2018-10-29 07:38:31 --> Input Class Initialized
INFO - 2018-10-29 07:38:31 --> Language Class Initialized
INFO - 2018-10-29 07:38:31 --> Language Class Initialized
INFO - 2018-10-29 07:38:31 --> Language Class Initialized
ERROR - 2018-10-29 07:38:31 --> 404 Page Not Found: Application/views
ERROR - 2018-10-29 07:38:31 --> 404 Page Not Found: Application/views
ERROR - 2018-10-29 07:38:31 --> 404 Page Not Found: Application/views
INFO - 2018-10-29 07:38:38 --> Config Class Initialized
INFO - 2018-10-29 07:38:38 --> Hooks Class Initialized
DEBUG - 2018-10-29 07:38:38 --> UTF-8 Support Enabled
INFO - 2018-10-29 07:38:38 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:38 --> URI Class Initialized
INFO - 2018-10-29 07:38:38 --> Router Class Initialized
INFO - 2018-10-29 07:38:38 --> Output Class Initialized
INFO - 2018-10-29 07:38:38 --> Security Class Initialized
DEBUG - 2018-10-29 07:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 07:38:38 --> Input Class Initialized
INFO - 2018-10-29 07:38:38 --> Language Class Initialized
INFO - 2018-10-29 07:38:38 --> Loader Class Initialized
INFO - 2018-10-29 07:38:38 --> Helper loaded: url_helper
INFO - 2018-10-29 07:38:38 --> Database Driver Class Initialized
INFO - 2018-10-29 07:38:38 --> Helper loaded: form_helper
INFO - 2018-10-29 07:38:38 --> Form Validation Class Initialized
INFO - 2018-10-29 07:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-29 07:38:38 --> Pagination Class Initialized
DEBUG - 2018-10-29 07:38:38 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-29 07:38:38 --> Email Class Initialized
INFO - 2018-10-29 07:38:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-29 07:38:38 --> Helper loaded: cookie_helper
INFO - 2018-10-29 07:38:38 --> Helper loaded: language_helper
DEBUG - 2018-10-29 07:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 07:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 07:38:38 --> Helper loaded: date_helper
INFO - 2018-10-29 07:38:39 --> Database Driver Class Initialized
INFO - 2018-10-29 07:38:39 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-29 07:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-29 07:38:39 --> Controller Class Initialized
INFO - 2018-10-29 07:38:39 --> Config Class Initialized
INFO - 2018-10-29 07:38:39 --> Hooks Class Initialized
DEBUG - 2018-10-29 07:38:39 --> UTF-8 Support Enabled
INFO - 2018-10-29 07:38:39 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:39 --> URI Class Initialized
INFO - 2018-10-29 07:38:39 --> Router Class Initialized
INFO - 2018-10-29 07:38:39 --> Output Class Initialized
INFO - 2018-10-29 07:38:39 --> Security Class Initialized
DEBUG - 2018-10-29 07:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 07:38:39 --> Input Class Initialized
INFO - 2018-10-29 07:38:39 --> Language Class Initialized
INFO - 2018-10-29 07:38:39 --> Loader Class Initialized
INFO - 2018-10-29 07:38:39 --> Helper loaded: url_helper
INFO - 2018-10-29 07:38:39 --> Database Driver Class Initialized
INFO - 2018-10-29 07:38:39 --> Helper loaded: form_helper
INFO - 2018-10-29 07:38:39 --> Form Validation Class Initialized
INFO - 2018-10-29 07:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-29 07:38:39 --> Pagination Class Initialized
DEBUG - 2018-10-29 07:38:39 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-29 07:38:39 --> Email Class Initialized
INFO - 2018-10-29 07:38:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-29 07:38:39 --> Helper loaded: cookie_helper
INFO - 2018-10-29 07:38:39 --> Helper loaded: language_helper
DEBUG - 2018-10-29 07:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 07:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 07:38:40 --> Helper loaded: date_helper
INFO - 2018-10-29 07:38:40 --> Database Driver Class Initialized
INFO - 2018-10-29 07:38:40 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-29 07:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-29 07:38:40 --> Controller Class Initialized
INFO - 2018-10-29 07:38:40 --> Model "Item_model" initialized
INFO - 2018-10-29 07:38:40 --> Model "Jenis_model" initialized
INFO - 2018-10-29 07:38:40 --> Model "Vendor_model" initialized
INFO - 2018-10-29 07:38:40 --> Model "Nota_model" initialized
INFO - 2018-10-29 07:38:40 --> Model "Notadetail_model" initialized
INFO - 2018-10-29 07:38:40 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-29 07:38:40 --> Final output sent to browser
DEBUG - 2018-10-29 07:38:40 --> Total execution time: 0.9817
INFO - 2018-10-29 07:38:40 --> Config Class Initialized
INFO - 2018-10-29 07:38:40 --> Hooks Class Initialized
DEBUG - 2018-10-29 07:38:40 --> UTF-8 Support Enabled
INFO - 2018-10-29 07:38:40 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:40 --> URI Class Initialized
INFO - 2018-10-29 07:38:40 --> Router Class Initialized
INFO - 2018-10-29 07:38:40 --> Output Class Initialized
INFO - 2018-10-29 07:38:40 --> Security Class Initialized
DEBUG - 2018-10-29 07:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 07:38:40 --> Input Class Initialized
INFO - 2018-10-29 07:38:40 --> Language Class Initialized
ERROR - 2018-10-29 07:38:40 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-29 07:38:42 --> Config Class Initialized
INFO - 2018-10-29 07:38:42 --> Hooks Class Initialized
DEBUG - 2018-10-29 07:38:42 --> UTF-8 Support Enabled
INFO - 2018-10-29 07:38:42 --> Utf8 Class Initialized
INFO - 2018-10-29 07:38:42 --> URI Class Initialized
INFO - 2018-10-29 07:38:42 --> Router Class Initialized
INFO - 2018-10-29 07:38:42 --> Output Class Initialized
INFO - 2018-10-29 07:38:42 --> Security Class Initialized
DEBUG - 2018-10-29 07:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 07:38:42 --> Input Class Initialized
INFO - 2018-10-29 07:38:42 --> Language Class Initialized
INFO - 2018-10-29 07:38:42 --> Loader Class Initialized
INFO - 2018-10-29 07:38:42 --> Helper loaded: url_helper
INFO - 2018-10-29 07:38:42 --> Database Driver Class Initialized
INFO - 2018-10-29 07:38:42 --> Helper loaded: form_helper
INFO - 2018-10-29 07:38:42 --> Form Validation Class Initialized
INFO - 2018-10-29 07:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-29 07:38:42 --> Pagination Class Initialized
DEBUG - 2018-10-29 07:38:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-29 07:38:42 --> Email Class Initialized
INFO - 2018-10-29 07:38:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-29 07:38:42 --> Helper loaded: cookie_helper
INFO - 2018-10-29 07:38:42 --> Helper loaded: language_helper
DEBUG - 2018-10-29 07:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 07:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 07:38:42 --> Helper loaded: date_helper
INFO - 2018-10-29 07:38:42 --> Database Driver Class Initialized
INFO - 2018-10-29 07:38:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-29 07:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-29 07:38:43 --> Controller Class Initialized
INFO - 2018-10-29 07:38:43 --> Model "Nota_model" initialized
INFO - 2018-10-29 07:38:43 --> Model "Notadetail_model" initialized
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-29 07:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-29 07:38:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-29 07:38:43 --> Final output sent to browser
DEBUG - 2018-10-29 07:38:43 --> Total execution time: 0.7102
INFO - 2018-10-29 08:21:04 --> Config Class Initialized
INFO - 2018-10-29 08:21:04 --> Hooks Class Initialized
DEBUG - 2018-10-29 08:21:04 --> UTF-8 Support Enabled
INFO - 2018-10-29 08:21:04 --> Utf8 Class Initialized
INFO - 2018-10-29 08:21:04 --> URI Class Initialized
INFO - 2018-10-29 08:21:04 --> Router Class Initialized
INFO - 2018-10-29 08:21:04 --> Output Class Initialized
INFO - 2018-10-29 08:21:04 --> Security Class Initialized
DEBUG - 2018-10-29 08:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 08:21:04 --> Input Class Initialized
INFO - 2018-10-29 08:21:04 --> Language Class Initialized
INFO - 2018-10-29 08:21:04 --> Loader Class Initialized
INFO - 2018-10-29 08:21:04 --> Helper loaded: url_helper
INFO - 2018-10-29 08:21:04 --> Database Driver Class Initialized
INFO - 2018-10-29 08:21:04 --> Helper loaded: form_helper
INFO - 2018-10-29 08:21:04 --> Form Validation Class Initialized
INFO - 2018-10-29 08:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-29 08:21:04 --> Pagination Class Initialized
DEBUG - 2018-10-29 08:21:04 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-29 08:21:04 --> Email Class Initialized
INFO - 2018-10-29 08:21:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-29 08:21:04 --> Helper loaded: cookie_helper
INFO - 2018-10-29 08:21:04 --> Helper loaded: language_helper
DEBUG - 2018-10-29 08:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 08:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 08:21:04 --> Helper loaded: date_helper
INFO - 2018-10-29 08:21:04 --> Database Driver Class Initialized
INFO - 2018-10-29 08:21:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-29 08:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-29 08:21:04 --> Controller Class Initialized
INFO - 2018-10-29 08:21:04 --> Model "Nota_model" initialized
INFO - 2018-10-29 08:21:04 --> Model "Notadetail_model" initialized
INFO - 2018-10-29 08:21:04 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-29 08:21:04 --> Final output sent to browser
DEBUG - 2018-10-29 08:21:04 --> Total execution time: 0.5711
INFO - 2018-10-29 08:47:17 --> Config Class Initialized
INFO - 2018-10-29 08:47:17 --> Hooks Class Initialized
DEBUG - 2018-10-29 08:47:17 --> UTF-8 Support Enabled
INFO - 2018-10-29 08:47:17 --> Utf8 Class Initialized
INFO - 2018-10-29 08:47:17 --> URI Class Initialized
INFO - 2018-10-29 08:47:17 --> Router Class Initialized
INFO - 2018-10-29 08:47:17 --> Output Class Initialized
INFO - 2018-10-29 08:47:17 --> Security Class Initialized
DEBUG - 2018-10-29 08:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 08:47:17 --> Input Class Initialized
INFO - 2018-10-29 08:47:17 --> Language Class Initialized
INFO - 2018-10-29 08:47:17 --> Loader Class Initialized
INFO - 2018-10-29 08:47:17 --> Helper loaded: url_helper
INFO - 2018-10-29 08:47:17 --> Database Driver Class Initialized
INFO - 2018-10-29 08:47:17 --> Helper loaded: form_helper
INFO - 2018-10-29 08:47:17 --> Form Validation Class Initialized
INFO - 2018-10-29 08:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-29 08:47:17 --> Pagination Class Initialized
DEBUG - 2018-10-29 08:47:17 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-29 08:47:17 --> Email Class Initialized
INFO - 2018-10-29 08:47:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-29 08:47:17 --> Helper loaded: cookie_helper
INFO - 2018-10-29 08:47:18 --> Helper loaded: language_helper
DEBUG - 2018-10-29 08:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 08:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 08:47:18 --> Helper loaded: date_helper
INFO - 2018-10-29 08:47:18 --> Database Driver Class Initialized
INFO - 2018-10-29 08:47:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-29 08:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-29 08:47:18 --> Controller Class Initialized
INFO - 2018-10-29 08:47:18 --> Model "Item_model" initialized
INFO - 2018-10-29 08:47:18 --> Model "Jenis_model" initialized
INFO - 2018-10-29 08:47:18 --> Model "Vendor_model" initialized
INFO - 2018-10-29 08:47:18 --> Model "Nota_model" initialized
INFO - 2018-10-29 08:47:18 --> Model "Notadetail_model" initialized
INFO - 2018-10-29 08:47:18 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-29 08:47:18 --> Final output sent to browser
DEBUG - 2018-10-29 08:47:18 --> Total execution time: 0.8586
INFO - 2018-10-29 08:47:31 --> Config Class Initialized
INFO - 2018-10-29 08:47:31 --> Hooks Class Initialized
DEBUG - 2018-10-29 08:47:31 --> UTF-8 Support Enabled
INFO - 2018-10-29 08:47:31 --> Utf8 Class Initialized
INFO - 2018-10-29 08:47:31 --> URI Class Initialized
INFO - 2018-10-29 08:47:31 --> Router Class Initialized
INFO - 2018-10-29 08:47:31 --> Output Class Initialized
INFO - 2018-10-29 08:47:31 --> Security Class Initialized
DEBUG - 2018-10-29 08:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 08:47:31 --> Input Class Initialized
INFO - 2018-10-29 08:47:31 --> Language Class Initialized
INFO - 2018-10-29 08:47:31 --> Loader Class Initialized
INFO - 2018-10-29 08:47:31 --> Helper loaded: url_helper
INFO - 2018-10-29 08:47:31 --> Database Driver Class Initialized
INFO - 2018-10-29 08:47:31 --> Helper loaded: form_helper
INFO - 2018-10-29 08:47:31 --> Form Validation Class Initialized
INFO - 2018-10-29 08:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-29 08:47:31 --> Pagination Class Initialized
DEBUG - 2018-10-29 08:47:31 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-29 08:47:31 --> Email Class Initialized
INFO - 2018-10-29 08:47:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-29 08:47:31 --> Helper loaded: cookie_helper
INFO - 2018-10-29 08:47:31 --> Helper loaded: language_helper
DEBUG - 2018-10-29 08:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-29 08:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-29 08:47:31 --> Helper loaded: date_helper
INFO - 2018-10-29 08:47:31 --> Database Driver Class Initialized
INFO - 2018-10-29 08:47:31 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-29 08:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-29 08:47:31 --> Controller Class Initialized
INFO - 2018-10-29 08:47:31 --> Model "Item_model" initialized
INFO - 2018-10-29 08:47:31 --> Model "Jenis_model" initialized
INFO - 2018-10-29 08:47:31 --> Model "Vendor_model" initialized
INFO - 2018-10-29 08:47:31 --> Model "Nota_model" initialized
INFO - 2018-10-29 08:47:31 --> Model "Notadetail_model" initialized
INFO - 2018-10-29 08:47:31 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-29 08:47:31 --> Final output sent to browser
DEBUG - 2018-10-29 08:47:31 --> Total execution time: 0.6836
INFO - 2018-10-29 08:47:31 --> Config Class Initialized
INFO - 2018-10-29 08:47:31 --> Hooks Class Initialized
DEBUG - 2018-10-29 08:47:31 --> UTF-8 Support Enabled
INFO - 2018-10-29 08:47:31 --> Utf8 Class Initialized
INFO - 2018-10-29 08:47:31 --> URI Class Initialized
INFO - 2018-10-29 08:47:31 --> Router Class Initialized
INFO - 2018-10-29 08:47:31 --> Output Class Initialized
INFO - 2018-10-29 08:47:31 --> Security Class Initialized
DEBUG - 2018-10-29 08:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-29 08:47:31 --> Input Class Initialized
INFO - 2018-10-29 08:47:31 --> Language Class Initialized
ERROR - 2018-10-29 08:47:31 --> 404 Page Not Found: Item/%3C
