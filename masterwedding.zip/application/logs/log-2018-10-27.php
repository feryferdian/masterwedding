<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-27 03:22:01 --> Config Class Initialized
INFO - 2018-10-27 03:22:01 --> Hooks Class Initialized
DEBUG - 2018-10-27 03:22:01 --> UTF-8 Support Enabled
INFO - 2018-10-27 03:22:01 --> Utf8 Class Initialized
INFO - 2018-10-27 03:22:01 --> URI Class Initialized
DEBUG - 2018-10-27 03:22:01 --> No URI present. Default controller set.
INFO - 2018-10-27 03:22:01 --> Router Class Initialized
INFO - 2018-10-27 03:22:01 --> Output Class Initialized
INFO - 2018-10-27 03:22:01 --> Security Class Initialized
DEBUG - 2018-10-27 03:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 03:22:01 --> Input Class Initialized
INFO - 2018-10-27 03:22:01 --> Language Class Initialized
INFO - 2018-10-27 03:22:01 --> Loader Class Initialized
INFO - 2018-10-27 03:22:01 --> Helper loaded: url_helper
INFO - 2018-10-27 03:22:01 --> Database Driver Class Initialized
INFO - 2018-10-27 03:22:01 --> Helper loaded: form_helper
INFO - 2018-10-27 03:22:01 --> Form Validation Class Initialized
INFO - 2018-10-27 03:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 03:22:01 --> Pagination Class Initialized
DEBUG - 2018-10-27 03:22:01 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 03:22:01 --> Email Class Initialized
INFO - 2018-10-27 03:22:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 03:22:01 --> Helper loaded: cookie_helper
INFO - 2018-10-27 03:22:01 --> Helper loaded: language_helper
DEBUG - 2018-10-27 03:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 03:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 03:22:01 --> Helper loaded: date_helper
INFO - 2018-10-27 03:22:01 --> Database Driver Class Initialized
INFO - 2018-10-27 03:22:02 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 03:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 03:22:02 --> Controller Class Initialized
INFO - 2018-10-27 03:22:02 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-27 03:22:02 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\index.php
INFO - 2018-10-27 03:22:02 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-10-27 03:22:02 --> Final output sent to browser
DEBUG - 2018-10-27 03:22:02 --> Total execution time: 1.0055
INFO - 2018-10-27 03:39:38 --> Config Class Initialized
INFO - 2018-10-27 03:39:38 --> Hooks Class Initialized
DEBUG - 2018-10-27 03:39:38 --> UTF-8 Support Enabled
INFO - 2018-10-27 03:39:38 --> Utf8 Class Initialized
INFO - 2018-10-27 03:39:38 --> URI Class Initialized
INFO - 2018-10-27 03:39:38 --> Router Class Initialized
INFO - 2018-10-27 03:39:38 --> Output Class Initialized
INFO - 2018-10-27 03:39:38 --> Security Class Initialized
DEBUG - 2018-10-27 03:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 03:39:38 --> Input Class Initialized
INFO - 2018-10-27 03:39:38 --> Language Class Initialized
INFO - 2018-10-27 03:39:39 --> Loader Class Initialized
INFO - 2018-10-27 03:39:39 --> Helper loaded: url_helper
INFO - 2018-10-27 03:39:39 --> Database Driver Class Initialized
INFO - 2018-10-27 03:39:39 --> Helper loaded: form_helper
INFO - 2018-10-27 03:39:39 --> Form Validation Class Initialized
INFO - 2018-10-27 03:39:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 03:39:39 --> Pagination Class Initialized
DEBUG - 2018-10-27 03:39:39 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 03:39:39 --> Email Class Initialized
INFO - 2018-10-27 03:39:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 03:39:39 --> Helper loaded: cookie_helper
INFO - 2018-10-27 03:39:39 --> Helper loaded: language_helper
DEBUG - 2018-10-27 03:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 03:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 03:39:39 --> Helper loaded: date_helper
INFO - 2018-10-27 03:39:39 --> Database Driver Class Initialized
INFO - 2018-10-27 03:39:39 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 03:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 03:39:39 --> Controller Class Initialized
INFO - 2018-10-27 03:39:39 --> Model "Nota_model" initialized
INFO - 2018-10-27 03:39:39 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 03:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-27 03:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-27 03:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-27 03:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-27 03:39:39 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-27 03:39:39 --> Final output sent to browser
DEBUG - 2018-10-27 03:39:39 --> Total execution time: 0.8519
INFO - 2018-10-27 03:56:30 --> Config Class Initialized
INFO - 2018-10-27 03:56:30 --> Hooks Class Initialized
DEBUG - 2018-10-27 03:56:30 --> UTF-8 Support Enabled
INFO - 2018-10-27 03:56:30 --> Utf8 Class Initialized
INFO - 2018-10-27 03:56:30 --> URI Class Initialized
INFO - 2018-10-27 03:56:30 --> Router Class Initialized
INFO - 2018-10-27 03:56:30 --> Output Class Initialized
INFO - 2018-10-27 03:56:30 --> Security Class Initialized
DEBUG - 2018-10-27 03:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 03:56:30 --> Input Class Initialized
INFO - 2018-10-27 03:56:30 --> Language Class Initialized
INFO - 2018-10-27 03:56:30 --> Loader Class Initialized
INFO - 2018-10-27 03:56:30 --> Helper loaded: url_helper
INFO - 2018-10-27 03:56:30 --> Database Driver Class Initialized
INFO - 2018-10-27 03:56:30 --> Helper loaded: form_helper
INFO - 2018-10-27 03:56:30 --> Form Validation Class Initialized
INFO - 2018-10-27 03:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 03:56:30 --> Pagination Class Initialized
DEBUG - 2018-10-27 03:56:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 03:56:30 --> Email Class Initialized
INFO - 2018-10-27 03:56:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 03:56:30 --> Helper loaded: cookie_helper
INFO - 2018-10-27 03:56:30 --> Helper loaded: language_helper
DEBUG - 2018-10-27 03:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 03:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 03:56:30 --> Helper loaded: date_helper
INFO - 2018-10-27 03:56:30 --> Database Driver Class Initialized
INFO - 2018-10-27 03:56:30 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 03:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 03:56:30 --> Controller Class Initialized
INFO - 2018-10-27 03:56:31 --> Model "Nota_model" initialized
INFO - 2018-10-27 03:56:31 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 03:56:31 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-27 03:56:31 --> Final output sent to browser
DEBUG - 2018-10-27 03:56:31 --> Total execution time: 0.5430
INFO - 2018-10-27 03:56:43 --> Config Class Initialized
INFO - 2018-10-27 03:56:43 --> Hooks Class Initialized
DEBUG - 2018-10-27 03:56:43 --> UTF-8 Support Enabled
INFO - 2018-10-27 03:56:43 --> Utf8 Class Initialized
INFO - 2018-10-27 03:56:43 --> URI Class Initialized
INFO - 2018-10-27 03:56:43 --> Router Class Initialized
INFO - 2018-10-27 03:56:43 --> Output Class Initialized
INFO - 2018-10-27 03:56:43 --> Security Class Initialized
DEBUG - 2018-10-27 03:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 03:56:43 --> Input Class Initialized
INFO - 2018-10-27 03:56:43 --> Language Class Initialized
INFO - 2018-10-27 03:56:43 --> Loader Class Initialized
INFO - 2018-10-27 03:56:43 --> Helper loaded: url_helper
INFO - 2018-10-27 03:56:43 --> Database Driver Class Initialized
INFO - 2018-10-27 03:56:43 --> Helper loaded: form_helper
INFO - 2018-10-27 03:56:43 --> Form Validation Class Initialized
INFO - 2018-10-27 03:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 03:56:43 --> Pagination Class Initialized
DEBUG - 2018-10-27 03:56:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 03:56:43 --> Email Class Initialized
INFO - 2018-10-27 03:56:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 03:56:43 --> Helper loaded: cookie_helper
INFO - 2018-10-27 03:56:43 --> Helper loaded: language_helper
DEBUG - 2018-10-27 03:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 03:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 03:56:43 --> Helper loaded: date_helper
INFO - 2018-10-27 03:56:43 --> Database Driver Class Initialized
INFO - 2018-10-27 03:56:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 03:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 03:56:43 --> Controller Class Initialized
INFO - 2018-10-27 03:56:43 --> Model "Item_model" initialized
INFO - 2018-10-27 03:56:43 --> Model "Jenis_model" initialized
INFO - 2018-10-27 03:56:43 --> Model "Vendor_model" initialized
INFO - 2018-10-27 03:56:43 --> Model "Nota_model" initialized
INFO - 2018-10-27 03:56:43 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 03:56:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 03:56:43 --> Final output sent to browser
DEBUG - 2018-10-27 03:56:43 --> Total execution time: 0.5289
INFO - 2018-10-27 03:56:50 --> Config Class Initialized
INFO - 2018-10-27 03:56:50 --> Hooks Class Initialized
DEBUG - 2018-10-27 03:56:50 --> UTF-8 Support Enabled
INFO - 2018-10-27 03:56:50 --> Utf8 Class Initialized
INFO - 2018-10-27 03:56:50 --> URI Class Initialized
INFO - 2018-10-27 03:56:50 --> Router Class Initialized
INFO - 2018-10-27 03:56:50 --> Output Class Initialized
INFO - 2018-10-27 03:56:50 --> Security Class Initialized
DEBUG - 2018-10-27 03:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 03:56:50 --> Input Class Initialized
INFO - 2018-10-27 03:56:50 --> Language Class Initialized
INFO - 2018-10-27 03:56:50 --> Loader Class Initialized
INFO - 2018-10-27 03:56:50 --> Helper loaded: url_helper
INFO - 2018-10-27 03:56:50 --> Database Driver Class Initialized
INFO - 2018-10-27 03:56:51 --> Helper loaded: form_helper
INFO - 2018-10-27 03:56:51 --> Form Validation Class Initialized
INFO - 2018-10-27 03:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 03:56:51 --> Pagination Class Initialized
DEBUG - 2018-10-27 03:56:51 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 03:56:51 --> Email Class Initialized
INFO - 2018-10-27 03:56:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 03:56:51 --> Helper loaded: cookie_helper
INFO - 2018-10-27 03:56:51 --> Helper loaded: language_helper
DEBUG - 2018-10-27 03:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 03:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 03:56:51 --> Helper loaded: date_helper
INFO - 2018-10-27 03:56:51 --> Database Driver Class Initialized
INFO - 2018-10-27 03:56:51 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 03:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 03:56:51 --> Controller Class Initialized
INFO - 2018-10-27 03:56:51 --> Model "Item_model" initialized
INFO - 2018-10-27 03:56:51 --> Model "Jenis_model" initialized
INFO - 2018-10-27 03:56:51 --> Model "Vendor_model" initialized
INFO - 2018-10-27 03:56:51 --> Model "Nota_model" initialized
INFO - 2018-10-27 03:56:51 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 03:56:51 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 03:56:51 --> Final output sent to browser
DEBUG - 2018-10-27 03:56:51 --> Total execution time: 0.4416
INFO - 2018-10-27 03:56:51 --> Config Class Initialized
INFO - 2018-10-27 03:56:51 --> Hooks Class Initialized
DEBUG - 2018-10-27 03:56:51 --> UTF-8 Support Enabled
INFO - 2018-10-27 03:56:51 --> Utf8 Class Initialized
INFO - 2018-10-27 03:56:51 --> URI Class Initialized
INFO - 2018-10-27 03:56:51 --> Router Class Initialized
INFO - 2018-10-27 03:56:51 --> Output Class Initialized
INFO - 2018-10-27 03:56:51 --> Security Class Initialized
DEBUG - 2018-10-27 03:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 03:56:51 --> Input Class Initialized
INFO - 2018-10-27 03:56:51 --> Language Class Initialized
ERROR - 2018-10-27 03:56:51 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 04:02:08 --> Config Class Initialized
INFO - 2018-10-27 04:02:08 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:02:08 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:02:08 --> Utf8 Class Initialized
INFO - 2018-10-27 04:02:08 --> URI Class Initialized
INFO - 2018-10-27 04:02:08 --> Router Class Initialized
INFO - 2018-10-27 04:02:08 --> Output Class Initialized
INFO - 2018-10-27 04:02:08 --> Security Class Initialized
DEBUG - 2018-10-27 04:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:02:08 --> Input Class Initialized
INFO - 2018-10-27 04:02:08 --> Language Class Initialized
INFO - 2018-10-27 04:02:08 --> Loader Class Initialized
INFO - 2018-10-27 04:02:08 --> Helper loaded: url_helper
INFO - 2018-10-27 04:02:08 --> Database Driver Class Initialized
INFO - 2018-10-27 04:02:08 --> Helper loaded: form_helper
INFO - 2018-10-27 04:02:08 --> Form Validation Class Initialized
INFO - 2018-10-27 04:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:02:09 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:02:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:02:09 --> Email Class Initialized
INFO - 2018-10-27 04:02:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:02:09 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:02:09 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:02:09 --> Helper loaded: date_helper
INFO - 2018-10-27 04:02:09 --> Database Driver Class Initialized
INFO - 2018-10-27 04:02:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:02:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:02:09 --> Controller Class Initialized
INFO - 2018-10-27 04:02:09 --> Model "Item_model" initialized
INFO - 2018-10-27 04:02:09 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:02:09 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:02:09 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:02:09 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:02:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 04:02:09 --> Final output sent to browser
DEBUG - 2018-10-27 04:02:09 --> Total execution time: 0.4330
INFO - 2018-10-27 04:02:09 --> Config Class Initialized
INFO - 2018-10-27 04:02:09 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:02:09 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:02:09 --> Utf8 Class Initialized
INFO - 2018-10-27 04:02:09 --> URI Class Initialized
INFO - 2018-10-27 04:02:09 --> Router Class Initialized
INFO - 2018-10-27 04:02:09 --> Output Class Initialized
INFO - 2018-10-27 04:02:09 --> Security Class Initialized
DEBUG - 2018-10-27 04:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:02:09 --> Input Class Initialized
INFO - 2018-10-27 04:02:09 --> Language Class Initialized
ERROR - 2018-10-27 04:02:09 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 04:02:19 --> Config Class Initialized
INFO - 2018-10-27 04:02:19 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:02:19 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:02:19 --> Utf8 Class Initialized
INFO - 2018-10-27 04:02:19 --> URI Class Initialized
INFO - 2018-10-27 04:02:19 --> Router Class Initialized
INFO - 2018-10-27 04:02:19 --> Output Class Initialized
INFO - 2018-10-27 04:02:19 --> Security Class Initialized
DEBUG - 2018-10-27 04:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:02:19 --> Input Class Initialized
INFO - 2018-10-27 04:02:19 --> Language Class Initialized
INFO - 2018-10-27 04:02:19 --> Loader Class Initialized
INFO - 2018-10-27 04:02:19 --> Helper loaded: url_helper
INFO - 2018-10-27 04:02:19 --> Database Driver Class Initialized
INFO - 2018-10-27 04:02:19 --> Helper loaded: form_helper
INFO - 2018-10-27 04:02:19 --> Form Validation Class Initialized
INFO - 2018-10-27 04:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:02:19 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:02:19 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:02:19 --> Email Class Initialized
INFO - 2018-10-27 04:02:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:02:19 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:02:19 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:02:19 --> Helper loaded: date_helper
INFO - 2018-10-27 04:02:19 --> Database Driver Class Initialized
INFO - 2018-10-27 04:02:19 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:02:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:02:19 --> Controller Class Initialized
INFO - 2018-10-27 04:02:19 --> Model "Item_model" initialized
INFO - 2018-10-27 04:02:19 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:02:19 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:02:19 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:02:19 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:02:19 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 04:02:19 --> Final output sent to browser
DEBUG - 2018-10-27 04:02:19 --> Total execution time: 0.4373
INFO - 2018-10-27 04:09:42 --> Config Class Initialized
INFO - 2018-10-27 04:09:42 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:09:42 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:09:42 --> Utf8 Class Initialized
INFO - 2018-10-27 04:09:42 --> URI Class Initialized
INFO - 2018-10-27 04:09:42 --> Router Class Initialized
INFO - 2018-10-27 04:09:42 --> Output Class Initialized
INFO - 2018-10-27 04:09:42 --> Security Class Initialized
DEBUG - 2018-10-27 04:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:09:42 --> Input Class Initialized
INFO - 2018-10-27 04:09:42 --> Language Class Initialized
INFO - 2018-10-27 04:09:42 --> Loader Class Initialized
INFO - 2018-10-27 04:09:42 --> Helper loaded: url_helper
INFO - 2018-10-27 04:09:42 --> Database Driver Class Initialized
INFO - 2018-10-27 04:09:42 --> Helper loaded: form_helper
INFO - 2018-10-27 04:09:42 --> Form Validation Class Initialized
INFO - 2018-10-27 04:09:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:09:42 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:09:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:09:42 --> Email Class Initialized
INFO - 2018-10-27 04:09:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:09:42 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:09:42 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:09:42 --> Helper loaded: date_helper
INFO - 2018-10-27 04:09:42 --> Database Driver Class Initialized
INFO - 2018-10-27 04:09:42 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:09:42 --> Controller Class Initialized
INFO - 2018-10-27 04:09:42 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:09:42 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 04:09:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-27 04:09:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-27 04:09:42 --> Final output sent to browser
DEBUG - 2018-10-27 04:09:42 --> Total execution time: 0.4076
INFO - 2018-10-27 04:44:53 --> Config Class Initialized
INFO - 2018-10-27 04:44:53 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:44:54 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:44:54 --> Utf8 Class Initialized
INFO - 2018-10-27 04:44:54 --> URI Class Initialized
DEBUG - 2018-10-27 04:44:54 --> No URI present. Default controller set.
INFO - 2018-10-27 04:44:54 --> Router Class Initialized
INFO - 2018-10-27 04:44:54 --> Output Class Initialized
INFO - 2018-10-27 04:44:54 --> Security Class Initialized
DEBUG - 2018-10-27 04:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:44:54 --> Input Class Initialized
INFO - 2018-10-27 04:44:54 --> Language Class Initialized
INFO - 2018-10-27 04:44:54 --> Loader Class Initialized
INFO - 2018-10-27 04:44:54 --> Helper loaded: url_helper
INFO - 2018-10-27 04:44:54 --> Database Driver Class Initialized
INFO - 2018-10-27 04:44:54 --> Helper loaded: form_helper
INFO - 2018-10-27 04:44:54 --> Form Validation Class Initialized
INFO - 2018-10-27 04:44:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:44:54 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:44:54 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:44:54 --> Email Class Initialized
INFO - 2018-10-27 04:44:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:44:54 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:44:54 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:44:54 --> Helper loaded: date_helper
INFO - 2018-10-27 04:44:54 --> Database Driver Class Initialized
INFO - 2018-10-27 04:44:54 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:44:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:44:54 --> Controller Class Initialized
INFO - 2018-10-27 04:44:54 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-27 04:44:54 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\index.php
INFO - 2018-10-27 04:44:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-10-27 04:44:54 --> Final output sent to browser
DEBUG - 2018-10-27 04:44:54 --> Total execution time: 1.0294
INFO - 2018-10-27 04:44:54 --> Config Class Initialized
INFO - 2018-10-27 04:44:54 --> Config Class Initialized
INFO - 2018-10-27 04:44:55 --> Hooks Class Initialized
INFO - 2018-10-27 04:44:55 --> Hooks Class Initialized
INFO - 2018-10-27 04:44:55 --> Config Class Initialized
INFO - 2018-10-27 04:44:55 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:44:55 --> UTF-8 Support Enabled
DEBUG - 2018-10-27 04:44:55 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:44:55 --> Utf8 Class Initialized
INFO - 2018-10-27 04:44:55 --> Utf8 Class Initialized
DEBUG - 2018-10-27 04:44:55 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:44:55 --> Utf8 Class Initialized
INFO - 2018-10-27 04:44:55 --> URI Class Initialized
INFO - 2018-10-27 04:44:55 --> URI Class Initialized
INFO - 2018-10-27 04:44:55 --> URI Class Initialized
INFO - 2018-10-27 04:44:55 --> Router Class Initialized
INFO - 2018-10-27 04:44:55 --> Router Class Initialized
INFO - 2018-10-27 04:44:55 --> Router Class Initialized
INFO - 2018-10-27 04:44:55 --> Output Class Initialized
INFO - 2018-10-27 04:44:55 --> Output Class Initialized
INFO - 2018-10-27 04:44:55 --> Security Class Initialized
INFO - 2018-10-27 04:44:55 --> Security Class Initialized
INFO - 2018-10-27 04:44:55 --> Output Class Initialized
DEBUG - 2018-10-27 04:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-27 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:44:55 --> Security Class Initialized
INFO - 2018-10-27 04:44:55 --> Input Class Initialized
INFO - 2018-10-27 04:44:55 --> Input Class Initialized
DEBUG - 2018-10-27 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:44:55 --> Input Class Initialized
INFO - 2018-10-27 04:44:55 --> Language Class Initialized
INFO - 2018-10-27 04:44:55 --> Language Class Initialized
INFO - 2018-10-27 04:44:55 --> Language Class Initialized
ERROR - 2018-10-27 04:44:55 --> 404 Page Not Found: Application/views
ERROR - 2018-10-27 04:44:55 --> 404 Page Not Found: Application/views
ERROR - 2018-10-27 04:44:55 --> 404 Page Not Found: Application/views
INFO - 2018-10-27 04:44:58 --> Config Class Initialized
INFO - 2018-10-27 04:44:58 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:44:58 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:44:58 --> Utf8 Class Initialized
INFO - 2018-10-27 04:44:58 --> URI Class Initialized
INFO - 2018-10-27 04:44:58 --> Router Class Initialized
INFO - 2018-10-27 04:44:58 --> Output Class Initialized
INFO - 2018-10-27 04:44:58 --> Security Class Initialized
DEBUG - 2018-10-27 04:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:44:58 --> Input Class Initialized
INFO - 2018-10-27 04:44:58 --> Language Class Initialized
INFO - 2018-10-27 04:44:58 --> Loader Class Initialized
INFO - 2018-10-27 04:44:58 --> Helper loaded: url_helper
INFO - 2018-10-27 04:44:58 --> Database Driver Class Initialized
INFO - 2018-10-27 04:44:58 --> Helper loaded: form_helper
INFO - 2018-10-27 04:44:58 --> Form Validation Class Initialized
INFO - 2018-10-27 04:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:44:58 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:44:58 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:44:58 --> Email Class Initialized
INFO - 2018-10-27 04:44:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:44:58 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:44:58 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:44:58 --> Helper loaded: date_helper
INFO - 2018-10-27 04:44:58 --> Database Driver Class Initialized
INFO - 2018-10-27 04:44:58 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:44:58 --> Controller Class Initialized
INFO - 2018-10-27 04:44:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-27 04:44:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\login.php
INFO - 2018-10-27 04:44:58 --> Final output sent to browser
DEBUG - 2018-10-27 04:44:58 --> Total execution time: 0.3949
INFO - 2018-10-27 04:44:58 --> Config Class Initialized
INFO - 2018-10-27 04:44:58 --> Config Class Initialized
INFO - 2018-10-27 04:44:58 --> Config Class Initialized
INFO - 2018-10-27 04:44:58 --> Hooks Class Initialized
INFO - 2018-10-27 04:44:58 --> Hooks Class Initialized
INFO - 2018-10-27 04:44:58 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:44:58 --> UTF-8 Support Enabled
DEBUG - 2018-10-27 04:44:58 --> UTF-8 Support Enabled
DEBUG - 2018-10-27 04:44:58 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:44:58 --> Utf8 Class Initialized
INFO - 2018-10-27 04:44:58 --> Utf8 Class Initialized
INFO - 2018-10-27 04:44:58 --> Utf8 Class Initialized
INFO - 2018-10-27 04:44:58 --> URI Class Initialized
INFO - 2018-10-27 04:44:58 --> URI Class Initialized
INFO - 2018-10-27 04:44:58 --> URI Class Initialized
INFO - 2018-10-27 04:44:58 --> Router Class Initialized
INFO - 2018-10-27 04:44:58 --> Router Class Initialized
INFO - 2018-10-27 04:44:58 --> Router Class Initialized
INFO - 2018-10-27 04:44:58 --> Output Class Initialized
INFO - 2018-10-27 04:44:58 --> Output Class Initialized
INFO - 2018-10-27 04:44:58 --> Output Class Initialized
INFO - 2018-10-27 04:44:59 --> Security Class Initialized
INFO - 2018-10-27 04:44:59 --> Security Class Initialized
INFO - 2018-10-27 04:44:59 --> Security Class Initialized
DEBUG - 2018-10-27 04:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-27 04:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-27 04:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:44:59 --> Input Class Initialized
INFO - 2018-10-27 04:44:59 --> Input Class Initialized
INFO - 2018-10-27 04:44:59 --> Input Class Initialized
INFO - 2018-10-27 04:44:59 --> Language Class Initialized
INFO - 2018-10-27 04:44:59 --> Language Class Initialized
INFO - 2018-10-27 04:44:59 --> Language Class Initialized
ERROR - 2018-10-27 04:44:59 --> 404 Page Not Found: Application/views
ERROR - 2018-10-27 04:44:59 --> 404 Page Not Found: Application/views
ERROR - 2018-10-27 04:44:59 --> 404 Page Not Found: Application/views
INFO - 2018-10-27 04:45:04 --> Config Class Initialized
INFO - 2018-10-27 04:45:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:45:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:45:04 --> Utf8 Class Initialized
INFO - 2018-10-27 04:45:04 --> URI Class Initialized
INFO - 2018-10-27 04:45:04 --> Router Class Initialized
INFO - 2018-10-27 04:45:04 --> Output Class Initialized
INFO - 2018-10-27 04:45:04 --> Security Class Initialized
DEBUG - 2018-10-27 04:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:45:04 --> Input Class Initialized
INFO - 2018-10-27 04:45:04 --> Language Class Initialized
INFO - 2018-10-27 04:45:04 --> Loader Class Initialized
INFO - 2018-10-27 04:45:04 --> Helper loaded: url_helper
INFO - 2018-10-27 04:45:04 --> Database Driver Class Initialized
INFO - 2018-10-27 04:45:04 --> Helper loaded: form_helper
INFO - 2018-10-27 04:45:05 --> Form Validation Class Initialized
INFO - 2018-10-27 04:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:45:05 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:45:05 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:45:05 --> Email Class Initialized
INFO - 2018-10-27 04:45:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:45:05 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:45:05 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:45:05 --> Helper loaded: date_helper
INFO - 2018-10-27 04:45:05 --> Database Driver Class Initialized
INFO - 2018-10-27 04:45:05 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:45:05 --> Controller Class Initialized
INFO - 2018-10-27 04:45:05 --> Config Class Initialized
INFO - 2018-10-27 04:45:05 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:45:05 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:45:05 --> Utf8 Class Initialized
INFO - 2018-10-27 04:45:05 --> URI Class Initialized
INFO - 2018-10-27 04:45:05 --> Router Class Initialized
INFO - 2018-10-27 04:45:05 --> Output Class Initialized
INFO - 2018-10-27 04:45:05 --> Security Class Initialized
DEBUG - 2018-10-27 04:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:45:05 --> Input Class Initialized
INFO - 2018-10-27 04:45:05 --> Language Class Initialized
INFO - 2018-10-27 04:45:05 --> Loader Class Initialized
INFO - 2018-10-27 04:45:05 --> Helper loaded: url_helper
INFO - 2018-10-27 04:45:05 --> Database Driver Class Initialized
INFO - 2018-10-27 04:45:05 --> Helper loaded: form_helper
INFO - 2018-10-27 04:45:05 --> Form Validation Class Initialized
INFO - 2018-10-27 04:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:45:05 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:45:05 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:45:05 --> Email Class Initialized
INFO - 2018-10-27 04:45:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:45:05 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:45:05 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:45:05 --> Helper loaded: date_helper
INFO - 2018-10-27 04:45:05 --> Database Driver Class Initialized
INFO - 2018-10-27 04:45:05 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:45:05 --> Controller Class Initialized
INFO - 2018-10-27 04:45:05 --> Model "Item_model" initialized
INFO - 2018-10-27 04:45:05 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:45:05 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:45:05 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:45:05 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:45:05 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 04:45:05 --> Final output sent to browser
DEBUG - 2018-10-27 04:45:05 --> Total execution time: 0.5348
INFO - 2018-10-27 04:45:06 --> Config Class Initialized
INFO - 2018-10-27 04:45:06 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:45:06 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:45:06 --> Utf8 Class Initialized
INFO - 2018-10-27 04:45:06 --> URI Class Initialized
INFO - 2018-10-27 04:45:06 --> Router Class Initialized
INFO - 2018-10-27 04:45:06 --> Output Class Initialized
INFO - 2018-10-27 04:45:06 --> Security Class Initialized
DEBUG - 2018-10-27 04:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:45:06 --> Input Class Initialized
INFO - 2018-10-27 04:45:06 --> Language Class Initialized
ERROR - 2018-10-27 04:45:06 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-27 04:45:08 --> Config Class Initialized
INFO - 2018-10-27 04:45:08 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:45:08 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:45:08 --> Utf8 Class Initialized
INFO - 2018-10-27 04:45:08 --> URI Class Initialized
INFO - 2018-10-27 04:45:08 --> Router Class Initialized
INFO - 2018-10-27 04:45:08 --> Output Class Initialized
INFO - 2018-10-27 04:45:08 --> Security Class Initialized
DEBUG - 2018-10-27 04:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:45:08 --> Input Class Initialized
INFO - 2018-10-27 04:45:08 --> Language Class Initialized
INFO - 2018-10-27 04:45:08 --> Loader Class Initialized
INFO - 2018-10-27 04:45:08 --> Helper loaded: url_helper
INFO - 2018-10-27 04:45:08 --> Database Driver Class Initialized
INFO - 2018-10-27 04:45:08 --> Helper loaded: form_helper
INFO - 2018-10-27 04:45:08 --> Form Validation Class Initialized
INFO - 2018-10-27 04:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:45:08 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:45:08 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:45:08 --> Email Class Initialized
INFO - 2018-10-27 04:45:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:45:08 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:45:08 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:45:08 --> Helper loaded: date_helper
INFO - 2018-10-27 04:45:08 --> Database Driver Class Initialized
INFO - 2018-10-27 04:45:08 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:45:08 --> Controller Class Initialized
INFO - 2018-10-27 04:45:08 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:45:08 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 04:45:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-27 04:45:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-27 04:45:09 --> Final output sent to browser
DEBUG - 2018-10-27 04:45:09 --> Total execution time: 0.4850
INFO - 2018-10-27 04:47:13 --> Config Class Initialized
INFO - 2018-10-27 04:47:13 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:47:13 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:47:13 --> Utf8 Class Initialized
INFO - 2018-10-27 04:47:13 --> URI Class Initialized
INFO - 2018-10-27 04:47:13 --> Router Class Initialized
INFO - 2018-10-27 04:47:13 --> Output Class Initialized
INFO - 2018-10-27 04:47:13 --> Security Class Initialized
DEBUG - 2018-10-27 04:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:47:13 --> Input Class Initialized
INFO - 2018-10-27 04:47:13 --> Language Class Initialized
INFO - 2018-10-27 04:47:13 --> Loader Class Initialized
INFO - 2018-10-27 04:47:13 --> Helper loaded: url_helper
INFO - 2018-10-27 04:47:13 --> Database Driver Class Initialized
INFO - 2018-10-27 04:47:13 --> Helper loaded: form_helper
INFO - 2018-10-27 04:47:13 --> Form Validation Class Initialized
INFO - 2018-10-27 04:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:47:13 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:47:13 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:47:13 --> Email Class Initialized
INFO - 2018-10-27 04:47:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:47:13 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:47:13 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:47:13 --> Helper loaded: date_helper
INFO - 2018-10-27 04:47:13 --> Database Driver Class Initialized
INFO - 2018-10-27 04:47:13 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:47:13 --> Controller Class Initialized
INFO - 2018-10-27 04:47:13 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:47:13 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:47:13 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-27 04:47:13 --> Final output sent to browser
DEBUG - 2018-10-27 04:47:13 --> Total execution time: 0.3770
INFO - 2018-10-27 04:48:26 --> Config Class Initialized
INFO - 2018-10-27 04:48:26 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:48:26 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:48:26 --> Utf8 Class Initialized
INFO - 2018-10-27 04:48:26 --> URI Class Initialized
INFO - 2018-10-27 04:48:26 --> Router Class Initialized
INFO - 2018-10-27 04:48:26 --> Output Class Initialized
INFO - 2018-10-27 04:48:26 --> Security Class Initialized
DEBUG - 2018-10-27 04:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:48:26 --> Input Class Initialized
INFO - 2018-10-27 04:48:26 --> Language Class Initialized
INFO - 2018-10-27 04:48:26 --> Loader Class Initialized
INFO - 2018-10-27 04:48:26 --> Helper loaded: url_helper
INFO - 2018-10-27 04:48:26 --> Database Driver Class Initialized
INFO - 2018-10-27 04:48:26 --> Helper loaded: form_helper
INFO - 2018-10-27 04:48:26 --> Form Validation Class Initialized
INFO - 2018-10-27 04:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:48:26 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:48:26 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:48:26 --> Email Class Initialized
INFO - 2018-10-27 04:48:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:48:26 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:48:26 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:48:26 --> Helper loaded: date_helper
INFO - 2018-10-27 04:48:26 --> Database Driver Class Initialized
INFO - 2018-10-27 04:48:26 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:48:26 --> Controller Class Initialized
INFO - 2018-10-27 04:48:26 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:48:26 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:48:26 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-27 04:48:26 --> Final output sent to browser
DEBUG - 2018-10-27 04:48:26 --> Total execution time: 0.3617
INFO - 2018-10-27 04:48:28 --> Config Class Initialized
INFO - 2018-10-27 04:48:28 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:48:28 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:48:28 --> Utf8 Class Initialized
INFO - 2018-10-27 04:48:28 --> URI Class Initialized
INFO - 2018-10-27 04:48:28 --> Router Class Initialized
INFO - 2018-10-27 04:48:28 --> Output Class Initialized
INFO - 2018-10-27 04:48:28 --> Security Class Initialized
DEBUG - 2018-10-27 04:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:48:28 --> Input Class Initialized
INFO - 2018-10-27 04:48:28 --> Language Class Initialized
INFO - 2018-10-27 04:48:28 --> Loader Class Initialized
INFO - 2018-10-27 04:48:28 --> Helper loaded: url_helper
INFO - 2018-10-27 04:48:28 --> Database Driver Class Initialized
INFO - 2018-10-27 04:48:28 --> Helper loaded: form_helper
INFO - 2018-10-27 04:48:28 --> Form Validation Class Initialized
INFO - 2018-10-27 04:48:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:48:28 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:48:28 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:48:28 --> Email Class Initialized
INFO - 2018-10-27 04:48:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:48:28 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:48:28 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:48:28 --> Helper loaded: date_helper
INFO - 2018-10-27 04:48:28 --> Database Driver Class Initialized
INFO - 2018-10-27 04:48:28 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:48:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:48:28 --> Controller Class Initialized
INFO - 2018-10-27 04:48:28 --> Model "Item_model" initialized
INFO - 2018-10-27 04:48:28 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:48:28 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:48:28 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:48:28 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:48:28 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 04:48:28 --> Final output sent to browser
DEBUG - 2018-10-27 04:48:28 --> Total execution time: 0.4261
INFO - 2018-10-27 04:48:40 --> Config Class Initialized
INFO - 2018-10-27 04:48:40 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:48:40 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:48:40 --> Utf8 Class Initialized
INFO - 2018-10-27 04:48:40 --> URI Class Initialized
INFO - 2018-10-27 04:48:40 --> Router Class Initialized
INFO - 2018-10-27 04:48:40 --> Output Class Initialized
INFO - 2018-10-27 04:48:40 --> Security Class Initialized
DEBUG - 2018-10-27 04:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:48:40 --> Input Class Initialized
INFO - 2018-10-27 04:48:40 --> Language Class Initialized
INFO - 2018-10-27 04:48:40 --> Loader Class Initialized
INFO - 2018-10-27 04:48:40 --> Helper loaded: url_helper
INFO - 2018-10-27 04:48:40 --> Database Driver Class Initialized
INFO - 2018-10-27 04:48:40 --> Helper loaded: form_helper
INFO - 2018-10-27 04:48:40 --> Form Validation Class Initialized
INFO - 2018-10-27 04:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:48:40 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:48:40 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:48:40 --> Email Class Initialized
INFO - 2018-10-27 04:48:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:48:40 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:48:40 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:48:40 --> Helper loaded: date_helper
INFO - 2018-10-27 04:48:40 --> Database Driver Class Initialized
INFO - 2018-10-27 04:48:40 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:48:40 --> Controller Class Initialized
INFO - 2018-10-27 04:48:40 --> Model "Item_model" initialized
INFO - 2018-10-27 04:48:40 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:48:40 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:48:40 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:48:40 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 04:48:40 --> Severity: Notice --> Undefined variable: no_nota D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 68
INFO - 2018-10-27 04:48:40 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 04:48:40 --> Final output sent to browser
DEBUG - 2018-10-27 04:48:40 --> Total execution time: 0.4150
INFO - 2018-10-27 04:48:40 --> Config Class Initialized
INFO - 2018-10-27 04:48:40 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:48:40 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:48:40 --> Utf8 Class Initialized
INFO - 2018-10-27 04:48:40 --> URI Class Initialized
INFO - 2018-10-27 04:48:40 --> Router Class Initialized
INFO - 2018-10-27 04:48:41 --> Output Class Initialized
INFO - 2018-10-27 04:48:41 --> Security Class Initialized
DEBUG - 2018-10-27 04:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:48:41 --> Input Class Initialized
INFO - 2018-10-27 04:48:41 --> Language Class Initialized
ERROR - 2018-10-27 04:48:41 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 04:50:02 --> Config Class Initialized
INFO - 2018-10-27 04:50:02 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:50:02 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:50:02 --> Utf8 Class Initialized
INFO - 2018-10-27 04:50:02 --> URI Class Initialized
INFO - 2018-10-27 04:50:02 --> Router Class Initialized
INFO - 2018-10-27 04:50:02 --> Output Class Initialized
INFO - 2018-10-27 04:50:02 --> Security Class Initialized
DEBUG - 2018-10-27 04:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:50:02 --> Input Class Initialized
INFO - 2018-10-27 04:50:02 --> Language Class Initialized
INFO - 2018-10-27 04:50:02 --> Loader Class Initialized
INFO - 2018-10-27 04:50:02 --> Helper loaded: url_helper
INFO - 2018-10-27 04:50:02 --> Database Driver Class Initialized
INFO - 2018-10-27 04:50:02 --> Helper loaded: form_helper
INFO - 2018-10-27 04:50:02 --> Form Validation Class Initialized
INFO - 2018-10-27 04:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:50:02 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:50:02 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:50:02 --> Email Class Initialized
INFO - 2018-10-27 04:50:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:50:02 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:50:02 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:50:02 --> Helper loaded: date_helper
INFO - 2018-10-27 04:50:02 --> Database Driver Class Initialized
INFO - 2018-10-27 04:50:02 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:50:02 --> Controller Class Initialized
INFO - 2018-10-27 04:50:02 --> Model "Item_model" initialized
INFO - 2018-10-27 04:50:02 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:50:02 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:50:02 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:50:02 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:50:02 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 04:50:02 --> Final output sent to browser
DEBUG - 2018-10-27 04:50:02 --> Total execution time: 0.3928
INFO - 2018-10-27 04:50:07 --> Config Class Initialized
INFO - 2018-10-27 04:50:07 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:50:07 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:50:07 --> Utf8 Class Initialized
INFO - 2018-10-27 04:50:07 --> URI Class Initialized
INFO - 2018-10-27 04:50:07 --> Router Class Initialized
INFO - 2018-10-27 04:50:07 --> Output Class Initialized
INFO - 2018-10-27 04:50:07 --> Security Class Initialized
DEBUG - 2018-10-27 04:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:50:07 --> Input Class Initialized
INFO - 2018-10-27 04:50:07 --> Language Class Initialized
INFO - 2018-10-27 04:50:07 --> Loader Class Initialized
INFO - 2018-10-27 04:50:07 --> Helper loaded: url_helper
INFO - 2018-10-27 04:50:07 --> Database Driver Class Initialized
INFO - 2018-10-27 04:50:07 --> Helper loaded: form_helper
INFO - 2018-10-27 04:50:07 --> Form Validation Class Initialized
INFO - 2018-10-27 04:50:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:50:07 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:50:07 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:50:07 --> Email Class Initialized
INFO - 2018-10-27 04:50:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:50:07 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:50:07 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:50:07 --> Helper loaded: date_helper
INFO - 2018-10-27 04:50:07 --> Database Driver Class Initialized
INFO - 2018-10-27 04:50:07 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:50:07 --> Controller Class Initialized
INFO - 2018-10-27 04:50:07 --> Model "Item_model" initialized
INFO - 2018-10-27 04:50:07 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:50:07 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:50:07 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:50:07 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 04:50:07 --> Severity: error --> Exception: syntax error, unexpected '?>' D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 68
INFO - 2018-10-27 04:50:35 --> Config Class Initialized
INFO - 2018-10-27 04:50:35 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:50:35 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:50:35 --> Utf8 Class Initialized
INFO - 2018-10-27 04:50:36 --> URI Class Initialized
INFO - 2018-10-27 04:50:36 --> Router Class Initialized
INFO - 2018-10-27 04:50:36 --> Output Class Initialized
INFO - 2018-10-27 04:50:36 --> Security Class Initialized
DEBUG - 2018-10-27 04:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:50:36 --> Input Class Initialized
INFO - 2018-10-27 04:50:36 --> Language Class Initialized
INFO - 2018-10-27 04:50:36 --> Loader Class Initialized
INFO - 2018-10-27 04:50:36 --> Helper loaded: url_helper
INFO - 2018-10-27 04:50:36 --> Database Driver Class Initialized
INFO - 2018-10-27 04:50:36 --> Helper loaded: form_helper
INFO - 2018-10-27 04:50:36 --> Form Validation Class Initialized
INFO - 2018-10-27 04:50:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:50:36 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:50:36 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:50:36 --> Email Class Initialized
INFO - 2018-10-27 04:50:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:50:36 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:50:36 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:50:36 --> Helper loaded: date_helper
INFO - 2018-10-27 04:50:36 --> Database Driver Class Initialized
INFO - 2018-10-27 04:50:36 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:50:36 --> Controller Class Initialized
INFO - 2018-10-27 04:50:36 --> Model "Item_model" initialized
INFO - 2018-10-27 04:50:36 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:50:36 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:50:36 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:50:36 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:50:36 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 04:50:36 --> Final output sent to browser
DEBUG - 2018-10-27 04:50:36 --> Total execution time: 0.4212
INFO - 2018-10-27 04:50:39 --> Config Class Initialized
INFO - 2018-10-27 04:50:39 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:50:39 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:50:39 --> Utf8 Class Initialized
INFO - 2018-10-27 04:50:39 --> URI Class Initialized
INFO - 2018-10-27 04:50:39 --> Router Class Initialized
INFO - 2018-10-27 04:50:39 --> Output Class Initialized
INFO - 2018-10-27 04:50:39 --> Security Class Initialized
DEBUG - 2018-10-27 04:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:50:39 --> Input Class Initialized
INFO - 2018-10-27 04:50:39 --> Language Class Initialized
INFO - 2018-10-27 04:50:39 --> Loader Class Initialized
INFO - 2018-10-27 04:50:39 --> Helper loaded: url_helper
INFO - 2018-10-27 04:50:39 --> Database Driver Class Initialized
INFO - 2018-10-27 04:50:39 --> Helper loaded: form_helper
INFO - 2018-10-27 04:50:39 --> Form Validation Class Initialized
INFO - 2018-10-27 04:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:50:39 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:50:39 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:50:39 --> Email Class Initialized
INFO - 2018-10-27 04:50:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:50:39 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:50:39 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:50:39 --> Helper loaded: date_helper
INFO - 2018-10-27 04:50:39 --> Database Driver Class Initialized
INFO - 2018-10-27 04:50:39 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:50:39 --> Controller Class Initialized
INFO - 2018-10-27 04:50:39 --> Model "Item_model" initialized
INFO - 2018-10-27 04:50:39 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:50:39 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:50:40 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:50:40 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:50:40 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 04:50:40 --> Final output sent to browser
DEBUG - 2018-10-27 04:50:40 --> Total execution time: 0.3898
INFO - 2018-10-27 04:50:40 --> Config Class Initialized
INFO - 2018-10-27 04:50:40 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:50:40 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:50:40 --> Utf8 Class Initialized
INFO - 2018-10-27 04:50:40 --> URI Class Initialized
INFO - 2018-10-27 04:50:40 --> Router Class Initialized
INFO - 2018-10-27 04:50:40 --> Output Class Initialized
INFO - 2018-10-27 04:50:40 --> Security Class Initialized
DEBUG - 2018-10-27 04:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:50:40 --> Input Class Initialized
INFO - 2018-10-27 04:50:40 --> Language Class Initialized
ERROR - 2018-10-27 04:50:40 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 04:52:51 --> Config Class Initialized
INFO - 2018-10-27 04:52:51 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:52:51 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:52:51 --> Utf8 Class Initialized
INFO - 2018-10-27 04:52:51 --> URI Class Initialized
INFO - 2018-10-27 04:52:51 --> Router Class Initialized
INFO - 2018-10-27 04:52:51 --> Output Class Initialized
INFO - 2018-10-27 04:52:51 --> Security Class Initialized
DEBUG - 2018-10-27 04:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:52:51 --> Input Class Initialized
INFO - 2018-10-27 04:52:51 --> Language Class Initialized
INFO - 2018-10-27 04:52:51 --> Loader Class Initialized
INFO - 2018-10-27 04:52:51 --> Helper loaded: url_helper
INFO - 2018-10-27 04:52:51 --> Database Driver Class Initialized
INFO - 2018-10-27 04:52:51 --> Helper loaded: form_helper
INFO - 2018-10-27 04:52:51 --> Form Validation Class Initialized
INFO - 2018-10-27 04:52:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:52:51 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:52:51 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:52:51 --> Email Class Initialized
INFO - 2018-10-27 04:52:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:52:51 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:52:51 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:52:51 --> Helper loaded: date_helper
INFO - 2018-10-27 04:52:51 --> Database Driver Class Initialized
INFO - 2018-10-27 04:52:51 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:52:51 --> Controller Class Initialized
INFO - 2018-10-27 04:52:51 --> Model "Item_model" initialized
INFO - 2018-10-27 04:52:51 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:52:51 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:52:51 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:52:51 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 04:52:51 --> Severity: Notice --> Undefined property: Item::$upload D:\xampp\htdocs\masterwedding\application\controllers\Item.php 134
ERROR - 2018-10-27 04:52:51 --> Severity: error --> Exception: Call to a member function display_errors() on null D:\xampp\htdocs\masterwedding\application\controllers\Item.php 134
INFO - 2018-10-27 04:54:22 --> Config Class Initialized
INFO - 2018-10-27 04:54:22 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:54:22 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:54:22 --> Utf8 Class Initialized
INFO - 2018-10-27 04:54:22 --> URI Class Initialized
INFO - 2018-10-27 04:54:22 --> Router Class Initialized
INFO - 2018-10-27 04:54:22 --> Output Class Initialized
INFO - 2018-10-27 04:54:22 --> Security Class Initialized
DEBUG - 2018-10-27 04:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:54:22 --> Input Class Initialized
INFO - 2018-10-27 04:54:22 --> Language Class Initialized
INFO - 2018-10-27 04:54:22 --> Loader Class Initialized
INFO - 2018-10-27 04:54:22 --> Helper loaded: url_helper
INFO - 2018-10-27 04:54:22 --> Database Driver Class Initialized
INFO - 2018-10-27 04:54:22 --> Helper loaded: form_helper
INFO - 2018-10-27 04:54:22 --> Form Validation Class Initialized
INFO - 2018-10-27 04:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:54:22 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:54:22 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:54:22 --> Email Class Initialized
INFO - 2018-10-27 04:54:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:54:22 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:54:22 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:54:22 --> Helper loaded: date_helper
INFO - 2018-10-27 04:54:22 --> Database Driver Class Initialized
INFO - 2018-10-27 04:54:22 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:54:22 --> Controller Class Initialized
INFO - 2018-10-27 04:54:22 --> Model "Item_model" initialized
INFO - 2018-10-27 04:54:22 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:54:22 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:54:22 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:54:22 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:54:22 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 04:54:23 --> Final output sent to browser
DEBUG - 2018-10-27 04:54:23 --> Total execution time: 0.4356
INFO - 2018-10-27 04:54:26 --> Config Class Initialized
INFO - 2018-10-27 04:54:26 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:54:26 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:54:26 --> Utf8 Class Initialized
INFO - 2018-10-27 04:54:26 --> URI Class Initialized
INFO - 2018-10-27 04:54:26 --> Router Class Initialized
INFO - 2018-10-27 04:54:26 --> Output Class Initialized
INFO - 2018-10-27 04:54:26 --> Security Class Initialized
DEBUG - 2018-10-27 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:54:26 --> Input Class Initialized
INFO - 2018-10-27 04:54:26 --> Language Class Initialized
INFO - 2018-10-27 04:54:26 --> Loader Class Initialized
INFO - 2018-10-27 04:54:26 --> Helper loaded: url_helper
INFO - 2018-10-27 04:54:26 --> Database Driver Class Initialized
INFO - 2018-10-27 04:54:26 --> Helper loaded: form_helper
INFO - 2018-10-27 04:54:26 --> Form Validation Class Initialized
INFO - 2018-10-27 04:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:54:26 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:54:26 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:54:26 --> Email Class Initialized
INFO - 2018-10-27 04:54:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:54:26 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:54:26 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:54:26 --> Helper loaded: date_helper
INFO - 2018-10-27 04:54:26 --> Database Driver Class Initialized
INFO - 2018-10-27 04:54:26 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:54:26 --> Controller Class Initialized
INFO - 2018-10-27 04:54:26 --> Model "Item_model" initialized
INFO - 2018-10-27 04:54:26 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:54:26 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:54:26 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:54:26 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:54:26 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 04:54:26 --> Final output sent to browser
DEBUG - 2018-10-27 04:54:26 --> Total execution time: 0.4038
INFO - 2018-10-27 04:54:26 --> Config Class Initialized
INFO - 2018-10-27 04:54:26 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:54:26 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:54:26 --> Utf8 Class Initialized
INFO - 2018-10-27 04:54:26 --> URI Class Initialized
INFO - 2018-10-27 04:54:26 --> Router Class Initialized
INFO - 2018-10-27 04:54:26 --> Output Class Initialized
INFO - 2018-10-27 04:54:26 --> Security Class Initialized
DEBUG - 2018-10-27 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:54:26 --> Input Class Initialized
INFO - 2018-10-27 04:54:26 --> Language Class Initialized
ERROR - 2018-10-27 04:54:26 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 04:54:29 --> Config Class Initialized
INFO - 2018-10-27 04:54:29 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:54:29 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:54:29 --> Utf8 Class Initialized
INFO - 2018-10-27 04:54:29 --> URI Class Initialized
INFO - 2018-10-27 04:54:29 --> Router Class Initialized
INFO - 2018-10-27 04:54:29 --> Output Class Initialized
INFO - 2018-10-27 04:54:29 --> Security Class Initialized
DEBUG - 2018-10-27 04:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:54:29 --> Input Class Initialized
INFO - 2018-10-27 04:54:29 --> Language Class Initialized
INFO - 2018-10-27 04:54:29 --> Loader Class Initialized
INFO - 2018-10-27 04:54:29 --> Helper loaded: url_helper
INFO - 2018-10-27 04:54:29 --> Database Driver Class Initialized
INFO - 2018-10-27 04:54:29 --> Helper loaded: form_helper
INFO - 2018-10-27 04:54:29 --> Form Validation Class Initialized
INFO - 2018-10-27 04:54:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:54:29 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:54:29 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:54:29 --> Email Class Initialized
INFO - 2018-10-27 04:54:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:54:29 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:54:29 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:54:29 --> Helper loaded: date_helper
INFO - 2018-10-27 04:54:29 --> Database Driver Class Initialized
INFO - 2018-10-27 04:54:29 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:54:29 --> Controller Class Initialized
INFO - 2018-10-27 04:54:29 --> Model "Item_model" initialized
INFO - 2018-10-27 04:54:29 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:54:29 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:54:29 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:54:29 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 04:54:29 --> Severity: error --> Exception: Call to undefined method Nota_model::display_errors() D:\xampp\htdocs\masterwedding\application\controllers\Item.php 134
INFO - 2018-10-27 04:55:04 --> Config Class Initialized
INFO - 2018-10-27 04:55:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:55:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:55:04 --> Utf8 Class Initialized
INFO - 2018-10-27 04:55:04 --> URI Class Initialized
INFO - 2018-10-27 04:55:04 --> Router Class Initialized
INFO - 2018-10-27 04:55:04 --> Output Class Initialized
INFO - 2018-10-27 04:55:04 --> Security Class Initialized
DEBUG - 2018-10-27 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:55:04 --> Input Class Initialized
INFO - 2018-10-27 04:55:04 --> Language Class Initialized
INFO - 2018-10-27 04:55:04 --> Loader Class Initialized
INFO - 2018-10-27 04:55:04 --> Helper loaded: url_helper
INFO - 2018-10-27 04:55:04 --> Database Driver Class Initialized
INFO - 2018-10-27 04:55:04 --> Helper loaded: form_helper
INFO - 2018-10-27 04:55:04 --> Form Validation Class Initialized
INFO - 2018-10-27 04:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:55:04 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:55:04 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:55:04 --> Email Class Initialized
INFO - 2018-10-27 04:55:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:55:04 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:55:04 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:55:04 --> Helper loaded: date_helper
INFO - 2018-10-27 04:55:04 --> Database Driver Class Initialized
INFO - 2018-10-27 04:55:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:55:04 --> Controller Class Initialized
INFO - 2018-10-27 04:55:04 --> Model "Item_model" initialized
INFO - 2018-10-27 04:55:04 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:55:04 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:55:04 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:55:04 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 04:55:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\masterwedding\application\controllers\Item.php 134
ERROR - 2018-10-27 04:55:04 --> Severity: Notice --> Undefined property: Item::$Array D:\xampp\htdocs\masterwedding\application\controllers\Item.php 134
ERROR - 2018-10-27 04:55:04 --> Severity: error --> Exception: Call to a member function display_errors() on null D:\xampp\htdocs\masterwedding\application\controllers\Item.php 134
INFO - 2018-10-27 04:55:09 --> Config Class Initialized
INFO - 2018-10-27 04:55:09 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:55:09 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:55:09 --> Utf8 Class Initialized
INFO - 2018-10-27 04:55:09 --> URI Class Initialized
INFO - 2018-10-27 04:55:09 --> Router Class Initialized
INFO - 2018-10-27 04:55:09 --> Output Class Initialized
INFO - 2018-10-27 04:55:09 --> Security Class Initialized
DEBUG - 2018-10-27 04:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:55:09 --> Input Class Initialized
INFO - 2018-10-27 04:55:09 --> Language Class Initialized
INFO - 2018-10-27 04:55:09 --> Loader Class Initialized
INFO - 2018-10-27 04:55:09 --> Helper loaded: url_helper
INFO - 2018-10-27 04:55:09 --> Database Driver Class Initialized
INFO - 2018-10-27 04:55:09 --> Helper loaded: form_helper
INFO - 2018-10-27 04:55:09 --> Form Validation Class Initialized
INFO - 2018-10-27 04:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:55:09 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:55:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:55:09 --> Email Class Initialized
INFO - 2018-10-27 04:55:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:55:09 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:55:09 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:55:09 --> Helper loaded: date_helper
INFO - 2018-10-27 04:55:09 --> Database Driver Class Initialized
INFO - 2018-10-27 04:55:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:55:09 --> Controller Class Initialized
INFO - 2018-10-27 04:55:09 --> Model "Item_model" initialized
INFO - 2018-10-27 04:55:09 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:55:09 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:55:09 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:55:09 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:55:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 04:55:09 --> Final output sent to browser
DEBUG - 2018-10-27 04:55:09 --> Total execution time: 0.4292
INFO - 2018-10-27 04:55:10 --> Config Class Initialized
INFO - 2018-10-27 04:55:10 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:55:10 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:55:10 --> Utf8 Class Initialized
INFO - 2018-10-27 04:55:10 --> URI Class Initialized
INFO - 2018-10-27 04:55:10 --> Router Class Initialized
INFO - 2018-10-27 04:55:10 --> Output Class Initialized
INFO - 2018-10-27 04:55:10 --> Security Class Initialized
DEBUG - 2018-10-27 04:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:55:10 --> Input Class Initialized
INFO - 2018-10-27 04:55:10 --> Language Class Initialized
INFO - 2018-10-27 04:55:10 --> Loader Class Initialized
INFO - 2018-10-27 04:55:10 --> Helper loaded: url_helper
INFO - 2018-10-27 04:55:10 --> Database Driver Class Initialized
INFO - 2018-10-27 04:55:10 --> Helper loaded: form_helper
INFO - 2018-10-27 04:55:10 --> Form Validation Class Initialized
INFO - 2018-10-27 04:55:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:55:10 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:55:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:55:10 --> Email Class Initialized
INFO - 2018-10-27 04:55:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:55:10 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:55:10 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:55:10 --> Helper loaded: date_helper
INFO - 2018-10-27 04:55:10 --> Database Driver Class Initialized
INFO - 2018-10-27 04:55:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:55:10 --> Controller Class Initialized
INFO - 2018-10-27 04:55:10 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:55:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:55:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-27 04:55:10 --> Final output sent to browser
DEBUG - 2018-10-27 04:55:10 --> Total execution time: 0.3988
INFO - 2018-10-27 04:55:12 --> Config Class Initialized
INFO - 2018-10-27 04:55:12 --> Hooks Class Initialized
DEBUG - 2018-10-27 04:55:12 --> UTF-8 Support Enabled
INFO - 2018-10-27 04:55:12 --> Utf8 Class Initialized
INFO - 2018-10-27 04:55:12 --> URI Class Initialized
INFO - 2018-10-27 04:55:12 --> Router Class Initialized
INFO - 2018-10-27 04:55:12 --> Output Class Initialized
INFO - 2018-10-27 04:55:12 --> Security Class Initialized
DEBUG - 2018-10-27 04:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 04:55:12 --> Input Class Initialized
INFO - 2018-10-27 04:55:12 --> Language Class Initialized
INFO - 2018-10-27 04:55:12 --> Loader Class Initialized
INFO - 2018-10-27 04:55:12 --> Helper loaded: url_helper
INFO - 2018-10-27 04:55:12 --> Database Driver Class Initialized
INFO - 2018-10-27 04:55:12 --> Helper loaded: form_helper
INFO - 2018-10-27 04:55:12 --> Form Validation Class Initialized
INFO - 2018-10-27 04:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 04:55:12 --> Pagination Class Initialized
DEBUG - 2018-10-27 04:55:12 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 04:55:12 --> Email Class Initialized
INFO - 2018-10-27 04:55:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 04:55:12 --> Helper loaded: cookie_helper
INFO - 2018-10-27 04:55:12 --> Helper loaded: language_helper
DEBUG - 2018-10-27 04:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 04:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 04:55:12 --> Helper loaded: date_helper
INFO - 2018-10-27 04:55:12 --> Database Driver Class Initialized
INFO - 2018-10-27 04:55:12 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 04:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 04:55:12 --> Controller Class Initialized
INFO - 2018-10-27 04:55:12 --> Model "Item_model" initialized
INFO - 2018-10-27 04:55:12 --> Model "Jenis_model" initialized
INFO - 2018-10-27 04:55:12 --> Model "Vendor_model" initialized
INFO - 2018-10-27 04:55:13 --> Model "Nota_model" initialized
INFO - 2018-10-27 04:55:13 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 04:55:13 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 04:55:13 --> Final output sent to browser
DEBUG - 2018-10-27 04:55:13 --> Total execution time: 0.4146
INFO - 2018-10-27 05:01:34 --> Config Class Initialized
INFO - 2018-10-27 05:01:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:01:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:01:34 --> Utf8 Class Initialized
INFO - 2018-10-27 05:01:34 --> URI Class Initialized
INFO - 2018-10-27 05:01:34 --> Router Class Initialized
INFO - 2018-10-27 05:01:34 --> Output Class Initialized
INFO - 2018-10-27 05:01:34 --> Security Class Initialized
DEBUG - 2018-10-27 05:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:01:34 --> Input Class Initialized
INFO - 2018-10-27 05:01:34 --> Language Class Initialized
INFO - 2018-10-27 05:01:34 --> Loader Class Initialized
INFO - 2018-10-27 05:01:34 --> Helper loaded: url_helper
INFO - 2018-10-27 05:01:34 --> Database Driver Class Initialized
INFO - 2018-10-27 05:01:34 --> Helper loaded: form_helper
INFO - 2018-10-27 05:01:34 --> Form Validation Class Initialized
INFO - 2018-10-27 05:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:01:34 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:01:34 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:01:34 --> Email Class Initialized
INFO - 2018-10-27 05:01:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:01:34 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:01:35 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:01:35 --> Helper loaded: date_helper
INFO - 2018-10-27 05:01:35 --> Database Driver Class Initialized
INFO - 2018-10-27 05:01:35 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:01:35 --> Controller Class Initialized
INFO - 2018-10-27 05:01:35 --> Model "Item_model" initialized
INFO - 2018-10-27 05:01:35 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:01:35 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:01:35 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:01:35 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 05:01:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 05:01:35 --> Final output sent to browser
DEBUG - 2018-10-27 05:01:35 --> Total execution time: 0.4483
INFO - 2018-10-27 05:01:35 --> Config Class Initialized
INFO - 2018-10-27 05:01:35 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:01:35 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:01:35 --> Utf8 Class Initialized
INFO - 2018-10-27 05:01:35 --> URI Class Initialized
INFO - 2018-10-27 05:01:35 --> Router Class Initialized
INFO - 2018-10-27 05:01:35 --> Output Class Initialized
INFO - 2018-10-27 05:01:35 --> Security Class Initialized
DEBUG - 2018-10-27 05:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:01:35 --> Input Class Initialized
INFO - 2018-10-27 05:01:35 --> Language Class Initialized
ERROR - 2018-10-27 05:01:35 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 05:01:40 --> Config Class Initialized
INFO - 2018-10-27 05:01:40 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:01:40 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:01:40 --> Utf8 Class Initialized
INFO - 2018-10-27 05:01:40 --> URI Class Initialized
INFO - 2018-10-27 05:01:40 --> Router Class Initialized
INFO - 2018-10-27 05:01:40 --> Output Class Initialized
INFO - 2018-10-27 05:01:40 --> Security Class Initialized
DEBUG - 2018-10-27 05:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:01:40 --> Input Class Initialized
INFO - 2018-10-27 05:01:40 --> Language Class Initialized
INFO - 2018-10-27 05:01:40 --> Loader Class Initialized
INFO - 2018-10-27 05:01:40 --> Helper loaded: url_helper
INFO - 2018-10-27 05:01:40 --> Database Driver Class Initialized
INFO - 2018-10-27 05:01:40 --> Helper loaded: form_helper
INFO - 2018-10-27 05:01:40 --> Form Validation Class Initialized
INFO - 2018-10-27 05:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:01:40 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:01:40 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:01:40 --> Email Class Initialized
INFO - 2018-10-27 05:01:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:01:40 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:01:40 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:01:40 --> Helper loaded: date_helper
INFO - 2018-10-27 05:01:40 --> Database Driver Class Initialized
INFO - 2018-10-27 05:01:40 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:01:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:01:40 --> Controller Class Initialized
INFO - 2018-10-27 05:01:40 --> Model "Item_model" initialized
INFO - 2018-10-27 05:01:40 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:01:40 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:01:40 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:01:40 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 05:01:40 --> Severity: Notice --> Undefined property: Item::$post D:\xampp\htdocs\masterwedding\application\controllers\Item.php 129
ERROR - 2018-10-27 05:01:40 --> Severity: error --> Exception: Call to a member function display_errors() on null D:\xampp\htdocs\masterwedding\application\controllers\Item.php 129
INFO - 2018-10-27 05:01:50 --> Config Class Initialized
INFO - 2018-10-27 05:01:50 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:01:50 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:01:50 --> Utf8 Class Initialized
INFO - 2018-10-27 05:01:50 --> URI Class Initialized
INFO - 2018-10-27 05:01:50 --> Router Class Initialized
INFO - 2018-10-27 05:01:50 --> Output Class Initialized
INFO - 2018-10-27 05:01:50 --> Security Class Initialized
DEBUG - 2018-10-27 05:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:01:50 --> Input Class Initialized
INFO - 2018-10-27 05:01:50 --> Language Class Initialized
INFO - 2018-10-27 05:01:50 --> Loader Class Initialized
INFO - 2018-10-27 05:01:50 --> Helper loaded: url_helper
INFO - 2018-10-27 05:01:50 --> Database Driver Class Initialized
INFO - 2018-10-27 05:01:50 --> Helper loaded: form_helper
INFO - 2018-10-27 05:01:50 --> Form Validation Class Initialized
INFO - 2018-10-27 05:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:01:50 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:01:50 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:01:50 --> Email Class Initialized
INFO - 2018-10-27 05:01:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:01:51 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:01:51 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:01:51 --> Helper loaded: date_helper
INFO - 2018-10-27 05:01:51 --> Database Driver Class Initialized
INFO - 2018-10-27 05:01:51 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:01:51 --> Controller Class Initialized
INFO - 2018-10-27 05:01:51 --> Model "Item_model" initialized
INFO - 2018-10-27 05:01:51 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:01:51 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:01:51 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:01:51 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 05:01:51 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 05:01:51 --> Final output sent to browser
DEBUG - 2018-10-27 05:01:51 --> Total execution time: 0.4485
INFO - 2018-10-27 05:01:57 --> Config Class Initialized
INFO - 2018-10-27 05:01:57 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:01:57 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:01:57 --> Utf8 Class Initialized
INFO - 2018-10-27 05:01:57 --> URI Class Initialized
INFO - 2018-10-27 05:01:57 --> Router Class Initialized
INFO - 2018-10-27 05:01:57 --> Output Class Initialized
INFO - 2018-10-27 05:01:57 --> Security Class Initialized
DEBUG - 2018-10-27 05:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:01:57 --> Input Class Initialized
INFO - 2018-10-27 05:01:57 --> Language Class Initialized
INFO - 2018-10-27 05:01:57 --> Loader Class Initialized
INFO - 2018-10-27 05:01:57 --> Helper loaded: url_helper
INFO - 2018-10-27 05:01:57 --> Database Driver Class Initialized
INFO - 2018-10-27 05:01:57 --> Helper loaded: form_helper
INFO - 2018-10-27 05:01:57 --> Form Validation Class Initialized
INFO - 2018-10-27 05:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:01:57 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:01:57 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:01:57 --> Email Class Initialized
INFO - 2018-10-27 05:01:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:01:57 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:01:57 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:01:57 --> Helper loaded: date_helper
INFO - 2018-10-27 05:01:57 --> Database Driver Class Initialized
INFO - 2018-10-27 05:01:57 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:01:57 --> Controller Class Initialized
INFO - 2018-10-27 05:01:57 --> Model "Item_model" initialized
INFO - 2018-10-27 05:01:57 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:01:57 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:01:57 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:01:57 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 05:01:57 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 05:01:57 --> Final output sent to browser
DEBUG - 2018-10-27 05:01:57 --> Total execution time: 0.4059
INFO - 2018-10-27 05:01:57 --> Config Class Initialized
INFO - 2018-10-27 05:01:57 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:01:57 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:01:57 --> Utf8 Class Initialized
INFO - 2018-10-27 05:01:57 --> URI Class Initialized
INFO - 2018-10-27 05:01:57 --> Router Class Initialized
INFO - 2018-10-27 05:01:57 --> Output Class Initialized
INFO - 2018-10-27 05:01:57 --> Security Class Initialized
DEBUG - 2018-10-27 05:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:01:57 --> Input Class Initialized
INFO - 2018-10-27 05:01:57 --> Language Class Initialized
ERROR - 2018-10-27 05:01:57 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 05:05:23 --> Config Class Initialized
INFO - 2018-10-27 05:05:23 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:05:23 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:05:23 --> Utf8 Class Initialized
INFO - 2018-10-27 05:05:23 --> URI Class Initialized
INFO - 2018-10-27 05:05:23 --> Router Class Initialized
INFO - 2018-10-27 05:05:23 --> Output Class Initialized
INFO - 2018-10-27 05:05:23 --> Security Class Initialized
DEBUG - 2018-10-27 05:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:05:23 --> Input Class Initialized
INFO - 2018-10-27 05:05:23 --> Language Class Initialized
INFO - 2018-10-27 05:05:23 --> Loader Class Initialized
INFO - 2018-10-27 05:05:23 --> Helper loaded: url_helper
INFO - 2018-10-27 05:05:23 --> Database Driver Class Initialized
INFO - 2018-10-27 05:05:23 --> Helper loaded: form_helper
INFO - 2018-10-27 05:05:23 --> Form Validation Class Initialized
INFO - 2018-10-27 05:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:05:23 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:05:23 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:05:23 --> Email Class Initialized
INFO - 2018-10-27 05:05:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:05:23 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:05:23 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:05:23 --> Helper loaded: date_helper
INFO - 2018-10-27 05:05:23 --> Database Driver Class Initialized
INFO - 2018-10-27 05:05:23 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:05:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:05:23 --> Controller Class Initialized
INFO - 2018-10-27 05:05:23 --> Model "Item_model" initialized
INFO - 2018-10-27 05:05:23 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:05:23 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:05:23 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:05:23 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 05:05:23 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 05:05:23 --> Final output sent to browser
DEBUG - 2018-10-27 05:05:24 --> Total execution time: 0.4388
INFO - 2018-10-27 05:05:24 --> Config Class Initialized
INFO - 2018-10-27 05:05:24 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:05:24 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:05:24 --> Utf8 Class Initialized
INFO - 2018-10-27 05:05:24 --> URI Class Initialized
INFO - 2018-10-27 05:05:24 --> Router Class Initialized
INFO - 2018-10-27 05:05:24 --> Output Class Initialized
INFO - 2018-10-27 05:05:24 --> Security Class Initialized
DEBUG - 2018-10-27 05:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:05:24 --> Input Class Initialized
INFO - 2018-10-27 05:05:24 --> Language Class Initialized
ERROR - 2018-10-27 05:05:24 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 05:05:25 --> Config Class Initialized
INFO - 2018-10-27 05:05:25 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:05:25 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:05:25 --> Utf8 Class Initialized
INFO - 2018-10-27 05:05:25 --> URI Class Initialized
INFO - 2018-10-27 05:05:25 --> Router Class Initialized
INFO - 2018-10-27 05:05:25 --> Output Class Initialized
INFO - 2018-10-27 05:05:25 --> Security Class Initialized
DEBUG - 2018-10-27 05:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:05:25 --> Input Class Initialized
INFO - 2018-10-27 05:05:25 --> Language Class Initialized
INFO - 2018-10-27 05:05:26 --> Loader Class Initialized
INFO - 2018-10-27 05:05:26 --> Helper loaded: url_helper
INFO - 2018-10-27 05:05:26 --> Database Driver Class Initialized
INFO - 2018-10-27 05:05:26 --> Helper loaded: form_helper
INFO - 2018-10-27 05:05:26 --> Form Validation Class Initialized
INFO - 2018-10-27 05:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:05:26 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:05:26 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:05:26 --> Email Class Initialized
INFO - 2018-10-27 05:05:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:05:26 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:05:26 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:05:26 --> Helper loaded: date_helper
INFO - 2018-10-27 05:05:26 --> Database Driver Class Initialized
INFO - 2018-10-27 05:05:26 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:05:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:05:26 --> Controller Class Initialized
INFO - 2018-10-27 05:05:26 --> Model "Item_model" initialized
INFO - 2018-10-27 05:05:26 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:05:26 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:05:26 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:05:26 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 05:05:26 --> Severity: error --> Exception: Call to undefined method CI_Input::display_errors() D:\xampp\htdocs\masterwedding\application\controllers\Item.php 129
INFO - 2018-10-27 05:05:32 --> Config Class Initialized
INFO - 2018-10-27 05:05:32 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:05:32 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:05:32 --> Utf8 Class Initialized
INFO - 2018-10-27 05:05:32 --> URI Class Initialized
INFO - 2018-10-27 05:05:32 --> Router Class Initialized
INFO - 2018-10-27 05:05:32 --> Output Class Initialized
INFO - 2018-10-27 05:05:32 --> Security Class Initialized
DEBUG - 2018-10-27 05:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:05:32 --> Input Class Initialized
INFO - 2018-10-27 05:05:32 --> Language Class Initialized
INFO - 2018-10-27 05:05:32 --> Loader Class Initialized
INFO - 2018-10-27 05:05:32 --> Helper loaded: url_helper
INFO - 2018-10-27 05:05:32 --> Database Driver Class Initialized
INFO - 2018-10-27 05:05:32 --> Helper loaded: form_helper
INFO - 2018-10-27 05:05:32 --> Form Validation Class Initialized
INFO - 2018-10-27 05:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:05:32 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:05:32 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:05:32 --> Email Class Initialized
INFO - 2018-10-27 05:05:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:05:32 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:05:32 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:05:32 --> Helper loaded: date_helper
INFO - 2018-10-27 05:05:32 --> Database Driver Class Initialized
INFO - 2018-10-27 05:05:32 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:05:32 --> Controller Class Initialized
INFO - 2018-10-27 05:05:32 --> Model "Item_model" initialized
INFO - 2018-10-27 05:05:32 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:05:32 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:05:32 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:05:32 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 05:05:32 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 05:05:32 --> Final output sent to browser
DEBUG - 2018-10-27 05:05:32 --> Total execution time: 0.4549
INFO - 2018-10-27 05:05:35 --> Config Class Initialized
INFO - 2018-10-27 05:05:35 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:05:36 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:05:36 --> Utf8 Class Initialized
INFO - 2018-10-27 05:05:36 --> URI Class Initialized
INFO - 2018-10-27 05:05:36 --> Router Class Initialized
INFO - 2018-10-27 05:05:36 --> Output Class Initialized
INFO - 2018-10-27 05:05:36 --> Security Class Initialized
DEBUG - 2018-10-27 05:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:05:36 --> Input Class Initialized
INFO - 2018-10-27 05:05:36 --> Language Class Initialized
INFO - 2018-10-27 05:05:36 --> Loader Class Initialized
INFO - 2018-10-27 05:05:36 --> Helper loaded: url_helper
INFO - 2018-10-27 05:05:36 --> Database Driver Class Initialized
INFO - 2018-10-27 05:05:36 --> Helper loaded: form_helper
INFO - 2018-10-27 05:05:36 --> Form Validation Class Initialized
INFO - 2018-10-27 05:05:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:05:36 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:05:36 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:05:36 --> Email Class Initialized
INFO - 2018-10-27 05:05:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:05:36 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:05:36 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:05:36 --> Helper loaded: date_helper
INFO - 2018-10-27 05:05:36 --> Database Driver Class Initialized
INFO - 2018-10-27 05:05:36 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:05:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:05:36 --> Controller Class Initialized
INFO - 2018-10-27 05:05:36 --> Model "Item_model" initialized
INFO - 2018-10-27 05:05:36 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:05:36 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:05:36 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:05:36 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 05:05:36 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 05:05:36 --> Final output sent to browser
DEBUG - 2018-10-27 05:05:36 --> Total execution time: 0.4208
INFO - 2018-10-27 05:05:36 --> Config Class Initialized
INFO - 2018-10-27 05:05:36 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:05:36 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:05:36 --> Utf8 Class Initialized
INFO - 2018-10-27 05:05:36 --> URI Class Initialized
INFO - 2018-10-27 05:05:36 --> Router Class Initialized
INFO - 2018-10-27 05:05:36 --> Output Class Initialized
INFO - 2018-10-27 05:05:36 --> Security Class Initialized
DEBUG - 2018-10-27 05:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:05:36 --> Input Class Initialized
INFO - 2018-10-27 05:05:36 --> Language Class Initialized
ERROR - 2018-10-27 05:05:36 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 05:05:58 --> Config Class Initialized
INFO - 2018-10-27 05:05:58 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:05:58 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:05:58 --> Utf8 Class Initialized
INFO - 2018-10-27 05:05:58 --> URI Class Initialized
INFO - 2018-10-27 05:05:58 --> Router Class Initialized
INFO - 2018-10-27 05:05:58 --> Output Class Initialized
INFO - 2018-10-27 05:05:58 --> Security Class Initialized
DEBUG - 2018-10-27 05:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:05:58 --> Input Class Initialized
INFO - 2018-10-27 05:05:58 --> Language Class Initialized
INFO - 2018-10-27 05:05:58 --> Loader Class Initialized
INFO - 2018-10-27 05:05:58 --> Helper loaded: url_helper
INFO - 2018-10-27 05:05:58 --> Database Driver Class Initialized
INFO - 2018-10-27 05:05:58 --> Helper loaded: form_helper
INFO - 2018-10-27 05:05:58 --> Form Validation Class Initialized
INFO - 2018-10-27 05:05:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:05:58 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:05:58 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:05:58 --> Email Class Initialized
INFO - 2018-10-27 05:05:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:05:58 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:05:58 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:05:58 --> Helper loaded: date_helper
INFO - 2018-10-27 05:05:58 --> Database Driver Class Initialized
INFO - 2018-10-27 05:05:58 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:05:58 --> Controller Class Initialized
INFO - 2018-10-27 05:05:58 --> Model "Item_model" initialized
INFO - 2018-10-27 05:05:58 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:05:58 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:05:58 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:05:58 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 05:05:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 05:05:58 --> Final output sent to browser
DEBUG - 2018-10-27 05:05:58 --> Total execution time: 0.4418
INFO - 2018-10-27 05:05:58 --> Config Class Initialized
INFO - 2018-10-27 05:05:58 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:05:58 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:05:58 --> Utf8 Class Initialized
INFO - 2018-10-27 05:05:58 --> URI Class Initialized
INFO - 2018-10-27 05:05:58 --> Router Class Initialized
INFO - 2018-10-27 05:05:58 --> Output Class Initialized
INFO - 2018-10-27 05:05:58 --> Security Class Initialized
DEBUG - 2018-10-27 05:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:05:58 --> Input Class Initialized
INFO - 2018-10-27 05:05:58 --> Language Class Initialized
ERROR - 2018-10-27 05:05:58 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 05:06:00 --> Config Class Initialized
INFO - 2018-10-27 05:06:00 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:06:00 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:06:00 --> Utf8 Class Initialized
INFO - 2018-10-27 05:06:00 --> URI Class Initialized
INFO - 2018-10-27 05:06:00 --> Router Class Initialized
INFO - 2018-10-27 05:06:00 --> Output Class Initialized
INFO - 2018-10-27 05:06:00 --> Security Class Initialized
DEBUG - 2018-10-27 05:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:06:00 --> Input Class Initialized
INFO - 2018-10-27 05:06:00 --> Language Class Initialized
INFO - 2018-10-27 05:06:00 --> Loader Class Initialized
INFO - 2018-10-27 05:06:00 --> Helper loaded: url_helper
INFO - 2018-10-27 05:06:00 --> Database Driver Class Initialized
INFO - 2018-10-27 05:06:00 --> Helper loaded: form_helper
INFO - 2018-10-27 05:06:00 --> Form Validation Class Initialized
INFO - 2018-10-27 05:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:06:00 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:06:00 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:06:00 --> Email Class Initialized
INFO - 2018-10-27 05:06:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:06:00 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:06:00 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:06:00 --> Helper loaded: date_helper
INFO - 2018-10-27 05:06:00 --> Database Driver Class Initialized
INFO - 2018-10-27 05:06:00 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:06:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:06:00 --> Controller Class Initialized
INFO - 2018-10-27 05:06:00 --> Model "Item_model" initialized
INFO - 2018-10-27 05:06:00 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:06:00 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:06:00 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:06:00 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 05:06:00 --> Severity: error --> Exception: Call to undefined method Item_model::display_errors() D:\xampp\htdocs\masterwedding\application\controllers\Item.php 129
INFO - 2018-10-27 05:06:41 --> Config Class Initialized
INFO - 2018-10-27 05:06:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:06:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:06:41 --> Utf8 Class Initialized
INFO - 2018-10-27 05:06:41 --> URI Class Initialized
INFO - 2018-10-27 05:06:41 --> Router Class Initialized
INFO - 2018-10-27 05:06:41 --> Output Class Initialized
INFO - 2018-10-27 05:06:41 --> Security Class Initialized
DEBUG - 2018-10-27 05:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:06:42 --> Input Class Initialized
INFO - 2018-10-27 05:06:42 --> Language Class Initialized
INFO - 2018-10-27 05:06:42 --> Loader Class Initialized
INFO - 2018-10-27 05:06:42 --> Helper loaded: url_helper
INFO - 2018-10-27 05:06:42 --> Database Driver Class Initialized
INFO - 2018-10-27 05:06:42 --> Helper loaded: form_helper
INFO - 2018-10-27 05:06:42 --> Form Validation Class Initialized
INFO - 2018-10-27 05:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:06:42 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:06:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:06:42 --> Email Class Initialized
INFO - 2018-10-27 05:06:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:06:42 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:06:42 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:06:42 --> Helper loaded: date_helper
INFO - 2018-10-27 05:06:42 --> Database Driver Class Initialized
INFO - 2018-10-27 05:06:42 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:06:42 --> Controller Class Initialized
INFO - 2018-10-27 05:06:42 --> Model "Item_model" initialized
INFO - 2018-10-27 05:06:42 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:06:42 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:06:42 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:06:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 05:06:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 05:06:42 --> Final output sent to browser
INFO - 2018-10-27 05:06:42 --> Config Class Initialized
INFO - 2018-10-27 05:06:42 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:06:42 --> Total execution time: 0.4515
DEBUG - 2018-10-27 05:06:42 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:06:42 --> Utf8 Class Initialized
INFO - 2018-10-27 05:06:42 --> URI Class Initialized
INFO - 2018-10-27 05:06:42 --> Router Class Initialized
INFO - 2018-10-27 05:06:42 --> Output Class Initialized
INFO - 2018-10-27 05:06:42 --> Security Class Initialized
DEBUG - 2018-10-27 05:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:06:42 --> Input Class Initialized
INFO - 2018-10-27 05:06:42 --> Language Class Initialized
INFO - 2018-10-27 05:06:42 --> Loader Class Initialized
INFO - 2018-10-27 05:06:42 --> Helper loaded: url_helper
INFO - 2018-10-27 05:06:42 --> Database Driver Class Initialized
INFO - 2018-10-27 05:06:42 --> Helper loaded: form_helper
INFO - 2018-10-27 05:06:42 --> Form Validation Class Initialized
INFO - 2018-10-27 05:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:06:42 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:06:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:06:42 --> Email Class Initialized
INFO - 2018-10-27 05:06:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:06:42 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:06:42 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:06:42 --> Helper loaded: date_helper
INFO - 2018-10-27 05:06:42 --> Database Driver Class Initialized
INFO - 2018-10-27 05:06:42 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:06:42 --> Controller Class Initialized
INFO - 2018-10-27 05:06:42 --> Model "Item_model" initialized
INFO - 2018-10-27 05:06:42 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:06:42 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:06:42 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:06:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 05:06:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 05:06:42 --> Final output sent to browser
DEBUG - 2018-10-27 05:06:42 --> Total execution time: 0.4282
INFO - 2018-10-27 05:06:42 --> Config Class Initialized
INFO - 2018-10-27 05:06:42 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:06:42 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:06:42 --> Utf8 Class Initialized
INFO - 2018-10-27 05:06:42 --> URI Class Initialized
INFO - 2018-10-27 05:06:42 --> Router Class Initialized
INFO - 2018-10-27 05:06:42 --> Output Class Initialized
INFO - 2018-10-27 05:06:42 --> Security Class Initialized
DEBUG - 2018-10-27 05:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:06:42 --> Input Class Initialized
INFO - 2018-10-27 05:06:42 --> Language Class Initialized
ERROR - 2018-10-27 05:06:42 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 05:06:45 --> Config Class Initialized
INFO - 2018-10-27 05:06:45 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:06:45 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:06:45 --> Utf8 Class Initialized
INFO - 2018-10-27 05:06:45 --> URI Class Initialized
INFO - 2018-10-27 05:06:45 --> Router Class Initialized
INFO - 2018-10-27 05:06:45 --> Output Class Initialized
INFO - 2018-10-27 05:06:45 --> Security Class Initialized
DEBUG - 2018-10-27 05:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:06:45 --> Input Class Initialized
INFO - 2018-10-27 05:06:45 --> Language Class Initialized
INFO - 2018-10-27 05:06:45 --> Loader Class Initialized
INFO - 2018-10-27 05:06:45 --> Helper loaded: url_helper
INFO - 2018-10-27 05:06:45 --> Database Driver Class Initialized
INFO - 2018-10-27 05:06:45 --> Helper loaded: form_helper
INFO - 2018-10-27 05:06:45 --> Form Validation Class Initialized
INFO - 2018-10-27 05:06:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:06:45 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:06:45 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:06:45 --> Email Class Initialized
INFO - 2018-10-27 05:06:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:06:45 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:06:45 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:06:45 --> Helper loaded: date_helper
INFO - 2018-10-27 05:06:45 --> Database Driver Class Initialized
INFO - 2018-10-27 05:06:45 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:06:45 --> Controller Class Initialized
INFO - 2018-10-27 05:06:45 --> Model "Item_model" initialized
INFO - 2018-10-27 05:06:45 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:06:45 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:06:45 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:06:45 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 05:06:45 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 05:06:45 --> Final output sent to browser
DEBUG - 2018-10-27 05:06:45 --> Total execution time: 0.4553
INFO - 2018-10-27 05:06:45 --> Config Class Initialized
INFO - 2018-10-27 05:06:45 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:06:45 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:06:45 --> Utf8 Class Initialized
INFO - 2018-10-27 05:06:45 --> URI Class Initialized
INFO - 2018-10-27 05:06:45 --> Router Class Initialized
INFO - 2018-10-27 05:06:45 --> Output Class Initialized
INFO - 2018-10-27 05:06:45 --> Security Class Initialized
DEBUG - 2018-10-27 05:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:06:45 --> Input Class Initialized
INFO - 2018-10-27 05:06:45 --> Language Class Initialized
ERROR - 2018-10-27 05:06:45 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 05:06:47 --> Config Class Initialized
INFO - 2018-10-27 05:06:47 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:06:47 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:06:47 --> Utf8 Class Initialized
INFO - 2018-10-27 05:06:47 --> URI Class Initialized
INFO - 2018-10-27 05:06:47 --> Router Class Initialized
INFO - 2018-10-27 05:06:47 --> Output Class Initialized
INFO - 2018-10-27 05:06:47 --> Security Class Initialized
DEBUG - 2018-10-27 05:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:06:47 --> Input Class Initialized
INFO - 2018-10-27 05:06:47 --> Language Class Initialized
INFO - 2018-10-27 05:06:47 --> Loader Class Initialized
INFO - 2018-10-27 05:06:47 --> Helper loaded: url_helper
INFO - 2018-10-27 05:06:47 --> Database Driver Class Initialized
INFO - 2018-10-27 05:06:47 --> Helper loaded: form_helper
INFO - 2018-10-27 05:06:47 --> Form Validation Class Initialized
INFO - 2018-10-27 05:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:06:47 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:06:47 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:06:47 --> Email Class Initialized
INFO - 2018-10-27 05:06:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:06:47 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:06:47 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:06:47 --> Helper loaded: date_helper
INFO - 2018-10-27 05:06:47 --> Database Driver Class Initialized
INFO - 2018-10-27 05:06:47 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:06:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:06:47 --> Controller Class Initialized
INFO - 2018-10-27 05:06:47 --> Model "Item_model" initialized
INFO - 2018-10-27 05:06:47 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:06:47 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:06:47 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:06:47 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 05:06:47 --> Severity: error --> Exception: Call to undefined method Item::display_errors() D:\xampp\htdocs\masterwedding\application\controllers\Item.php 129
INFO - 2018-10-27 05:59:26 --> Config Class Initialized
INFO - 2018-10-27 05:59:26 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:59:26 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:59:26 --> Utf8 Class Initialized
INFO - 2018-10-27 05:59:26 --> URI Class Initialized
INFO - 2018-10-27 05:59:26 --> Router Class Initialized
INFO - 2018-10-27 05:59:27 --> Output Class Initialized
INFO - 2018-10-27 05:59:27 --> Security Class Initialized
DEBUG - 2018-10-27 05:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:59:27 --> Input Class Initialized
INFO - 2018-10-27 05:59:27 --> Language Class Initialized
INFO - 2018-10-27 05:59:27 --> Loader Class Initialized
INFO - 2018-10-27 05:59:27 --> Helper loaded: url_helper
INFO - 2018-10-27 05:59:27 --> Database Driver Class Initialized
INFO - 2018-10-27 05:59:27 --> Helper loaded: form_helper
INFO - 2018-10-27 05:59:27 --> Form Validation Class Initialized
INFO - 2018-10-27 05:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 05:59:27 --> Pagination Class Initialized
DEBUG - 2018-10-27 05:59:27 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 05:59:27 --> Email Class Initialized
INFO - 2018-10-27 05:59:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 05:59:27 --> Helper loaded: cookie_helper
INFO - 2018-10-27 05:59:27 --> Helper loaded: language_helper
DEBUG - 2018-10-27 05:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:59:27 --> Helper loaded: date_helper
INFO - 2018-10-27 05:59:27 --> Database Driver Class Initialized
INFO - 2018-10-27 05:59:27 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 05:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 05:59:27 --> Controller Class Initialized
INFO - 2018-10-27 05:59:27 --> Model "Item_model" initialized
INFO - 2018-10-27 05:59:27 --> Model "Jenis_model" initialized
INFO - 2018-10-27 05:59:27 --> Model "Vendor_model" initialized
INFO - 2018-10-27 05:59:27 --> Model "Nota_model" initialized
INFO - 2018-10-27 05:59:27 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 05:59:27 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 05:59:27 --> Final output sent to browser
DEBUG - 2018-10-27 05:59:27 --> Total execution time: 0.4858
INFO - 2018-10-27 06:00:44 --> Config Class Initialized
INFO - 2018-10-27 06:00:44 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:00:44 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:00:44 --> Utf8 Class Initialized
INFO - 2018-10-27 06:00:44 --> URI Class Initialized
INFO - 2018-10-27 06:00:44 --> Router Class Initialized
INFO - 2018-10-27 06:00:44 --> Output Class Initialized
INFO - 2018-10-27 06:00:44 --> Security Class Initialized
DEBUG - 2018-10-27 06:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:00:44 --> Input Class Initialized
INFO - 2018-10-27 06:00:44 --> Language Class Initialized
INFO - 2018-10-27 06:00:44 --> Loader Class Initialized
INFO - 2018-10-27 06:00:44 --> Helper loaded: url_helper
INFO - 2018-10-27 06:00:44 --> Database Driver Class Initialized
INFO - 2018-10-27 06:00:44 --> Helper loaded: form_helper
INFO - 2018-10-27 06:00:44 --> Form Validation Class Initialized
INFO - 2018-10-27 06:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:00:44 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:00:44 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:00:44 --> Email Class Initialized
INFO - 2018-10-27 06:00:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:00:44 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:00:44 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:00:44 --> Helper loaded: date_helper
INFO - 2018-10-27 06:00:44 --> Database Driver Class Initialized
INFO - 2018-10-27 06:00:44 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:00:44 --> Controller Class Initialized
INFO - 2018-10-27 06:00:45 --> Model "Item_model" initialized
INFO - 2018-10-27 06:00:45 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:00:45 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:00:45 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:00:45 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:00:45 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 06:00:45 --> Final output sent to browser
DEBUG - 2018-10-27 06:00:45 --> Total execution time: 0.4625
INFO - 2018-10-27 06:00:45 --> Config Class Initialized
INFO - 2018-10-27 06:00:45 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:00:45 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:00:45 --> Utf8 Class Initialized
INFO - 2018-10-27 06:00:45 --> URI Class Initialized
INFO - 2018-10-27 06:00:45 --> Router Class Initialized
INFO - 2018-10-27 06:00:45 --> Output Class Initialized
INFO - 2018-10-27 06:00:45 --> Security Class Initialized
DEBUG - 2018-10-27 06:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:00:45 --> Input Class Initialized
INFO - 2018-10-27 06:00:45 --> Language Class Initialized
ERROR - 2018-10-27 06:00:45 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:00:47 --> Config Class Initialized
INFO - 2018-10-27 06:00:47 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:00:47 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:00:47 --> Utf8 Class Initialized
INFO - 2018-10-27 06:00:47 --> URI Class Initialized
INFO - 2018-10-27 06:00:47 --> Router Class Initialized
INFO - 2018-10-27 06:00:47 --> Output Class Initialized
INFO - 2018-10-27 06:00:47 --> Security Class Initialized
DEBUG - 2018-10-27 06:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:00:47 --> Input Class Initialized
INFO - 2018-10-27 06:00:47 --> Language Class Initialized
INFO - 2018-10-27 06:00:47 --> Loader Class Initialized
INFO - 2018-10-27 06:00:47 --> Helper loaded: url_helper
INFO - 2018-10-27 06:00:47 --> Database Driver Class Initialized
INFO - 2018-10-27 06:00:47 --> Helper loaded: form_helper
INFO - 2018-10-27 06:00:47 --> Form Validation Class Initialized
INFO - 2018-10-27 06:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:00:47 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:00:47 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:00:47 --> Email Class Initialized
INFO - 2018-10-27 06:00:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:00:47 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:00:47 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:00:47 --> Helper loaded: date_helper
INFO - 2018-10-27 06:00:47 --> Database Driver Class Initialized
INFO - 2018-10-27 06:00:47 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:00:47 --> Controller Class Initialized
INFO - 2018-10-27 06:00:47 --> Model "Item_model" initialized
INFO - 2018-10-27 06:00:47 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:00:47 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:00:47 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:00:47 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:00:47 --> Severity: Notice --> Undefined variable: detail D:\xampp\htdocs\masterwedding\application\controllers\Item.php 129
INFO - 2018-10-27 06:01:25 --> Config Class Initialized
INFO - 2018-10-27 06:01:25 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:01:25 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:01:25 --> Utf8 Class Initialized
INFO - 2018-10-27 06:01:25 --> URI Class Initialized
INFO - 2018-10-27 06:01:25 --> Router Class Initialized
INFO - 2018-10-27 06:01:25 --> Output Class Initialized
INFO - 2018-10-27 06:01:25 --> Security Class Initialized
DEBUG - 2018-10-27 06:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:01:25 --> Input Class Initialized
INFO - 2018-10-27 06:01:25 --> Language Class Initialized
INFO - 2018-10-27 06:01:25 --> Loader Class Initialized
INFO - 2018-10-27 06:01:25 --> Helper loaded: url_helper
INFO - 2018-10-27 06:01:25 --> Database Driver Class Initialized
INFO - 2018-10-27 06:01:25 --> Helper loaded: form_helper
INFO - 2018-10-27 06:01:25 --> Form Validation Class Initialized
INFO - 2018-10-27 06:01:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:01:25 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:01:25 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:01:25 --> Email Class Initialized
INFO - 2018-10-27 06:01:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:01:25 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:01:25 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:01:25 --> Helper loaded: date_helper
INFO - 2018-10-27 06:01:25 --> Database Driver Class Initialized
INFO - 2018-10-27 06:01:25 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:01:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:01:25 --> Controller Class Initialized
INFO - 2018-10-27 06:01:25 --> Model "Item_model" initialized
INFO - 2018-10-27 06:01:25 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:01:25 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:01:25 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:01:25 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:03:13 --> Config Class Initialized
INFO - 2018-10-27 06:03:13 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:13 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:13 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:13 --> URI Class Initialized
INFO - 2018-10-27 06:03:13 --> Router Class Initialized
INFO - 2018-10-27 06:03:13 --> Output Class Initialized
INFO - 2018-10-27 06:03:13 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:13 --> Input Class Initialized
INFO - 2018-10-27 06:03:13 --> Language Class Initialized
INFO - 2018-10-27 06:03:13 --> Loader Class Initialized
INFO - 2018-10-27 06:03:13 --> Helper loaded: url_helper
INFO - 2018-10-27 06:03:13 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:13 --> Helper loaded: form_helper
INFO - 2018-10-27 06:03:13 --> Form Validation Class Initialized
INFO - 2018-10-27 06:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:03:13 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:03:13 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:03:13 --> Email Class Initialized
INFO - 2018-10-27 06:03:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:03:13 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:03:13 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:03:13 --> Helper loaded: date_helper
INFO - 2018-10-27 06:03:13 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:13 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:03:13 --> Controller Class Initialized
INFO - 2018-10-27 06:03:13 --> Model "Item_model" initialized
INFO - 2018-10-27 06:03:13 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:03:13 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:03:13 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:03:13 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:03:20 --> Config Class Initialized
INFO - 2018-10-27 06:03:20 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:20 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:20 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:20 --> URI Class Initialized
INFO - 2018-10-27 06:03:20 --> Router Class Initialized
INFO - 2018-10-27 06:03:20 --> Output Class Initialized
INFO - 2018-10-27 06:03:20 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:20 --> Input Class Initialized
INFO - 2018-10-27 06:03:20 --> Language Class Initialized
INFO - 2018-10-27 06:03:20 --> Loader Class Initialized
INFO - 2018-10-27 06:03:20 --> Helper loaded: url_helper
INFO - 2018-10-27 06:03:20 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:20 --> Helper loaded: form_helper
INFO - 2018-10-27 06:03:20 --> Form Validation Class Initialized
INFO - 2018-10-27 06:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:03:20 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:03:20 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:03:20 --> Email Class Initialized
INFO - 2018-10-27 06:03:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:03:20 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:03:20 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:03:20 --> Helper loaded: date_helper
INFO - 2018-10-27 06:03:20 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:20 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:03:20 --> Controller Class Initialized
INFO - 2018-10-27 06:03:20 --> Model "Item_model" initialized
INFO - 2018-10-27 06:03:20 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:03:20 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:03:20 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:03:20 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:03:20 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 06:03:20 --> Final output sent to browser
DEBUG - 2018-10-27 06:03:20 --> Total execution time: 0.4609
INFO - 2018-10-27 06:03:24 --> Config Class Initialized
INFO - 2018-10-27 06:03:24 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:24 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:24 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:24 --> URI Class Initialized
INFO - 2018-10-27 06:03:24 --> Router Class Initialized
INFO - 2018-10-27 06:03:24 --> Output Class Initialized
INFO - 2018-10-27 06:03:24 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:25 --> Input Class Initialized
INFO - 2018-10-27 06:03:25 --> Language Class Initialized
INFO - 2018-10-27 06:03:25 --> Loader Class Initialized
INFO - 2018-10-27 06:03:25 --> Helper loaded: url_helper
INFO - 2018-10-27 06:03:25 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:25 --> Helper loaded: form_helper
INFO - 2018-10-27 06:03:25 --> Form Validation Class Initialized
INFO - 2018-10-27 06:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:03:25 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:03:25 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:03:25 --> Email Class Initialized
INFO - 2018-10-27 06:03:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:03:25 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:03:25 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:03:25 --> Helper loaded: date_helper
INFO - 2018-10-27 06:03:25 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:25 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:03:25 --> Controller Class Initialized
INFO - 2018-10-27 06:03:25 --> Model "Item_model" initialized
INFO - 2018-10-27 06:03:25 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:03:25 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:03:25 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:03:25 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:03:25 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 06:03:25 --> Final output sent to browser
DEBUG - 2018-10-27 06:03:25 --> Total execution time: 0.4374
INFO - 2018-10-27 06:03:25 --> Config Class Initialized
INFO - 2018-10-27 06:03:25 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:25 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:25 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:25 --> URI Class Initialized
INFO - 2018-10-27 06:03:25 --> Router Class Initialized
INFO - 2018-10-27 06:03:25 --> Output Class Initialized
INFO - 2018-10-27 06:03:25 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:25 --> Input Class Initialized
INFO - 2018-10-27 06:03:25 --> Language Class Initialized
ERROR - 2018-10-27 06:03:25 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:03:26 --> Config Class Initialized
INFO - 2018-10-27 06:03:26 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:26 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:26 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:26 --> URI Class Initialized
INFO - 2018-10-27 06:03:26 --> Router Class Initialized
INFO - 2018-10-27 06:03:26 --> Output Class Initialized
INFO - 2018-10-27 06:03:26 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:26 --> Input Class Initialized
INFO - 2018-10-27 06:03:26 --> Language Class Initialized
INFO - 2018-10-27 06:03:26 --> Loader Class Initialized
INFO - 2018-10-27 06:03:26 --> Helper loaded: url_helper
INFO - 2018-10-27 06:03:26 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:27 --> Helper loaded: form_helper
INFO - 2018-10-27 06:03:27 --> Form Validation Class Initialized
INFO - 2018-10-27 06:03:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:03:27 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:03:27 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:03:27 --> Email Class Initialized
INFO - 2018-10-27 06:03:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:03:27 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:03:27 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:03:27 --> Helper loaded: date_helper
INFO - 2018-10-27 06:03:27 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:27 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:03:27 --> Controller Class Initialized
INFO - 2018-10-27 06:03:27 --> Model "Item_model" initialized
INFO - 2018-10-27 06:03:27 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:03:27 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:03:27 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:03:27 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:03:30 --> Config Class Initialized
INFO - 2018-10-27 06:03:30 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:30 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:30 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:30 --> URI Class Initialized
INFO - 2018-10-27 06:03:30 --> Router Class Initialized
INFO - 2018-10-27 06:03:30 --> Output Class Initialized
INFO - 2018-10-27 06:03:30 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:30 --> Input Class Initialized
INFO - 2018-10-27 06:03:30 --> Language Class Initialized
INFO - 2018-10-27 06:03:30 --> Loader Class Initialized
INFO - 2018-10-27 06:03:30 --> Helper loaded: url_helper
INFO - 2018-10-27 06:03:30 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:30 --> Helper loaded: form_helper
INFO - 2018-10-27 06:03:30 --> Form Validation Class Initialized
INFO - 2018-10-27 06:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:03:30 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:03:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:03:30 --> Email Class Initialized
INFO - 2018-10-27 06:03:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:03:30 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:03:30 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:03:30 --> Helper loaded: date_helper
INFO - 2018-10-27 06:03:30 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:30 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:03:30 --> Controller Class Initialized
INFO - 2018-10-27 06:03:30 --> Model "Item_model" initialized
INFO - 2018-10-27 06:03:30 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:03:30 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:03:30 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:03:30 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:03:30 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 06:03:30 --> Final output sent to browser
DEBUG - 2018-10-27 06:03:30 --> Total execution time: 0.4760
INFO - 2018-10-27 06:03:34 --> Config Class Initialized
INFO - 2018-10-27 06:03:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:34 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:34 --> URI Class Initialized
INFO - 2018-10-27 06:03:34 --> Router Class Initialized
INFO - 2018-10-27 06:03:34 --> Output Class Initialized
INFO - 2018-10-27 06:03:34 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:34 --> Input Class Initialized
INFO - 2018-10-27 06:03:34 --> Language Class Initialized
INFO - 2018-10-27 06:03:34 --> Loader Class Initialized
INFO - 2018-10-27 06:03:34 --> Helper loaded: url_helper
INFO - 2018-10-27 06:03:34 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:34 --> Helper loaded: form_helper
INFO - 2018-10-27 06:03:34 --> Form Validation Class Initialized
INFO - 2018-10-27 06:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:03:34 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:03:34 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:03:35 --> Email Class Initialized
INFO - 2018-10-27 06:03:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:03:35 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:03:35 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:03:35 --> Helper loaded: date_helper
INFO - 2018-10-27 06:03:35 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:35 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:03:35 --> Controller Class Initialized
INFO - 2018-10-27 06:03:35 --> Model "Item_model" initialized
INFO - 2018-10-27 06:03:35 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:03:35 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:03:35 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:03:35 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:03:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 06:03:35 --> Final output sent to browser
DEBUG - 2018-10-27 06:03:35 --> Total execution time: 0.4580
INFO - 2018-10-27 06:03:35 --> Config Class Initialized
INFO - 2018-10-27 06:03:35 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:35 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:35 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:35 --> URI Class Initialized
INFO - 2018-10-27 06:03:35 --> Router Class Initialized
INFO - 2018-10-27 06:03:35 --> Output Class Initialized
INFO - 2018-10-27 06:03:35 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:35 --> Input Class Initialized
INFO - 2018-10-27 06:03:35 --> Language Class Initialized
ERROR - 2018-10-27 06:03:35 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:03:36 --> Config Class Initialized
INFO - 2018-10-27 06:03:36 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:36 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:36 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:36 --> URI Class Initialized
INFO - 2018-10-27 06:03:36 --> Router Class Initialized
INFO - 2018-10-27 06:03:36 --> Output Class Initialized
INFO - 2018-10-27 06:03:36 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:37 --> Input Class Initialized
INFO - 2018-10-27 06:03:37 --> Language Class Initialized
INFO - 2018-10-27 06:03:37 --> Loader Class Initialized
INFO - 2018-10-27 06:03:37 --> Helper loaded: url_helper
INFO - 2018-10-27 06:03:37 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:37 --> Helper loaded: form_helper
INFO - 2018-10-27 06:03:37 --> Form Validation Class Initialized
INFO - 2018-10-27 06:03:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:03:37 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:03:37 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:03:37 --> Email Class Initialized
INFO - 2018-10-27 06:03:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:03:37 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:03:37 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:03:37 --> Helper loaded: date_helper
INFO - 2018-10-27 06:03:37 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:37 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:03:37 --> Controller Class Initialized
INFO - 2018-10-27 06:03:37 --> Model "Item_model" initialized
INFO - 2018-10-27 06:03:37 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:03:37 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:03:37 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:03:37 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:03:57 --> Config Class Initialized
INFO - 2018-10-27 06:03:57 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:57 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:57 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:57 --> URI Class Initialized
INFO - 2018-10-27 06:03:57 --> Router Class Initialized
INFO - 2018-10-27 06:03:57 --> Output Class Initialized
INFO - 2018-10-27 06:03:57 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:57 --> Input Class Initialized
INFO - 2018-10-27 06:03:57 --> Language Class Initialized
INFO - 2018-10-27 06:03:57 --> Loader Class Initialized
INFO - 2018-10-27 06:03:57 --> Helper loaded: url_helper
INFO - 2018-10-27 06:03:57 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:57 --> Helper loaded: form_helper
INFO - 2018-10-27 06:03:57 --> Form Validation Class Initialized
INFO - 2018-10-27 06:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:03:57 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:03:57 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:03:57 --> Email Class Initialized
INFO - 2018-10-27 06:03:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:03:57 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:03:57 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:03:57 --> Helper loaded: date_helper
INFO - 2018-10-27 06:03:57 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:57 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:03:58 --> Controller Class Initialized
INFO - 2018-10-27 06:03:58 --> Model "Item_model" initialized
INFO - 2018-10-27 06:03:58 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:03:58 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:03:58 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:03:58 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:03:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 06:03:58 --> Final output sent to browser
DEBUG - 2018-10-27 06:03:58 --> Total execution time: 0.4898
INFO - 2018-10-27 06:04:04 --> Config Class Initialized
INFO - 2018-10-27 06:04:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:04:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:04:04 --> Utf8 Class Initialized
INFO - 2018-10-27 06:04:04 --> URI Class Initialized
INFO - 2018-10-27 06:04:04 --> Router Class Initialized
INFO - 2018-10-27 06:04:04 --> Output Class Initialized
INFO - 2018-10-27 06:04:04 --> Security Class Initialized
DEBUG - 2018-10-27 06:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:04:04 --> Input Class Initialized
INFO - 2018-10-27 06:04:04 --> Language Class Initialized
INFO - 2018-10-27 06:04:04 --> Loader Class Initialized
INFO - 2018-10-27 06:04:04 --> Helper loaded: url_helper
INFO - 2018-10-27 06:04:04 --> Database Driver Class Initialized
INFO - 2018-10-27 06:04:04 --> Helper loaded: form_helper
INFO - 2018-10-27 06:04:04 --> Form Validation Class Initialized
INFO - 2018-10-27 06:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:04:04 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:04:04 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:04:04 --> Email Class Initialized
INFO - 2018-10-27 06:04:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:04:04 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:04:04 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:04:04 --> Helper loaded: date_helper
INFO - 2018-10-27 06:04:04 --> Database Driver Class Initialized
INFO - 2018-10-27 06:04:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:04:04 --> Controller Class Initialized
INFO - 2018-10-27 06:04:04 --> Model "Item_model" initialized
INFO - 2018-10-27 06:04:04 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:04:04 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:04:04 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:04:04 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:04:04 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 06:04:04 --> Final output sent to browser
DEBUG - 2018-10-27 06:04:04 --> Total execution time: 0.4817
INFO - 2018-10-27 06:04:04 --> Config Class Initialized
INFO - 2018-10-27 06:04:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:04:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:04:04 --> Utf8 Class Initialized
INFO - 2018-10-27 06:04:04 --> URI Class Initialized
INFO - 2018-10-27 06:04:04 --> Router Class Initialized
INFO - 2018-10-27 06:04:04 --> Output Class Initialized
INFO - 2018-10-27 06:04:04 --> Security Class Initialized
DEBUG - 2018-10-27 06:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:04:04 --> Input Class Initialized
INFO - 2018-10-27 06:04:04 --> Language Class Initialized
ERROR - 2018-10-27 06:04:04 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:04:07 --> Config Class Initialized
INFO - 2018-10-27 06:04:07 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:04:07 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:04:07 --> Utf8 Class Initialized
INFO - 2018-10-27 06:04:07 --> URI Class Initialized
INFO - 2018-10-27 06:04:07 --> Router Class Initialized
INFO - 2018-10-27 06:04:07 --> Output Class Initialized
INFO - 2018-10-27 06:04:07 --> Security Class Initialized
DEBUG - 2018-10-27 06:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:04:07 --> Input Class Initialized
INFO - 2018-10-27 06:04:07 --> Language Class Initialized
INFO - 2018-10-27 06:04:07 --> Loader Class Initialized
INFO - 2018-10-27 06:04:07 --> Helper loaded: url_helper
INFO - 2018-10-27 06:04:07 --> Database Driver Class Initialized
INFO - 2018-10-27 06:04:07 --> Helper loaded: form_helper
INFO - 2018-10-27 06:04:07 --> Form Validation Class Initialized
INFO - 2018-10-27 06:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:04:07 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:04:07 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:04:07 --> Email Class Initialized
INFO - 2018-10-27 06:04:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:04:07 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:04:07 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:04:07 --> Helper loaded: date_helper
INFO - 2018-10-27 06:04:07 --> Database Driver Class Initialized
INFO - 2018-10-27 06:04:07 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:04:07 --> Controller Class Initialized
INFO - 2018-10-27 06:04:07 --> Model "Item_model" initialized
INFO - 2018-10-27 06:04:07 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:04:07 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:04:07 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:04:07 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:04:54 --> Config Class Initialized
INFO - 2018-10-27 06:04:54 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:04:54 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:04:54 --> Utf8 Class Initialized
INFO - 2018-10-27 06:04:54 --> URI Class Initialized
INFO - 2018-10-27 06:04:54 --> Router Class Initialized
INFO - 2018-10-27 06:04:54 --> Output Class Initialized
INFO - 2018-10-27 06:04:54 --> Security Class Initialized
DEBUG - 2018-10-27 06:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:04:54 --> Input Class Initialized
INFO - 2018-10-27 06:04:54 --> Language Class Initialized
INFO - 2018-10-27 06:04:54 --> Loader Class Initialized
INFO - 2018-10-27 06:04:54 --> Helper loaded: url_helper
INFO - 2018-10-27 06:04:54 --> Database Driver Class Initialized
INFO - 2018-10-27 06:04:54 --> Helper loaded: form_helper
INFO - 2018-10-27 06:04:54 --> Form Validation Class Initialized
INFO - 2018-10-27 06:04:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:04:54 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:04:54 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:04:54 --> Email Class Initialized
INFO - 2018-10-27 06:04:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:04:54 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:04:54 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:04:55 --> Helper loaded: date_helper
INFO - 2018-10-27 06:04:55 --> Database Driver Class Initialized
INFO - 2018-10-27 06:04:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:04:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:04:55 --> Controller Class Initialized
INFO - 2018-10-27 06:04:55 --> Model "Item_model" initialized
INFO - 2018-10-27 06:04:55 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:04:55 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:04:55 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:04:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:05:39 --> Config Class Initialized
INFO - 2018-10-27 06:05:39 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:05:39 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:05:39 --> Utf8 Class Initialized
INFO - 2018-10-27 06:05:39 --> URI Class Initialized
INFO - 2018-10-27 06:05:39 --> Router Class Initialized
INFO - 2018-10-27 06:05:39 --> Output Class Initialized
INFO - 2018-10-27 06:05:39 --> Security Class Initialized
DEBUG - 2018-10-27 06:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:05:39 --> Input Class Initialized
INFO - 2018-10-27 06:05:39 --> Language Class Initialized
INFO - 2018-10-27 06:05:39 --> Loader Class Initialized
INFO - 2018-10-27 06:05:39 --> Helper loaded: url_helper
INFO - 2018-10-27 06:05:39 --> Database Driver Class Initialized
INFO - 2018-10-27 06:05:39 --> Helper loaded: form_helper
INFO - 2018-10-27 06:05:39 --> Form Validation Class Initialized
INFO - 2018-10-27 06:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:05:39 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:05:39 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:05:39 --> Email Class Initialized
INFO - 2018-10-27 06:05:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:05:39 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:05:39 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:05:39 --> Helper loaded: date_helper
INFO - 2018-10-27 06:05:39 --> Database Driver Class Initialized
INFO - 2018-10-27 06:05:39 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:05:39 --> Controller Class Initialized
INFO - 2018-10-27 06:05:39 --> Model "Item_model" initialized
INFO - 2018-10-27 06:05:39 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:05:39 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:05:39 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:05:39 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:06:02 --> Config Class Initialized
INFO - 2018-10-27 06:06:02 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:06:02 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:06:02 --> Utf8 Class Initialized
INFO - 2018-10-27 06:06:02 --> URI Class Initialized
INFO - 2018-10-27 06:06:02 --> Router Class Initialized
INFO - 2018-10-27 06:06:02 --> Output Class Initialized
INFO - 2018-10-27 06:06:02 --> Security Class Initialized
DEBUG - 2018-10-27 06:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:06:02 --> Input Class Initialized
INFO - 2018-10-27 06:06:02 --> Language Class Initialized
INFO - 2018-10-27 06:06:02 --> Loader Class Initialized
INFO - 2018-10-27 06:06:02 --> Helper loaded: url_helper
INFO - 2018-10-27 06:06:02 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:02 --> Helper loaded: form_helper
INFO - 2018-10-27 06:06:02 --> Form Validation Class Initialized
INFO - 2018-10-27 06:06:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:06:02 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:06:02 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:06:02 --> Email Class Initialized
INFO - 2018-10-27 06:06:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:06:02 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:06:02 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:06:02 --> Helper loaded: date_helper
INFO - 2018-10-27 06:06:02 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:02 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:06:02 --> Controller Class Initialized
INFO - 2018-10-27 06:06:02 --> Model "Item_model" initialized
INFO - 2018-10-27 06:06:02 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:06:02 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:06:02 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:06:02 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:06:36 --> Config Class Initialized
INFO - 2018-10-27 06:06:36 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:06:36 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:06:36 --> Utf8 Class Initialized
INFO - 2018-10-27 06:06:36 --> URI Class Initialized
INFO - 2018-10-27 06:06:36 --> Router Class Initialized
INFO - 2018-10-27 06:06:36 --> Output Class Initialized
INFO - 2018-10-27 06:06:36 --> Security Class Initialized
DEBUG - 2018-10-27 06:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:06:37 --> Input Class Initialized
INFO - 2018-10-27 06:06:37 --> Language Class Initialized
INFO - 2018-10-27 06:06:37 --> Loader Class Initialized
INFO - 2018-10-27 06:06:37 --> Helper loaded: url_helper
INFO - 2018-10-27 06:06:37 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:37 --> Helper loaded: form_helper
INFO - 2018-10-27 06:06:37 --> Form Validation Class Initialized
INFO - 2018-10-27 06:06:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:06:37 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:06:37 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:06:37 --> Email Class Initialized
INFO - 2018-10-27 06:06:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:06:37 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:06:37 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:06:37 --> Helper loaded: date_helper
INFO - 2018-10-27 06:06:37 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:37 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:06:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:06:37 --> Controller Class Initialized
INFO - 2018-10-27 06:06:37 --> Model "Item_model" initialized
INFO - 2018-10-27 06:06:37 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:06:37 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:06:37 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:06:37 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:06:59 --> Config Class Initialized
INFO - 2018-10-27 06:06:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:06:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:06:59 --> Utf8 Class Initialized
INFO - 2018-10-27 06:06:59 --> URI Class Initialized
INFO - 2018-10-27 06:06:59 --> Router Class Initialized
INFO - 2018-10-27 06:06:59 --> Output Class Initialized
INFO - 2018-10-27 06:06:59 --> Security Class Initialized
DEBUG - 2018-10-27 06:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:06:59 --> Input Class Initialized
INFO - 2018-10-27 06:06:59 --> Language Class Initialized
INFO - 2018-10-27 06:06:59 --> Loader Class Initialized
INFO - 2018-10-27 06:06:59 --> Helper loaded: url_helper
INFO - 2018-10-27 06:06:59 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:59 --> Helper loaded: form_helper
INFO - 2018-10-27 06:06:59 --> Form Validation Class Initialized
INFO - 2018-10-27 06:06:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:06:59 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:06:59 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:06:59 --> Email Class Initialized
INFO - 2018-10-27 06:06:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:06:59 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:06:59 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:06:59 --> Helper loaded: date_helper
INFO - 2018-10-27 06:06:59 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:59 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:06:59 --> Controller Class Initialized
INFO - 2018-10-27 06:06:59 --> Model "Item_model" initialized
INFO - 2018-10-27 06:06:59 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:06:59 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:06:59 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:07:00 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:07:17 --> Config Class Initialized
INFO - 2018-10-27 06:07:17 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:07:17 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:07:17 --> Utf8 Class Initialized
INFO - 2018-10-27 06:07:17 --> URI Class Initialized
INFO - 2018-10-27 06:07:17 --> Router Class Initialized
INFO - 2018-10-27 06:07:18 --> Output Class Initialized
INFO - 2018-10-27 06:07:18 --> Security Class Initialized
DEBUG - 2018-10-27 06:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:07:18 --> Input Class Initialized
INFO - 2018-10-27 06:07:18 --> Language Class Initialized
INFO - 2018-10-27 06:07:18 --> Loader Class Initialized
INFO - 2018-10-27 06:07:18 --> Helper loaded: url_helper
INFO - 2018-10-27 06:07:18 --> Database Driver Class Initialized
INFO - 2018-10-27 06:07:18 --> Helper loaded: form_helper
INFO - 2018-10-27 06:07:18 --> Form Validation Class Initialized
INFO - 2018-10-27 06:07:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:07:18 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:07:18 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:07:18 --> Email Class Initialized
INFO - 2018-10-27 06:07:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:07:18 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:07:18 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:07:18 --> Helper loaded: date_helper
INFO - 2018-10-27 06:07:18 --> Database Driver Class Initialized
INFO - 2018-10-27 06:07:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:07:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:07:18 --> Controller Class Initialized
INFO - 2018-10-27 06:07:18 --> Model "Item_model" initialized
INFO - 2018-10-27 06:07:18 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:07:18 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:07:18 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:07:18 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:07:18 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 06:07:18 --> Final output sent to browser
DEBUG - 2018-10-27 06:07:18 --> Total execution time: 0.5108
INFO - 2018-10-27 06:07:22 --> Config Class Initialized
INFO - 2018-10-27 06:07:22 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:07:22 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:07:22 --> Utf8 Class Initialized
INFO - 2018-10-27 06:07:23 --> URI Class Initialized
INFO - 2018-10-27 06:07:23 --> Router Class Initialized
INFO - 2018-10-27 06:07:23 --> Output Class Initialized
INFO - 2018-10-27 06:07:23 --> Security Class Initialized
DEBUG - 2018-10-27 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:07:23 --> Input Class Initialized
INFO - 2018-10-27 06:07:23 --> Language Class Initialized
INFO - 2018-10-27 06:07:23 --> Loader Class Initialized
INFO - 2018-10-27 06:07:23 --> Helper loaded: url_helper
INFO - 2018-10-27 06:07:23 --> Database Driver Class Initialized
INFO - 2018-10-27 06:07:23 --> Helper loaded: form_helper
INFO - 2018-10-27 06:07:23 --> Form Validation Class Initialized
INFO - 2018-10-27 06:07:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:07:23 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:07:23 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:07:23 --> Email Class Initialized
INFO - 2018-10-27 06:07:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:07:23 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:07:23 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:07:23 --> Helper loaded: date_helper
INFO - 2018-10-27 06:07:23 --> Database Driver Class Initialized
INFO - 2018-10-27 06:07:23 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:07:23 --> Controller Class Initialized
INFO - 2018-10-27 06:07:23 --> Model "Item_model" initialized
INFO - 2018-10-27 06:07:23 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:07:23 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:07:23 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:07:23 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:07:23 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 06:07:23 --> Final output sent to browser
DEBUG - 2018-10-27 06:07:23 --> Total execution time: 0.4874
INFO - 2018-10-27 06:07:23 --> Config Class Initialized
INFO - 2018-10-27 06:07:23 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:07:23 --> Utf8 Class Initialized
INFO - 2018-10-27 06:07:23 --> URI Class Initialized
INFO - 2018-10-27 06:07:23 --> Router Class Initialized
INFO - 2018-10-27 06:07:23 --> Output Class Initialized
INFO - 2018-10-27 06:07:23 --> Security Class Initialized
DEBUG - 2018-10-27 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:07:23 --> Input Class Initialized
INFO - 2018-10-27 06:07:23 --> Language Class Initialized
ERROR - 2018-10-27 06:07:23 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:07:25 --> Config Class Initialized
INFO - 2018-10-27 06:07:25 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:07:25 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:07:25 --> Utf8 Class Initialized
INFO - 2018-10-27 06:07:25 --> URI Class Initialized
INFO - 2018-10-27 06:07:25 --> Router Class Initialized
INFO - 2018-10-27 06:07:25 --> Output Class Initialized
INFO - 2018-10-27 06:07:25 --> Security Class Initialized
DEBUG - 2018-10-27 06:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:07:25 --> Input Class Initialized
INFO - 2018-10-27 06:07:25 --> Language Class Initialized
INFO - 2018-10-27 06:07:25 --> Loader Class Initialized
INFO - 2018-10-27 06:07:25 --> Helper loaded: url_helper
INFO - 2018-10-27 06:07:25 --> Database Driver Class Initialized
INFO - 2018-10-27 06:07:25 --> Helper loaded: form_helper
INFO - 2018-10-27 06:07:25 --> Form Validation Class Initialized
INFO - 2018-10-27 06:07:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:07:25 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:07:25 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:07:25 --> Email Class Initialized
INFO - 2018-10-27 06:07:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:07:25 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:07:25 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:07:25 --> Helper loaded: date_helper
INFO - 2018-10-27 06:07:25 --> Database Driver Class Initialized
INFO - 2018-10-27 06:07:25 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:07:25 --> Controller Class Initialized
INFO - 2018-10-27 06:07:25 --> Model "Item_model" initialized
INFO - 2018-10-27 06:07:25 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:07:25 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:07:25 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:07:25 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:13:04 --> Config Class Initialized
INFO - 2018-10-27 06:13:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:13:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:13:04 --> Utf8 Class Initialized
INFO - 2018-10-27 06:13:04 --> URI Class Initialized
INFO - 2018-10-27 06:13:04 --> Router Class Initialized
INFO - 2018-10-27 06:13:04 --> Output Class Initialized
INFO - 2018-10-27 06:13:04 --> Security Class Initialized
DEBUG - 2018-10-27 06:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:13:04 --> Input Class Initialized
INFO - 2018-10-27 06:13:04 --> Language Class Initialized
INFO - 2018-10-27 06:13:04 --> Loader Class Initialized
INFO - 2018-10-27 06:13:04 --> Helper loaded: url_helper
INFO - 2018-10-27 06:13:04 --> Database Driver Class Initialized
INFO - 2018-10-27 06:13:04 --> Helper loaded: form_helper
INFO - 2018-10-27 06:13:04 --> Form Validation Class Initialized
INFO - 2018-10-27 06:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:13:04 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:13:04 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:13:04 --> Email Class Initialized
INFO - 2018-10-27 06:13:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:13:04 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:13:04 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:13:04 --> Helper loaded: date_helper
INFO - 2018-10-27 06:13:04 --> Database Driver Class Initialized
INFO - 2018-10-27 06:13:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:13:04 --> Controller Class Initialized
INFO - 2018-10-27 06:13:04 --> Model "Item_model" initialized
INFO - 2018-10-27 06:13:04 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:13:04 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:13:04 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:13:04 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:13:04 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 06:13:04 --> Final output sent to browser
INFO - 2018-10-27 06:13:04 --> Config Class Initialized
INFO - 2018-10-27 06:13:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:13:04 --> Total execution time: 0.5231
DEBUG - 2018-10-27 06:13:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:13:04 --> Utf8 Class Initialized
INFO - 2018-10-27 06:13:04 --> URI Class Initialized
INFO - 2018-10-27 06:13:04 --> Router Class Initialized
INFO - 2018-10-27 06:13:04 --> Output Class Initialized
INFO - 2018-10-27 06:13:04 --> Security Class Initialized
DEBUG - 2018-10-27 06:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:13:04 --> Input Class Initialized
INFO - 2018-10-27 06:13:04 --> Language Class Initialized
INFO - 2018-10-27 06:13:04 --> Loader Class Initialized
INFO - 2018-10-27 06:13:04 --> Helper loaded: url_helper
INFO - 2018-10-27 06:13:04 --> Database Driver Class Initialized
INFO - 2018-10-27 06:13:04 --> Helper loaded: form_helper
INFO - 2018-10-27 06:13:04 --> Form Validation Class Initialized
INFO - 2018-10-27 06:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:13:04 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:13:04 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:13:04 --> Email Class Initialized
INFO - 2018-10-27 06:13:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:13:04 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:13:04 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:13:04 --> Helper loaded: date_helper
INFO - 2018-10-27 06:13:04 --> Database Driver Class Initialized
INFO - 2018-10-27 06:13:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:13:04 --> Controller Class Initialized
INFO - 2018-10-27 06:13:04 --> Model "Item_model" initialized
INFO - 2018-10-27 06:13:04 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:13:04 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:13:05 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:13:05 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:13:05 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 06:13:05 --> Final output sent to browser
DEBUG - 2018-10-27 06:13:05 --> Total execution time: 0.4757
INFO - 2018-10-27 06:13:09 --> Config Class Initialized
INFO - 2018-10-27 06:13:09 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:13:09 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:13:09 --> Utf8 Class Initialized
INFO - 2018-10-27 06:13:09 --> URI Class Initialized
INFO - 2018-10-27 06:13:09 --> Router Class Initialized
INFO - 2018-10-27 06:13:09 --> Output Class Initialized
INFO - 2018-10-27 06:13:09 --> Security Class Initialized
DEBUG - 2018-10-27 06:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:13:09 --> Input Class Initialized
INFO - 2018-10-27 06:13:09 --> Language Class Initialized
INFO - 2018-10-27 06:13:09 --> Loader Class Initialized
INFO - 2018-10-27 06:13:09 --> Helper loaded: url_helper
INFO - 2018-10-27 06:13:09 --> Database Driver Class Initialized
INFO - 2018-10-27 06:13:09 --> Helper loaded: form_helper
INFO - 2018-10-27 06:13:09 --> Form Validation Class Initialized
INFO - 2018-10-27 06:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:13:09 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:13:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:13:09 --> Email Class Initialized
INFO - 2018-10-27 06:13:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:13:09 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:13:09 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:13:09 --> Helper loaded: date_helper
INFO - 2018-10-27 06:13:09 --> Database Driver Class Initialized
INFO - 2018-10-27 06:13:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:13:09 --> Controller Class Initialized
INFO - 2018-10-27 06:13:09 --> Model "Item_model" initialized
INFO - 2018-10-27 06:13:09 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:13:09 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:13:09 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:13:09 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:13:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 06:13:09 --> Final output sent to browser
DEBUG - 2018-10-27 06:13:09 --> Total execution time: 0.4956
INFO - 2018-10-27 06:13:09 --> Config Class Initialized
INFO - 2018-10-27 06:13:09 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:13:09 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:13:09 --> Utf8 Class Initialized
INFO - 2018-10-27 06:13:09 --> URI Class Initialized
INFO - 2018-10-27 06:13:09 --> Router Class Initialized
INFO - 2018-10-27 06:13:09 --> Output Class Initialized
INFO - 2018-10-27 06:13:09 --> Security Class Initialized
DEBUG - 2018-10-27 06:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:13:09 --> Input Class Initialized
INFO - 2018-10-27 06:13:09 --> Language Class Initialized
ERROR - 2018-10-27 06:13:09 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:13:11 --> Config Class Initialized
INFO - 2018-10-27 06:13:11 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:13:11 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:13:11 --> Utf8 Class Initialized
INFO - 2018-10-27 06:13:11 --> URI Class Initialized
INFO - 2018-10-27 06:13:11 --> Router Class Initialized
INFO - 2018-10-27 06:13:11 --> Output Class Initialized
INFO - 2018-10-27 06:13:11 --> Security Class Initialized
DEBUG - 2018-10-27 06:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:13:11 --> Input Class Initialized
INFO - 2018-10-27 06:13:11 --> Language Class Initialized
INFO - 2018-10-27 06:13:11 --> Loader Class Initialized
INFO - 2018-10-27 06:13:11 --> Helper loaded: url_helper
INFO - 2018-10-27 06:13:11 --> Database Driver Class Initialized
INFO - 2018-10-27 06:13:11 --> Helper loaded: form_helper
INFO - 2018-10-27 06:13:11 --> Form Validation Class Initialized
INFO - 2018-10-27 06:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:13:11 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:13:11 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:13:11 --> Email Class Initialized
INFO - 2018-10-27 06:13:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:13:11 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:13:11 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:13:11 --> Helper loaded: date_helper
INFO - 2018-10-27 06:13:11 --> Database Driver Class Initialized
INFO - 2018-10-27 06:13:11 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:13:11 --> Controller Class Initialized
INFO - 2018-10-27 06:13:11 --> Model "Item_model" initialized
INFO - 2018-10-27 06:13:11 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:13:11 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:13:11 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:13:11 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:13:11 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:13:11 --> Final output sent to browser
DEBUG - 2018-10-27 06:13:11 --> Total execution time: 0.4970
INFO - 2018-10-27 06:13:11 --> Config Class Initialized
INFO - 2018-10-27 06:13:11 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:13:11 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:13:11 --> Utf8 Class Initialized
INFO - 2018-10-27 06:13:11 --> URI Class Initialized
INFO - 2018-10-27 06:13:11 --> Router Class Initialized
INFO - 2018-10-27 06:13:11 --> Output Class Initialized
INFO - 2018-10-27 06:13:11 --> Security Class Initialized
DEBUG - 2018-10-27 06:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:13:11 --> Input Class Initialized
INFO - 2018-10-27 06:13:11 --> Language Class Initialized
ERROR - 2018-10-27 06:13:11 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:14:08 --> Config Class Initialized
INFO - 2018-10-27 06:14:08 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:14:08 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:14:08 --> Utf8 Class Initialized
INFO - 2018-10-27 06:14:08 --> URI Class Initialized
INFO - 2018-10-27 06:14:08 --> Router Class Initialized
INFO - 2018-10-27 06:14:08 --> Output Class Initialized
INFO - 2018-10-27 06:14:08 --> Security Class Initialized
DEBUG - 2018-10-27 06:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:14:08 --> Input Class Initialized
INFO - 2018-10-27 06:14:08 --> Language Class Initialized
INFO - 2018-10-27 06:14:08 --> Loader Class Initialized
INFO - 2018-10-27 06:14:08 --> Helper loaded: url_helper
INFO - 2018-10-27 06:14:08 --> Database Driver Class Initialized
INFO - 2018-10-27 06:14:08 --> Helper loaded: form_helper
INFO - 2018-10-27 06:14:08 --> Form Validation Class Initialized
INFO - 2018-10-27 06:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:14:09 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:14:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:14:09 --> Email Class Initialized
INFO - 2018-10-27 06:14:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:14:09 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:14:09 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:14:09 --> Helper loaded: date_helper
INFO - 2018-10-27 06:14:09 --> Database Driver Class Initialized
INFO - 2018-10-27 06:14:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:14:09 --> Controller Class Initialized
INFO - 2018-10-27 06:14:09 --> Model "Item_model" initialized
INFO - 2018-10-27 06:14:09 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:14:09 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:14:09 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:14:09 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:14:09 --> Severity: Notice --> Undefined index: notaid D:\xampp\htdocs\masterwedding\application\views\item\nota.php 27
INFO - 2018-10-27 06:14:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:14:09 --> Final output sent to browser
DEBUG - 2018-10-27 06:14:09 --> Total execution time: 0.4918
INFO - 2018-10-27 06:14:09 --> Config Class Initialized
INFO - 2018-10-27 06:14:09 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:14:09 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:14:09 --> Utf8 Class Initialized
INFO - 2018-10-27 06:14:09 --> URI Class Initialized
INFO - 2018-10-27 06:14:09 --> Router Class Initialized
INFO - 2018-10-27 06:14:09 --> Output Class Initialized
INFO - 2018-10-27 06:14:09 --> Security Class Initialized
DEBUG - 2018-10-27 06:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:14:09 --> Input Class Initialized
INFO - 2018-10-27 06:14:09 --> Language Class Initialized
ERROR - 2018-10-27 06:14:09 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:14:21 --> Config Class Initialized
INFO - 2018-10-27 06:14:21 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:14:21 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:14:21 --> Utf8 Class Initialized
INFO - 2018-10-27 06:14:21 --> URI Class Initialized
INFO - 2018-10-27 06:14:21 --> Router Class Initialized
INFO - 2018-10-27 06:14:21 --> Output Class Initialized
INFO - 2018-10-27 06:14:21 --> Security Class Initialized
DEBUG - 2018-10-27 06:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:14:21 --> Input Class Initialized
INFO - 2018-10-27 06:14:21 --> Language Class Initialized
INFO - 2018-10-27 06:14:21 --> Loader Class Initialized
INFO - 2018-10-27 06:14:21 --> Helper loaded: url_helper
INFO - 2018-10-27 06:14:21 --> Database Driver Class Initialized
INFO - 2018-10-27 06:14:21 --> Helper loaded: form_helper
INFO - 2018-10-27 06:14:21 --> Form Validation Class Initialized
INFO - 2018-10-27 06:14:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:14:21 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:14:21 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:14:21 --> Email Class Initialized
INFO - 2018-10-27 06:14:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:14:21 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:14:21 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:14:21 --> Helper loaded: date_helper
INFO - 2018-10-27 06:14:21 --> Database Driver Class Initialized
INFO - 2018-10-27 06:14:21 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:14:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:14:21 --> Controller Class Initialized
INFO - 2018-10-27 06:14:21 --> Model "Item_model" initialized
INFO - 2018-10-27 06:14:21 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:14:21 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:14:21 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:14:21 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:14:21 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:14:22 --> Final output sent to browser
DEBUG - 2018-10-27 06:14:22 --> Total execution time: 0.4946
INFO - 2018-10-27 06:14:22 --> Config Class Initialized
INFO - 2018-10-27 06:14:22 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:14:22 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:14:22 --> Utf8 Class Initialized
INFO - 2018-10-27 06:14:22 --> URI Class Initialized
INFO - 2018-10-27 06:14:22 --> Router Class Initialized
INFO - 2018-10-27 06:14:22 --> Output Class Initialized
INFO - 2018-10-27 06:14:22 --> Security Class Initialized
DEBUG - 2018-10-27 06:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:14:22 --> Input Class Initialized
INFO - 2018-10-27 06:14:22 --> Language Class Initialized
ERROR - 2018-10-27 06:14:22 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:14:31 --> Config Class Initialized
INFO - 2018-10-27 06:14:31 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:14:31 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:14:31 --> Utf8 Class Initialized
INFO - 2018-10-27 06:14:32 --> URI Class Initialized
INFO - 2018-10-27 06:14:32 --> Router Class Initialized
INFO - 2018-10-27 06:14:32 --> Output Class Initialized
INFO - 2018-10-27 06:14:32 --> Security Class Initialized
DEBUG - 2018-10-27 06:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:14:32 --> Input Class Initialized
INFO - 2018-10-27 06:14:32 --> Language Class Initialized
INFO - 2018-10-27 06:14:32 --> Loader Class Initialized
INFO - 2018-10-27 06:14:32 --> Helper loaded: url_helper
INFO - 2018-10-27 06:14:32 --> Database Driver Class Initialized
INFO - 2018-10-27 06:14:32 --> Helper loaded: form_helper
INFO - 2018-10-27 06:14:32 --> Form Validation Class Initialized
INFO - 2018-10-27 06:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:14:32 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:14:32 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:14:32 --> Email Class Initialized
INFO - 2018-10-27 06:14:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:14:32 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:14:32 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:14:32 --> Helper loaded: date_helper
INFO - 2018-10-27 06:14:32 --> Database Driver Class Initialized
INFO - 2018-10-27 06:14:32 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:14:32 --> Controller Class Initialized
INFO - 2018-10-27 06:14:32 --> Model "Item_model" initialized
INFO - 2018-10-27 06:14:32 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:14:32 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:14:32 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:14:32 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:14:32 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:14:32 --> Final output sent to browser
DEBUG - 2018-10-27 06:14:32 --> Total execution time: 0.5007
INFO - 2018-10-27 06:14:32 --> Config Class Initialized
INFO - 2018-10-27 06:14:32 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:14:32 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:14:32 --> Utf8 Class Initialized
INFO - 2018-10-27 06:14:32 --> URI Class Initialized
INFO - 2018-10-27 06:14:32 --> Router Class Initialized
INFO - 2018-10-27 06:14:32 --> Output Class Initialized
INFO - 2018-10-27 06:14:32 --> Security Class Initialized
DEBUG - 2018-10-27 06:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:14:32 --> Input Class Initialized
INFO - 2018-10-27 06:14:32 --> Language Class Initialized
ERROR - 2018-10-27 06:14:32 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:15:01 --> Config Class Initialized
INFO - 2018-10-27 06:15:01 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:15:01 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:15:01 --> Utf8 Class Initialized
INFO - 2018-10-27 06:15:01 --> URI Class Initialized
INFO - 2018-10-27 06:15:01 --> Router Class Initialized
INFO - 2018-10-27 06:15:01 --> Output Class Initialized
INFO - 2018-10-27 06:15:01 --> Security Class Initialized
DEBUG - 2018-10-27 06:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:15:01 --> Input Class Initialized
INFO - 2018-10-27 06:15:01 --> Language Class Initialized
INFO - 2018-10-27 06:15:01 --> Loader Class Initialized
INFO - 2018-10-27 06:15:01 --> Helper loaded: url_helper
INFO - 2018-10-27 06:15:01 --> Database Driver Class Initialized
INFO - 2018-10-27 06:15:01 --> Helper loaded: form_helper
INFO - 2018-10-27 06:15:01 --> Form Validation Class Initialized
INFO - 2018-10-27 06:15:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:15:01 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:15:01 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:15:01 --> Email Class Initialized
INFO - 2018-10-27 06:15:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:15:01 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:15:01 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:15:01 --> Helper loaded: date_helper
INFO - 2018-10-27 06:15:01 --> Database Driver Class Initialized
INFO - 2018-10-27 06:15:01 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:15:01 --> Controller Class Initialized
INFO - 2018-10-27 06:15:01 --> Model "Item_model" initialized
INFO - 2018-10-27 06:15:01 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:15:01 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:15:01 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:15:01 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:15:01 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:15:01 --> Final output sent to browser
DEBUG - 2018-10-27 06:15:01 --> Total execution time: 0.5054
INFO - 2018-10-27 06:15:01 --> Config Class Initialized
INFO - 2018-10-27 06:15:01 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:15:01 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:15:01 --> Utf8 Class Initialized
INFO - 2018-10-27 06:15:01 --> URI Class Initialized
INFO - 2018-10-27 06:15:01 --> Router Class Initialized
INFO - 2018-10-27 06:15:01 --> Output Class Initialized
INFO - 2018-10-27 06:15:01 --> Security Class Initialized
DEBUG - 2018-10-27 06:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:15:01 --> Input Class Initialized
INFO - 2018-10-27 06:15:01 --> Language Class Initialized
ERROR - 2018-10-27 06:15:01 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:15:14 --> Config Class Initialized
INFO - 2018-10-27 06:15:14 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:15:14 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:15:14 --> Utf8 Class Initialized
INFO - 2018-10-27 06:15:14 --> URI Class Initialized
INFO - 2018-10-27 06:15:14 --> Router Class Initialized
INFO - 2018-10-27 06:15:14 --> Output Class Initialized
INFO - 2018-10-27 06:15:14 --> Security Class Initialized
DEBUG - 2018-10-27 06:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:15:14 --> Input Class Initialized
INFO - 2018-10-27 06:15:14 --> Language Class Initialized
INFO - 2018-10-27 06:15:14 --> Loader Class Initialized
INFO - 2018-10-27 06:15:14 --> Helper loaded: url_helper
INFO - 2018-10-27 06:15:14 --> Database Driver Class Initialized
INFO - 2018-10-27 06:15:14 --> Helper loaded: form_helper
INFO - 2018-10-27 06:15:14 --> Form Validation Class Initialized
INFO - 2018-10-27 06:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:15:14 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:15:14 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:15:14 --> Email Class Initialized
INFO - 2018-10-27 06:15:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:15:14 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:15:14 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:15:15 --> Helper loaded: date_helper
INFO - 2018-10-27 06:15:15 --> Database Driver Class Initialized
INFO - 2018-10-27 06:15:15 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:15:15 --> Controller Class Initialized
INFO - 2018-10-27 06:15:15 --> Model "Item_model" initialized
INFO - 2018-10-27 06:15:15 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:15:15 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:15:15 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:15:15 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:15:15 --> Severity: Notice --> Undefined index: itemid D:\xampp\htdocs\masterwedding\application\views\item\nota.php 30
INFO - 2018-10-27 06:15:15 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:15:15 --> Final output sent to browser
DEBUG - 2018-10-27 06:15:15 --> Total execution time: 0.4852
INFO - 2018-10-27 06:15:15 --> Config Class Initialized
INFO - 2018-10-27 06:15:15 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:15:15 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:15:15 --> Utf8 Class Initialized
INFO - 2018-10-27 06:15:15 --> URI Class Initialized
INFO - 2018-10-27 06:15:15 --> Router Class Initialized
INFO - 2018-10-27 06:15:15 --> Output Class Initialized
INFO - 2018-10-27 06:15:15 --> Security Class Initialized
DEBUG - 2018-10-27 06:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:15:15 --> Input Class Initialized
INFO - 2018-10-27 06:15:15 --> Language Class Initialized
ERROR - 2018-10-27 06:15:15 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:15:20 --> Config Class Initialized
INFO - 2018-10-27 06:15:20 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:15:20 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:15:20 --> Utf8 Class Initialized
INFO - 2018-10-27 06:15:20 --> URI Class Initialized
INFO - 2018-10-27 06:15:20 --> Router Class Initialized
INFO - 2018-10-27 06:15:20 --> Output Class Initialized
INFO - 2018-10-27 06:15:20 --> Security Class Initialized
DEBUG - 2018-10-27 06:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:15:20 --> Input Class Initialized
INFO - 2018-10-27 06:15:20 --> Language Class Initialized
INFO - 2018-10-27 06:15:20 --> Loader Class Initialized
INFO - 2018-10-27 06:15:20 --> Helper loaded: url_helper
INFO - 2018-10-27 06:15:20 --> Database Driver Class Initialized
INFO - 2018-10-27 06:15:20 --> Helper loaded: form_helper
INFO - 2018-10-27 06:15:20 --> Form Validation Class Initialized
INFO - 2018-10-27 06:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:15:20 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:15:20 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:15:20 --> Email Class Initialized
INFO - 2018-10-27 06:15:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:15:20 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:15:20 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:15:20 --> Helper loaded: date_helper
INFO - 2018-10-27 06:15:20 --> Database Driver Class Initialized
INFO - 2018-10-27 06:15:20 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:15:20 --> Controller Class Initialized
INFO - 2018-10-27 06:15:20 --> Model "Item_model" initialized
INFO - 2018-10-27 06:15:20 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:15:20 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:15:21 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:15:21 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:15:21 --> Severity: Notice --> Undefined index: itemid D:\xampp\htdocs\masterwedding\application\views\item\nota.php 30
INFO - 2018-10-27 06:15:21 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:15:21 --> Final output sent to browser
DEBUG - 2018-10-27 06:15:21 --> Total execution time: 0.5096
INFO - 2018-10-27 06:15:21 --> Config Class Initialized
INFO - 2018-10-27 06:15:21 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:15:21 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:15:21 --> Utf8 Class Initialized
INFO - 2018-10-27 06:15:21 --> URI Class Initialized
INFO - 2018-10-27 06:15:21 --> Router Class Initialized
INFO - 2018-10-27 06:15:21 --> Output Class Initialized
INFO - 2018-10-27 06:15:21 --> Security Class Initialized
DEBUG - 2018-10-27 06:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:15:21 --> Input Class Initialized
INFO - 2018-10-27 06:15:21 --> Language Class Initialized
ERROR - 2018-10-27 06:15:21 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:15:23 --> Config Class Initialized
INFO - 2018-10-27 06:15:23 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:15:23 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:15:23 --> Utf8 Class Initialized
INFO - 2018-10-27 06:15:23 --> URI Class Initialized
INFO - 2018-10-27 06:15:23 --> Router Class Initialized
INFO - 2018-10-27 06:15:23 --> Output Class Initialized
INFO - 2018-10-27 06:15:23 --> Security Class Initialized
DEBUG - 2018-10-27 06:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:15:23 --> Input Class Initialized
INFO - 2018-10-27 06:15:23 --> Language Class Initialized
INFO - 2018-10-27 06:15:23 --> Loader Class Initialized
INFO - 2018-10-27 06:15:23 --> Helper loaded: url_helper
INFO - 2018-10-27 06:15:23 --> Database Driver Class Initialized
INFO - 2018-10-27 06:15:23 --> Helper loaded: form_helper
INFO - 2018-10-27 06:15:23 --> Form Validation Class Initialized
INFO - 2018-10-27 06:15:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:15:23 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:15:23 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:15:23 --> Email Class Initialized
INFO - 2018-10-27 06:15:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:15:23 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:15:23 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:15:23 --> Helper loaded: date_helper
INFO - 2018-10-27 06:15:23 --> Database Driver Class Initialized
INFO - 2018-10-27 06:15:23 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:15:23 --> Controller Class Initialized
INFO - 2018-10-27 06:15:23 --> Model "Item_model" initialized
INFO - 2018-10-27 06:15:23 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:15:23 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:15:23 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:15:23 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:15:23 --> Severity: Notice --> Undefined index: itemid D:\xampp\htdocs\masterwedding\application\views\item\nota.php 30
INFO - 2018-10-27 06:15:23 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:15:23 --> Final output sent to browser
DEBUG - 2018-10-27 06:15:23 --> Total execution time: 0.5263
INFO - 2018-10-27 06:15:23 --> Config Class Initialized
INFO - 2018-10-27 06:15:23 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:15:23 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:15:23 --> Utf8 Class Initialized
INFO - 2018-10-27 06:15:23 --> URI Class Initialized
INFO - 2018-10-27 06:15:23 --> Router Class Initialized
INFO - 2018-10-27 06:15:23 --> Output Class Initialized
INFO - 2018-10-27 06:15:24 --> Security Class Initialized
DEBUG - 2018-10-27 06:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:15:24 --> Input Class Initialized
INFO - 2018-10-27 06:15:24 --> Language Class Initialized
ERROR - 2018-10-27 06:15:24 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:15:58 --> Config Class Initialized
INFO - 2018-10-27 06:15:58 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:15:58 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:15:58 --> Utf8 Class Initialized
INFO - 2018-10-27 06:15:58 --> URI Class Initialized
INFO - 2018-10-27 06:15:58 --> Router Class Initialized
INFO - 2018-10-27 06:15:58 --> Output Class Initialized
INFO - 2018-10-27 06:15:58 --> Security Class Initialized
DEBUG - 2018-10-27 06:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:15:58 --> Input Class Initialized
INFO - 2018-10-27 06:15:58 --> Language Class Initialized
INFO - 2018-10-27 06:15:58 --> Loader Class Initialized
INFO - 2018-10-27 06:15:58 --> Helper loaded: url_helper
INFO - 2018-10-27 06:15:58 --> Database Driver Class Initialized
INFO - 2018-10-27 06:15:59 --> Helper loaded: form_helper
INFO - 2018-10-27 06:15:59 --> Form Validation Class Initialized
INFO - 2018-10-27 06:15:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:15:59 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:15:59 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:15:59 --> Email Class Initialized
INFO - 2018-10-27 06:15:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:15:59 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:15:59 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:15:59 --> Helper loaded: date_helper
INFO - 2018-10-27 06:15:59 --> Database Driver Class Initialized
INFO - 2018-10-27 06:15:59 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:15:59 --> Controller Class Initialized
INFO - 2018-10-27 06:15:59 --> Model "Item_model" initialized
INFO - 2018-10-27 06:15:59 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:15:59 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:15:59 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:15:59 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:15:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:15:59 --> Final output sent to browser
DEBUG - 2018-10-27 06:15:59 --> Total execution time: 0.5058
INFO - 2018-10-27 06:15:59 --> Config Class Initialized
INFO - 2018-10-27 06:15:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:15:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:15:59 --> Utf8 Class Initialized
INFO - 2018-10-27 06:15:59 --> URI Class Initialized
INFO - 2018-10-27 06:15:59 --> Router Class Initialized
INFO - 2018-10-27 06:15:59 --> Output Class Initialized
INFO - 2018-10-27 06:15:59 --> Security Class Initialized
DEBUG - 2018-10-27 06:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:15:59 --> Input Class Initialized
INFO - 2018-10-27 06:15:59 --> Language Class Initialized
ERROR - 2018-10-27 06:15:59 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:16:04 --> Config Class Initialized
INFO - 2018-10-27 06:16:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:16:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:16:04 --> Utf8 Class Initialized
INFO - 2018-10-27 06:16:04 --> URI Class Initialized
INFO - 2018-10-27 06:16:04 --> Router Class Initialized
INFO - 2018-10-27 06:16:04 --> Output Class Initialized
INFO - 2018-10-27 06:16:04 --> Security Class Initialized
DEBUG - 2018-10-27 06:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:16:04 --> Input Class Initialized
INFO - 2018-10-27 06:16:04 --> Language Class Initialized
INFO - 2018-10-27 06:16:04 --> Loader Class Initialized
INFO - 2018-10-27 06:16:04 --> Helper loaded: url_helper
INFO - 2018-10-27 06:16:04 --> Database Driver Class Initialized
INFO - 2018-10-27 06:16:04 --> Helper loaded: form_helper
INFO - 2018-10-27 06:16:04 --> Form Validation Class Initialized
INFO - 2018-10-27 06:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:16:04 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:16:04 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:16:04 --> Email Class Initialized
INFO - 2018-10-27 06:16:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:16:04 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:16:04 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:16:04 --> Helper loaded: date_helper
INFO - 2018-10-27 06:16:04 --> Database Driver Class Initialized
INFO - 2018-10-27 06:16:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:16:04 --> Controller Class Initialized
INFO - 2018-10-27 06:16:04 --> Model "Item_model" initialized
INFO - 2018-10-27 06:16:04 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:16:04 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:16:04 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:16:04 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:16:04 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:16:04 --> Final output sent to browser
DEBUG - 2018-10-27 06:16:04 --> Total execution time: 0.5003
INFO - 2018-10-27 06:16:04 --> Config Class Initialized
INFO - 2018-10-27 06:16:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:16:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:16:04 --> Utf8 Class Initialized
INFO - 2018-10-27 06:16:04 --> URI Class Initialized
INFO - 2018-10-27 06:16:04 --> Router Class Initialized
INFO - 2018-10-27 06:16:04 --> Output Class Initialized
INFO - 2018-10-27 06:16:04 --> Security Class Initialized
DEBUG - 2018-10-27 06:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:16:04 --> Input Class Initialized
INFO - 2018-10-27 06:16:04 --> Language Class Initialized
ERROR - 2018-10-27 06:16:04 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:16:19 --> Config Class Initialized
INFO - 2018-10-27 06:16:19 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:16:19 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:16:19 --> Utf8 Class Initialized
INFO - 2018-10-27 06:16:19 --> URI Class Initialized
INFO - 2018-10-27 06:16:19 --> Router Class Initialized
INFO - 2018-10-27 06:16:19 --> Output Class Initialized
INFO - 2018-10-27 06:16:19 --> Security Class Initialized
DEBUG - 2018-10-27 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:16:19 --> Input Class Initialized
INFO - 2018-10-27 06:16:19 --> Language Class Initialized
INFO - 2018-10-27 06:16:19 --> Loader Class Initialized
INFO - 2018-10-27 06:16:19 --> Helper loaded: url_helper
INFO - 2018-10-27 06:16:19 --> Database Driver Class Initialized
INFO - 2018-10-27 06:16:19 --> Helper loaded: form_helper
INFO - 2018-10-27 06:16:19 --> Form Validation Class Initialized
INFO - 2018-10-27 06:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:16:19 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:16:19 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:16:19 --> Email Class Initialized
INFO - 2018-10-27 06:16:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:16:19 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:16:19 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:16:19 --> Helper loaded: date_helper
INFO - 2018-10-27 06:16:19 --> Database Driver Class Initialized
INFO - 2018-10-27 06:16:19 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:16:19 --> Controller Class Initialized
INFO - 2018-10-27 06:16:19 --> Model "Item_model" initialized
INFO - 2018-10-27 06:16:19 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:16:19 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:16:19 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:16:19 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:16:19 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:16:19 --> Final output sent to browser
DEBUG - 2018-10-27 06:16:19 --> Total execution time: 0.5010
INFO - 2018-10-27 06:16:19 --> Config Class Initialized
INFO - 2018-10-27 06:16:19 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:16:19 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:16:19 --> Utf8 Class Initialized
INFO - 2018-10-27 06:16:19 --> URI Class Initialized
INFO - 2018-10-27 06:16:19 --> Router Class Initialized
INFO - 2018-10-27 06:16:19 --> Output Class Initialized
INFO - 2018-10-27 06:16:19 --> Security Class Initialized
DEBUG - 2018-10-27 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:16:19 --> Input Class Initialized
INFO - 2018-10-27 06:16:19 --> Language Class Initialized
ERROR - 2018-10-27 06:16:19 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:17:14 --> Config Class Initialized
INFO - 2018-10-27 06:17:14 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:17:14 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:17:14 --> Utf8 Class Initialized
INFO - 2018-10-27 06:17:14 --> URI Class Initialized
INFO - 2018-10-27 06:17:14 --> Router Class Initialized
INFO - 2018-10-27 06:17:14 --> Output Class Initialized
INFO - 2018-10-27 06:17:14 --> Security Class Initialized
DEBUG - 2018-10-27 06:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:17:14 --> Input Class Initialized
INFO - 2018-10-27 06:17:14 --> Language Class Initialized
INFO - 2018-10-27 06:17:14 --> Loader Class Initialized
INFO - 2018-10-27 06:17:14 --> Helper loaded: url_helper
INFO - 2018-10-27 06:17:14 --> Database Driver Class Initialized
INFO - 2018-10-27 06:17:14 --> Helper loaded: form_helper
INFO - 2018-10-27 06:17:14 --> Form Validation Class Initialized
INFO - 2018-10-27 06:17:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:17:14 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:17:14 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:17:14 --> Email Class Initialized
INFO - 2018-10-27 06:17:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:17:14 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:17:14 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:17:14 --> Helper loaded: date_helper
INFO - 2018-10-27 06:17:14 --> Database Driver Class Initialized
INFO - 2018-10-27 06:17:14 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:17:14 --> Controller Class Initialized
INFO - 2018-10-27 06:17:14 --> Model "Item_model" initialized
INFO - 2018-10-27 06:17:14 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:17:14 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:17:14 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:17:14 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:17:14 --> Severity: Notice --> Undefined variable: subtotal D:\xampp\htdocs\masterwedding\application\views\item\nota.php 38
INFO - 2018-10-27 06:17:14 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:17:14 --> Final output sent to browser
DEBUG - 2018-10-27 06:17:14 --> Total execution time: 0.5427
INFO - 2018-10-27 06:17:14 --> Config Class Initialized
INFO - 2018-10-27 06:17:14 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:17:14 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:17:14 --> Utf8 Class Initialized
INFO - 2018-10-27 06:17:14 --> URI Class Initialized
INFO - 2018-10-27 06:17:14 --> Router Class Initialized
INFO - 2018-10-27 06:17:14 --> Output Class Initialized
INFO - 2018-10-27 06:17:14 --> Security Class Initialized
DEBUG - 2018-10-27 06:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:17:14 --> Input Class Initialized
INFO - 2018-10-27 06:17:14 --> Language Class Initialized
ERROR - 2018-10-27 06:17:14 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:17:55 --> Config Class Initialized
INFO - 2018-10-27 06:17:55 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:17:55 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:17:55 --> Utf8 Class Initialized
INFO - 2018-10-27 06:17:55 --> URI Class Initialized
INFO - 2018-10-27 06:17:55 --> Router Class Initialized
INFO - 2018-10-27 06:17:55 --> Output Class Initialized
INFO - 2018-10-27 06:17:55 --> Security Class Initialized
DEBUG - 2018-10-27 06:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:17:55 --> Input Class Initialized
INFO - 2018-10-27 06:17:55 --> Language Class Initialized
INFO - 2018-10-27 06:17:56 --> Loader Class Initialized
INFO - 2018-10-27 06:17:56 --> Helper loaded: url_helper
INFO - 2018-10-27 06:17:56 --> Database Driver Class Initialized
INFO - 2018-10-27 06:17:56 --> Helper loaded: form_helper
INFO - 2018-10-27 06:17:56 --> Form Validation Class Initialized
INFO - 2018-10-27 06:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:17:56 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:17:56 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:17:56 --> Email Class Initialized
INFO - 2018-10-27 06:17:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:17:56 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:17:56 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:17:56 --> Helper loaded: date_helper
INFO - 2018-10-27 06:17:56 --> Database Driver Class Initialized
INFO - 2018-10-27 06:17:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:17:56 --> Controller Class Initialized
INFO - 2018-10-27 06:17:56 --> Model "Item_model" initialized
INFO - 2018-10-27 06:17:56 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:17:56 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:17:56 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:17:56 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:17:56 --> Severity: error --> Exception: Function name must be a string D:\xampp\htdocs\masterwedding\application\views\item\nota.php 38
INFO - 2018-10-27 06:17:56 --> Config Class Initialized
INFO - 2018-10-27 06:17:56 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:17:56 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:17:56 --> Utf8 Class Initialized
INFO - 2018-10-27 06:17:56 --> URI Class Initialized
INFO - 2018-10-27 06:17:56 --> Router Class Initialized
INFO - 2018-10-27 06:17:56 --> Output Class Initialized
INFO - 2018-10-27 06:17:56 --> Security Class Initialized
DEBUG - 2018-10-27 06:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:17:56 --> Input Class Initialized
INFO - 2018-10-27 06:17:56 --> Language Class Initialized
ERROR - 2018-10-27 06:17:56 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:18:07 --> Config Class Initialized
INFO - 2018-10-27 06:18:08 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:18:08 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:18:08 --> Utf8 Class Initialized
INFO - 2018-10-27 06:18:08 --> URI Class Initialized
INFO - 2018-10-27 06:18:08 --> Router Class Initialized
INFO - 2018-10-27 06:18:08 --> Output Class Initialized
INFO - 2018-10-27 06:18:08 --> Security Class Initialized
DEBUG - 2018-10-27 06:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:18:08 --> Input Class Initialized
INFO - 2018-10-27 06:18:08 --> Language Class Initialized
INFO - 2018-10-27 06:18:08 --> Loader Class Initialized
INFO - 2018-10-27 06:18:08 --> Helper loaded: url_helper
INFO - 2018-10-27 06:18:08 --> Database Driver Class Initialized
INFO - 2018-10-27 06:18:08 --> Helper loaded: form_helper
INFO - 2018-10-27 06:18:08 --> Form Validation Class Initialized
INFO - 2018-10-27 06:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:18:08 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:18:08 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:18:08 --> Email Class Initialized
INFO - 2018-10-27 06:18:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:18:08 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:18:08 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:18:08 --> Helper loaded: date_helper
INFO - 2018-10-27 06:18:08 --> Database Driver Class Initialized
INFO - 2018-10-27 06:18:08 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:18:08 --> Controller Class Initialized
INFO - 2018-10-27 06:18:08 --> Model "Item_model" initialized
INFO - 2018-10-27 06:18:08 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:18:08 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:18:08 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:18:08 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:18:08 --> Severity: error --> Exception: Function name must be a string D:\xampp\htdocs\masterwedding\application\views\item\nota.php 38
INFO - 2018-10-27 06:18:08 --> Config Class Initialized
INFO - 2018-10-27 06:18:08 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:18:08 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:18:08 --> Utf8 Class Initialized
INFO - 2018-10-27 06:18:08 --> URI Class Initialized
INFO - 2018-10-27 06:18:08 --> Router Class Initialized
INFO - 2018-10-27 06:18:08 --> Output Class Initialized
INFO - 2018-10-27 06:18:08 --> Security Class Initialized
DEBUG - 2018-10-27 06:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:18:08 --> Input Class Initialized
INFO - 2018-10-27 06:18:08 --> Language Class Initialized
ERROR - 2018-10-27 06:18:08 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:18:11 --> Config Class Initialized
INFO - 2018-10-27 06:18:11 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:18:11 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:18:11 --> Utf8 Class Initialized
INFO - 2018-10-27 06:18:11 --> URI Class Initialized
INFO - 2018-10-27 06:18:11 --> Router Class Initialized
INFO - 2018-10-27 06:18:11 --> Output Class Initialized
INFO - 2018-10-27 06:18:11 --> Security Class Initialized
DEBUG - 2018-10-27 06:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:18:11 --> Input Class Initialized
INFO - 2018-10-27 06:18:11 --> Language Class Initialized
INFO - 2018-10-27 06:18:11 --> Loader Class Initialized
INFO - 2018-10-27 06:18:11 --> Helper loaded: url_helper
INFO - 2018-10-27 06:18:11 --> Database Driver Class Initialized
INFO - 2018-10-27 06:18:11 --> Helper loaded: form_helper
INFO - 2018-10-27 06:18:11 --> Form Validation Class Initialized
INFO - 2018-10-27 06:18:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:18:11 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:18:11 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:18:11 --> Email Class Initialized
INFO - 2018-10-27 06:18:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:18:11 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:18:11 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:18:11 --> Helper loaded: date_helper
INFO - 2018-10-27 06:18:11 --> Database Driver Class Initialized
INFO - 2018-10-27 06:18:11 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:18:11 --> Controller Class Initialized
INFO - 2018-10-27 06:18:11 --> Model "Item_model" initialized
INFO - 2018-10-27 06:18:11 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:18:11 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:18:11 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:18:11 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:18:11 --> Severity: error --> Exception: Function name must be a string D:\xampp\htdocs\masterwedding\application\views\item\nota.php 38
INFO - 2018-10-27 06:18:11 --> Config Class Initialized
INFO - 2018-10-27 06:18:11 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:18:11 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:18:11 --> Utf8 Class Initialized
INFO - 2018-10-27 06:18:11 --> URI Class Initialized
INFO - 2018-10-27 06:18:11 --> Router Class Initialized
INFO - 2018-10-27 06:18:11 --> Output Class Initialized
INFO - 2018-10-27 06:18:11 --> Security Class Initialized
DEBUG - 2018-10-27 06:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:18:11 --> Input Class Initialized
INFO - 2018-10-27 06:18:11 --> Language Class Initialized
ERROR - 2018-10-27 06:18:11 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:18:11 --> Config Class Initialized
INFO - 2018-10-27 06:18:11 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:18:12 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:18:12 --> Utf8 Class Initialized
INFO - 2018-10-27 06:18:12 --> URI Class Initialized
INFO - 2018-10-27 06:18:12 --> Router Class Initialized
INFO - 2018-10-27 06:18:12 --> Output Class Initialized
INFO - 2018-10-27 06:18:12 --> Security Class Initialized
DEBUG - 2018-10-27 06:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:18:12 --> Input Class Initialized
INFO - 2018-10-27 06:18:12 --> Language Class Initialized
INFO - 2018-10-27 06:18:12 --> Loader Class Initialized
INFO - 2018-10-27 06:18:12 --> Helper loaded: url_helper
INFO - 2018-10-27 06:18:12 --> Database Driver Class Initialized
INFO - 2018-10-27 06:18:12 --> Helper loaded: form_helper
INFO - 2018-10-27 06:18:12 --> Form Validation Class Initialized
INFO - 2018-10-27 06:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:18:12 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:18:12 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:18:12 --> Email Class Initialized
INFO - 2018-10-27 06:18:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:18:12 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:18:12 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:18:12 --> Helper loaded: date_helper
INFO - 2018-10-27 06:18:12 --> Database Driver Class Initialized
INFO - 2018-10-27 06:18:12 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:18:12 --> Controller Class Initialized
INFO - 2018-10-27 06:18:12 --> Model "Item_model" initialized
INFO - 2018-10-27 06:18:12 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:18:12 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:18:12 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:18:12 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:18:12 --> Severity: error --> Exception: Function name must be a string D:\xampp\htdocs\masterwedding\application\views\item\nota.php 38
INFO - 2018-10-27 06:18:12 --> Config Class Initialized
INFO - 2018-10-27 06:18:12 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:18:12 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:18:12 --> Utf8 Class Initialized
INFO - 2018-10-27 06:18:12 --> URI Class Initialized
INFO - 2018-10-27 06:18:12 --> Router Class Initialized
INFO - 2018-10-27 06:18:12 --> Output Class Initialized
INFO - 2018-10-27 06:18:12 --> Security Class Initialized
DEBUG - 2018-10-27 06:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:18:12 --> Input Class Initialized
INFO - 2018-10-27 06:18:12 --> Language Class Initialized
ERROR - 2018-10-27 06:18:12 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:19:27 --> Config Class Initialized
INFO - 2018-10-27 06:19:27 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:19:27 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:19:27 --> Utf8 Class Initialized
INFO - 2018-10-27 06:19:27 --> URI Class Initialized
INFO - 2018-10-27 06:19:27 --> Router Class Initialized
INFO - 2018-10-27 06:19:27 --> Output Class Initialized
INFO - 2018-10-27 06:19:27 --> Security Class Initialized
DEBUG - 2018-10-27 06:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:19:27 --> Input Class Initialized
INFO - 2018-10-27 06:19:27 --> Language Class Initialized
INFO - 2018-10-27 06:19:27 --> Loader Class Initialized
INFO - 2018-10-27 06:19:27 --> Helper loaded: url_helper
INFO - 2018-10-27 06:19:27 --> Database Driver Class Initialized
INFO - 2018-10-27 06:19:27 --> Helper loaded: form_helper
INFO - 2018-10-27 06:19:27 --> Form Validation Class Initialized
INFO - 2018-10-27 06:19:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:19:27 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:19:27 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:19:27 --> Email Class Initialized
INFO - 2018-10-27 06:19:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:19:27 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:19:27 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:19:27 --> Helper loaded: date_helper
INFO - 2018-10-27 06:19:27 --> Database Driver Class Initialized
INFO - 2018-10-27 06:19:27 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:19:27 --> Controller Class Initialized
INFO - 2018-10-27 06:19:27 --> Model "Item_model" initialized
INFO - 2018-10-27 06:19:27 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:19:27 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:19:27 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:19:27 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:19:27 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:19:27 --> Final output sent to browser
DEBUG - 2018-10-27 06:19:27 --> Total execution time: 0.5480
INFO - 2018-10-27 06:19:27 --> Config Class Initialized
INFO - 2018-10-27 06:19:27 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:19:27 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:19:27 --> Utf8 Class Initialized
INFO - 2018-10-27 06:19:27 --> URI Class Initialized
INFO - 2018-10-27 06:19:27 --> Router Class Initialized
INFO - 2018-10-27 06:19:27 --> Output Class Initialized
INFO - 2018-10-27 06:19:27 --> Security Class Initialized
DEBUG - 2018-10-27 06:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:19:27 --> Input Class Initialized
INFO - 2018-10-27 06:19:27 --> Language Class Initialized
ERROR - 2018-10-27 06:19:27 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:20:58 --> Config Class Initialized
INFO - 2018-10-27 06:20:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:20:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:20:59 --> Utf8 Class Initialized
INFO - 2018-10-27 06:20:59 --> URI Class Initialized
INFO - 2018-10-27 06:20:59 --> Router Class Initialized
INFO - 2018-10-27 06:20:59 --> Output Class Initialized
INFO - 2018-10-27 06:20:59 --> Security Class Initialized
DEBUG - 2018-10-27 06:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:20:59 --> Input Class Initialized
INFO - 2018-10-27 06:20:59 --> Language Class Initialized
INFO - 2018-10-27 06:20:59 --> Loader Class Initialized
INFO - 2018-10-27 06:20:59 --> Helper loaded: url_helper
INFO - 2018-10-27 06:20:59 --> Database Driver Class Initialized
INFO - 2018-10-27 06:20:59 --> Helper loaded: form_helper
INFO - 2018-10-27 06:20:59 --> Form Validation Class Initialized
INFO - 2018-10-27 06:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:20:59 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:20:59 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:20:59 --> Email Class Initialized
INFO - 2018-10-27 06:20:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:20:59 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:20:59 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:20:59 --> Helper loaded: date_helper
INFO - 2018-10-27 06:20:59 --> Database Driver Class Initialized
INFO - 2018-10-27 06:20:59 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:20:59 --> Controller Class Initialized
INFO - 2018-10-27 06:20:59 --> Model "Item_model" initialized
INFO - 2018-10-27 06:20:59 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:20:59 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:20:59 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:20:59 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:20:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:20:59 --> Final output sent to browser
DEBUG - 2018-10-27 06:20:59 --> Total execution time: 0.5080
INFO - 2018-10-27 06:20:59 --> Config Class Initialized
INFO - 2018-10-27 06:20:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:20:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:20:59 --> Utf8 Class Initialized
INFO - 2018-10-27 06:20:59 --> URI Class Initialized
INFO - 2018-10-27 06:20:59 --> Router Class Initialized
INFO - 2018-10-27 06:20:59 --> Output Class Initialized
INFO - 2018-10-27 06:20:59 --> Security Class Initialized
DEBUG - 2018-10-27 06:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:20:59 --> Input Class Initialized
INFO - 2018-10-27 06:20:59 --> Language Class Initialized
ERROR - 2018-10-27 06:20:59 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:21:21 --> Config Class Initialized
INFO - 2018-10-27 06:21:21 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:21:21 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:21:21 --> Utf8 Class Initialized
INFO - 2018-10-27 06:21:21 --> URI Class Initialized
INFO - 2018-10-27 06:21:21 --> Router Class Initialized
INFO - 2018-10-27 06:21:21 --> Output Class Initialized
INFO - 2018-10-27 06:21:21 --> Security Class Initialized
DEBUG - 2018-10-27 06:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:21:21 --> Input Class Initialized
INFO - 2018-10-27 06:21:21 --> Language Class Initialized
INFO - 2018-10-27 06:21:21 --> Loader Class Initialized
INFO - 2018-10-27 06:21:21 --> Helper loaded: url_helper
INFO - 2018-10-27 06:21:21 --> Database Driver Class Initialized
INFO - 2018-10-27 06:21:21 --> Helper loaded: form_helper
INFO - 2018-10-27 06:21:21 --> Form Validation Class Initialized
INFO - 2018-10-27 06:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:21:21 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:21:21 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:21:21 --> Email Class Initialized
INFO - 2018-10-27 06:21:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:21:21 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:21:21 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:21:21 --> Helper loaded: date_helper
INFO - 2018-10-27 06:21:21 --> Database Driver Class Initialized
INFO - 2018-10-27 06:21:21 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:21:21 --> Controller Class Initialized
INFO - 2018-10-27 06:21:21 --> Model "Item_model" initialized
INFO - 2018-10-27 06:21:21 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:21:21 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:21:21 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:21:21 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:21:22 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\masterwedding\application\views\item\nota.php 31
INFO - 2018-10-27 06:21:59 --> Config Class Initialized
INFO - 2018-10-27 06:21:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:21:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:21:59 --> Utf8 Class Initialized
INFO - 2018-10-27 06:22:00 --> URI Class Initialized
INFO - 2018-10-27 06:22:00 --> Router Class Initialized
INFO - 2018-10-27 06:22:00 --> Output Class Initialized
INFO - 2018-10-27 06:22:00 --> Security Class Initialized
DEBUG - 2018-10-27 06:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:22:00 --> Input Class Initialized
INFO - 2018-10-27 06:22:00 --> Language Class Initialized
INFO - 2018-10-27 06:22:00 --> Loader Class Initialized
INFO - 2018-10-27 06:22:00 --> Helper loaded: url_helper
INFO - 2018-10-27 06:22:00 --> Database Driver Class Initialized
INFO - 2018-10-27 06:22:00 --> Helper loaded: form_helper
INFO - 2018-10-27 06:22:00 --> Form Validation Class Initialized
INFO - 2018-10-27 06:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:22:00 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:22:00 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:22:00 --> Email Class Initialized
INFO - 2018-10-27 06:22:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:22:00 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:22:00 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:22:00 --> Helper loaded: date_helper
INFO - 2018-10-27 06:22:00 --> Database Driver Class Initialized
INFO - 2018-10-27 06:22:00 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:22:00 --> Controller Class Initialized
INFO - 2018-10-27 06:22:00 --> Model "Item_model" initialized
INFO - 2018-10-27 06:22:00 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:22:00 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:22:00 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:22:00 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:22:00 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:22:00 --> Final output sent to browser
DEBUG - 2018-10-27 06:22:00 --> Total execution time: 0.5583
INFO - 2018-10-27 06:22:00 --> Config Class Initialized
INFO - 2018-10-27 06:22:00 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:22:00 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:22:00 --> Utf8 Class Initialized
INFO - 2018-10-27 06:22:00 --> URI Class Initialized
INFO - 2018-10-27 06:22:00 --> Router Class Initialized
INFO - 2018-10-27 06:22:00 --> Output Class Initialized
INFO - 2018-10-27 06:22:00 --> Security Class Initialized
DEBUG - 2018-10-27 06:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:22:00 --> Input Class Initialized
INFO - 2018-10-27 06:22:00 --> Language Class Initialized
ERROR - 2018-10-27 06:22:00 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:22:16 --> Config Class Initialized
INFO - 2018-10-27 06:22:16 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:22:16 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:22:16 --> Utf8 Class Initialized
INFO - 2018-10-27 06:22:16 --> URI Class Initialized
INFO - 2018-10-27 06:22:16 --> Router Class Initialized
INFO - 2018-10-27 06:22:16 --> Output Class Initialized
INFO - 2018-10-27 06:22:16 --> Security Class Initialized
DEBUG - 2018-10-27 06:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:22:16 --> Input Class Initialized
INFO - 2018-10-27 06:22:17 --> Language Class Initialized
INFO - 2018-10-27 06:22:17 --> Loader Class Initialized
INFO - 2018-10-27 06:22:17 --> Helper loaded: url_helper
INFO - 2018-10-27 06:22:17 --> Database Driver Class Initialized
INFO - 2018-10-27 06:22:17 --> Helper loaded: form_helper
INFO - 2018-10-27 06:22:17 --> Form Validation Class Initialized
INFO - 2018-10-27 06:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:22:17 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:22:17 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:22:17 --> Email Class Initialized
INFO - 2018-10-27 06:22:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:22:17 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:22:17 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:22:17 --> Helper loaded: date_helper
INFO - 2018-10-27 06:22:17 --> Database Driver Class Initialized
INFO - 2018-10-27 06:22:17 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:22:17 --> Controller Class Initialized
INFO - 2018-10-27 06:22:17 --> Model "Item_model" initialized
INFO - 2018-10-27 06:22:17 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:22:17 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:22:17 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:22:17 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:22:17 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\masterwedding\application\views\item\nota.php 31
INFO - 2018-10-27 06:22:28 --> Config Class Initialized
INFO - 2018-10-27 06:22:28 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:22:28 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:22:28 --> Utf8 Class Initialized
INFO - 2018-10-27 06:22:28 --> URI Class Initialized
INFO - 2018-10-27 06:22:28 --> Router Class Initialized
INFO - 2018-10-27 06:22:28 --> Output Class Initialized
INFO - 2018-10-27 06:22:28 --> Security Class Initialized
DEBUG - 2018-10-27 06:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:22:28 --> Input Class Initialized
INFO - 2018-10-27 06:22:28 --> Language Class Initialized
INFO - 2018-10-27 06:22:28 --> Loader Class Initialized
INFO - 2018-10-27 06:22:28 --> Helper loaded: url_helper
INFO - 2018-10-27 06:22:28 --> Database Driver Class Initialized
INFO - 2018-10-27 06:22:28 --> Helper loaded: form_helper
INFO - 2018-10-27 06:22:28 --> Form Validation Class Initialized
INFO - 2018-10-27 06:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:22:28 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:22:28 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:22:28 --> Email Class Initialized
INFO - 2018-10-27 06:22:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:22:28 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:22:28 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:22:28 --> Helper loaded: date_helper
INFO - 2018-10-27 06:22:28 --> Database Driver Class Initialized
INFO - 2018-10-27 06:22:28 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:22:28 --> Controller Class Initialized
INFO - 2018-10-27 06:22:28 --> Model "Item_model" initialized
INFO - 2018-10-27 06:22:28 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:22:28 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:22:29 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:22:29 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:22:29 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\masterwedding\application\views\item\nota.php 31
INFO - 2018-10-27 06:22:33 --> Config Class Initialized
INFO - 2018-10-27 06:22:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:22:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:22:34 --> Utf8 Class Initialized
INFO - 2018-10-27 06:22:34 --> URI Class Initialized
INFO - 2018-10-27 06:22:34 --> Router Class Initialized
INFO - 2018-10-27 06:22:34 --> Output Class Initialized
INFO - 2018-10-27 06:22:34 --> Security Class Initialized
DEBUG - 2018-10-27 06:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:22:34 --> Input Class Initialized
INFO - 2018-10-27 06:22:34 --> Language Class Initialized
INFO - 2018-10-27 06:22:34 --> Loader Class Initialized
INFO - 2018-10-27 06:22:34 --> Helper loaded: url_helper
INFO - 2018-10-27 06:22:34 --> Database Driver Class Initialized
INFO - 2018-10-27 06:22:34 --> Helper loaded: form_helper
INFO - 2018-10-27 06:22:34 --> Form Validation Class Initialized
INFO - 2018-10-27 06:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:22:34 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:22:34 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:22:34 --> Email Class Initialized
INFO - 2018-10-27 06:22:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:22:34 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:22:34 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:22:34 --> Helper loaded: date_helper
INFO - 2018-10-27 06:22:34 --> Database Driver Class Initialized
INFO - 2018-10-27 06:22:34 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:22:34 --> Controller Class Initialized
INFO - 2018-10-27 06:22:34 --> Model "Item_model" initialized
INFO - 2018-10-27 06:22:34 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:22:34 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:22:34 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:22:34 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:22:34 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\masterwedding\application\views\item\nota.php 31
INFO - 2018-10-27 06:22:54 --> Config Class Initialized
INFO - 2018-10-27 06:22:54 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:22:54 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:22:54 --> Utf8 Class Initialized
INFO - 2018-10-27 06:22:54 --> URI Class Initialized
INFO - 2018-10-27 06:22:54 --> Router Class Initialized
INFO - 2018-10-27 06:22:54 --> Output Class Initialized
INFO - 2018-10-27 06:22:54 --> Security Class Initialized
DEBUG - 2018-10-27 06:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:22:54 --> Input Class Initialized
INFO - 2018-10-27 06:22:54 --> Language Class Initialized
INFO - 2018-10-27 06:22:54 --> Loader Class Initialized
INFO - 2018-10-27 06:22:54 --> Helper loaded: url_helper
INFO - 2018-10-27 06:22:54 --> Database Driver Class Initialized
INFO - 2018-10-27 06:22:54 --> Helper loaded: form_helper
INFO - 2018-10-27 06:22:54 --> Form Validation Class Initialized
INFO - 2018-10-27 06:22:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:22:54 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:22:54 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:22:54 --> Email Class Initialized
INFO - 2018-10-27 06:22:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:22:54 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:22:54 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:22:54 --> Helper loaded: date_helper
INFO - 2018-10-27 06:22:54 --> Database Driver Class Initialized
INFO - 2018-10-27 06:22:54 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:22:54 --> Controller Class Initialized
INFO - 2018-10-27 06:22:54 --> Model "Item_model" initialized
INFO - 2018-10-27 06:22:54 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:22:54 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:22:54 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:22:54 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:22:54 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:22:54 --> Final output sent to browser
DEBUG - 2018-10-27 06:22:54 --> Total execution time: 0.5316
INFO - 2018-10-27 06:22:54 --> Config Class Initialized
INFO - 2018-10-27 06:22:54 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:22:54 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:22:54 --> Utf8 Class Initialized
INFO - 2018-10-27 06:22:54 --> URI Class Initialized
INFO - 2018-10-27 06:22:54 --> Router Class Initialized
INFO - 2018-10-27 06:22:54 --> Output Class Initialized
INFO - 2018-10-27 06:22:55 --> Security Class Initialized
DEBUG - 2018-10-27 06:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:22:55 --> Input Class Initialized
INFO - 2018-10-27 06:22:55 --> Language Class Initialized
ERROR - 2018-10-27 06:22:55 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:24:46 --> Config Class Initialized
INFO - 2018-10-27 06:24:46 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:24:46 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:24:46 --> Utf8 Class Initialized
INFO - 2018-10-27 06:24:46 --> URI Class Initialized
INFO - 2018-10-27 06:24:46 --> Router Class Initialized
INFO - 2018-10-27 06:24:46 --> Output Class Initialized
INFO - 2018-10-27 06:24:46 --> Security Class Initialized
DEBUG - 2018-10-27 06:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:24:46 --> Input Class Initialized
INFO - 2018-10-27 06:24:46 --> Language Class Initialized
INFO - 2018-10-27 06:24:46 --> Loader Class Initialized
INFO - 2018-10-27 06:24:46 --> Helper loaded: url_helper
INFO - 2018-10-27 06:24:46 --> Database Driver Class Initialized
INFO - 2018-10-27 06:24:46 --> Helper loaded: form_helper
INFO - 2018-10-27 06:24:46 --> Form Validation Class Initialized
INFO - 2018-10-27 06:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:24:46 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:24:46 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:24:46 --> Email Class Initialized
INFO - 2018-10-27 06:24:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:24:46 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:24:46 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:24:47 --> Helper loaded: date_helper
INFO - 2018-10-27 06:24:47 --> Database Driver Class Initialized
INFO - 2018-10-27 06:24:47 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:24:47 --> Controller Class Initialized
INFO - 2018-10-27 06:24:47 --> Model "Item_model" initialized
INFO - 2018-10-27 06:24:47 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:24:47 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:24:47 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:24:47 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:24:47 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 06:24:47 --> Final output sent to browser
DEBUG - 2018-10-27 06:24:47 --> Total execution time: 0.5515
INFO - 2018-10-27 06:25:46 --> Config Class Initialized
INFO - 2018-10-27 06:25:46 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:25:46 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:25:46 --> Utf8 Class Initialized
INFO - 2018-10-27 06:25:46 --> URI Class Initialized
INFO - 2018-10-27 06:25:46 --> Router Class Initialized
INFO - 2018-10-27 06:25:46 --> Output Class Initialized
INFO - 2018-10-27 06:25:46 --> Security Class Initialized
DEBUG - 2018-10-27 06:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:25:46 --> Input Class Initialized
INFO - 2018-10-27 06:25:46 --> Language Class Initialized
INFO - 2018-10-27 06:25:46 --> Loader Class Initialized
INFO - 2018-10-27 06:25:46 --> Helper loaded: url_helper
INFO - 2018-10-27 06:25:46 --> Database Driver Class Initialized
INFO - 2018-10-27 06:25:46 --> Helper loaded: form_helper
INFO - 2018-10-27 06:25:46 --> Form Validation Class Initialized
INFO - 2018-10-27 06:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:25:46 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:25:46 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:25:46 --> Email Class Initialized
INFO - 2018-10-27 06:25:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:25:46 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:25:46 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:25:47 --> Helper loaded: date_helper
INFO - 2018-10-27 06:25:47 --> Database Driver Class Initialized
INFO - 2018-10-27 06:25:47 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:25:47 --> Controller Class Initialized
INFO - 2018-10-27 06:25:47 --> Model "Item_model" initialized
INFO - 2018-10-27 06:25:47 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:25:47 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:25:47 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:25:47 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:25:47 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 06:25:47 --> Final output sent to browser
DEBUG - 2018-10-27 06:25:47 --> Total execution time: 0.5363
INFO - 2018-10-27 06:25:47 --> Config Class Initialized
INFO - 2018-10-27 06:25:47 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:25:47 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:25:47 --> Utf8 Class Initialized
INFO - 2018-10-27 06:25:47 --> URI Class Initialized
INFO - 2018-10-27 06:25:47 --> Router Class Initialized
INFO - 2018-10-27 06:25:47 --> Output Class Initialized
INFO - 2018-10-27 06:25:47 --> Security Class Initialized
DEBUG - 2018-10-27 06:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:25:47 --> Input Class Initialized
INFO - 2018-10-27 06:25:47 --> Language Class Initialized
ERROR - 2018-10-27 06:25:47 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:25:49 --> Config Class Initialized
INFO - 2018-10-27 06:25:49 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:25:49 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:25:49 --> Utf8 Class Initialized
INFO - 2018-10-27 06:25:49 --> URI Class Initialized
INFO - 2018-10-27 06:25:49 --> Router Class Initialized
INFO - 2018-10-27 06:25:49 --> Output Class Initialized
INFO - 2018-10-27 06:25:49 --> Security Class Initialized
DEBUG - 2018-10-27 06:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:25:49 --> Input Class Initialized
INFO - 2018-10-27 06:25:49 --> Language Class Initialized
INFO - 2018-10-27 06:25:49 --> Loader Class Initialized
INFO - 2018-10-27 06:25:49 --> Helper loaded: url_helper
INFO - 2018-10-27 06:25:49 --> Database Driver Class Initialized
INFO - 2018-10-27 06:25:49 --> Helper loaded: form_helper
INFO - 2018-10-27 06:25:49 --> Form Validation Class Initialized
INFO - 2018-10-27 06:25:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:25:49 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:25:49 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:25:49 --> Email Class Initialized
INFO - 2018-10-27 06:25:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:25:49 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:25:49 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:25:49 --> Helper loaded: date_helper
INFO - 2018-10-27 06:25:49 --> Database Driver Class Initialized
INFO - 2018-10-27 06:25:49 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:25:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:25:49 --> Controller Class Initialized
INFO - 2018-10-27 06:25:49 --> Model "Item_model" initialized
INFO - 2018-10-27 06:25:49 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:25:49 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:25:49 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:25:49 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:25:49 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:25:49 --> Final output sent to browser
DEBUG - 2018-10-27 06:25:49 --> Total execution time: 0.5245
INFO - 2018-10-27 06:25:50 --> Config Class Initialized
INFO - 2018-10-27 06:25:50 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:25:50 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:25:50 --> Utf8 Class Initialized
INFO - 2018-10-27 06:25:50 --> URI Class Initialized
INFO - 2018-10-27 06:25:50 --> Router Class Initialized
INFO - 2018-10-27 06:25:50 --> Output Class Initialized
INFO - 2018-10-27 06:25:50 --> Security Class Initialized
DEBUG - 2018-10-27 06:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:25:50 --> Input Class Initialized
INFO - 2018-10-27 06:25:50 --> Language Class Initialized
ERROR - 2018-10-27 06:25:50 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:39:26 --> Config Class Initialized
INFO - 2018-10-27 06:39:26 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:39:26 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:39:26 --> Utf8 Class Initialized
INFO - 2018-10-27 06:39:26 --> URI Class Initialized
INFO - 2018-10-27 06:39:26 --> Router Class Initialized
INFO - 2018-10-27 06:39:26 --> Output Class Initialized
INFO - 2018-10-27 06:39:26 --> Security Class Initialized
DEBUG - 2018-10-27 06:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:39:26 --> Input Class Initialized
INFO - 2018-10-27 06:39:26 --> Language Class Initialized
INFO - 2018-10-27 06:39:26 --> Loader Class Initialized
INFO - 2018-10-27 06:39:26 --> Helper loaded: url_helper
INFO - 2018-10-27 06:39:26 --> Database Driver Class Initialized
INFO - 2018-10-27 06:39:26 --> Helper loaded: form_helper
INFO - 2018-10-27 06:39:26 --> Form Validation Class Initialized
INFO - 2018-10-27 06:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:39:26 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:39:26 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:39:26 --> Email Class Initialized
INFO - 2018-10-27 06:39:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:39:26 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:39:26 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:39:26 --> Helper loaded: date_helper
INFO - 2018-10-27 06:39:26 --> Database Driver Class Initialized
INFO - 2018-10-27 06:39:26 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:39:26 --> Controller Class Initialized
INFO - 2018-10-27 06:39:26 --> Model "Item_model" initialized
INFO - 2018-10-27 06:39:26 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:39:26 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:39:26 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:39:26 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:39:26 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:39:26 --> Final output sent to browser
DEBUG - 2018-10-27 06:39:26 --> Total execution time: 0.5405
INFO - 2018-10-27 06:39:26 --> Config Class Initialized
INFO - 2018-10-27 06:39:26 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:39:26 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:39:26 --> Utf8 Class Initialized
INFO - 2018-10-27 06:39:26 --> URI Class Initialized
INFO - 2018-10-27 06:39:26 --> Router Class Initialized
INFO - 2018-10-27 06:39:26 --> Output Class Initialized
INFO - 2018-10-27 06:39:26 --> Security Class Initialized
DEBUG - 2018-10-27 06:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:39:26 --> Input Class Initialized
INFO - 2018-10-27 06:39:26 --> Language Class Initialized
ERROR - 2018-10-27 06:39:26 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:41:32 --> Config Class Initialized
INFO - 2018-10-27 06:41:32 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:41:32 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:41:32 --> Utf8 Class Initialized
INFO - 2018-10-27 06:41:32 --> URI Class Initialized
INFO - 2018-10-27 06:41:32 --> Router Class Initialized
INFO - 2018-10-27 06:41:32 --> Output Class Initialized
INFO - 2018-10-27 06:41:32 --> Security Class Initialized
DEBUG - 2018-10-27 06:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:41:32 --> Input Class Initialized
INFO - 2018-10-27 06:41:32 --> Language Class Initialized
INFO - 2018-10-27 06:41:32 --> Loader Class Initialized
INFO - 2018-10-27 06:41:32 --> Helper loaded: url_helper
INFO - 2018-10-27 06:41:32 --> Database Driver Class Initialized
INFO - 2018-10-27 06:41:32 --> Helper loaded: form_helper
INFO - 2018-10-27 06:41:32 --> Form Validation Class Initialized
INFO - 2018-10-27 06:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:41:32 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:41:32 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:41:32 --> Email Class Initialized
INFO - 2018-10-27 06:41:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:41:32 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:41:32 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:41:32 --> Helper loaded: date_helper
INFO - 2018-10-27 06:41:33 --> Database Driver Class Initialized
INFO - 2018-10-27 06:41:33 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:41:33 --> Controller Class Initialized
INFO - 2018-10-27 06:41:33 --> Model "Item_model" initialized
INFO - 2018-10-27 06:41:33 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:41:33 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:41:33 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:41:33 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:41:33 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 06:41:33 --> Final output sent to browser
DEBUG - 2018-10-27 06:41:33 --> Total execution time: 0.5790
INFO - 2018-10-27 06:41:38 --> Config Class Initialized
INFO - 2018-10-27 06:41:38 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:41:38 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:41:38 --> Utf8 Class Initialized
INFO - 2018-10-27 06:41:38 --> URI Class Initialized
INFO - 2018-10-27 06:41:38 --> Router Class Initialized
INFO - 2018-10-27 06:41:38 --> Output Class Initialized
INFO - 2018-10-27 06:41:38 --> Security Class Initialized
DEBUG - 2018-10-27 06:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:41:38 --> Input Class Initialized
INFO - 2018-10-27 06:41:38 --> Language Class Initialized
INFO - 2018-10-27 06:41:38 --> Loader Class Initialized
INFO - 2018-10-27 06:41:38 --> Helper loaded: url_helper
INFO - 2018-10-27 06:41:38 --> Database Driver Class Initialized
INFO - 2018-10-27 06:41:39 --> Helper loaded: form_helper
INFO - 2018-10-27 06:41:39 --> Form Validation Class Initialized
INFO - 2018-10-27 06:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:41:39 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:41:39 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:41:39 --> Email Class Initialized
INFO - 2018-10-27 06:41:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:41:39 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:41:39 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:41:39 --> Helper loaded: date_helper
INFO - 2018-10-27 06:41:39 --> Database Driver Class Initialized
INFO - 2018-10-27 06:41:39 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:41:39 --> Controller Class Initialized
INFO - 2018-10-27 06:41:39 --> Model "Item_model" initialized
INFO - 2018-10-27 06:41:39 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:41:39 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:41:39 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:41:39 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:41:39 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 06:41:39 --> Final output sent to browser
DEBUG - 2018-10-27 06:41:39 --> Total execution time: 0.5592
INFO - 2018-10-27 06:41:39 --> Config Class Initialized
INFO - 2018-10-27 06:41:39 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:41:39 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:41:39 --> Utf8 Class Initialized
INFO - 2018-10-27 06:41:39 --> URI Class Initialized
INFO - 2018-10-27 06:41:39 --> Router Class Initialized
INFO - 2018-10-27 06:41:39 --> Output Class Initialized
INFO - 2018-10-27 06:41:39 --> Security Class Initialized
DEBUG - 2018-10-27 06:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:41:39 --> Input Class Initialized
INFO - 2018-10-27 06:41:39 --> Language Class Initialized
ERROR - 2018-10-27 06:41:39 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:41:43 --> Config Class Initialized
INFO - 2018-10-27 06:41:43 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:41:43 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:41:43 --> Utf8 Class Initialized
INFO - 2018-10-27 06:41:43 --> URI Class Initialized
INFO - 2018-10-27 06:41:43 --> Router Class Initialized
INFO - 2018-10-27 06:41:43 --> Output Class Initialized
INFO - 2018-10-27 06:41:43 --> Security Class Initialized
DEBUG - 2018-10-27 06:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:41:43 --> Input Class Initialized
INFO - 2018-10-27 06:41:43 --> Language Class Initialized
INFO - 2018-10-27 06:41:43 --> Loader Class Initialized
INFO - 2018-10-27 06:41:43 --> Helper loaded: url_helper
INFO - 2018-10-27 06:41:43 --> Database Driver Class Initialized
INFO - 2018-10-27 06:41:43 --> Helper loaded: form_helper
INFO - 2018-10-27 06:41:43 --> Form Validation Class Initialized
INFO - 2018-10-27 06:41:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:41:43 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:41:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:41:43 --> Email Class Initialized
INFO - 2018-10-27 06:41:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:41:43 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:41:43 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:41:43 --> Helper loaded: date_helper
INFO - 2018-10-27 06:41:43 --> Database Driver Class Initialized
INFO - 2018-10-27 06:41:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:41:43 --> Controller Class Initialized
INFO - 2018-10-27 06:41:43 --> Model "Item_model" initialized
INFO - 2018-10-27 06:41:43 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:41:43 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:41:43 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:41:43 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:41:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:41:43 --> Final output sent to browser
DEBUG - 2018-10-27 06:41:43 --> Total execution time: 0.5629
INFO - 2018-10-27 06:41:43 --> Config Class Initialized
INFO - 2018-10-27 06:41:44 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:41:44 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:41:44 --> Utf8 Class Initialized
INFO - 2018-10-27 06:41:44 --> URI Class Initialized
INFO - 2018-10-27 06:41:44 --> Router Class Initialized
INFO - 2018-10-27 06:41:44 --> Output Class Initialized
INFO - 2018-10-27 06:41:44 --> Security Class Initialized
DEBUG - 2018-10-27 06:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:41:44 --> Input Class Initialized
INFO - 2018-10-27 06:41:44 --> Language Class Initialized
ERROR - 2018-10-27 06:41:44 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:53:52 --> Config Class Initialized
INFO - 2018-10-27 06:53:52 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:53:52 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:53:52 --> Utf8 Class Initialized
INFO - 2018-10-27 06:53:52 --> URI Class Initialized
INFO - 2018-10-27 06:53:52 --> Router Class Initialized
INFO - 2018-10-27 06:53:52 --> Output Class Initialized
INFO - 2018-10-27 06:53:52 --> Security Class Initialized
DEBUG - 2018-10-27 06:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:53:52 --> Input Class Initialized
INFO - 2018-10-27 06:53:52 --> Language Class Initialized
INFO - 2018-10-27 06:53:52 --> Loader Class Initialized
INFO - 2018-10-27 06:53:52 --> Helper loaded: url_helper
INFO - 2018-10-27 06:53:52 --> Database Driver Class Initialized
INFO - 2018-10-27 06:53:52 --> Helper loaded: form_helper
INFO - 2018-10-27 06:53:52 --> Form Validation Class Initialized
INFO - 2018-10-27 06:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:53:52 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:53:52 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:53:52 --> Email Class Initialized
INFO - 2018-10-27 06:53:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:53:52 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:53:52 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:53:52 --> Helper loaded: date_helper
INFO - 2018-10-27 06:53:52 --> Database Driver Class Initialized
INFO - 2018-10-27 06:53:52 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:53:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:53:52 --> Controller Class Initialized
INFO - 2018-10-27 06:53:52 --> Model "Item_model" initialized
INFO - 2018-10-27 06:53:52 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:53:52 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:53:52 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:53:52 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:53:52 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 06:53:52 --> Final output sent to browser
DEBUG - 2018-10-27 06:53:52 --> Total execution time: 0.5705
INFO - 2018-10-27 06:53:58 --> Config Class Initialized
INFO - 2018-10-27 06:53:58 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:53:58 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:53:58 --> Utf8 Class Initialized
INFO - 2018-10-27 06:53:58 --> URI Class Initialized
INFO - 2018-10-27 06:53:58 --> Router Class Initialized
INFO - 2018-10-27 06:53:58 --> Output Class Initialized
INFO - 2018-10-27 06:53:58 --> Security Class Initialized
DEBUG - 2018-10-27 06:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:53:58 --> Input Class Initialized
INFO - 2018-10-27 06:53:58 --> Language Class Initialized
INFO - 2018-10-27 06:53:58 --> Loader Class Initialized
INFO - 2018-10-27 06:53:58 --> Helper loaded: url_helper
INFO - 2018-10-27 06:53:58 --> Database Driver Class Initialized
INFO - 2018-10-27 06:53:58 --> Helper loaded: form_helper
INFO - 2018-10-27 06:53:58 --> Form Validation Class Initialized
INFO - 2018-10-27 06:53:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:53:58 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:53:58 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:53:58 --> Email Class Initialized
INFO - 2018-10-27 06:53:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:53:59 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:53:59 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:53:59 --> Helper loaded: date_helper
INFO - 2018-10-27 06:53:59 --> Database Driver Class Initialized
INFO - 2018-10-27 06:53:59 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:53:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:53:59 --> Controller Class Initialized
INFO - 2018-10-27 06:53:59 --> Model "Item_model" initialized
INFO - 2018-10-27 06:53:59 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:53:59 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:53:59 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:53:59 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:53:59 --> Severity: Notice --> Undefined index: notaid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 65
ERROR - 2018-10-27 06:53:59 --> Severity: Notice --> Undefined index: notaid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 65
INFO - 2018-10-27 06:53:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 06:53:59 --> Final output sent to browser
DEBUG - 2018-10-27 06:53:59 --> Total execution time: 0.5735
INFO - 2018-10-27 06:53:59 --> Config Class Initialized
INFO - 2018-10-27 06:53:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:53:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:53:59 --> Utf8 Class Initialized
INFO - 2018-10-27 06:53:59 --> URI Class Initialized
INFO - 2018-10-27 06:53:59 --> Router Class Initialized
INFO - 2018-10-27 06:53:59 --> Output Class Initialized
INFO - 2018-10-27 06:53:59 --> Security Class Initialized
DEBUG - 2018-10-27 06:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:53:59 --> Input Class Initialized
INFO - 2018-10-27 06:53:59 --> Language Class Initialized
ERROR - 2018-10-27 06:53:59 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:55:38 --> Config Class Initialized
INFO - 2018-10-27 06:55:38 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:55:38 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:55:38 --> Utf8 Class Initialized
INFO - 2018-10-27 06:55:38 --> URI Class Initialized
INFO - 2018-10-27 06:55:38 --> Router Class Initialized
INFO - 2018-10-27 06:55:38 --> Output Class Initialized
INFO - 2018-10-27 06:55:38 --> Security Class Initialized
DEBUG - 2018-10-27 06:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:55:38 --> Input Class Initialized
INFO - 2018-10-27 06:55:38 --> Language Class Initialized
INFO - 2018-10-27 06:55:38 --> Loader Class Initialized
INFO - 2018-10-27 06:55:38 --> Helper loaded: url_helper
INFO - 2018-10-27 06:55:38 --> Database Driver Class Initialized
INFO - 2018-10-27 06:55:38 --> Helper loaded: form_helper
INFO - 2018-10-27 06:55:38 --> Form Validation Class Initialized
INFO - 2018-10-27 06:55:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:55:38 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:55:38 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:55:38 --> Email Class Initialized
INFO - 2018-10-27 06:55:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:55:38 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:55:38 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:55:39 --> Helper loaded: date_helper
INFO - 2018-10-27 06:55:39 --> Database Driver Class Initialized
INFO - 2018-10-27 06:55:39 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:55:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:55:39 --> Controller Class Initialized
INFO - 2018-10-27 06:55:39 --> Model "Item_model" initialized
INFO - 2018-10-27 06:55:39 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:55:39 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:55:39 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:55:39 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:55:39 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 06:55:39 --> Final output sent to browser
DEBUG - 2018-10-27 06:55:39 --> Total execution time: 0.5514
INFO - 2018-10-27 06:55:39 --> Config Class Initialized
INFO - 2018-10-27 06:55:39 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:55:39 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:55:39 --> Utf8 Class Initialized
INFO - 2018-10-27 06:55:39 --> URI Class Initialized
INFO - 2018-10-27 06:55:39 --> Router Class Initialized
INFO - 2018-10-27 06:55:39 --> Output Class Initialized
INFO - 2018-10-27 06:55:39 --> Security Class Initialized
DEBUG - 2018-10-27 06:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:55:39 --> Input Class Initialized
INFO - 2018-10-27 06:55:39 --> Language Class Initialized
ERROR - 2018-10-27 06:55:39 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:55:42 --> Config Class Initialized
INFO - 2018-10-27 06:55:42 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:55:42 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:55:42 --> Utf8 Class Initialized
INFO - 2018-10-27 06:55:42 --> URI Class Initialized
INFO - 2018-10-27 06:55:42 --> Router Class Initialized
INFO - 2018-10-27 06:55:42 --> Output Class Initialized
INFO - 2018-10-27 06:55:42 --> Security Class Initialized
DEBUG - 2018-10-27 06:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:55:42 --> Input Class Initialized
INFO - 2018-10-27 06:55:42 --> Language Class Initialized
INFO - 2018-10-27 06:55:42 --> Loader Class Initialized
INFO - 2018-10-27 06:55:42 --> Helper loaded: url_helper
INFO - 2018-10-27 06:55:42 --> Database Driver Class Initialized
INFO - 2018-10-27 06:55:42 --> Helper loaded: form_helper
INFO - 2018-10-27 06:55:42 --> Form Validation Class Initialized
INFO - 2018-10-27 06:55:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:55:42 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:55:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:55:42 --> Email Class Initialized
INFO - 2018-10-27 06:55:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:55:42 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:55:42 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:55:43 --> Helper loaded: date_helper
INFO - 2018-10-27 06:55:43 --> Database Driver Class Initialized
INFO - 2018-10-27 06:55:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:55:43 --> Controller Class Initialized
INFO - 2018-10-27 06:55:43 --> Model "Item_model" initialized
INFO - 2018-10-27 06:55:43 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:55:43 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:55:43 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:55:43 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:55:43 --> Severity: Notice --> Undefined index: notaid D:\xampp\htdocs\masterwedding\application\views\item\nota.php 30
INFO - 2018-10-27 06:55:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:55:43 --> Final output sent to browser
DEBUG - 2018-10-27 06:55:43 --> Total execution time: 0.5750
INFO - 2018-10-27 06:55:43 --> Config Class Initialized
INFO - 2018-10-27 06:55:43 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:55:43 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:55:43 --> Utf8 Class Initialized
INFO - 2018-10-27 06:55:43 --> URI Class Initialized
INFO - 2018-10-27 06:55:43 --> Router Class Initialized
INFO - 2018-10-27 06:55:43 --> Output Class Initialized
INFO - 2018-10-27 06:55:43 --> Security Class Initialized
DEBUG - 2018-10-27 06:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:55:43 --> Input Class Initialized
INFO - 2018-10-27 06:55:43 --> Language Class Initialized
ERROR - 2018-10-27 06:55:43 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:56:59 --> Config Class Initialized
INFO - 2018-10-27 06:56:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:56:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:56:59 --> Utf8 Class Initialized
INFO - 2018-10-27 06:56:59 --> URI Class Initialized
INFO - 2018-10-27 06:56:59 --> Router Class Initialized
INFO - 2018-10-27 06:56:59 --> Output Class Initialized
INFO - 2018-10-27 06:56:59 --> Security Class Initialized
DEBUG - 2018-10-27 06:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:56:59 --> Input Class Initialized
INFO - 2018-10-27 06:56:59 --> Language Class Initialized
INFO - 2018-10-27 06:56:59 --> Loader Class Initialized
INFO - 2018-10-27 06:56:59 --> Helper loaded: url_helper
INFO - 2018-10-27 06:56:59 --> Database Driver Class Initialized
INFO - 2018-10-27 06:56:59 --> Helper loaded: form_helper
INFO - 2018-10-27 06:56:59 --> Form Validation Class Initialized
INFO - 2018-10-27 06:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:56:59 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:56:59 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:56:59 --> Email Class Initialized
INFO - 2018-10-27 06:56:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:56:59 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:56:59 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:56:59 --> Helper loaded: date_helper
INFO - 2018-10-27 06:56:59 --> Database Driver Class Initialized
INFO - 2018-10-27 06:56:59 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:56:59 --> Controller Class Initialized
INFO - 2018-10-27 06:56:59 --> Model "Item_model" initialized
INFO - 2018-10-27 06:56:59 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:56:59 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:56:59 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:56:59 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:56:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 06:56:59 --> Final output sent to browser
DEBUG - 2018-10-27 06:56:59 --> Total execution time: 0.5614
INFO - 2018-10-27 06:57:03 --> Config Class Initialized
INFO - 2018-10-27 06:57:03 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:03 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:03 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:03 --> URI Class Initialized
INFO - 2018-10-27 06:57:03 --> Router Class Initialized
INFO - 2018-10-27 06:57:03 --> Output Class Initialized
INFO - 2018-10-27 06:57:03 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:03 --> Input Class Initialized
INFO - 2018-10-27 06:57:03 --> Language Class Initialized
INFO - 2018-10-27 06:57:03 --> Loader Class Initialized
INFO - 2018-10-27 06:57:03 --> Helper loaded: url_helper
INFO - 2018-10-27 06:57:03 --> Database Driver Class Initialized
INFO - 2018-10-27 06:57:03 --> Helper loaded: form_helper
INFO - 2018-10-27 06:57:03 --> Form Validation Class Initialized
INFO - 2018-10-27 06:57:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:57:03 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:57:03 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:57:03 --> Email Class Initialized
INFO - 2018-10-27 06:57:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:57:03 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:57:04 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:57:04 --> Helper loaded: date_helper
INFO - 2018-10-27 06:57:04 --> Database Driver Class Initialized
INFO - 2018-10-27 06:57:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:57:04 --> Controller Class Initialized
INFO - 2018-10-27 06:57:04 --> Model "Item_model" initialized
INFO - 2018-10-27 06:57:04 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:57:04 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:57:04 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:57:04 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:57:04 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 06:57:04 --> Final output sent to browser
DEBUG - 2018-10-27 06:57:04 --> Total execution time: 0.5851
INFO - 2018-10-27 06:57:04 --> Config Class Initialized
INFO - 2018-10-27 06:57:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:04 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:04 --> URI Class Initialized
INFO - 2018-10-27 06:57:04 --> Router Class Initialized
INFO - 2018-10-27 06:57:04 --> Output Class Initialized
INFO - 2018-10-27 06:57:04 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:04 --> Input Class Initialized
INFO - 2018-10-27 06:57:04 --> Language Class Initialized
ERROR - 2018-10-27 06:57:04 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:57:05 --> Config Class Initialized
INFO - 2018-10-27 06:57:05 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:05 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:06 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:06 --> URI Class Initialized
INFO - 2018-10-27 06:57:06 --> Router Class Initialized
INFO - 2018-10-27 06:57:06 --> Output Class Initialized
INFO - 2018-10-27 06:57:06 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:06 --> Input Class Initialized
INFO - 2018-10-27 06:57:06 --> Language Class Initialized
INFO - 2018-10-27 06:57:06 --> Loader Class Initialized
INFO - 2018-10-27 06:57:06 --> Helper loaded: url_helper
INFO - 2018-10-27 06:57:06 --> Database Driver Class Initialized
INFO - 2018-10-27 06:57:06 --> Helper loaded: form_helper
INFO - 2018-10-27 06:57:06 --> Form Validation Class Initialized
INFO - 2018-10-27 06:57:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:57:06 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:57:06 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:57:06 --> Email Class Initialized
INFO - 2018-10-27 06:57:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:57:06 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:57:06 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:57:06 --> Helper loaded: date_helper
INFO - 2018-10-27 06:57:06 --> Database Driver Class Initialized
INFO - 2018-10-27 06:57:06 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:57:06 --> Controller Class Initialized
INFO - 2018-10-27 06:57:06 --> Model "Item_model" initialized
INFO - 2018-10-27 06:57:06 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:57:06 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:57:06 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:57:06 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 06:57:06 --> Severity: Notice --> Undefined index: notaid D:\xampp\htdocs\masterwedding\application\views\item\nota.php 30
INFO - 2018-10-27 06:57:06 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:57:06 --> Final output sent to browser
DEBUG - 2018-10-27 06:57:06 --> Total execution time: 0.5695
INFO - 2018-10-27 06:57:06 --> Config Class Initialized
INFO - 2018-10-27 06:57:06 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:06 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:06 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:06 --> URI Class Initialized
INFO - 2018-10-27 06:57:06 --> Router Class Initialized
INFO - 2018-10-27 06:57:06 --> Output Class Initialized
INFO - 2018-10-27 06:57:06 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:06 --> Input Class Initialized
INFO - 2018-10-27 06:57:06 --> Language Class Initialized
ERROR - 2018-10-27 06:57:06 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 06:57:41 --> Config Class Initialized
INFO - 2018-10-27 06:57:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:41 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:41 --> URI Class Initialized
INFO - 2018-10-27 06:57:41 --> Router Class Initialized
INFO - 2018-10-27 06:57:41 --> Output Class Initialized
INFO - 2018-10-27 06:57:41 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:41 --> Input Class Initialized
INFO - 2018-10-27 06:57:41 --> Language Class Initialized
INFO - 2018-10-27 06:57:41 --> Loader Class Initialized
INFO - 2018-10-27 06:57:41 --> Helper loaded: url_helper
INFO - 2018-10-27 06:57:41 --> Database Driver Class Initialized
INFO - 2018-10-27 06:57:41 --> Helper loaded: form_helper
INFO - 2018-10-27 06:57:41 --> Form Validation Class Initialized
INFO - 2018-10-27 06:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 06:57:41 --> Pagination Class Initialized
DEBUG - 2018-10-27 06:57:41 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 06:57:41 --> Email Class Initialized
INFO - 2018-10-27 06:57:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 06:57:41 --> Helper loaded: cookie_helper
INFO - 2018-10-27 06:57:41 --> Helper loaded: language_helper
DEBUG - 2018-10-27 06:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:57:41 --> Helper loaded: date_helper
INFO - 2018-10-27 06:57:41 --> Database Driver Class Initialized
INFO - 2018-10-27 06:57:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 06:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 06:57:41 --> Controller Class Initialized
INFO - 2018-10-27 06:57:41 --> Model "Item_model" initialized
INFO - 2018-10-27 06:57:41 --> Model "Jenis_model" initialized
INFO - 2018-10-27 06:57:41 --> Model "Vendor_model" initialized
INFO - 2018-10-27 06:57:41 --> Model "Nota_model" initialized
INFO - 2018-10-27 06:57:41 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 06:57:41 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 06:57:41 --> Final output sent to browser
DEBUG - 2018-10-27 06:57:41 --> Total execution time: 0.5843
INFO - 2018-10-27 06:57:41 --> Config Class Initialized
INFO - 2018-10-27 06:57:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:41 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:41 --> URI Class Initialized
INFO - 2018-10-27 06:57:41 --> Router Class Initialized
INFO - 2018-10-27 06:57:41 --> Output Class Initialized
INFO - 2018-10-27 06:57:42 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:42 --> Input Class Initialized
INFO - 2018-10-27 06:57:42 --> Language Class Initialized
ERROR - 2018-10-27 06:57:42 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:20:16 --> Config Class Initialized
INFO - 2018-10-27 10:20:16 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:16 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:16 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:16 --> URI Class Initialized
INFO - 2018-10-27 10:20:16 --> Router Class Initialized
INFO - 2018-10-27 10:20:16 --> Output Class Initialized
INFO - 2018-10-27 10:20:16 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:16 --> Input Class Initialized
INFO - 2018-10-27 10:20:16 --> Language Class Initialized
INFO - 2018-10-27 10:20:16 --> Loader Class Initialized
INFO - 2018-10-27 10:20:16 --> Helper loaded: url_helper
INFO - 2018-10-27 10:20:16 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:17 --> Helper loaded: form_helper
INFO - 2018-10-27 10:20:17 --> Form Validation Class Initialized
INFO - 2018-10-27 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:20:17 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:20:17 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:20:17 --> Email Class Initialized
INFO - 2018-10-27 10:20:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:20:17 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:20:17 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:20:17 --> Helper loaded: date_helper
INFO - 2018-10-27 10:20:17 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:17 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:20:17 --> Controller Class Initialized
INFO - 2018-10-27 10:20:17 --> Model "Item_model" initialized
INFO - 2018-10-27 10:20:17 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:20:17 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:20:17 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:20:17 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 10:20:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\masterwedding\application\controllers\Item.php 18
ERROR - 2018-10-27 10:20:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\masterwedding\application\controllers\Item.php 19
INFO - 2018-10-27 10:20:17 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:20:17 --> Final output sent to browser
DEBUG - 2018-10-27 10:20:17 --> Total execution time: 1.4172
INFO - 2018-10-27 10:20:17 --> Config Class Initialized
INFO - 2018-10-27 10:20:17 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:17 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:17 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:17 --> URI Class Initialized
INFO - 2018-10-27 10:20:17 --> Router Class Initialized
INFO - 2018-10-27 10:20:17 --> Output Class Initialized
INFO - 2018-10-27 10:20:17 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:17 --> Input Class Initialized
INFO - 2018-10-27 10:20:17 --> Language Class Initialized
INFO - 2018-10-27 10:20:17 --> Loader Class Initialized
INFO - 2018-10-27 10:20:17 --> Helper loaded: url_helper
INFO - 2018-10-27 10:20:17 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:18 --> Helper loaded: form_helper
INFO - 2018-10-27 10:20:18 --> Form Validation Class Initialized
INFO - 2018-10-27 10:20:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:20:18 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:20:18 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:20:18 --> Email Class Initialized
INFO - 2018-10-27 10:20:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:20:18 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:20:18 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:20:18 --> Helper loaded: date_helper
INFO - 2018-10-27 10:20:18 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:20:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:20:18 --> Controller Class Initialized
INFO - 2018-10-27 10:20:18 --> Model "Item_model" initialized
INFO - 2018-10-27 10:20:18 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:20:18 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:20:18 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:20:18 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 10:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\masterwedding\application\controllers\Item.php 18
ERROR - 2018-10-27 10:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\masterwedding\application\controllers\Item.php 19
INFO - 2018-10-27 10:20:18 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:20:18 --> Final output sent to browser
DEBUG - 2018-10-27 10:20:18 --> Total execution time: 0.5838
INFO - 2018-10-27 10:20:18 --> Config Class Initialized
INFO - 2018-10-27 10:20:18 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:18 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:18 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:18 --> URI Class Initialized
INFO - 2018-10-27 10:20:18 --> Router Class Initialized
INFO - 2018-10-27 10:20:18 --> Output Class Initialized
INFO - 2018-10-27 10:20:18 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:18 --> Input Class Initialized
INFO - 2018-10-27 10:20:18 --> Language Class Initialized
ERROR - 2018-10-27 10:20:18 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:20:32 --> Config Class Initialized
INFO - 2018-10-27 10:20:32 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:32 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:32 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:32 --> URI Class Initialized
DEBUG - 2018-10-27 10:20:32 --> No URI present. Default controller set.
INFO - 2018-10-27 10:20:32 --> Router Class Initialized
INFO - 2018-10-27 10:20:32 --> Output Class Initialized
INFO - 2018-10-27 10:20:32 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:32 --> Input Class Initialized
INFO - 2018-10-27 10:20:32 --> Language Class Initialized
INFO - 2018-10-27 10:20:32 --> Loader Class Initialized
INFO - 2018-10-27 10:20:32 --> Helper loaded: url_helper
INFO - 2018-10-27 10:20:32 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:33 --> Helper loaded: form_helper
INFO - 2018-10-27 10:20:33 --> Form Validation Class Initialized
INFO - 2018-10-27 10:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:20:33 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:20:33 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:20:33 --> Email Class Initialized
INFO - 2018-10-27 10:20:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:20:33 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:20:33 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:20:33 --> Helper loaded: date_helper
INFO - 2018-10-27 10:20:33 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:33 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:20:33 --> Controller Class Initialized
INFO - 2018-10-27 10:20:33 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-27 10:20:33 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\index.php
INFO - 2018-10-27 10:20:33 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-10-27 10:20:33 --> Final output sent to browser
INFO - 2018-10-27 10:20:33 --> Config Class Initialized
DEBUG - 2018-10-27 10:20:33 --> Total execution time: 0.5856
INFO - 2018-10-27 10:20:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:33 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:33 --> URI Class Initialized
DEBUG - 2018-10-27 10:20:33 --> No URI present. Default controller set.
INFO - 2018-10-27 10:20:33 --> Router Class Initialized
INFO - 2018-10-27 10:20:33 --> Output Class Initialized
INFO - 2018-10-27 10:20:33 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:33 --> Input Class Initialized
INFO - 2018-10-27 10:20:33 --> Language Class Initialized
INFO - 2018-10-27 10:20:33 --> Loader Class Initialized
INFO - 2018-10-27 10:20:33 --> Helper loaded: url_helper
INFO - 2018-10-27 10:20:33 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:33 --> Helper loaded: form_helper
INFO - 2018-10-27 10:20:33 --> Form Validation Class Initialized
INFO - 2018-10-27 10:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:20:33 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:20:33 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:20:33 --> Email Class Initialized
INFO - 2018-10-27 10:20:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:20:33 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:20:33 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:20:33 --> Helper loaded: date_helper
INFO - 2018-10-27 10:20:33 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:33 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:20:33 --> Controller Class Initialized
INFO - 2018-10-27 10:20:33 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-27 10:20:33 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\index.php
INFO - 2018-10-27 10:20:33 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-10-27 10:20:33 --> Final output sent to browser
DEBUG - 2018-10-27 10:20:33 --> Total execution time: 0.4991
INFO - 2018-10-27 10:20:33 --> Config Class Initialized
INFO - 2018-10-27 10:20:33 --> Config Class Initialized
INFO - 2018-10-27 10:20:33 --> Config Class Initialized
INFO - 2018-10-27 10:20:33 --> Hooks Class Initialized
INFO - 2018-10-27 10:20:33 --> Hooks Class Initialized
INFO - 2018-10-27 10:20:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:33 --> UTF-8 Support Enabled
DEBUG - 2018-10-27 10:20:33 --> UTF-8 Support Enabled
DEBUG - 2018-10-27 10:20:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:33 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:33 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:33 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:33 --> URI Class Initialized
INFO - 2018-10-27 10:20:33 --> URI Class Initialized
INFO - 2018-10-27 10:20:33 --> URI Class Initialized
INFO - 2018-10-27 10:20:33 --> Router Class Initialized
INFO - 2018-10-27 10:20:33 --> Router Class Initialized
INFO - 2018-10-27 10:20:33 --> Router Class Initialized
INFO - 2018-10-27 10:20:34 --> Output Class Initialized
INFO - 2018-10-27 10:20:34 --> Output Class Initialized
INFO - 2018-10-27 10:20:34 --> Output Class Initialized
INFO - 2018-10-27 10:20:34 --> Security Class Initialized
INFO - 2018-10-27 10:20:34 --> Security Class Initialized
INFO - 2018-10-27 10:20:34 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-27 10:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-27 10:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:34 --> Input Class Initialized
INFO - 2018-10-27 10:20:34 --> Input Class Initialized
INFO - 2018-10-27 10:20:34 --> Input Class Initialized
INFO - 2018-10-27 10:20:34 --> Language Class Initialized
INFO - 2018-10-27 10:20:34 --> Language Class Initialized
INFO - 2018-10-27 10:20:34 --> Language Class Initialized
ERROR - 2018-10-27 10:20:34 --> 404 Page Not Found: Application/views
ERROR - 2018-10-27 10:20:34 --> 404 Page Not Found: Application/views
ERROR - 2018-10-27 10:20:34 --> 404 Page Not Found: Application/views
INFO - 2018-10-27 10:20:35 --> Config Class Initialized
INFO - 2018-10-27 10:20:35 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:35 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:35 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:35 --> URI Class Initialized
INFO - 2018-10-27 10:20:35 --> Router Class Initialized
INFO - 2018-10-27 10:20:36 --> Output Class Initialized
INFO - 2018-10-27 10:20:36 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:36 --> Input Class Initialized
INFO - 2018-10-27 10:20:36 --> Language Class Initialized
INFO - 2018-10-27 10:20:36 --> Loader Class Initialized
INFO - 2018-10-27 10:20:36 --> Helper loaded: url_helper
INFO - 2018-10-27 10:20:36 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:36 --> Helper loaded: form_helper
INFO - 2018-10-27 10:20:36 --> Form Validation Class Initialized
INFO - 2018-10-27 10:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:20:36 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:20:36 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:20:36 --> Email Class Initialized
INFO - 2018-10-27 10:20:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:20:36 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:20:36 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:20:36 --> Helper loaded: date_helper
INFO - 2018-10-27 10:20:36 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:36 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:20:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:20:36 --> Controller Class Initialized
INFO - 2018-10-27 10:20:36 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-27 10:20:36 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\login.php
INFO - 2018-10-27 10:20:36 --> Final output sent to browser
DEBUG - 2018-10-27 10:20:36 --> Total execution time: 0.5554
INFO - 2018-10-27 10:20:36 --> Config Class Initialized
INFO - 2018-10-27 10:20:36 --> Config Class Initialized
INFO - 2018-10-27 10:20:36 --> Config Class Initialized
INFO - 2018-10-27 10:20:36 --> Hooks Class Initialized
INFO - 2018-10-27 10:20:36 --> Hooks Class Initialized
INFO - 2018-10-27 10:20:36 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:36 --> UTF-8 Support Enabled
DEBUG - 2018-10-27 10:20:36 --> UTF-8 Support Enabled
DEBUG - 2018-10-27 10:20:36 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:36 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:36 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:36 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:36 --> URI Class Initialized
INFO - 2018-10-27 10:20:36 --> URI Class Initialized
INFO - 2018-10-27 10:20:36 --> URI Class Initialized
INFO - 2018-10-27 10:20:36 --> Router Class Initialized
INFO - 2018-10-27 10:20:36 --> Router Class Initialized
INFO - 2018-10-27 10:20:36 --> Router Class Initialized
INFO - 2018-10-27 10:20:36 --> Output Class Initialized
INFO - 2018-10-27 10:20:36 --> Output Class Initialized
INFO - 2018-10-27 10:20:36 --> Output Class Initialized
INFO - 2018-10-27 10:20:36 --> Security Class Initialized
INFO - 2018-10-27 10:20:36 --> Security Class Initialized
INFO - 2018-10-27 10:20:36 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-27 10:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-27 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:36 --> Input Class Initialized
INFO - 2018-10-27 10:20:36 --> Input Class Initialized
INFO - 2018-10-27 10:20:36 --> Input Class Initialized
INFO - 2018-10-27 10:20:36 --> Language Class Initialized
INFO - 2018-10-27 10:20:36 --> Language Class Initialized
INFO - 2018-10-27 10:20:36 --> Language Class Initialized
ERROR - 2018-10-27 10:20:36 --> 404 Page Not Found: Application/views
ERROR - 2018-10-27 10:20:36 --> 404 Page Not Found: Application/views
ERROR - 2018-10-27 10:20:36 --> 404 Page Not Found: Application/views
INFO - 2018-10-27 10:20:43 --> Config Class Initialized
INFO - 2018-10-27 10:20:43 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:43 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:43 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:43 --> URI Class Initialized
INFO - 2018-10-27 10:20:43 --> Router Class Initialized
INFO - 2018-10-27 10:20:43 --> Output Class Initialized
INFO - 2018-10-27 10:20:43 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:43 --> Input Class Initialized
INFO - 2018-10-27 10:20:43 --> Language Class Initialized
INFO - 2018-10-27 10:20:43 --> Loader Class Initialized
INFO - 2018-10-27 10:20:43 --> Helper loaded: url_helper
INFO - 2018-10-27 10:20:43 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:43 --> Helper loaded: form_helper
INFO - 2018-10-27 10:20:44 --> Form Validation Class Initialized
INFO - 2018-10-27 10:20:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:20:44 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:20:44 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:20:44 --> Email Class Initialized
INFO - 2018-10-27 10:20:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:20:44 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:20:44 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:20:44 --> Helper loaded: date_helper
INFO - 2018-10-27 10:20:44 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:44 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:20:44 --> Controller Class Initialized
INFO - 2018-10-27 10:20:44 --> Config Class Initialized
INFO - 2018-10-27 10:20:44 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:44 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:44 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:44 --> URI Class Initialized
INFO - 2018-10-27 10:20:44 --> Router Class Initialized
INFO - 2018-10-27 10:20:44 --> Output Class Initialized
INFO - 2018-10-27 10:20:44 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:44 --> Input Class Initialized
INFO - 2018-10-27 10:20:44 --> Language Class Initialized
INFO - 2018-10-27 10:20:44 --> Loader Class Initialized
INFO - 2018-10-27 10:20:44 --> Helper loaded: url_helper
INFO - 2018-10-27 10:20:44 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:44 --> Helper loaded: form_helper
INFO - 2018-10-27 10:20:44 --> Form Validation Class Initialized
INFO - 2018-10-27 10:20:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:20:44 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:20:44 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:20:44 --> Email Class Initialized
INFO - 2018-10-27 10:20:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:20:44 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:20:44 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:20:44 --> Helper loaded: date_helper
INFO - 2018-10-27 10:20:44 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:44 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:20:44 --> Controller Class Initialized
INFO - 2018-10-27 10:20:44 --> Model "Item_model" initialized
INFO - 2018-10-27 10:20:44 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:20:44 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:20:44 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:20:44 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:20:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:20:44 --> Final output sent to browser
DEBUG - 2018-10-27 10:20:44 --> Total execution time: 0.5430
INFO - 2018-10-27 10:20:44 --> Config Class Initialized
INFO - 2018-10-27 10:20:44 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:44 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:44 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:45 --> URI Class Initialized
INFO - 2018-10-27 10:20:45 --> Router Class Initialized
INFO - 2018-10-27 10:20:45 --> Output Class Initialized
INFO - 2018-10-27 10:20:45 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:45 --> Input Class Initialized
INFO - 2018-10-27 10:20:45 --> Language Class Initialized
ERROR - 2018-10-27 10:20:45 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-27 10:20:47 --> Config Class Initialized
INFO - 2018-10-27 10:20:47 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:20:47 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:20:47 --> Utf8 Class Initialized
INFO - 2018-10-27 10:20:47 --> URI Class Initialized
INFO - 2018-10-27 10:20:47 --> Router Class Initialized
INFO - 2018-10-27 10:20:47 --> Output Class Initialized
INFO - 2018-10-27 10:20:47 --> Security Class Initialized
DEBUG - 2018-10-27 10:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:20:47 --> Input Class Initialized
INFO - 2018-10-27 10:20:47 --> Language Class Initialized
INFO - 2018-10-27 10:20:47 --> Loader Class Initialized
INFO - 2018-10-27 10:20:47 --> Helper loaded: url_helper
INFO - 2018-10-27 10:20:47 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:48 --> Helper loaded: form_helper
INFO - 2018-10-27 10:20:48 --> Form Validation Class Initialized
INFO - 2018-10-27 10:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:20:48 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:20:48 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:20:48 --> Email Class Initialized
INFO - 2018-10-27 10:20:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:20:48 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:20:48 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:20:48 --> Helper loaded: date_helper
INFO - 2018-10-27 10:20:48 --> Database Driver Class Initialized
INFO - 2018-10-27 10:20:48 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:20:48 --> Controller Class Initialized
INFO - 2018-10-27 10:20:48 --> Model "Item_model" initialized
INFO - 2018-10-27 10:20:48 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:20:48 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:20:48 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:20:48 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:20:48 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:20:48 --> Final output sent to browser
DEBUG - 2018-10-27 10:20:48 --> Total execution time: 0.6009
INFO - 2018-10-27 10:28:49 --> Config Class Initialized
INFO - 2018-10-27 10:28:49 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:28:49 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:28:49 --> Utf8 Class Initialized
INFO - 2018-10-27 10:28:49 --> URI Class Initialized
INFO - 2018-10-27 10:28:49 --> Router Class Initialized
INFO - 2018-10-27 10:28:49 --> Output Class Initialized
INFO - 2018-10-27 10:28:49 --> Security Class Initialized
DEBUG - 2018-10-27 10:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:28:49 --> Input Class Initialized
INFO - 2018-10-27 10:28:49 --> Language Class Initialized
INFO - 2018-10-27 10:28:49 --> Loader Class Initialized
INFO - 2018-10-27 10:28:49 --> Helper loaded: url_helper
INFO - 2018-10-27 10:28:49 --> Database Driver Class Initialized
INFO - 2018-10-27 10:28:49 --> Helper loaded: form_helper
INFO - 2018-10-27 10:28:49 --> Form Validation Class Initialized
INFO - 2018-10-27 10:28:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:28:49 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:28:49 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:28:49 --> Email Class Initialized
INFO - 2018-10-27 10:28:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:28:49 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:28:49 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:28:49 --> Helper loaded: date_helper
INFO - 2018-10-27 10:28:49 --> Database Driver Class Initialized
INFO - 2018-10-27 10:28:49 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:28:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:28:49 --> Controller Class Initialized
INFO - 2018-10-27 10:28:49 --> Model "Item_model" initialized
INFO - 2018-10-27 10:28:49 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:28:49 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:28:49 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:28:49 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:28:49 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:28:49 --> Final output sent to browser
DEBUG - 2018-10-27 10:28:49 --> Total execution time: 0.5912
INFO - 2018-10-27 10:28:52 --> Config Class Initialized
INFO - 2018-10-27 10:28:52 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:28:52 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:28:52 --> Utf8 Class Initialized
INFO - 2018-10-27 10:28:52 --> URI Class Initialized
INFO - 2018-10-27 10:28:52 --> Router Class Initialized
INFO - 2018-10-27 10:28:52 --> Output Class Initialized
INFO - 2018-10-27 10:28:52 --> Security Class Initialized
DEBUG - 2018-10-27 10:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:28:52 --> Input Class Initialized
INFO - 2018-10-27 10:28:52 --> Language Class Initialized
INFO - 2018-10-27 10:28:52 --> Loader Class Initialized
INFO - 2018-10-27 10:28:52 --> Helper loaded: url_helper
INFO - 2018-10-27 10:28:52 --> Database Driver Class Initialized
INFO - 2018-10-27 10:28:52 --> Helper loaded: form_helper
INFO - 2018-10-27 10:28:52 --> Form Validation Class Initialized
INFO - 2018-10-27 10:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:28:52 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:28:53 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:28:53 --> Email Class Initialized
INFO - 2018-10-27 10:28:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:28:53 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:28:53 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:28:53 --> Helper loaded: date_helper
INFO - 2018-10-27 10:28:53 --> Database Driver Class Initialized
INFO - 2018-10-27 10:28:53 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:28:53 --> Controller Class Initialized
INFO - 2018-10-27 10:28:53 --> Model "Item_model" initialized
INFO - 2018-10-27 10:28:53 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:28:53 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:28:53 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:28:53 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:28:53 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:28:53 --> Final output sent to browser
DEBUG - 2018-10-27 10:28:53 --> Total execution time: 0.5807
INFO - 2018-10-27 10:29:00 --> Config Class Initialized
INFO - 2018-10-27 10:29:00 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:29:00 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:29:00 --> Utf8 Class Initialized
INFO - 2018-10-27 10:29:00 --> URI Class Initialized
INFO - 2018-10-27 10:29:00 --> Router Class Initialized
INFO - 2018-10-27 10:29:00 --> Output Class Initialized
INFO - 2018-10-27 10:29:00 --> Security Class Initialized
DEBUG - 2018-10-27 10:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:29:00 --> Input Class Initialized
INFO - 2018-10-27 10:29:00 --> Language Class Initialized
INFO - 2018-10-27 10:29:00 --> Loader Class Initialized
INFO - 2018-10-27 10:29:00 --> Helper loaded: url_helper
INFO - 2018-10-27 10:29:00 --> Database Driver Class Initialized
INFO - 2018-10-27 10:29:00 --> Helper loaded: form_helper
INFO - 2018-10-27 10:29:00 --> Form Validation Class Initialized
INFO - 2018-10-27 10:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:29:00 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:29:00 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:29:00 --> Email Class Initialized
INFO - 2018-10-27 10:29:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:29:00 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:29:00 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:29:00 --> Helper loaded: date_helper
INFO - 2018-10-27 10:29:00 --> Database Driver Class Initialized
INFO - 2018-10-27 10:29:00 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:29:00 --> Controller Class Initialized
INFO - 2018-10-27 10:29:00 --> Model "Item_model" initialized
INFO - 2018-10-27 10:29:00 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:29:00 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:29:00 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:29:00 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:29:00 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 10:29:00 --> Final output sent to browser
DEBUG - 2018-10-27 10:29:00 --> Total execution time: 0.6203
INFO - 2018-10-27 10:29:00 --> Config Class Initialized
INFO - 2018-10-27 10:29:00 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:29:00 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:29:00 --> Utf8 Class Initialized
INFO - 2018-10-27 10:29:00 --> URI Class Initialized
INFO - 2018-10-27 10:29:01 --> Router Class Initialized
INFO - 2018-10-27 10:29:01 --> Output Class Initialized
INFO - 2018-10-27 10:29:01 --> Security Class Initialized
DEBUG - 2018-10-27 10:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:29:01 --> Input Class Initialized
INFO - 2018-10-27 10:29:01 --> Language Class Initialized
ERROR - 2018-10-27 10:29:01 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:29:06 --> Config Class Initialized
INFO - 2018-10-27 10:29:06 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:29:07 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:29:07 --> Utf8 Class Initialized
INFO - 2018-10-27 10:29:07 --> URI Class Initialized
INFO - 2018-10-27 10:29:07 --> Router Class Initialized
INFO - 2018-10-27 10:29:07 --> Output Class Initialized
INFO - 2018-10-27 10:29:07 --> Security Class Initialized
DEBUG - 2018-10-27 10:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:29:07 --> Input Class Initialized
INFO - 2018-10-27 10:29:07 --> Language Class Initialized
INFO - 2018-10-27 10:29:07 --> Loader Class Initialized
INFO - 2018-10-27 10:29:07 --> Helper loaded: url_helper
INFO - 2018-10-27 10:29:07 --> Database Driver Class Initialized
INFO - 2018-10-27 10:29:07 --> Helper loaded: form_helper
INFO - 2018-10-27 10:29:07 --> Form Validation Class Initialized
INFO - 2018-10-27 10:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:29:07 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:29:07 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:29:07 --> Email Class Initialized
INFO - 2018-10-27 10:29:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:29:07 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:29:07 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:29:07 --> Helper loaded: date_helper
INFO - 2018-10-27 10:29:07 --> Database Driver Class Initialized
INFO - 2018-10-27 10:29:07 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:29:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:29:07 --> Controller Class Initialized
INFO - 2018-10-27 10:29:07 --> Model "Item_model" initialized
INFO - 2018-10-27 10:29:07 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:29:07 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:29:07 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:29:07 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 10:29:07 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\masterwedding\application\controllers\Item.php 145
ERROR - 2018-10-27 10:29:07 --> Query error: Column 'notaid' cannot be null - Invalid query: INSERT INTO `nota_detail` (`notaid`, `subtotal`) VALUES (NULL, '30000000')
DEBUG - 2018-10-27 10:29:07 --> DB Transaction Failure
INFO - 2018-10-27 10:29:07 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-27 10:31:20 --> Config Class Initialized
INFO - 2018-10-27 10:31:20 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:31:20 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:31:20 --> Utf8 Class Initialized
INFO - 2018-10-27 10:31:20 --> URI Class Initialized
INFO - 2018-10-27 10:31:20 --> Router Class Initialized
INFO - 2018-10-27 10:31:20 --> Output Class Initialized
INFO - 2018-10-27 10:31:20 --> Security Class Initialized
DEBUG - 2018-10-27 10:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:31:20 --> Input Class Initialized
INFO - 2018-10-27 10:31:20 --> Language Class Initialized
INFO - 2018-10-27 10:31:20 --> Loader Class Initialized
INFO - 2018-10-27 10:31:20 --> Helper loaded: url_helper
INFO - 2018-10-27 10:31:20 --> Database Driver Class Initialized
INFO - 2018-10-27 10:31:20 --> Helper loaded: form_helper
INFO - 2018-10-27 10:31:20 --> Form Validation Class Initialized
INFO - 2018-10-27 10:31:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:31:20 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:31:20 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:31:20 --> Email Class Initialized
INFO - 2018-10-27 10:31:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:31:21 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:31:21 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:31:21 --> Helper loaded: date_helper
INFO - 2018-10-27 10:31:21 --> Database Driver Class Initialized
INFO - 2018-10-27 10:31:21 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:31:21 --> Controller Class Initialized
INFO - 2018-10-27 10:31:21 --> Model "Item_model" initialized
INFO - 2018-10-27 10:31:21 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:31:21 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:31:21 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:31:21 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:31:21 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:31:21 --> Final output sent to browser
DEBUG - 2018-10-27 10:31:21 --> Total execution time: 0.5838
INFO - 2018-10-27 10:31:21 --> Config Class Initialized
INFO - 2018-10-27 10:31:21 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:31:21 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:31:21 --> Utf8 Class Initialized
INFO - 2018-10-27 10:31:21 --> URI Class Initialized
INFO - 2018-10-27 10:31:21 --> Router Class Initialized
INFO - 2018-10-27 10:31:21 --> Output Class Initialized
INFO - 2018-10-27 10:31:21 --> Security Class Initialized
DEBUG - 2018-10-27 10:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:31:21 --> Input Class Initialized
INFO - 2018-10-27 10:31:21 --> Language Class Initialized
ERROR - 2018-10-27 10:31:21 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:33:27 --> Config Class Initialized
INFO - 2018-10-27 10:33:27 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:33:27 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:33:27 --> Utf8 Class Initialized
INFO - 2018-10-27 10:33:27 --> URI Class Initialized
INFO - 2018-10-27 10:33:27 --> Router Class Initialized
INFO - 2018-10-27 10:33:27 --> Output Class Initialized
INFO - 2018-10-27 10:33:27 --> Security Class Initialized
DEBUG - 2018-10-27 10:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:33:27 --> Input Class Initialized
INFO - 2018-10-27 10:33:27 --> Language Class Initialized
INFO - 2018-10-27 10:33:27 --> Loader Class Initialized
INFO - 2018-10-27 10:33:27 --> Helper loaded: url_helper
INFO - 2018-10-27 10:33:27 --> Database Driver Class Initialized
INFO - 2018-10-27 10:33:28 --> Helper loaded: form_helper
INFO - 2018-10-27 10:33:28 --> Form Validation Class Initialized
INFO - 2018-10-27 10:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:33:28 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:33:28 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:33:28 --> Email Class Initialized
INFO - 2018-10-27 10:33:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:33:28 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:33:28 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:33:28 --> Helper loaded: date_helper
INFO - 2018-10-27 10:33:28 --> Database Driver Class Initialized
INFO - 2018-10-27 10:33:28 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:33:28 --> Controller Class Initialized
INFO - 2018-10-27 10:33:28 --> Model "Item_model" initialized
INFO - 2018-10-27 10:33:28 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:33:28 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:33:28 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:33:28 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:33:28 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:33:28 --> Final output sent to browser
DEBUG - 2018-10-27 10:33:28 --> Total execution time: 0.5952
INFO - 2018-10-27 10:33:31 --> Config Class Initialized
INFO - 2018-10-27 10:33:31 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:33:31 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:33:31 --> Utf8 Class Initialized
INFO - 2018-10-27 10:33:31 --> URI Class Initialized
INFO - 2018-10-27 10:33:31 --> Router Class Initialized
INFO - 2018-10-27 10:33:31 --> Output Class Initialized
INFO - 2018-10-27 10:33:31 --> Security Class Initialized
DEBUG - 2018-10-27 10:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:33:31 --> Input Class Initialized
INFO - 2018-10-27 10:33:31 --> Language Class Initialized
INFO - 2018-10-27 10:33:31 --> Loader Class Initialized
INFO - 2018-10-27 10:33:31 --> Helper loaded: url_helper
INFO - 2018-10-27 10:33:31 --> Database Driver Class Initialized
INFO - 2018-10-27 10:33:31 --> Helper loaded: form_helper
INFO - 2018-10-27 10:33:31 --> Form Validation Class Initialized
INFO - 2018-10-27 10:33:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:33:31 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:33:31 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:33:31 --> Email Class Initialized
INFO - 2018-10-27 10:33:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:33:31 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:33:31 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:33:31 --> Helper loaded: date_helper
INFO - 2018-10-27 10:33:31 --> Database Driver Class Initialized
INFO - 2018-10-27 10:33:31 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:33:31 --> Controller Class Initialized
INFO - 2018-10-27 10:33:31 --> Model "Item_model" initialized
INFO - 2018-10-27 10:33:31 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:33:31 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:33:31 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:33:31 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:33:31 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 10:33:31 --> Final output sent to browser
DEBUG - 2018-10-27 10:33:31 --> Total execution time: 0.5942
INFO - 2018-10-27 10:33:31 --> Config Class Initialized
INFO - 2018-10-27 10:33:31 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:33:32 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:33:32 --> Utf8 Class Initialized
INFO - 2018-10-27 10:33:32 --> URI Class Initialized
INFO - 2018-10-27 10:33:32 --> Router Class Initialized
INFO - 2018-10-27 10:33:32 --> Output Class Initialized
INFO - 2018-10-27 10:33:32 --> Security Class Initialized
DEBUG - 2018-10-27 10:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:33:32 --> Input Class Initialized
INFO - 2018-10-27 10:33:32 --> Language Class Initialized
ERROR - 2018-10-27 10:33:32 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:33:33 --> Config Class Initialized
INFO - 2018-10-27 10:33:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:33:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:33:33 --> Utf8 Class Initialized
INFO - 2018-10-27 10:33:33 --> URI Class Initialized
INFO - 2018-10-27 10:33:33 --> Router Class Initialized
INFO - 2018-10-27 10:33:33 --> Output Class Initialized
INFO - 2018-10-27 10:33:33 --> Security Class Initialized
DEBUG - 2018-10-27 10:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:33:33 --> Input Class Initialized
INFO - 2018-10-27 10:33:33 --> Language Class Initialized
INFO - 2018-10-27 10:33:33 --> Loader Class Initialized
INFO - 2018-10-27 10:33:33 --> Helper loaded: url_helper
INFO - 2018-10-27 10:33:33 --> Database Driver Class Initialized
INFO - 2018-10-27 10:33:33 --> Helper loaded: form_helper
INFO - 2018-10-27 10:33:33 --> Form Validation Class Initialized
INFO - 2018-10-27 10:33:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:33:33 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:33:33 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:33:33 --> Email Class Initialized
INFO - 2018-10-27 10:33:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:33:33 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:33:33 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:33:34 --> Helper loaded: date_helper
INFO - 2018-10-27 10:33:34 --> Database Driver Class Initialized
INFO - 2018-10-27 10:33:34 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:33:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:33:34 --> Controller Class Initialized
INFO - 2018-10-27 10:33:34 --> Model "Item_model" initialized
INFO - 2018-10-27 10:33:34 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:33:34 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:33:34 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:33:34 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:33:34 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:33:34 --> Final output sent to browser
DEBUG - 2018-10-27 10:33:34 --> Total execution time: 0.5874
INFO - 2018-10-27 10:33:34 --> Config Class Initialized
INFO - 2018-10-27 10:33:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:33:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:33:34 --> Utf8 Class Initialized
INFO - 2018-10-27 10:33:34 --> URI Class Initialized
INFO - 2018-10-27 10:33:34 --> Router Class Initialized
INFO - 2018-10-27 10:33:34 --> Output Class Initialized
INFO - 2018-10-27 10:33:34 --> Security Class Initialized
DEBUG - 2018-10-27 10:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:33:34 --> Input Class Initialized
INFO - 2018-10-27 10:33:34 --> Language Class Initialized
ERROR - 2018-10-27 10:33:34 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:37:18 --> Config Class Initialized
INFO - 2018-10-27 10:37:18 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:37:18 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:37:18 --> Utf8 Class Initialized
INFO - 2018-10-27 10:37:18 --> URI Class Initialized
INFO - 2018-10-27 10:37:18 --> Router Class Initialized
INFO - 2018-10-27 10:37:18 --> Output Class Initialized
INFO - 2018-10-27 10:37:18 --> Security Class Initialized
DEBUG - 2018-10-27 10:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:37:18 --> Input Class Initialized
INFO - 2018-10-27 10:37:18 --> Language Class Initialized
INFO - 2018-10-27 10:37:18 --> Loader Class Initialized
INFO - 2018-10-27 10:37:18 --> Helper loaded: url_helper
INFO - 2018-10-27 10:37:18 --> Database Driver Class Initialized
INFO - 2018-10-27 10:37:18 --> Helper loaded: form_helper
INFO - 2018-10-27 10:37:18 --> Form Validation Class Initialized
INFO - 2018-10-27 10:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:37:18 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:37:18 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:37:18 --> Email Class Initialized
INFO - 2018-10-27 10:37:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:37:18 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:37:18 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:37:18 --> Helper loaded: date_helper
INFO - 2018-10-27 10:37:18 --> Database Driver Class Initialized
INFO - 2018-10-27 10:37:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:37:18 --> Controller Class Initialized
INFO - 2018-10-27 10:37:18 --> Model "Item_model" initialized
INFO - 2018-10-27 10:37:18 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:37:18 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:37:18 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:37:18 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 10:37:18 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\masterwedding\application\views\item\nota.php 12
ERROR - 2018-10-27 10:37:18 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\masterwedding\application\views\item\nota.php 30
INFO - 2018-10-27 10:37:18 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:37:18 --> Final output sent to browser
DEBUG - 2018-10-27 10:37:18 --> Total execution time: 0.6365
INFO - 2018-10-27 10:37:18 --> Config Class Initialized
INFO - 2018-10-27 10:37:19 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:37:19 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:37:19 --> Utf8 Class Initialized
INFO - 2018-10-27 10:37:19 --> URI Class Initialized
INFO - 2018-10-27 10:37:19 --> Router Class Initialized
INFO - 2018-10-27 10:37:19 --> Output Class Initialized
INFO - 2018-10-27 10:37:19 --> Security Class Initialized
DEBUG - 2018-10-27 10:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:37:19 --> Input Class Initialized
INFO - 2018-10-27 10:37:19 --> Language Class Initialized
ERROR - 2018-10-27 10:37:19 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:38:08 --> Config Class Initialized
INFO - 2018-10-27 10:38:08 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:38:08 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:38:08 --> Utf8 Class Initialized
INFO - 2018-10-27 10:38:08 --> URI Class Initialized
INFO - 2018-10-27 10:38:08 --> Router Class Initialized
INFO - 2018-10-27 10:38:08 --> Output Class Initialized
INFO - 2018-10-27 10:38:08 --> Security Class Initialized
DEBUG - 2018-10-27 10:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:38:08 --> Input Class Initialized
INFO - 2018-10-27 10:38:08 --> Language Class Initialized
INFO - 2018-10-27 10:38:08 --> Loader Class Initialized
INFO - 2018-10-27 10:38:08 --> Helper loaded: url_helper
INFO - 2018-10-27 10:38:08 --> Database Driver Class Initialized
INFO - 2018-10-27 10:38:08 --> Helper loaded: form_helper
INFO - 2018-10-27 10:38:08 --> Form Validation Class Initialized
INFO - 2018-10-27 10:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:38:08 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:38:08 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:38:08 --> Email Class Initialized
INFO - 2018-10-27 10:38:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:38:08 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:38:08 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:38:09 --> Helper loaded: date_helper
INFO - 2018-10-27 10:38:09 --> Database Driver Class Initialized
INFO - 2018-10-27 10:38:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:38:09 --> Controller Class Initialized
INFO - 2018-10-27 10:38:09 --> Model "Item_model" initialized
INFO - 2018-10-27 10:38:09 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:38:09 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:38:09 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:38:09 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 10:38:09 --> Severity: Notice --> Undefined variable: notaid D:\xampp\htdocs\masterwedding\application\views\item\nota.php 12
ERROR - 2018-10-27 10:38:09 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\masterwedding\application\views\item\nota.php 30
INFO - 2018-10-27 10:38:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:38:09 --> Final output sent to browser
DEBUG - 2018-10-27 10:38:09 --> Total execution time: 0.6093
INFO - 2018-10-27 10:38:09 --> Config Class Initialized
INFO - 2018-10-27 10:38:09 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:38:09 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:38:09 --> Utf8 Class Initialized
INFO - 2018-10-27 10:38:09 --> URI Class Initialized
INFO - 2018-10-27 10:38:09 --> Router Class Initialized
INFO - 2018-10-27 10:38:09 --> Output Class Initialized
INFO - 2018-10-27 10:38:09 --> Security Class Initialized
DEBUG - 2018-10-27 10:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:38:09 --> Input Class Initialized
INFO - 2018-10-27 10:38:09 --> Language Class Initialized
ERROR - 2018-10-27 10:38:09 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:39:46 --> Config Class Initialized
INFO - 2018-10-27 10:39:46 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:39:46 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:39:46 --> Utf8 Class Initialized
INFO - 2018-10-27 10:39:46 --> URI Class Initialized
INFO - 2018-10-27 10:39:46 --> Router Class Initialized
INFO - 2018-10-27 10:39:46 --> Output Class Initialized
INFO - 2018-10-27 10:39:46 --> Security Class Initialized
DEBUG - 2018-10-27 10:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:39:46 --> Input Class Initialized
INFO - 2018-10-27 10:39:46 --> Language Class Initialized
INFO - 2018-10-27 10:39:46 --> Loader Class Initialized
INFO - 2018-10-27 10:39:46 --> Helper loaded: url_helper
INFO - 2018-10-27 10:39:46 --> Database Driver Class Initialized
INFO - 2018-10-27 10:39:46 --> Helper loaded: form_helper
INFO - 2018-10-27 10:39:46 --> Form Validation Class Initialized
INFO - 2018-10-27 10:39:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:39:46 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:39:46 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:39:46 --> Email Class Initialized
INFO - 2018-10-27 10:39:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:39:46 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:39:46 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:39:46 --> Helper loaded: date_helper
INFO - 2018-10-27 10:39:46 --> Database Driver Class Initialized
INFO - 2018-10-27 10:39:46 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:39:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:39:46 --> Controller Class Initialized
INFO - 2018-10-27 10:39:46 --> Model "Item_model" initialized
INFO - 2018-10-27 10:39:46 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:39:46 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:39:46 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:39:46 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 10:39:46 --> Severity: Notice --> Undefined variable: notaid D:\xampp\htdocs\masterwedding\application\views\item\nota.php 30
INFO - 2018-10-27 10:39:46 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:39:46 --> Final output sent to browser
DEBUG - 2018-10-27 10:39:46 --> Total execution time: 0.6192
INFO - 2018-10-27 10:39:46 --> Config Class Initialized
INFO - 2018-10-27 10:39:46 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:39:46 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:39:46 --> Utf8 Class Initialized
INFO - 2018-10-27 10:39:46 --> URI Class Initialized
INFO - 2018-10-27 10:39:46 --> Router Class Initialized
INFO - 2018-10-27 10:39:46 --> Output Class Initialized
INFO - 2018-10-27 10:39:46 --> Security Class Initialized
DEBUG - 2018-10-27 10:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:39:46 --> Input Class Initialized
INFO - 2018-10-27 10:39:46 --> Language Class Initialized
ERROR - 2018-10-27 10:39:46 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:41:07 --> Config Class Initialized
INFO - 2018-10-27 10:41:07 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:41:07 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:41:07 --> Utf8 Class Initialized
INFO - 2018-10-27 10:41:07 --> URI Class Initialized
INFO - 2018-10-27 10:41:07 --> Router Class Initialized
INFO - 2018-10-27 10:41:07 --> Output Class Initialized
INFO - 2018-10-27 10:41:07 --> Security Class Initialized
DEBUG - 2018-10-27 10:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:41:07 --> Input Class Initialized
INFO - 2018-10-27 10:41:07 --> Language Class Initialized
INFO - 2018-10-27 10:41:07 --> Loader Class Initialized
INFO - 2018-10-27 10:41:07 --> Helper loaded: url_helper
INFO - 2018-10-27 10:41:07 --> Database Driver Class Initialized
INFO - 2018-10-27 10:41:07 --> Helper loaded: form_helper
INFO - 2018-10-27 10:41:07 --> Form Validation Class Initialized
INFO - 2018-10-27 10:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:41:07 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:41:07 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:41:07 --> Email Class Initialized
INFO - 2018-10-27 10:41:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:41:07 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:41:07 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:41:07 --> Helper loaded: date_helper
INFO - 2018-10-27 10:41:07 --> Database Driver Class Initialized
INFO - 2018-10-27 10:41:07 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:41:07 --> Controller Class Initialized
INFO - 2018-10-27 10:41:07 --> Model "Item_model" initialized
INFO - 2018-10-27 10:41:07 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:41:07 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:41:07 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:41:07 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:41:07 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:41:07 --> Final output sent to browser
DEBUG - 2018-10-27 10:41:07 --> Total execution time: 0.6043
INFO - 2018-10-27 10:41:07 --> Config Class Initialized
INFO - 2018-10-27 10:41:07 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:41:08 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:41:08 --> Utf8 Class Initialized
INFO - 2018-10-27 10:41:08 --> URI Class Initialized
INFO - 2018-10-27 10:41:08 --> Router Class Initialized
INFO - 2018-10-27 10:41:08 --> Output Class Initialized
INFO - 2018-10-27 10:41:08 --> Security Class Initialized
DEBUG - 2018-10-27 10:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:41:08 --> Input Class Initialized
INFO - 2018-10-27 10:41:08 --> Language Class Initialized
ERROR - 2018-10-27 10:41:08 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:43:08 --> Config Class Initialized
INFO - 2018-10-27 10:43:08 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:43:08 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:43:08 --> Utf8 Class Initialized
INFO - 2018-10-27 10:43:08 --> URI Class Initialized
INFO - 2018-10-27 10:43:08 --> Router Class Initialized
INFO - 2018-10-27 10:43:08 --> Output Class Initialized
INFO - 2018-10-27 10:43:08 --> Security Class Initialized
DEBUG - 2018-10-27 10:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:43:08 --> Input Class Initialized
INFO - 2018-10-27 10:43:08 --> Language Class Initialized
INFO - 2018-10-27 10:43:08 --> Loader Class Initialized
INFO - 2018-10-27 10:43:08 --> Helper loaded: url_helper
INFO - 2018-10-27 10:43:08 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:08 --> Helper loaded: form_helper
INFO - 2018-10-27 10:43:09 --> Form Validation Class Initialized
INFO - 2018-10-27 10:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:43:09 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:43:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:43:09 --> Email Class Initialized
INFO - 2018-10-27 10:43:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:43:09 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:43:09 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:43:09 --> Helper loaded: date_helper
INFO - 2018-10-27 10:43:09 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:43:09 --> Controller Class Initialized
INFO - 2018-10-27 10:43:09 --> Model "Item_model" initialized
INFO - 2018-10-27 10:43:09 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:43:09 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:43:09 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:43:09 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:43:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:43:09 --> Final output sent to browser
DEBUG - 2018-10-27 10:43:09 --> Total execution time: 0.6127
INFO - 2018-10-27 10:43:13 --> Config Class Initialized
INFO - 2018-10-27 10:43:13 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:43:13 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:43:13 --> Utf8 Class Initialized
INFO - 2018-10-27 10:43:13 --> URI Class Initialized
INFO - 2018-10-27 10:43:13 --> Router Class Initialized
INFO - 2018-10-27 10:43:13 --> Output Class Initialized
INFO - 2018-10-27 10:43:13 --> Security Class Initialized
DEBUG - 2018-10-27 10:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:43:13 --> Input Class Initialized
INFO - 2018-10-27 10:43:13 --> Language Class Initialized
INFO - 2018-10-27 10:43:13 --> Loader Class Initialized
INFO - 2018-10-27 10:43:13 --> Helper loaded: url_helper
INFO - 2018-10-27 10:43:13 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:13 --> Helper loaded: form_helper
INFO - 2018-10-27 10:43:13 --> Form Validation Class Initialized
INFO - 2018-10-27 10:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:43:13 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:43:13 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:43:13 --> Email Class Initialized
INFO - 2018-10-27 10:43:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:43:13 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:43:13 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:43:13 --> Helper loaded: date_helper
INFO - 2018-10-27 10:43:13 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:13 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:43:13 --> Controller Class Initialized
INFO - 2018-10-27 10:43:14 --> Model "Item_model" initialized
INFO - 2018-10-27 10:43:14 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:43:14 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:43:14 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:43:14 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:43:14 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/tambah.php
INFO - 2018-10-27 10:43:14 --> Final output sent to browser
INFO - 2018-10-27 10:43:14 --> Config Class Initialized
DEBUG - 2018-10-27 10:43:14 --> Total execution time: 0.6327
INFO - 2018-10-27 10:43:14 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:43:14 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:43:14 --> Utf8 Class Initialized
INFO - 2018-10-27 10:43:14 --> URI Class Initialized
INFO - 2018-10-27 10:43:14 --> Router Class Initialized
INFO - 2018-10-27 10:43:14 --> Output Class Initialized
INFO - 2018-10-27 10:43:14 --> Security Class Initialized
DEBUG - 2018-10-27 10:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:43:14 --> Input Class Initialized
INFO - 2018-10-27 10:43:14 --> Language Class Initialized
ERROR - 2018-10-27 10:43:14 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:43:16 --> Config Class Initialized
INFO - 2018-10-27 10:43:16 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:43:16 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:43:16 --> Utf8 Class Initialized
INFO - 2018-10-27 10:43:16 --> URI Class Initialized
INFO - 2018-10-27 10:43:16 --> Router Class Initialized
INFO - 2018-10-27 10:43:16 --> Output Class Initialized
INFO - 2018-10-27 10:43:16 --> Security Class Initialized
DEBUG - 2018-10-27 10:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:43:16 --> Input Class Initialized
INFO - 2018-10-27 10:43:16 --> Language Class Initialized
INFO - 2018-10-27 10:43:16 --> Loader Class Initialized
INFO - 2018-10-27 10:43:16 --> Helper loaded: url_helper
INFO - 2018-10-27 10:43:16 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:16 --> Helper loaded: form_helper
INFO - 2018-10-27 10:43:16 --> Form Validation Class Initialized
INFO - 2018-10-27 10:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:43:16 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:43:16 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:43:16 --> Email Class Initialized
INFO - 2018-10-27 10:43:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:43:16 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:43:16 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:43:17 --> Helper loaded: date_helper
INFO - 2018-10-27 10:43:17 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:17 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:43:17 --> Controller Class Initialized
INFO - 2018-10-27 10:43:17 --> Model "Item_model" initialized
INFO - 2018-10-27 10:43:17 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:43:17 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:43:17 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:43:17 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:43:17 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:43:17 --> Final output sent to browser
DEBUG - 2018-10-27 10:43:17 --> Total execution time: 0.6114
INFO - 2018-10-27 10:43:19 --> Config Class Initialized
INFO - 2018-10-27 10:43:19 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:43:19 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:43:19 --> Utf8 Class Initialized
INFO - 2018-10-27 10:43:19 --> URI Class Initialized
INFO - 2018-10-27 10:43:19 --> Router Class Initialized
INFO - 2018-10-27 10:43:19 --> Output Class Initialized
INFO - 2018-10-27 10:43:19 --> Security Class Initialized
DEBUG - 2018-10-27 10:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:43:19 --> Input Class Initialized
INFO - 2018-10-27 10:43:19 --> Language Class Initialized
INFO - 2018-10-27 10:43:19 --> Loader Class Initialized
INFO - 2018-10-27 10:43:19 --> Helper loaded: url_helper
INFO - 2018-10-27 10:43:19 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:19 --> Helper loaded: form_helper
INFO - 2018-10-27 10:43:19 --> Form Validation Class Initialized
INFO - 2018-10-27 10:43:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:43:19 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:43:19 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:43:19 --> Email Class Initialized
INFO - 2018-10-27 10:43:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:43:19 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:43:19 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:43:19 --> Helper loaded: date_helper
INFO - 2018-10-27 10:43:19 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:19 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:43:19 --> Controller Class Initialized
INFO - 2018-10-27 10:43:19 --> Model "Item_model" initialized
INFO - 2018-10-27 10:43:19 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:43:19 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:43:19 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:43:19 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:43:19 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/tambah.php
INFO - 2018-10-27 10:43:20 --> Final output sent to browser
DEBUG - 2018-10-27 10:43:20 --> Total execution time: 0.6049
INFO - 2018-10-27 10:43:20 --> Config Class Initialized
INFO - 2018-10-27 10:43:20 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:43:20 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:43:20 --> Utf8 Class Initialized
INFO - 2018-10-27 10:43:20 --> URI Class Initialized
INFO - 2018-10-27 10:43:20 --> Router Class Initialized
INFO - 2018-10-27 10:43:20 --> Output Class Initialized
INFO - 2018-10-27 10:43:20 --> Security Class Initialized
DEBUG - 2018-10-27 10:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:43:20 --> Input Class Initialized
INFO - 2018-10-27 10:43:20 --> Language Class Initialized
ERROR - 2018-10-27 10:43:20 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:43:41 --> Config Class Initialized
INFO - 2018-10-27 10:43:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:43:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:43:41 --> Utf8 Class Initialized
INFO - 2018-10-27 10:43:41 --> URI Class Initialized
INFO - 2018-10-27 10:43:41 --> Router Class Initialized
INFO - 2018-10-27 10:43:41 --> Output Class Initialized
INFO - 2018-10-27 10:43:41 --> Security Class Initialized
DEBUG - 2018-10-27 10:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:43:41 --> Input Class Initialized
INFO - 2018-10-27 10:43:41 --> Language Class Initialized
INFO - 2018-10-27 10:43:41 --> Loader Class Initialized
INFO - 2018-10-27 10:43:41 --> Helper loaded: url_helper
INFO - 2018-10-27 10:43:41 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:41 --> Helper loaded: form_helper
INFO - 2018-10-27 10:43:41 --> Form Validation Class Initialized
INFO - 2018-10-27 10:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:43:41 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:43:41 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:43:41 --> Email Class Initialized
INFO - 2018-10-27 10:43:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:43:41 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:43:41 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:43:41 --> Helper loaded: date_helper
INFO - 2018-10-27 10:43:41 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:43:41 --> Controller Class Initialized
INFO - 2018-10-27 10:43:41 --> Model "Item_model" initialized
INFO - 2018-10-27 10:43:41 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:43:41 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:43:41 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:43:41 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:43:41 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:43:42 --> Final output sent to browser
DEBUG - 2018-10-27 10:43:42 --> Total execution time: 0.6058
INFO - 2018-10-27 10:43:46 --> Config Class Initialized
INFO - 2018-10-27 10:43:46 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:43:46 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:43:46 --> Utf8 Class Initialized
INFO - 2018-10-27 10:43:46 --> URI Class Initialized
INFO - 2018-10-27 10:43:46 --> Router Class Initialized
INFO - 2018-10-27 10:43:46 --> Output Class Initialized
INFO - 2018-10-27 10:43:46 --> Security Class Initialized
DEBUG - 2018-10-27 10:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:43:46 --> Input Class Initialized
INFO - 2018-10-27 10:43:46 --> Language Class Initialized
INFO - 2018-10-27 10:43:46 --> Loader Class Initialized
INFO - 2018-10-27 10:43:46 --> Helper loaded: url_helper
INFO - 2018-10-27 10:43:46 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:46 --> Helper loaded: form_helper
INFO - 2018-10-27 10:43:46 --> Form Validation Class Initialized
INFO - 2018-10-27 10:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:43:46 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:43:46 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:43:46 --> Email Class Initialized
INFO - 2018-10-27 10:43:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:43:46 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:43:46 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:43:46 --> Helper loaded: date_helper
INFO - 2018-10-27 10:43:46 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:46 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:43:46 --> Controller Class Initialized
INFO - 2018-10-27 10:43:46 --> Model "Item_model" initialized
INFO - 2018-10-27 10:43:46 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:43:46 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:43:46 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:43:46 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:43:46 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 10:43:46 --> Final output sent to browser
DEBUG - 2018-10-27 10:43:46 --> Total execution time: 0.6139
INFO - 2018-10-27 10:43:46 --> Config Class Initialized
INFO - 2018-10-27 10:43:46 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:43:46 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:43:46 --> Utf8 Class Initialized
INFO - 2018-10-27 10:43:46 --> URI Class Initialized
INFO - 2018-10-27 10:43:46 --> Router Class Initialized
INFO - 2018-10-27 10:43:46 --> Output Class Initialized
INFO - 2018-10-27 10:43:46 --> Security Class Initialized
DEBUG - 2018-10-27 10:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:43:46 --> Input Class Initialized
INFO - 2018-10-27 10:43:46 --> Language Class Initialized
ERROR - 2018-10-27 10:43:46 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:43:50 --> Config Class Initialized
INFO - 2018-10-27 10:43:50 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:43:50 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:43:51 --> Utf8 Class Initialized
INFO - 2018-10-27 10:43:51 --> URI Class Initialized
INFO - 2018-10-27 10:43:51 --> Router Class Initialized
INFO - 2018-10-27 10:43:51 --> Output Class Initialized
INFO - 2018-10-27 10:43:51 --> Security Class Initialized
DEBUG - 2018-10-27 10:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:43:51 --> Input Class Initialized
INFO - 2018-10-27 10:43:51 --> Language Class Initialized
INFO - 2018-10-27 10:43:51 --> Loader Class Initialized
INFO - 2018-10-27 10:43:51 --> Helper loaded: url_helper
INFO - 2018-10-27 10:43:51 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:51 --> Helper loaded: form_helper
INFO - 2018-10-27 10:43:51 --> Form Validation Class Initialized
INFO - 2018-10-27 10:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:43:51 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:43:51 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:43:51 --> Email Class Initialized
INFO - 2018-10-27 10:43:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:43:51 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:43:51 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:43:51 --> Helper loaded: date_helper
INFO - 2018-10-27 10:43:51 --> Database Driver Class Initialized
INFO - 2018-10-27 10:43:51 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:43:51 --> Controller Class Initialized
INFO - 2018-10-27 10:43:51 --> Model "Item_model" initialized
INFO - 2018-10-27 10:43:51 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:43:51 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:43:51 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:43:51 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:43:51 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:43:51 --> Final output sent to browser
DEBUG - 2018-10-27 10:43:51 --> Total execution time: 0.6165
INFO - 2018-10-27 10:43:51 --> Config Class Initialized
INFO - 2018-10-27 10:43:51 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:43:51 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:43:51 --> Utf8 Class Initialized
INFO - 2018-10-27 10:43:51 --> URI Class Initialized
INFO - 2018-10-27 10:43:51 --> Router Class Initialized
INFO - 2018-10-27 10:43:51 --> Output Class Initialized
INFO - 2018-10-27 10:43:51 --> Security Class Initialized
DEBUG - 2018-10-27 10:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:43:51 --> Input Class Initialized
INFO - 2018-10-27 10:43:51 --> Language Class Initialized
ERROR - 2018-10-27 10:43:51 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:46:33 --> Config Class Initialized
INFO - 2018-10-27 10:46:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:46:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:46:33 --> Utf8 Class Initialized
INFO - 2018-10-27 10:46:33 --> URI Class Initialized
INFO - 2018-10-27 10:46:33 --> Router Class Initialized
INFO - 2018-10-27 10:46:33 --> Output Class Initialized
INFO - 2018-10-27 10:46:33 --> Security Class Initialized
DEBUG - 2018-10-27 10:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:46:33 --> Input Class Initialized
INFO - 2018-10-27 10:46:33 --> Language Class Initialized
INFO - 2018-10-27 10:46:34 --> Loader Class Initialized
INFO - 2018-10-27 10:46:34 --> Helper loaded: url_helper
INFO - 2018-10-27 10:46:34 --> Database Driver Class Initialized
INFO - 2018-10-27 10:46:34 --> Helper loaded: form_helper
INFO - 2018-10-27 10:46:34 --> Form Validation Class Initialized
INFO - 2018-10-27 10:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:46:34 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:46:34 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:46:34 --> Email Class Initialized
INFO - 2018-10-27 10:46:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:46:34 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:46:34 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:46:34 --> Helper loaded: date_helper
INFO - 2018-10-27 10:46:34 --> Database Driver Class Initialized
INFO - 2018-10-27 10:46:34 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:46:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:46:34 --> Controller Class Initialized
INFO - 2018-10-27 10:46:34 --> Model "Item_model" initialized
INFO - 2018-10-27 10:46:34 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:46:34 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:46:34 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:46:34 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:46:34 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:46:34 --> Final output sent to browser
DEBUG - 2018-10-27 10:46:34 --> Total execution time: 0.6147
INFO - 2018-10-27 10:46:37 --> Config Class Initialized
INFO - 2018-10-27 10:46:37 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:46:37 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:46:37 --> Utf8 Class Initialized
INFO - 2018-10-27 10:46:37 --> URI Class Initialized
INFO - 2018-10-27 10:46:37 --> Router Class Initialized
INFO - 2018-10-27 10:46:37 --> Output Class Initialized
INFO - 2018-10-27 10:46:37 --> Security Class Initialized
DEBUG - 2018-10-27 10:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:46:37 --> Input Class Initialized
INFO - 2018-10-27 10:46:37 --> Language Class Initialized
INFO - 2018-10-27 10:46:37 --> Loader Class Initialized
INFO - 2018-10-27 10:46:37 --> Helper loaded: url_helper
INFO - 2018-10-27 10:46:37 --> Database Driver Class Initialized
INFO - 2018-10-27 10:46:37 --> Helper loaded: form_helper
INFO - 2018-10-27 10:46:37 --> Form Validation Class Initialized
INFO - 2018-10-27 10:46:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:46:37 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:46:37 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:46:37 --> Email Class Initialized
INFO - 2018-10-27 10:46:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:46:37 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:46:37 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:46:38 --> Helper loaded: date_helper
INFO - 2018-10-27 10:46:38 --> Database Driver Class Initialized
INFO - 2018-10-27 10:46:38 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:46:38 --> Controller Class Initialized
INFO - 2018-10-27 10:46:38 --> Model "Item_model" initialized
INFO - 2018-10-27 10:46:38 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:46:38 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:46:38 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:46:38 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:46:38 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 10:46:38 --> Final output sent to browser
DEBUG - 2018-10-27 10:46:38 --> Total execution time: 0.6075
INFO - 2018-10-27 10:46:38 --> Config Class Initialized
INFO - 2018-10-27 10:46:38 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:46:38 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:46:38 --> Utf8 Class Initialized
INFO - 2018-10-27 10:46:38 --> URI Class Initialized
INFO - 2018-10-27 10:46:38 --> Router Class Initialized
INFO - 2018-10-27 10:46:38 --> Output Class Initialized
INFO - 2018-10-27 10:46:38 --> Security Class Initialized
DEBUG - 2018-10-27 10:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:46:38 --> Input Class Initialized
INFO - 2018-10-27 10:46:38 --> Language Class Initialized
ERROR - 2018-10-27 10:46:38 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:46:43 --> Config Class Initialized
INFO - 2018-10-27 10:46:43 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:46:43 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:46:43 --> Utf8 Class Initialized
INFO - 2018-10-27 10:46:43 --> URI Class Initialized
INFO - 2018-10-27 10:46:43 --> Router Class Initialized
INFO - 2018-10-27 10:46:43 --> Output Class Initialized
INFO - 2018-10-27 10:46:43 --> Security Class Initialized
DEBUG - 2018-10-27 10:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:46:43 --> Input Class Initialized
INFO - 2018-10-27 10:46:43 --> Language Class Initialized
INFO - 2018-10-27 10:46:43 --> Loader Class Initialized
INFO - 2018-10-27 10:46:43 --> Helper loaded: url_helper
INFO - 2018-10-27 10:46:43 --> Database Driver Class Initialized
INFO - 2018-10-27 10:46:43 --> Helper loaded: form_helper
INFO - 2018-10-27 10:46:43 --> Form Validation Class Initialized
INFO - 2018-10-27 10:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:46:43 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:46:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:46:43 --> Email Class Initialized
INFO - 2018-10-27 10:46:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:46:43 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:46:43 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:46:43 --> Helper loaded: date_helper
INFO - 2018-10-27 10:46:43 --> Database Driver Class Initialized
INFO - 2018-10-27 10:46:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:46:44 --> Controller Class Initialized
INFO - 2018-10-27 10:46:44 --> Model "Item_model" initialized
INFO - 2018-10-27 10:46:44 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:46:44 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:46:44 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:46:44 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:46:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:46:44 --> Final output sent to browser
DEBUG - 2018-10-27 10:46:44 --> Total execution time: 0.6269
INFO - 2018-10-27 10:46:44 --> Config Class Initialized
INFO - 2018-10-27 10:46:44 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:46:44 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:46:44 --> Utf8 Class Initialized
INFO - 2018-10-27 10:46:44 --> URI Class Initialized
INFO - 2018-10-27 10:46:44 --> Router Class Initialized
INFO - 2018-10-27 10:46:44 --> Output Class Initialized
INFO - 2018-10-27 10:46:44 --> Security Class Initialized
DEBUG - 2018-10-27 10:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:46:44 --> Input Class Initialized
INFO - 2018-10-27 10:46:44 --> Language Class Initialized
ERROR - 2018-10-27 10:46:44 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:49:24 --> Config Class Initialized
INFO - 2018-10-27 10:49:24 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:49:24 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:49:24 --> Utf8 Class Initialized
INFO - 2018-10-27 10:49:24 --> URI Class Initialized
INFO - 2018-10-27 10:49:24 --> Router Class Initialized
INFO - 2018-10-27 10:49:24 --> Output Class Initialized
INFO - 2018-10-27 10:49:24 --> Security Class Initialized
DEBUG - 2018-10-27 10:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:49:24 --> Input Class Initialized
INFO - 2018-10-27 10:49:24 --> Language Class Initialized
INFO - 2018-10-27 10:49:24 --> Loader Class Initialized
INFO - 2018-10-27 10:49:24 --> Helper loaded: url_helper
INFO - 2018-10-27 10:49:24 --> Database Driver Class Initialized
INFO - 2018-10-27 10:49:24 --> Helper loaded: form_helper
INFO - 2018-10-27 10:49:24 --> Form Validation Class Initialized
INFO - 2018-10-27 10:49:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:49:24 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:49:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:49:24 --> Email Class Initialized
INFO - 2018-10-27 10:49:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:49:24 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:49:24 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:49:24 --> Helper loaded: date_helper
INFO - 2018-10-27 10:49:24 --> Database Driver Class Initialized
INFO - 2018-10-27 10:49:24 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:49:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:49:24 --> Controller Class Initialized
INFO - 2018-10-27 10:49:24 --> Model "Item_model" initialized
INFO - 2018-10-27 10:49:24 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:49:24 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:49:24 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:49:24 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:49:24 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:49:24 --> Final output sent to browser
DEBUG - 2018-10-27 10:49:24 --> Total execution time: 0.6711
INFO - 2018-10-27 10:49:30 --> Config Class Initialized
INFO - 2018-10-27 10:49:30 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:49:30 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:49:30 --> Utf8 Class Initialized
INFO - 2018-10-27 10:49:30 --> URI Class Initialized
INFO - 2018-10-27 10:49:30 --> Router Class Initialized
INFO - 2018-10-27 10:49:30 --> Output Class Initialized
INFO - 2018-10-27 10:49:30 --> Security Class Initialized
DEBUG - 2018-10-27 10:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:49:30 --> Input Class Initialized
INFO - 2018-10-27 10:49:30 --> Language Class Initialized
INFO - 2018-10-27 10:49:30 --> Loader Class Initialized
INFO - 2018-10-27 10:49:30 --> Helper loaded: url_helper
INFO - 2018-10-27 10:49:30 --> Database Driver Class Initialized
INFO - 2018-10-27 10:49:30 --> Helper loaded: form_helper
INFO - 2018-10-27 10:49:30 --> Form Validation Class Initialized
INFO - 2018-10-27 10:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:49:30 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:49:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:49:30 --> Email Class Initialized
INFO - 2018-10-27 10:49:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:49:30 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:49:30 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:49:31 --> Helper loaded: date_helper
INFO - 2018-10-27 10:49:31 --> Database Driver Class Initialized
INFO - 2018-10-27 10:49:31 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:49:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:49:31 --> Controller Class Initialized
INFO - 2018-10-27 10:49:31 --> Model "Item_model" initialized
INFO - 2018-10-27 10:49:31 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:49:31 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:49:31 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:49:31 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:49:31 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 10:49:31 --> Final output sent to browser
DEBUG - 2018-10-27 10:49:31 --> Total execution time: 0.6305
INFO - 2018-10-27 10:49:31 --> Config Class Initialized
INFO - 2018-10-27 10:49:31 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:49:31 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:49:31 --> Utf8 Class Initialized
INFO - 2018-10-27 10:49:31 --> URI Class Initialized
INFO - 2018-10-27 10:49:31 --> Router Class Initialized
INFO - 2018-10-27 10:49:31 --> Output Class Initialized
INFO - 2018-10-27 10:49:31 --> Security Class Initialized
DEBUG - 2018-10-27 10:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:49:31 --> Input Class Initialized
INFO - 2018-10-27 10:49:31 --> Language Class Initialized
ERROR - 2018-10-27 10:49:31 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:49:32 --> Config Class Initialized
INFO - 2018-10-27 10:49:32 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:49:32 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:49:32 --> Utf8 Class Initialized
INFO - 2018-10-27 10:49:32 --> URI Class Initialized
INFO - 2018-10-27 10:49:32 --> Router Class Initialized
INFO - 2018-10-27 10:49:32 --> Output Class Initialized
INFO - 2018-10-27 10:49:32 --> Security Class Initialized
DEBUG - 2018-10-27 10:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:49:32 --> Input Class Initialized
INFO - 2018-10-27 10:49:32 --> Language Class Initialized
INFO - 2018-10-27 10:49:32 --> Loader Class Initialized
INFO - 2018-10-27 10:49:32 --> Helper loaded: url_helper
INFO - 2018-10-27 10:49:32 --> Database Driver Class Initialized
INFO - 2018-10-27 10:49:32 --> Helper loaded: form_helper
INFO - 2018-10-27 10:49:33 --> Form Validation Class Initialized
INFO - 2018-10-27 10:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:49:33 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:49:33 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:49:33 --> Email Class Initialized
INFO - 2018-10-27 10:49:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:49:33 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:49:33 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:49:33 --> Helper loaded: date_helper
INFO - 2018-10-27 10:49:33 --> Database Driver Class Initialized
INFO - 2018-10-27 10:49:33 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:49:33 --> Controller Class Initialized
INFO - 2018-10-27 10:49:33 --> Model "Item_model" initialized
INFO - 2018-10-27 10:49:33 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:49:33 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:49:33 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:49:33 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:49:33 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:49:33 --> Final output sent to browser
DEBUG - 2018-10-27 10:49:33 --> Total execution time: 0.6539
INFO - 2018-10-27 10:49:33 --> Config Class Initialized
INFO - 2018-10-27 10:49:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:49:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:49:33 --> Utf8 Class Initialized
INFO - 2018-10-27 10:49:33 --> URI Class Initialized
INFO - 2018-10-27 10:49:33 --> Router Class Initialized
INFO - 2018-10-27 10:49:33 --> Output Class Initialized
INFO - 2018-10-27 10:49:33 --> Security Class Initialized
DEBUG - 2018-10-27 10:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:49:33 --> Input Class Initialized
INFO - 2018-10-27 10:49:33 --> Language Class Initialized
ERROR - 2018-10-27 10:49:33 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:52:41 --> Config Class Initialized
INFO - 2018-10-27 10:52:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:52:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:52:41 --> Utf8 Class Initialized
INFO - 2018-10-27 10:52:41 --> URI Class Initialized
INFO - 2018-10-27 10:52:41 --> Router Class Initialized
INFO - 2018-10-27 10:52:41 --> Output Class Initialized
INFO - 2018-10-27 10:52:41 --> Security Class Initialized
DEBUG - 2018-10-27 10:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:52:41 --> Input Class Initialized
INFO - 2018-10-27 10:52:41 --> Language Class Initialized
INFO - 2018-10-27 10:52:41 --> Loader Class Initialized
INFO - 2018-10-27 10:52:41 --> Helper loaded: url_helper
INFO - 2018-10-27 10:52:41 --> Database Driver Class Initialized
INFO - 2018-10-27 10:52:41 --> Helper loaded: form_helper
INFO - 2018-10-27 10:52:41 --> Form Validation Class Initialized
INFO - 2018-10-27 10:52:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:52:41 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:52:41 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:52:41 --> Email Class Initialized
INFO - 2018-10-27 10:52:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:52:41 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:52:41 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:52:41 --> Helper loaded: date_helper
INFO - 2018-10-27 10:52:41 --> Database Driver Class Initialized
INFO - 2018-10-27 10:52:42 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:52:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:52:42 --> Controller Class Initialized
INFO - 2018-10-27 10:52:42 --> Model "Item_model" initialized
INFO - 2018-10-27 10:52:42 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:52:42 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:52:42 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:52:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:52:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:52:42 --> Final output sent to browser
DEBUG - 2018-10-27 10:52:42 --> Total execution time: 0.6277
INFO - 2018-10-27 10:52:42 --> Config Class Initialized
INFO - 2018-10-27 10:52:42 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:52:42 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:52:42 --> Utf8 Class Initialized
INFO - 2018-10-27 10:52:42 --> URI Class Initialized
INFO - 2018-10-27 10:52:42 --> Router Class Initialized
INFO - 2018-10-27 10:52:42 --> Output Class Initialized
INFO - 2018-10-27 10:52:42 --> Security Class Initialized
DEBUG - 2018-10-27 10:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:52:42 --> Input Class Initialized
INFO - 2018-10-27 10:52:42 --> Language Class Initialized
ERROR - 2018-10-27 10:52:42 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:53:28 --> Config Class Initialized
INFO - 2018-10-27 10:53:28 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:53:28 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:53:28 --> Utf8 Class Initialized
INFO - 2018-10-27 10:53:28 --> URI Class Initialized
INFO - 2018-10-27 10:53:28 --> Router Class Initialized
INFO - 2018-10-27 10:53:28 --> Output Class Initialized
INFO - 2018-10-27 10:53:28 --> Security Class Initialized
DEBUG - 2018-10-27 10:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:53:28 --> Input Class Initialized
INFO - 2018-10-27 10:53:28 --> Language Class Initialized
INFO - 2018-10-27 10:53:28 --> Loader Class Initialized
INFO - 2018-10-27 10:53:28 --> Helper loaded: url_helper
INFO - 2018-10-27 10:53:28 --> Database Driver Class Initialized
INFO - 2018-10-27 10:53:28 --> Helper loaded: form_helper
INFO - 2018-10-27 10:53:28 --> Form Validation Class Initialized
INFO - 2018-10-27 10:53:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:53:28 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:53:28 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:53:28 --> Email Class Initialized
INFO - 2018-10-27 10:53:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:53:28 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:53:28 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:53:29 --> Helper loaded: date_helper
INFO - 2018-10-27 10:53:29 --> Database Driver Class Initialized
INFO - 2018-10-27 10:53:29 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:53:29 --> Controller Class Initialized
INFO - 2018-10-27 10:53:29 --> Model "Item_model" initialized
INFO - 2018-10-27 10:53:29 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:53:29 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:53:29 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:53:29 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:53:29 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:53:29 --> Final output sent to browser
DEBUG - 2018-10-27 10:53:29 --> Total execution time: 0.6534
INFO - 2018-10-27 10:53:29 --> Config Class Initialized
INFO - 2018-10-27 10:53:29 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:53:29 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:53:29 --> Utf8 Class Initialized
INFO - 2018-10-27 10:53:29 --> URI Class Initialized
INFO - 2018-10-27 10:53:29 --> Router Class Initialized
INFO - 2018-10-27 10:53:29 --> Output Class Initialized
INFO - 2018-10-27 10:53:29 --> Security Class Initialized
DEBUG - 2018-10-27 10:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:53:29 --> Input Class Initialized
INFO - 2018-10-27 10:53:29 --> Language Class Initialized
ERROR - 2018-10-27 10:53:29 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:54:14 --> Config Class Initialized
INFO - 2018-10-27 10:54:14 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:54:14 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:54:14 --> Utf8 Class Initialized
INFO - 2018-10-27 10:54:14 --> URI Class Initialized
INFO - 2018-10-27 10:54:14 --> Router Class Initialized
INFO - 2018-10-27 10:54:14 --> Output Class Initialized
INFO - 2018-10-27 10:54:14 --> Security Class Initialized
DEBUG - 2018-10-27 10:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:54:14 --> Input Class Initialized
INFO - 2018-10-27 10:54:14 --> Language Class Initialized
INFO - 2018-10-27 10:54:14 --> Loader Class Initialized
INFO - 2018-10-27 10:54:14 --> Helper loaded: url_helper
INFO - 2018-10-27 10:54:14 --> Database Driver Class Initialized
INFO - 2018-10-27 10:54:14 --> Helper loaded: form_helper
INFO - 2018-10-27 10:54:14 --> Form Validation Class Initialized
INFO - 2018-10-27 10:54:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:54:14 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:54:14 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:54:14 --> Email Class Initialized
INFO - 2018-10-27 10:54:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:54:14 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:54:14 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:54:14 --> Helper loaded: date_helper
INFO - 2018-10-27 10:54:14 --> Database Driver Class Initialized
INFO - 2018-10-27 10:54:14 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:54:14 --> Controller Class Initialized
INFO - 2018-10-27 10:54:14 --> Model "Item_model" initialized
INFO - 2018-10-27 10:54:14 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:54:14 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:54:14 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:54:14 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:54:14 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:54:14 --> Final output sent to browser
DEBUG - 2018-10-27 10:54:14 --> Total execution time: 0.6499
INFO - 2018-10-27 10:54:18 --> Config Class Initialized
INFO - 2018-10-27 10:54:18 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:54:18 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:54:18 --> Utf8 Class Initialized
INFO - 2018-10-27 10:54:18 --> URI Class Initialized
INFO - 2018-10-27 10:54:18 --> Router Class Initialized
INFO - 2018-10-27 10:54:18 --> Output Class Initialized
INFO - 2018-10-27 10:54:18 --> Security Class Initialized
DEBUG - 2018-10-27 10:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:54:18 --> Input Class Initialized
INFO - 2018-10-27 10:54:18 --> Language Class Initialized
INFO - 2018-10-27 10:54:18 --> Loader Class Initialized
INFO - 2018-10-27 10:54:18 --> Helper loaded: url_helper
INFO - 2018-10-27 10:54:18 --> Database Driver Class Initialized
INFO - 2018-10-27 10:54:18 --> Helper loaded: form_helper
INFO - 2018-10-27 10:54:18 --> Form Validation Class Initialized
INFO - 2018-10-27 10:54:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:54:18 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:54:18 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:54:18 --> Email Class Initialized
INFO - 2018-10-27 10:54:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:54:18 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:54:18 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:54:18 --> Helper loaded: date_helper
INFO - 2018-10-27 10:54:18 --> Database Driver Class Initialized
INFO - 2018-10-27 10:54:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:54:18 --> Controller Class Initialized
INFO - 2018-10-27 10:54:18 --> Model "Item_model" initialized
INFO - 2018-10-27 10:54:18 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:54:18 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:54:18 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:54:18 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:54:18 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 10:54:18 --> Final output sent to browser
DEBUG - 2018-10-27 10:54:18 --> Total execution time: 0.6601
INFO - 2018-10-27 10:54:18 --> Config Class Initialized
INFO - 2018-10-27 10:54:18 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:54:18 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:54:18 --> Utf8 Class Initialized
INFO - 2018-10-27 10:54:18 --> URI Class Initialized
INFO - 2018-10-27 10:54:18 --> Router Class Initialized
INFO - 2018-10-27 10:54:18 --> Output Class Initialized
INFO - 2018-10-27 10:54:18 --> Security Class Initialized
DEBUG - 2018-10-27 10:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:54:19 --> Input Class Initialized
INFO - 2018-10-27 10:54:19 --> Language Class Initialized
ERROR - 2018-10-27 10:54:19 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:54:32 --> Config Class Initialized
INFO - 2018-10-27 10:54:32 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:54:32 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:54:32 --> Utf8 Class Initialized
INFO - 2018-10-27 10:54:32 --> URI Class Initialized
INFO - 2018-10-27 10:54:32 --> Router Class Initialized
INFO - 2018-10-27 10:54:32 --> Output Class Initialized
INFO - 2018-10-27 10:54:32 --> Security Class Initialized
DEBUG - 2018-10-27 10:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:54:32 --> Input Class Initialized
INFO - 2018-10-27 10:54:32 --> Language Class Initialized
INFO - 2018-10-27 10:54:32 --> Loader Class Initialized
INFO - 2018-10-27 10:54:32 --> Helper loaded: url_helper
INFO - 2018-10-27 10:54:32 --> Database Driver Class Initialized
INFO - 2018-10-27 10:54:32 --> Helper loaded: form_helper
INFO - 2018-10-27 10:54:32 --> Form Validation Class Initialized
INFO - 2018-10-27 10:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:54:32 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:54:32 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:54:32 --> Email Class Initialized
INFO - 2018-10-27 10:54:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:54:32 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:54:32 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:54:32 --> Helper loaded: date_helper
INFO - 2018-10-27 10:54:32 --> Database Driver Class Initialized
INFO - 2018-10-27 10:54:32 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:54:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:54:33 --> Controller Class Initialized
INFO - 2018-10-27 10:54:33 --> Model "Item_model" initialized
INFO - 2018-10-27 10:54:33 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:54:33 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:54:33 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:54:33 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:54:33 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:54:33 --> Final output sent to browser
DEBUG - 2018-10-27 10:54:33 --> Total execution time: 0.6389
INFO - 2018-10-27 10:54:33 --> Config Class Initialized
INFO - 2018-10-27 10:54:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:54:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:54:33 --> Utf8 Class Initialized
INFO - 2018-10-27 10:54:33 --> URI Class Initialized
INFO - 2018-10-27 10:54:33 --> Router Class Initialized
INFO - 2018-10-27 10:54:33 --> Output Class Initialized
INFO - 2018-10-27 10:54:33 --> Security Class Initialized
DEBUG - 2018-10-27 10:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:54:33 --> Input Class Initialized
INFO - 2018-10-27 10:54:33 --> Language Class Initialized
ERROR - 2018-10-27 10:54:33 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:57:20 --> Config Class Initialized
INFO - 2018-10-27 10:57:20 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:57:20 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:57:20 --> Utf8 Class Initialized
INFO - 2018-10-27 10:57:20 --> URI Class Initialized
INFO - 2018-10-27 10:57:20 --> Router Class Initialized
INFO - 2018-10-27 10:57:20 --> Output Class Initialized
INFO - 2018-10-27 10:57:20 --> Security Class Initialized
DEBUG - 2018-10-27 10:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:57:20 --> Input Class Initialized
INFO - 2018-10-27 10:57:20 --> Language Class Initialized
INFO - 2018-10-27 10:57:20 --> Loader Class Initialized
INFO - 2018-10-27 10:57:20 --> Helper loaded: url_helper
INFO - 2018-10-27 10:57:20 --> Database Driver Class Initialized
INFO - 2018-10-27 10:57:20 --> Helper loaded: form_helper
INFO - 2018-10-27 10:57:20 --> Form Validation Class Initialized
INFO - 2018-10-27 10:57:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:57:20 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:57:20 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:57:20 --> Email Class Initialized
INFO - 2018-10-27 10:57:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:57:20 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:57:20 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:57:20 --> Helper loaded: date_helper
INFO - 2018-10-27 10:57:20 --> Database Driver Class Initialized
INFO - 2018-10-27 10:57:21 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:57:21 --> Controller Class Initialized
INFO - 2018-10-27 10:57:21 --> Model "Item_model" initialized
INFO - 2018-10-27 10:57:21 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:57:21 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:57:21 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:57:21 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:57:21 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:57:21 --> Final output sent to browser
DEBUG - 2018-10-27 10:57:21 --> Total execution time: 0.6401
INFO - 2018-10-27 10:57:24 --> Config Class Initialized
INFO - 2018-10-27 10:57:24 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:57:24 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:57:24 --> Utf8 Class Initialized
INFO - 2018-10-27 10:57:24 --> URI Class Initialized
INFO - 2018-10-27 10:57:24 --> Router Class Initialized
INFO - 2018-10-27 10:57:24 --> Output Class Initialized
INFO - 2018-10-27 10:57:24 --> Security Class Initialized
DEBUG - 2018-10-27 10:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:57:24 --> Input Class Initialized
INFO - 2018-10-27 10:57:24 --> Language Class Initialized
INFO - 2018-10-27 10:57:24 --> Loader Class Initialized
INFO - 2018-10-27 10:57:24 --> Helper loaded: url_helper
INFO - 2018-10-27 10:57:24 --> Database Driver Class Initialized
INFO - 2018-10-27 10:57:24 --> Helper loaded: form_helper
INFO - 2018-10-27 10:57:24 --> Form Validation Class Initialized
INFO - 2018-10-27 10:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:57:24 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:57:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:57:24 --> Email Class Initialized
INFO - 2018-10-27 10:57:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:57:24 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:57:24 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:57:24 --> Helper loaded: date_helper
INFO - 2018-10-27 10:57:24 --> Database Driver Class Initialized
INFO - 2018-10-27 10:57:24 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:57:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:57:24 --> Controller Class Initialized
INFO - 2018-10-27 10:57:24 --> Model "Item_model" initialized
INFO - 2018-10-27 10:57:24 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:57:24 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:57:24 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:57:24 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:57:25 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 10:57:25 --> Final output sent to browser
DEBUG - 2018-10-27 10:57:25 --> Total execution time: 0.6292
INFO - 2018-10-27 10:57:25 --> Config Class Initialized
INFO - 2018-10-27 10:57:25 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:57:25 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:57:25 --> Utf8 Class Initialized
INFO - 2018-10-27 10:57:25 --> URI Class Initialized
INFO - 2018-10-27 10:57:25 --> Router Class Initialized
INFO - 2018-10-27 10:57:25 --> Output Class Initialized
INFO - 2018-10-27 10:57:25 --> Security Class Initialized
DEBUG - 2018-10-27 10:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:57:25 --> Input Class Initialized
INFO - 2018-10-27 10:57:25 --> Language Class Initialized
ERROR - 2018-10-27 10:57:25 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:57:28 --> Config Class Initialized
INFO - 2018-10-27 10:57:28 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:57:28 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:57:28 --> Utf8 Class Initialized
INFO - 2018-10-27 10:57:28 --> URI Class Initialized
INFO - 2018-10-27 10:57:28 --> Router Class Initialized
INFO - 2018-10-27 10:57:28 --> Output Class Initialized
INFO - 2018-10-27 10:57:28 --> Security Class Initialized
DEBUG - 2018-10-27 10:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:57:28 --> Input Class Initialized
INFO - 2018-10-27 10:57:28 --> Language Class Initialized
INFO - 2018-10-27 10:57:28 --> Loader Class Initialized
INFO - 2018-10-27 10:57:28 --> Helper loaded: url_helper
INFO - 2018-10-27 10:57:28 --> Database Driver Class Initialized
INFO - 2018-10-27 10:57:28 --> Helper loaded: form_helper
INFO - 2018-10-27 10:57:28 --> Form Validation Class Initialized
INFO - 2018-10-27 10:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:57:28 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:57:28 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:57:28 --> Email Class Initialized
INFO - 2018-10-27 10:57:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:57:28 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:57:28 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:57:28 --> Helper loaded: date_helper
INFO - 2018-10-27 10:57:28 --> Database Driver Class Initialized
INFO - 2018-10-27 10:57:28 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:57:29 --> Controller Class Initialized
INFO - 2018-10-27 10:57:29 --> Model "Item_model" initialized
INFO - 2018-10-27 10:57:29 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:57:29 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:57:29 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:57:29 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:57:29 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:57:29 --> Final output sent to browser
DEBUG - 2018-10-27 10:57:29 --> Total execution time: 0.6097
INFO - 2018-10-27 10:57:34 --> Config Class Initialized
INFO - 2018-10-27 10:57:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:57:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:57:34 --> Utf8 Class Initialized
INFO - 2018-10-27 10:57:34 --> URI Class Initialized
INFO - 2018-10-27 10:57:34 --> Router Class Initialized
INFO - 2018-10-27 10:57:34 --> Output Class Initialized
INFO - 2018-10-27 10:57:34 --> Security Class Initialized
DEBUG - 2018-10-27 10:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:57:34 --> Input Class Initialized
INFO - 2018-10-27 10:57:34 --> Language Class Initialized
INFO - 2018-10-27 10:57:34 --> Loader Class Initialized
INFO - 2018-10-27 10:57:34 --> Helper loaded: url_helper
INFO - 2018-10-27 10:57:34 --> Database Driver Class Initialized
INFO - 2018-10-27 10:57:34 --> Helper loaded: form_helper
INFO - 2018-10-27 10:57:34 --> Form Validation Class Initialized
INFO - 2018-10-27 10:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:57:34 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:57:35 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:57:35 --> Email Class Initialized
INFO - 2018-10-27 10:57:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:57:35 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:57:35 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:57:35 --> Helper loaded: date_helper
INFO - 2018-10-27 10:57:35 --> Database Driver Class Initialized
INFO - 2018-10-27 10:57:35 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:57:35 --> Controller Class Initialized
INFO - 2018-10-27 10:57:35 --> Model "Item_model" initialized
INFO - 2018-10-27 10:57:35 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:57:35 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:57:35 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:57:35 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:57:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 10:57:35 --> Final output sent to browser
DEBUG - 2018-10-27 10:57:35 --> Total execution time: 0.6511
INFO - 2018-10-27 10:57:35 --> Config Class Initialized
INFO - 2018-10-27 10:57:35 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:57:35 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:57:35 --> Utf8 Class Initialized
INFO - 2018-10-27 10:57:35 --> URI Class Initialized
INFO - 2018-10-27 10:57:35 --> Router Class Initialized
INFO - 2018-10-27 10:57:35 --> Output Class Initialized
INFO - 2018-10-27 10:57:35 --> Security Class Initialized
DEBUG - 2018-10-27 10:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:57:35 --> Input Class Initialized
INFO - 2018-10-27 10:57:35 --> Language Class Initialized
ERROR - 2018-10-27 10:57:35 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:57:41 --> Config Class Initialized
INFO - 2018-10-27 10:57:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:57:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:57:41 --> Utf8 Class Initialized
INFO - 2018-10-27 10:57:41 --> URI Class Initialized
INFO - 2018-10-27 10:57:41 --> Router Class Initialized
INFO - 2018-10-27 10:57:41 --> Output Class Initialized
INFO - 2018-10-27 10:57:41 --> Security Class Initialized
DEBUG - 2018-10-27 10:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:57:41 --> Input Class Initialized
INFO - 2018-10-27 10:57:41 --> Language Class Initialized
INFO - 2018-10-27 10:57:41 --> Loader Class Initialized
INFO - 2018-10-27 10:57:41 --> Helper loaded: url_helper
INFO - 2018-10-27 10:57:41 --> Database Driver Class Initialized
INFO - 2018-10-27 10:57:41 --> Helper loaded: form_helper
INFO - 2018-10-27 10:57:41 --> Form Validation Class Initialized
INFO - 2018-10-27 10:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:57:41 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:57:41 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:57:41 --> Email Class Initialized
INFO - 2018-10-27 10:57:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:57:41 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:57:41 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:57:41 --> Helper loaded: date_helper
INFO - 2018-10-27 10:57:41 --> Database Driver Class Initialized
INFO - 2018-10-27 10:57:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:57:41 --> Controller Class Initialized
INFO - 2018-10-27 10:57:41 --> Model "Item_model" initialized
INFO - 2018-10-27 10:57:41 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:57:41 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:57:41 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:57:41 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 10:57:41 --> Severity: Notice --> Undefined variable: records D:\xampp\htdocs\masterwedding\application\views\item\nota.php 53
ERROR - 2018-10-27 10:57:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\nota.php 53
ERROR - 2018-10-27 10:57:41 --> Severity: Notice --> Undefined variable: records D:\xampp\htdocs\masterwedding\application\views\item\nota.php 57
ERROR - 2018-10-27 10:57:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\nota.php 57
INFO - 2018-10-27 10:57:41 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:57:41 --> Final output sent to browser
DEBUG - 2018-10-27 10:57:41 --> Total execution time: 0.7041
INFO - 2018-10-27 10:57:41 --> Config Class Initialized
INFO - 2018-10-27 10:57:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:57:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:57:41 --> Utf8 Class Initialized
INFO - 2018-10-27 10:57:41 --> URI Class Initialized
INFO - 2018-10-27 10:57:41 --> Router Class Initialized
INFO - 2018-10-27 10:57:41 --> Output Class Initialized
INFO - 2018-10-27 10:57:41 --> Security Class Initialized
DEBUG - 2018-10-27 10:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:57:41 --> Input Class Initialized
INFO - 2018-10-27 10:57:41 --> Language Class Initialized
ERROR - 2018-10-27 10:57:41 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:59:34 --> Config Class Initialized
INFO - 2018-10-27 10:59:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:59:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:59:34 --> Utf8 Class Initialized
INFO - 2018-10-27 10:59:34 --> URI Class Initialized
INFO - 2018-10-27 10:59:34 --> Router Class Initialized
INFO - 2018-10-27 10:59:34 --> Output Class Initialized
INFO - 2018-10-27 10:59:34 --> Security Class Initialized
DEBUG - 2018-10-27 10:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:59:34 --> Input Class Initialized
INFO - 2018-10-27 10:59:34 --> Language Class Initialized
INFO - 2018-10-27 10:59:34 --> Loader Class Initialized
INFO - 2018-10-27 10:59:34 --> Helper loaded: url_helper
INFO - 2018-10-27 10:59:34 --> Database Driver Class Initialized
INFO - 2018-10-27 10:59:34 --> Helper loaded: form_helper
INFO - 2018-10-27 10:59:34 --> Form Validation Class Initialized
INFO - 2018-10-27 10:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:59:34 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:59:34 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:59:34 --> Email Class Initialized
INFO - 2018-10-27 10:59:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:59:34 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:59:34 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:59:34 --> Helper loaded: date_helper
INFO - 2018-10-27 10:59:34 --> Database Driver Class Initialized
INFO - 2018-10-27 10:59:34 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:59:34 --> Controller Class Initialized
INFO - 2018-10-27 10:59:34 --> Model "Item_model" initialized
INFO - 2018-10-27 10:59:34 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:59:35 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:59:35 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:59:35 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:59:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 10:59:35 --> Final output sent to browser
DEBUG - 2018-10-27 10:59:35 --> Total execution time: 0.6779
INFO - 2018-10-27 10:59:38 --> Config Class Initialized
INFO - 2018-10-27 10:59:38 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:59:38 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:59:38 --> Utf8 Class Initialized
INFO - 2018-10-27 10:59:38 --> URI Class Initialized
INFO - 2018-10-27 10:59:38 --> Router Class Initialized
INFO - 2018-10-27 10:59:38 --> Output Class Initialized
INFO - 2018-10-27 10:59:38 --> Security Class Initialized
DEBUG - 2018-10-27 10:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:59:38 --> Input Class Initialized
INFO - 2018-10-27 10:59:38 --> Language Class Initialized
INFO - 2018-10-27 10:59:38 --> Loader Class Initialized
INFO - 2018-10-27 10:59:38 --> Helper loaded: url_helper
INFO - 2018-10-27 10:59:38 --> Database Driver Class Initialized
INFO - 2018-10-27 10:59:38 --> Helper loaded: form_helper
INFO - 2018-10-27 10:59:38 --> Form Validation Class Initialized
INFO - 2018-10-27 10:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 10:59:38 --> Pagination Class Initialized
DEBUG - 2018-10-27 10:59:38 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 10:59:38 --> Email Class Initialized
INFO - 2018-10-27 10:59:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 10:59:38 --> Helper loaded: cookie_helper
INFO - 2018-10-27 10:59:38 --> Helper loaded: language_helper
DEBUG - 2018-10-27 10:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 10:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 10:59:38 --> Helper loaded: date_helper
INFO - 2018-10-27 10:59:38 --> Database Driver Class Initialized
INFO - 2018-10-27 10:59:38 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 10:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 10:59:38 --> Controller Class Initialized
INFO - 2018-10-27 10:59:38 --> Model "Item_model" initialized
INFO - 2018-10-27 10:59:38 --> Model "Jenis_model" initialized
INFO - 2018-10-27 10:59:38 --> Model "Vendor_model" initialized
INFO - 2018-10-27 10:59:38 --> Model "Nota_model" initialized
INFO - 2018-10-27 10:59:38 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 10:59:38 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
ERROR - 2018-10-27 10:59:38 --> Severity: Notice --> Undefined variable: no_nota D:\xampp\htdocs\masterwedding\application\views\item\nota.php 13
ERROR - 2018-10-27 10:59:38 --> Severity: Notice --> Undefined variable: tanggal D:\xampp\htdocs\masterwedding\application\views\item\nota.php 17
ERROR - 2018-10-27 10:59:38 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\masterwedding\application\views\item\nota.php 21
INFO - 2018-10-27 10:59:38 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 10:59:38 --> Final output sent to browser
DEBUG - 2018-10-27 10:59:38 --> Total execution time: 0.7519
INFO - 2018-10-27 10:59:38 --> Config Class Initialized
INFO - 2018-10-27 10:59:38 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:59:38 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:59:38 --> Utf8 Class Initialized
INFO - 2018-10-27 10:59:38 --> URI Class Initialized
INFO - 2018-10-27 10:59:38 --> Router Class Initialized
INFO - 2018-10-27 10:59:38 --> Output Class Initialized
INFO - 2018-10-27 10:59:38 --> Security Class Initialized
DEBUG - 2018-10-27 10:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:59:38 --> Input Class Initialized
INFO - 2018-10-27 10:59:38 --> Language Class Initialized
ERROR - 2018-10-27 10:59:38 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 10:59:39 --> Config Class Initialized
INFO - 2018-10-27 10:59:39 --> Hooks Class Initialized
DEBUG - 2018-10-27 10:59:39 --> UTF-8 Support Enabled
INFO - 2018-10-27 10:59:39 --> Utf8 Class Initialized
INFO - 2018-10-27 10:59:39 --> URI Class Initialized
INFO - 2018-10-27 10:59:39 --> Router Class Initialized
INFO - 2018-10-27 10:59:39 --> Output Class Initialized
INFO - 2018-10-27 10:59:39 --> Security Class Initialized
DEBUG - 2018-10-27 10:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 10:59:39 --> Input Class Initialized
INFO - 2018-10-27 10:59:39 --> Language Class Initialized
ERROR - 2018-10-27 10:59:39 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:01:25 --> Config Class Initialized
INFO - 2018-10-27 11:01:25 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:01:25 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:01:25 --> Utf8 Class Initialized
INFO - 2018-10-27 11:01:25 --> URI Class Initialized
INFO - 2018-10-27 11:01:25 --> Router Class Initialized
INFO - 2018-10-27 11:01:25 --> Output Class Initialized
INFO - 2018-10-27 11:01:25 --> Security Class Initialized
DEBUG - 2018-10-27 11:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:01:26 --> Input Class Initialized
INFO - 2018-10-27 11:01:26 --> Language Class Initialized
INFO - 2018-10-27 11:01:26 --> Loader Class Initialized
INFO - 2018-10-27 11:01:26 --> Helper loaded: url_helper
INFO - 2018-10-27 11:01:26 --> Database Driver Class Initialized
INFO - 2018-10-27 11:01:26 --> Helper loaded: form_helper
INFO - 2018-10-27 11:01:26 --> Form Validation Class Initialized
INFO - 2018-10-27 11:01:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:01:26 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:01:26 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:01:26 --> Email Class Initialized
INFO - 2018-10-27 11:01:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:01:26 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:01:26 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:01:26 --> Helper loaded: date_helper
INFO - 2018-10-27 11:01:26 --> Database Driver Class Initialized
INFO - 2018-10-27 11:01:26 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:01:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:01:26 --> Controller Class Initialized
INFO - 2018-10-27 11:01:26 --> Model "Item_model" initialized
INFO - 2018-10-27 11:01:26 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:01:26 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:01:26 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:01:26 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 11:01:26 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 11:01:26 --> Final output sent to browser
DEBUG - 2018-10-27 11:01:26 --> Total execution time: 0.6548
INFO - 2018-10-27 11:01:30 --> Config Class Initialized
INFO - 2018-10-27 11:01:30 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:01:30 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:01:30 --> Utf8 Class Initialized
INFO - 2018-10-27 11:01:30 --> URI Class Initialized
INFO - 2018-10-27 11:01:30 --> Router Class Initialized
INFO - 2018-10-27 11:01:30 --> Output Class Initialized
INFO - 2018-10-27 11:01:30 --> Security Class Initialized
DEBUG - 2018-10-27 11:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:01:30 --> Input Class Initialized
INFO - 2018-10-27 11:01:30 --> Language Class Initialized
INFO - 2018-10-27 11:01:30 --> Loader Class Initialized
INFO - 2018-10-27 11:01:30 --> Helper loaded: url_helper
INFO - 2018-10-27 11:01:30 --> Database Driver Class Initialized
INFO - 2018-10-27 11:01:30 --> Helper loaded: form_helper
INFO - 2018-10-27 11:01:30 --> Form Validation Class Initialized
INFO - 2018-10-27 11:01:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:01:30 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:01:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:01:30 --> Email Class Initialized
INFO - 2018-10-27 11:01:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:01:30 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:01:30 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:01:30 --> Helper loaded: date_helper
INFO - 2018-10-27 11:01:30 --> Database Driver Class Initialized
INFO - 2018-10-27 11:01:30 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:01:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:01:30 --> Controller Class Initialized
INFO - 2018-10-27 11:01:30 --> Model "Item_model" initialized
INFO - 2018-10-27 11:01:30 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:01:30 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:01:30 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:01:30 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 11:01:30 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 11:01:30 --> Final output sent to browser
DEBUG - 2018-10-27 11:01:30 --> Total execution time: 0.6318
INFO - 2018-10-27 11:01:30 --> Config Class Initialized
INFO - 2018-10-27 11:01:30 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:01:30 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:01:30 --> Utf8 Class Initialized
INFO - 2018-10-27 11:01:30 --> URI Class Initialized
INFO - 2018-10-27 11:01:31 --> Router Class Initialized
INFO - 2018-10-27 11:01:31 --> Output Class Initialized
INFO - 2018-10-27 11:01:31 --> Security Class Initialized
DEBUG - 2018-10-27 11:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:01:31 --> Input Class Initialized
INFO - 2018-10-27 11:01:31 --> Language Class Initialized
ERROR - 2018-10-27 11:01:31 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:01:34 --> Config Class Initialized
INFO - 2018-10-27 11:01:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:01:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:01:34 --> Utf8 Class Initialized
INFO - 2018-10-27 11:01:34 --> URI Class Initialized
INFO - 2018-10-27 11:01:34 --> Router Class Initialized
INFO - 2018-10-27 11:01:34 --> Output Class Initialized
INFO - 2018-10-27 11:01:34 --> Security Class Initialized
DEBUG - 2018-10-27 11:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:01:34 --> Input Class Initialized
INFO - 2018-10-27 11:01:34 --> Language Class Initialized
INFO - 2018-10-27 11:01:34 --> Loader Class Initialized
INFO - 2018-10-27 11:01:34 --> Helper loaded: url_helper
INFO - 2018-10-27 11:01:34 --> Database Driver Class Initialized
INFO - 2018-10-27 11:01:34 --> Helper loaded: form_helper
INFO - 2018-10-27 11:01:34 --> Form Validation Class Initialized
INFO - 2018-10-27 11:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:01:34 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:01:34 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:01:34 --> Email Class Initialized
INFO - 2018-10-27 11:01:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:01:34 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:01:34 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:01:34 --> Helper loaded: date_helper
INFO - 2018-10-27 11:01:34 --> Database Driver Class Initialized
INFO - 2018-10-27 11:01:34 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:01:34 --> Controller Class Initialized
INFO - 2018-10-27 11:01:34 --> Model "Item_model" initialized
INFO - 2018-10-27 11:01:34 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:01:34 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:01:34 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:01:34 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 11:01:34 --> Severity: Notice --> Undefined variable: record D:\xampp\htdocs\masterwedding\application\controllers\Item.php 159
ERROR - 2018-10-27 11:01:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 53
ERROR - 2018-10-27 11:01:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 57
INFO - 2018-10-27 11:01:34 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 11:01:34 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 11:01:34 --> Final output sent to browser
DEBUG - 2018-10-27 11:01:34 --> Total execution time: 0.6954
INFO - 2018-10-27 11:01:34 --> Config Class Initialized
INFO - 2018-10-27 11:01:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:01:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:01:34 --> Utf8 Class Initialized
INFO - 2018-10-27 11:01:34 --> URI Class Initialized
INFO - 2018-10-27 11:01:34 --> Router Class Initialized
INFO - 2018-10-27 11:01:34 --> Output Class Initialized
INFO - 2018-10-27 11:01:34 --> Security Class Initialized
DEBUG - 2018-10-27 11:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:01:35 --> Input Class Initialized
INFO - 2018-10-27 11:01:35 --> Language Class Initialized
ERROR - 2018-10-27 11:01:35 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:01:35 --> Config Class Initialized
INFO - 2018-10-27 11:01:35 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:01:35 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:01:35 --> Utf8 Class Initialized
INFO - 2018-10-27 11:01:35 --> URI Class Initialized
INFO - 2018-10-27 11:01:35 --> Router Class Initialized
INFO - 2018-10-27 11:01:35 --> Output Class Initialized
INFO - 2018-10-27 11:01:35 --> Security Class Initialized
DEBUG - 2018-10-27 11:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:01:35 --> Input Class Initialized
INFO - 2018-10-27 11:01:35 --> Language Class Initialized
ERROR - 2018-10-27 11:01:35 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:01:56 --> Config Class Initialized
INFO - 2018-10-27 11:01:56 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:01:56 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:01:56 --> Utf8 Class Initialized
INFO - 2018-10-27 11:01:56 --> URI Class Initialized
INFO - 2018-10-27 11:01:56 --> Router Class Initialized
INFO - 2018-10-27 11:01:56 --> Output Class Initialized
INFO - 2018-10-27 11:01:56 --> Security Class Initialized
DEBUG - 2018-10-27 11:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:01:56 --> Input Class Initialized
INFO - 2018-10-27 11:01:57 --> Language Class Initialized
INFO - 2018-10-27 11:01:57 --> Loader Class Initialized
INFO - 2018-10-27 11:01:57 --> Helper loaded: url_helper
INFO - 2018-10-27 11:01:57 --> Database Driver Class Initialized
INFO - 2018-10-27 11:01:57 --> Helper loaded: form_helper
INFO - 2018-10-27 11:01:57 --> Form Validation Class Initialized
INFO - 2018-10-27 11:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:01:57 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:01:57 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:01:57 --> Email Class Initialized
INFO - 2018-10-27 11:01:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:01:57 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:01:57 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:01:57 --> Helper loaded: date_helper
INFO - 2018-10-27 11:01:57 --> Database Driver Class Initialized
INFO - 2018-10-27 11:01:57 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:01:57 --> Controller Class Initialized
INFO - 2018-10-27 11:01:57 --> Model "Item_model" initialized
INFO - 2018-10-27 11:01:57 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:01:57 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:01:57 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:01:57 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 11:01:57 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 11:01:57 --> Final output sent to browser
DEBUG - 2018-10-27 11:01:57 --> Total execution time: 0.6319
INFO - 2018-10-27 11:02:01 --> Config Class Initialized
INFO - 2018-10-27 11:02:02 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:02:02 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:02:02 --> Utf8 Class Initialized
INFO - 2018-10-27 11:02:02 --> URI Class Initialized
INFO - 2018-10-27 11:02:02 --> Router Class Initialized
INFO - 2018-10-27 11:02:02 --> Output Class Initialized
INFO - 2018-10-27 11:02:02 --> Security Class Initialized
DEBUG - 2018-10-27 11:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:02:02 --> Input Class Initialized
INFO - 2018-10-27 11:02:02 --> Language Class Initialized
INFO - 2018-10-27 11:02:02 --> Loader Class Initialized
INFO - 2018-10-27 11:02:02 --> Helper loaded: url_helper
INFO - 2018-10-27 11:02:02 --> Database Driver Class Initialized
INFO - 2018-10-27 11:02:02 --> Helper loaded: form_helper
INFO - 2018-10-27 11:02:02 --> Form Validation Class Initialized
INFO - 2018-10-27 11:02:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:02:02 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:02:02 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:02:02 --> Email Class Initialized
INFO - 2018-10-27 11:02:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:02:02 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:02:02 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:02:02 --> Helper loaded: date_helper
INFO - 2018-10-27 11:02:02 --> Database Driver Class Initialized
INFO - 2018-10-27 11:02:02 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:02:02 --> Controller Class Initialized
INFO - 2018-10-27 11:02:02 --> Model "Item_model" initialized
INFO - 2018-10-27 11:02:02 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:02:02 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:02:02 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:02:02 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 11:02:02 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 11:02:02 --> Final output sent to browser
INFO - 2018-10-27 11:02:02 --> Config Class Initialized
INFO - 2018-10-27 11:02:02 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:02:02 --> Total execution time: 0.6555
DEBUG - 2018-10-27 11:02:02 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:02:02 --> Utf8 Class Initialized
INFO - 2018-10-27 11:02:02 --> URI Class Initialized
INFO - 2018-10-27 11:02:02 --> Router Class Initialized
INFO - 2018-10-27 11:02:02 --> Output Class Initialized
INFO - 2018-10-27 11:02:02 --> Security Class Initialized
DEBUG - 2018-10-27 11:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:02:02 --> Input Class Initialized
INFO - 2018-10-27 11:02:02 --> Language Class Initialized
ERROR - 2018-10-27 11:02:02 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:02:29 --> Config Class Initialized
INFO - 2018-10-27 11:02:29 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:02:29 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:02:29 --> Utf8 Class Initialized
INFO - 2018-10-27 11:02:29 --> URI Class Initialized
INFO - 2018-10-27 11:02:29 --> Router Class Initialized
INFO - 2018-10-27 11:02:29 --> Output Class Initialized
INFO - 2018-10-27 11:02:29 --> Security Class Initialized
DEBUG - 2018-10-27 11:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:02:29 --> Input Class Initialized
INFO - 2018-10-27 11:02:29 --> Language Class Initialized
INFO - 2018-10-27 11:02:29 --> Loader Class Initialized
INFO - 2018-10-27 11:02:29 --> Helper loaded: url_helper
INFO - 2018-10-27 11:02:29 --> Database Driver Class Initialized
INFO - 2018-10-27 11:02:29 --> Helper loaded: form_helper
INFO - 2018-10-27 11:02:29 --> Form Validation Class Initialized
INFO - 2018-10-27 11:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:02:29 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:02:29 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:02:29 --> Email Class Initialized
INFO - 2018-10-27 11:02:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:02:29 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:02:29 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:02:29 --> Helper loaded: date_helper
INFO - 2018-10-27 11:02:29 --> Database Driver Class Initialized
INFO - 2018-10-27 11:02:30 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:02:30 --> Controller Class Initialized
INFO - 2018-10-27 11:02:30 --> Model "Item_model" initialized
INFO - 2018-10-27 11:02:30 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:02:30 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:02:30 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:02:30 --> Model "Notadetail_model" initialized
ERROR - 2018-10-27 11:02:30 --> Severity: Notice --> Undefined variable: record D:\xampp\htdocs\masterwedding\application\controllers\Item.php 159
ERROR - 2018-10-27 11:02:30 --> Severity: Notice --> Undefined variable: no_nota D:\xampp\htdocs\masterwedding\application\views\item\nota.php 13
ERROR - 2018-10-27 11:02:30 --> Severity: Notice --> Undefined variable: tanggal D:\xampp\htdocs\masterwedding\application\views\item\nota.php 17
ERROR - 2018-10-27 11:02:30 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\masterwedding\application\views\item\nota.php 21
INFO - 2018-10-27 11:02:30 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 11:02:30 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 11:02:30 --> Final output sent to browser
DEBUG - 2018-10-27 11:02:30 --> Total execution time: 0.7471
INFO - 2018-10-27 11:02:30 --> Config Class Initialized
INFO - 2018-10-27 11:02:30 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:02:30 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:02:30 --> Utf8 Class Initialized
INFO - 2018-10-27 11:02:30 --> URI Class Initialized
INFO - 2018-10-27 11:02:30 --> Router Class Initialized
INFO - 2018-10-27 11:02:30 --> Output Class Initialized
INFO - 2018-10-27 11:02:30 --> Security Class Initialized
DEBUG - 2018-10-27 11:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:02:30 --> Input Class Initialized
INFO - 2018-10-27 11:02:30 --> Language Class Initialized
ERROR - 2018-10-27 11:02:30 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:02:30 --> Config Class Initialized
INFO - 2018-10-27 11:02:30 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:02:30 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:02:30 --> Utf8 Class Initialized
INFO - 2018-10-27 11:02:30 --> URI Class Initialized
INFO - 2018-10-27 11:02:30 --> Router Class Initialized
INFO - 2018-10-27 11:02:30 --> Output Class Initialized
INFO - 2018-10-27 11:02:30 --> Security Class Initialized
DEBUG - 2018-10-27 11:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:02:30 --> Input Class Initialized
INFO - 2018-10-27 11:02:30 --> Language Class Initialized
ERROR - 2018-10-27 11:02:30 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:02:43 --> Config Class Initialized
INFO - 2018-10-27 11:02:43 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:02:43 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:02:43 --> Utf8 Class Initialized
INFO - 2018-10-27 11:02:43 --> URI Class Initialized
INFO - 2018-10-27 11:02:43 --> Router Class Initialized
INFO - 2018-10-27 11:02:43 --> Output Class Initialized
INFO - 2018-10-27 11:02:43 --> Security Class Initialized
DEBUG - 2018-10-27 11:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:02:43 --> Input Class Initialized
INFO - 2018-10-27 11:02:43 --> Language Class Initialized
INFO - 2018-10-27 11:02:43 --> Loader Class Initialized
INFO - 2018-10-27 11:02:43 --> Helper loaded: url_helper
INFO - 2018-10-27 11:02:43 --> Database Driver Class Initialized
INFO - 2018-10-27 11:02:43 --> Helper loaded: form_helper
INFO - 2018-10-27 11:02:43 --> Form Validation Class Initialized
INFO - 2018-10-27 11:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:02:43 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:02:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:02:43 --> Email Class Initialized
INFO - 2018-10-27 11:02:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:02:43 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:02:43 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:02:43 --> Helper loaded: date_helper
INFO - 2018-10-27 11:02:43 --> Database Driver Class Initialized
INFO - 2018-10-27 11:02:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:02:43 --> Controller Class Initialized
INFO - 2018-10-27 11:02:43 --> Model "Item_model" initialized
INFO - 2018-10-27 11:02:44 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:02:44 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:02:44 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:02:44 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 11:02:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-27 11:02:44 --> Final output sent to browser
DEBUG - 2018-10-27 11:02:44 --> Total execution time: 0.6770
INFO - 2018-10-27 11:02:44 --> Config Class Initialized
INFO - 2018-10-27 11:02:44 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:02:44 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:02:44 --> Utf8 Class Initialized
INFO - 2018-10-27 11:02:44 --> URI Class Initialized
INFO - 2018-10-27 11:02:44 --> Router Class Initialized
INFO - 2018-10-27 11:02:44 --> Output Class Initialized
INFO - 2018-10-27 11:02:44 --> Security Class Initialized
DEBUG - 2018-10-27 11:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:02:44 --> Input Class Initialized
INFO - 2018-10-27 11:02:44 --> Language Class Initialized
ERROR - 2018-10-27 11:02:44 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:03:46 --> Config Class Initialized
INFO - 2018-10-27 11:03:46 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:03:46 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:03:46 --> Utf8 Class Initialized
INFO - 2018-10-27 11:03:46 --> URI Class Initialized
INFO - 2018-10-27 11:03:46 --> Router Class Initialized
INFO - 2018-10-27 11:03:46 --> Output Class Initialized
INFO - 2018-10-27 11:03:46 --> Security Class Initialized
DEBUG - 2018-10-27 11:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:03:46 --> Input Class Initialized
INFO - 2018-10-27 11:03:46 --> Language Class Initialized
ERROR - 2018-10-27 11:03:46 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file D:\xampp\htdocs\masterwedding\application\controllers\Item.php 178
INFO - 2018-10-27 11:04:57 --> Config Class Initialized
INFO - 2018-10-27 11:04:57 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:04:57 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:04:57 --> Utf8 Class Initialized
INFO - 2018-10-27 11:04:57 --> URI Class Initialized
INFO - 2018-10-27 11:04:57 --> Router Class Initialized
INFO - 2018-10-27 11:04:57 --> Output Class Initialized
INFO - 2018-10-27 11:04:57 --> Security Class Initialized
DEBUG - 2018-10-27 11:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:04:57 --> Input Class Initialized
INFO - 2018-10-27 11:04:57 --> Language Class Initialized
INFO - 2018-10-27 11:04:57 --> Loader Class Initialized
INFO - 2018-10-27 11:04:57 --> Helper loaded: url_helper
INFO - 2018-10-27 11:04:57 --> Database Driver Class Initialized
INFO - 2018-10-27 11:04:57 --> Helper loaded: form_helper
INFO - 2018-10-27 11:04:57 --> Form Validation Class Initialized
INFO - 2018-10-27 11:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:04:57 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:04:57 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:04:57 --> Email Class Initialized
INFO - 2018-10-27 11:04:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:04:57 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:04:57 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:04:58 --> Helper loaded: date_helper
INFO - 2018-10-27 11:04:58 --> Database Driver Class Initialized
INFO - 2018-10-27 11:04:58 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:04:58 --> Controller Class Initialized
INFO - 2018-10-27 11:04:58 --> Model "Item_model" initialized
INFO - 2018-10-27 11:04:58 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:04:58 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:04:58 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:04:58 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 11:04:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-27 11:04:58 --> Final output sent to browser
DEBUG - 2018-10-27 11:04:58 --> Total execution time: 0.7360
INFO - 2018-10-27 11:05:04 --> Config Class Initialized
INFO - 2018-10-27 11:05:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:05:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:05:04 --> Utf8 Class Initialized
INFO - 2018-10-27 11:05:04 --> URI Class Initialized
INFO - 2018-10-27 11:05:04 --> Router Class Initialized
INFO - 2018-10-27 11:05:04 --> Output Class Initialized
INFO - 2018-10-27 11:05:04 --> Security Class Initialized
DEBUG - 2018-10-27 11:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:05:04 --> Input Class Initialized
INFO - 2018-10-27 11:05:04 --> Language Class Initialized
INFO - 2018-10-27 11:05:04 --> Loader Class Initialized
INFO - 2018-10-27 11:05:04 --> Helper loaded: url_helper
INFO - 2018-10-27 11:05:04 --> Database Driver Class Initialized
INFO - 2018-10-27 11:05:04 --> Helper loaded: form_helper
INFO - 2018-10-27 11:05:04 --> Form Validation Class Initialized
INFO - 2018-10-27 11:05:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:05:04 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:05:04 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:05:04 --> Email Class Initialized
INFO - 2018-10-27 11:05:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:05:04 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:05:04 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:05:04 --> Helper loaded: date_helper
INFO - 2018-10-27 11:05:04 --> Database Driver Class Initialized
INFO - 2018-10-27 11:05:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:05:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:05:04 --> Controller Class Initialized
INFO - 2018-10-27 11:05:04 --> Model "Item_model" initialized
INFO - 2018-10-27 11:05:04 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:05:04 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:05:04 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:05:04 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 11:05:04 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 11:05:04 --> Final output sent to browser
DEBUG - 2018-10-27 11:05:04 --> Total execution time: 0.6762
INFO - 2018-10-27 11:05:04 --> Config Class Initialized
INFO - 2018-10-27 11:05:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:05:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:05:04 --> Utf8 Class Initialized
INFO - 2018-10-27 11:05:04 --> URI Class Initialized
INFO - 2018-10-27 11:05:04 --> Router Class Initialized
INFO - 2018-10-27 11:05:04 --> Output Class Initialized
INFO - 2018-10-27 11:05:05 --> Security Class Initialized
DEBUG - 2018-10-27 11:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:05:05 --> Input Class Initialized
INFO - 2018-10-27 11:05:05 --> Language Class Initialized
ERROR - 2018-10-27 11:05:05 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:05:08 --> Config Class Initialized
INFO - 2018-10-27 11:05:08 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:05:08 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:05:08 --> Utf8 Class Initialized
INFO - 2018-10-27 11:05:08 --> URI Class Initialized
INFO - 2018-10-27 11:05:08 --> Router Class Initialized
INFO - 2018-10-27 11:05:08 --> Output Class Initialized
INFO - 2018-10-27 11:05:08 --> Security Class Initialized
DEBUG - 2018-10-27 11:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:05:08 --> Input Class Initialized
INFO - 2018-10-27 11:05:08 --> Language Class Initialized
INFO - 2018-10-27 11:05:08 --> Loader Class Initialized
INFO - 2018-10-27 11:05:08 --> Helper loaded: url_helper
INFO - 2018-10-27 11:05:08 --> Database Driver Class Initialized
INFO - 2018-10-27 11:05:08 --> Helper loaded: form_helper
INFO - 2018-10-27 11:05:08 --> Form Validation Class Initialized
INFO - 2018-10-27 11:05:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:05:08 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:05:08 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:05:08 --> Email Class Initialized
INFO - 2018-10-27 11:05:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:05:08 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:05:08 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:05:08 --> Helper loaded: date_helper
INFO - 2018-10-27 11:05:08 --> Database Driver Class Initialized
INFO - 2018-10-27 11:05:08 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:05:08 --> Controller Class Initialized
INFO - 2018-10-27 11:05:08 --> Model "Item_model" initialized
INFO - 2018-10-27 11:05:08 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:05:08 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:05:08 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:05:08 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 11:05:08 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-27 11:05:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\controllers\Item.php 167
INFO - 2018-10-27 11:05:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 11:05:09 --> Final output sent to browser
DEBUG - 2018-10-27 11:05:09 --> Total execution time: 0.7164
INFO - 2018-10-27 11:05:09 --> Config Class Initialized
INFO - 2018-10-27 11:05:09 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:05:09 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:05:09 --> Utf8 Class Initialized
INFO - 2018-10-27 11:05:09 --> URI Class Initialized
INFO - 2018-10-27 11:05:09 --> Router Class Initialized
INFO - 2018-10-27 11:05:09 --> Output Class Initialized
INFO - 2018-10-27 11:05:09 --> Security Class Initialized
DEBUG - 2018-10-27 11:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:05:09 --> Input Class Initialized
INFO - 2018-10-27 11:05:09 --> Language Class Initialized
ERROR - 2018-10-27 11:05:09 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:05:09 --> Config Class Initialized
INFO - 2018-10-27 11:05:09 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:05:09 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:05:09 --> Utf8 Class Initialized
INFO - 2018-10-27 11:05:09 --> URI Class Initialized
INFO - 2018-10-27 11:05:09 --> Router Class Initialized
INFO - 2018-10-27 11:05:09 --> Output Class Initialized
INFO - 2018-10-27 11:05:09 --> Security Class Initialized
DEBUG - 2018-10-27 11:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:05:09 --> Input Class Initialized
INFO - 2018-10-27 11:05:09 --> Language Class Initialized
ERROR - 2018-10-27 11:05:09 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:06:11 --> Config Class Initialized
INFO - 2018-10-27 11:06:11 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:06:11 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:06:11 --> Utf8 Class Initialized
INFO - 2018-10-27 11:06:11 --> URI Class Initialized
INFO - 2018-10-27 11:06:11 --> Router Class Initialized
INFO - 2018-10-27 11:06:11 --> Output Class Initialized
INFO - 2018-10-27 11:06:11 --> Security Class Initialized
DEBUG - 2018-10-27 11:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:06:11 --> Input Class Initialized
INFO - 2018-10-27 11:06:11 --> Language Class Initialized
INFO - 2018-10-27 11:06:11 --> Loader Class Initialized
INFO - 2018-10-27 11:06:11 --> Helper loaded: url_helper
INFO - 2018-10-27 11:06:11 --> Database Driver Class Initialized
INFO - 2018-10-27 11:06:11 --> Helper loaded: form_helper
INFO - 2018-10-27 11:06:11 --> Form Validation Class Initialized
INFO - 2018-10-27 11:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:06:11 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:06:11 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:06:11 --> Email Class Initialized
INFO - 2018-10-27 11:06:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:06:11 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:06:11 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:06:11 --> Helper loaded: date_helper
INFO - 2018-10-27 11:06:11 --> Database Driver Class Initialized
INFO - 2018-10-27 11:06:11 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:06:11 --> Controller Class Initialized
INFO - 2018-10-27 11:06:11 --> Model "Item_model" initialized
INFO - 2018-10-27 11:06:11 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:06:11 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:06:11 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:06:11 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 11:06:11 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-27 11:06:11 --> Severity: Notice --> Undefined variable: records D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 53
ERROR - 2018-10-27 11:06:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 53
ERROR - 2018-10-27 11:06:11 --> Severity: Notice --> Undefined variable: records D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 57
ERROR - 2018-10-27 11:06:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 57
INFO - 2018-10-27 11:06:11 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 11:06:11 --> Final output sent to browser
DEBUG - 2018-10-27 11:06:11 --> Total execution time: 0.7726
INFO - 2018-10-27 11:06:11 --> Config Class Initialized
INFO - 2018-10-27 11:06:11 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:06:11 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:06:11 --> Utf8 Class Initialized
INFO - 2018-10-27 11:06:11 --> URI Class Initialized
INFO - 2018-10-27 11:06:11 --> Router Class Initialized
INFO - 2018-10-27 11:06:11 --> Output Class Initialized
INFO - 2018-10-27 11:06:11 --> Security Class Initialized
DEBUG - 2018-10-27 11:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:06:11 --> Input Class Initialized
INFO - 2018-10-27 11:06:12 --> Language Class Initialized
ERROR - 2018-10-27 11:06:12 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:06:12 --> Config Class Initialized
INFO - 2018-10-27 11:06:12 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:06:12 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:06:12 --> Utf8 Class Initialized
INFO - 2018-10-27 11:06:12 --> URI Class Initialized
INFO - 2018-10-27 11:06:12 --> Router Class Initialized
INFO - 2018-10-27 11:06:12 --> Output Class Initialized
INFO - 2018-10-27 11:06:12 --> Security Class Initialized
DEBUG - 2018-10-27 11:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:06:12 --> Input Class Initialized
INFO - 2018-10-27 11:06:12 --> Language Class Initialized
ERROR - 2018-10-27 11:06:12 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:06:54 --> Config Class Initialized
INFO - 2018-10-27 11:06:54 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:06:54 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:06:54 --> Utf8 Class Initialized
INFO - 2018-10-27 11:06:54 --> URI Class Initialized
INFO - 2018-10-27 11:06:54 --> Router Class Initialized
INFO - 2018-10-27 11:06:54 --> Output Class Initialized
INFO - 2018-10-27 11:06:54 --> Security Class Initialized
DEBUG - 2018-10-27 11:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:06:54 --> Input Class Initialized
INFO - 2018-10-27 11:06:54 --> Language Class Initialized
INFO - 2018-10-27 11:06:54 --> Loader Class Initialized
INFO - 2018-10-27 11:06:54 --> Helper loaded: url_helper
INFO - 2018-10-27 11:06:54 --> Database Driver Class Initialized
INFO - 2018-10-27 11:06:54 --> Helper loaded: form_helper
INFO - 2018-10-27 11:06:54 --> Form Validation Class Initialized
INFO - 2018-10-27 11:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 11:06:55 --> Pagination Class Initialized
DEBUG - 2018-10-27 11:06:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-27 11:06:55 --> Email Class Initialized
INFO - 2018-10-27 11:06:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-27 11:06:55 --> Helper loaded: cookie_helper
INFO - 2018-10-27 11:06:55 --> Helper loaded: language_helper
DEBUG - 2018-10-27 11:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 11:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 11:06:55 --> Helper loaded: date_helper
INFO - 2018-10-27 11:06:55 --> Database Driver Class Initialized
INFO - 2018-10-27 11:06:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-27 11:06:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-27 11:06:55 --> Controller Class Initialized
INFO - 2018-10-27 11:06:55 --> Model "Item_model" initialized
INFO - 2018-10-27 11:06:55 --> Model "Jenis_model" initialized
INFO - 2018-10-27 11:06:55 --> Model "Vendor_model" initialized
INFO - 2018-10-27 11:06:55 --> Model "Nota_model" initialized
INFO - 2018-10-27 11:06:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-27 11:06:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-27 11:06:55 --> Severity: Notice --> Undefined variable: record D:\xampp\htdocs\masterwedding\application\controllers\Item.php 165
ERROR - 2018-10-27 11:06:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 53
ERROR - 2018-10-27 11:06:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 57
INFO - 2018-10-27 11:06:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-27 11:06:55 --> Final output sent to browser
DEBUG - 2018-10-27 11:06:55 --> Total execution time: 0.7615
INFO - 2018-10-27 11:06:55 --> Config Class Initialized
INFO - 2018-10-27 11:06:55 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:06:55 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:06:55 --> Utf8 Class Initialized
INFO - 2018-10-27 11:06:55 --> URI Class Initialized
INFO - 2018-10-27 11:06:55 --> Router Class Initialized
INFO - 2018-10-27 11:06:55 --> Output Class Initialized
INFO - 2018-10-27 11:06:55 --> Security Class Initialized
DEBUG - 2018-10-27 11:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:06:55 --> Input Class Initialized
INFO - 2018-10-27 11:06:55 --> Language Class Initialized
ERROR - 2018-10-27 11:06:55 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-27 11:06:55 --> Config Class Initialized
INFO - 2018-10-27 11:06:55 --> Hooks Class Initialized
DEBUG - 2018-10-27 11:06:55 --> UTF-8 Support Enabled
INFO - 2018-10-27 11:06:55 --> Utf8 Class Initialized
INFO - 2018-10-27 11:06:55 --> URI Class Initialized
INFO - 2018-10-27 11:06:55 --> Router Class Initialized
INFO - 2018-10-27 11:06:55 --> Output Class Initialized
INFO - 2018-10-27 11:06:55 --> Security Class Initialized
DEBUG - 2018-10-27 11:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 11:06:55 --> Input Class Initialized
INFO - 2018-10-27 11:06:55 --> Language Class Initialized
ERROR - 2018-10-27 11:06:55 --> 404 Page Not Found: Item/%3C
