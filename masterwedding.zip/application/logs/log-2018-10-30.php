<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-30 03:58:10 --> Config Class Initialized
INFO - 2018-10-30 03:58:10 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:58:10 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:58:10 --> Utf8 Class Initialized
INFO - 2018-10-30 03:58:10 --> URI Class Initialized
INFO - 2018-10-30 03:58:10 --> Router Class Initialized
INFO - 2018-10-30 03:58:10 --> Output Class Initialized
INFO - 2018-10-30 03:58:10 --> Security Class Initialized
DEBUG - 2018-10-30 03:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:58:10 --> Input Class Initialized
INFO - 2018-10-30 03:58:11 --> Language Class Initialized
INFO - 2018-10-30 03:58:11 --> Loader Class Initialized
INFO - 2018-10-30 03:58:11 --> Helper loaded: url_helper
INFO - 2018-10-30 03:58:11 --> Database Driver Class Initialized
INFO - 2018-10-30 03:58:11 --> Helper loaded: form_helper
INFO - 2018-10-30 03:58:11 --> Form Validation Class Initialized
INFO - 2018-10-30 03:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 03:58:11 --> Pagination Class Initialized
DEBUG - 2018-10-30 03:58:11 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 03:58:11 --> Email Class Initialized
INFO - 2018-10-30 03:58:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 03:58:11 --> Helper loaded: cookie_helper
INFO - 2018-10-30 03:58:11 --> Helper loaded: language_helper
DEBUG - 2018-10-30 03:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 03:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 03:58:11 --> Helper loaded: date_helper
INFO - 2018-10-30 03:58:11 --> Database Driver Class Initialized
INFO - 2018-10-30 03:58:11 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 03:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 03:58:11 --> Controller Class Initialized
INFO - 2018-10-30 03:58:11 --> Model "Item_model" initialized
INFO - 2018-10-30 03:58:11 --> Model "Jenis_model" initialized
INFO - 2018-10-30 03:58:11 --> Model "Vendor_model" initialized
INFO - 2018-10-30 03:58:11 --> Model "Nota_model" initialized
INFO - 2018-10-30 03:58:11 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 03:58:11 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 03:58:11 --> Final output sent to browser
DEBUG - 2018-10-30 03:58:11 --> Total execution time: 1.1011
INFO - 2018-10-30 03:58:11 --> Config Class Initialized
INFO - 2018-10-30 03:58:11 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:58:11 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:58:11 --> Utf8 Class Initialized
INFO - 2018-10-30 03:58:11 --> URI Class Initialized
INFO - 2018-10-30 03:58:11 --> Router Class Initialized
INFO - 2018-10-30 03:58:11 --> Output Class Initialized
INFO - 2018-10-30 03:58:11 --> Security Class Initialized
DEBUG - 2018-10-30 03:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:58:11 --> Input Class Initialized
INFO - 2018-10-30 03:58:11 --> Language Class Initialized
ERROR - 2018-10-30 03:58:11 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 03:58:12 --> Config Class Initialized
INFO - 2018-10-30 03:58:12 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:58:12 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:58:12 --> Utf8 Class Initialized
INFO - 2018-10-30 03:58:12 --> URI Class Initialized
INFO - 2018-10-30 03:58:12 --> Router Class Initialized
INFO - 2018-10-30 03:58:12 --> Output Class Initialized
INFO - 2018-10-30 03:58:12 --> Security Class Initialized
DEBUG - 2018-10-30 03:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:58:12 --> Input Class Initialized
INFO - 2018-10-30 03:58:12 --> Language Class Initialized
ERROR - 2018-10-30 03:58:12 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-30 03:58:27 --> Config Class Initialized
INFO - 2018-10-30 03:58:27 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:58:27 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:58:27 --> Utf8 Class Initialized
INFO - 2018-10-30 03:58:27 --> URI Class Initialized
INFO - 2018-10-30 03:58:27 --> Router Class Initialized
INFO - 2018-10-30 03:58:27 --> Output Class Initialized
INFO - 2018-10-30 03:58:27 --> Security Class Initialized
DEBUG - 2018-10-30 03:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:58:27 --> Input Class Initialized
INFO - 2018-10-30 03:58:27 --> Language Class Initialized
INFO - 2018-10-30 03:58:27 --> Loader Class Initialized
INFO - 2018-10-30 03:58:27 --> Helper loaded: url_helper
INFO - 2018-10-30 03:58:27 --> Database Driver Class Initialized
INFO - 2018-10-30 03:58:27 --> Helper loaded: form_helper
INFO - 2018-10-30 03:58:27 --> Form Validation Class Initialized
INFO - 2018-10-30 03:58:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 03:58:27 --> Pagination Class Initialized
DEBUG - 2018-10-30 03:58:27 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 03:58:27 --> Email Class Initialized
INFO - 2018-10-30 03:58:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 03:58:27 --> Helper loaded: cookie_helper
INFO - 2018-10-30 03:58:27 --> Helper loaded: language_helper
DEBUG - 2018-10-30 03:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 03:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 03:58:27 --> Helper loaded: date_helper
INFO - 2018-10-30 03:58:27 --> Database Driver Class Initialized
INFO - 2018-10-30 03:58:27 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 03:58:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 03:58:27 --> Controller Class Initialized
INFO - 2018-10-30 03:58:27 --> Model "Item_model" initialized
INFO - 2018-10-30 03:58:27 --> Model "Jenis_model" initialized
INFO - 2018-10-30 03:58:27 --> Model "Vendor_model" initialized
INFO - 2018-10-30 03:58:27 --> Model "Nota_model" initialized
INFO - 2018-10-30 03:58:27 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 03:58:27 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`dbmasterwed`.`nota_detail`, CONSTRAINT `nota_detail_ibfk_1` FOREIGN KEY (`itemid`) REFERENCES `item` (`id`)) - Invalid query: INSERT INTO `nota_detail` (`notaid`, `subtotal`) VALUES (' 18103022', '45000000')
DEBUG - 2018-10-30 03:58:27 --> DB Transaction Failure
INFO - 2018-10-30 03:58:27 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-30 03:59:33 --> Config Class Initialized
INFO - 2018-10-30 03:59:33 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:59:33 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:59:33 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:34 --> URI Class Initialized
INFO - 2018-10-30 03:59:34 --> Router Class Initialized
INFO - 2018-10-30 03:59:34 --> Output Class Initialized
INFO - 2018-10-30 03:59:34 --> Security Class Initialized
DEBUG - 2018-10-30 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:59:34 --> Input Class Initialized
INFO - 2018-10-30 03:59:34 --> Language Class Initialized
INFO - 2018-10-30 03:59:34 --> Loader Class Initialized
INFO - 2018-10-30 03:59:34 --> Helper loaded: url_helper
INFO - 2018-10-30 03:59:34 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:34 --> Helper loaded: form_helper
INFO - 2018-10-30 03:59:34 --> Form Validation Class Initialized
INFO - 2018-10-30 03:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 03:59:34 --> Pagination Class Initialized
DEBUG - 2018-10-30 03:59:34 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 03:59:34 --> Email Class Initialized
INFO - 2018-10-30 03:59:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 03:59:34 --> Helper loaded: cookie_helper
INFO - 2018-10-30 03:59:34 --> Helper loaded: language_helper
DEBUG - 2018-10-30 03:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 03:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 03:59:34 --> Helper loaded: date_helper
INFO - 2018-10-30 03:59:34 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:34 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 03:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 03:59:34 --> Controller Class Initialized
INFO - 2018-10-30 03:59:34 --> Model "Item_model" initialized
INFO - 2018-10-30 03:59:34 --> Model "Jenis_model" initialized
INFO - 2018-10-30 03:59:34 --> Model "Vendor_model" initialized
INFO - 2018-10-30 03:59:34 --> Model "Nota_model" initialized
INFO - 2018-10-30 03:59:34 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 03:59:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\masterwedding\application\controllers\Item.php 18
ERROR - 2018-10-30 03:59:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\masterwedding\application\controllers\Item.php 19
INFO - 2018-10-30 03:59:34 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 03:59:34 --> Final output sent to browser
DEBUG - 2018-10-30 03:59:34 --> Total execution time: 0.4490
INFO - 2018-10-30 03:59:38 --> Config Class Initialized
INFO - 2018-10-30 03:59:39 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:59:39 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:59:39 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:39 --> URI Class Initialized
INFO - 2018-10-30 03:59:39 --> Router Class Initialized
INFO - 2018-10-30 03:59:39 --> Output Class Initialized
INFO - 2018-10-30 03:59:39 --> Security Class Initialized
DEBUG - 2018-10-30 03:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:59:39 --> Input Class Initialized
INFO - 2018-10-30 03:59:39 --> Language Class Initialized
INFO - 2018-10-30 03:59:39 --> Loader Class Initialized
INFO - 2018-10-30 03:59:39 --> Helper loaded: url_helper
INFO - 2018-10-30 03:59:39 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:39 --> Helper loaded: form_helper
INFO - 2018-10-30 03:59:39 --> Form Validation Class Initialized
INFO - 2018-10-30 03:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 03:59:39 --> Pagination Class Initialized
DEBUG - 2018-10-30 03:59:39 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 03:59:39 --> Email Class Initialized
INFO - 2018-10-30 03:59:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 03:59:39 --> Helper loaded: cookie_helper
INFO - 2018-10-30 03:59:39 --> Helper loaded: language_helper
DEBUG - 2018-10-30 03:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 03:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 03:59:39 --> Helper loaded: date_helper
INFO - 2018-10-30 03:59:39 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:39 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 03:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 03:59:39 --> Controller Class Initialized
INFO - 2018-10-30 03:59:39 --> Config Class Initialized
INFO - 2018-10-30 03:59:39 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:59:39 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:59:39 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:39 --> URI Class Initialized
INFO - 2018-10-30 03:59:39 --> Router Class Initialized
INFO - 2018-10-30 03:59:39 --> Output Class Initialized
INFO - 2018-10-30 03:59:39 --> Security Class Initialized
DEBUG - 2018-10-30 03:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:59:39 --> Input Class Initialized
INFO - 2018-10-30 03:59:39 --> Language Class Initialized
INFO - 2018-10-30 03:59:39 --> Loader Class Initialized
INFO - 2018-10-30 03:59:39 --> Helper loaded: url_helper
INFO - 2018-10-30 03:59:39 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:39 --> Helper loaded: form_helper
INFO - 2018-10-30 03:59:39 --> Form Validation Class Initialized
INFO - 2018-10-30 03:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 03:59:39 --> Pagination Class Initialized
DEBUG - 2018-10-30 03:59:39 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 03:59:39 --> Email Class Initialized
INFO - 2018-10-30 03:59:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 03:59:39 --> Helper loaded: cookie_helper
INFO - 2018-10-30 03:59:39 --> Helper loaded: language_helper
DEBUG - 2018-10-30 03:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 03:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 03:59:39 --> Helper loaded: date_helper
INFO - 2018-10-30 03:59:39 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:39 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 03:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 03:59:39 --> Controller Class Initialized
INFO - 2018-10-30 03:59:39 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-30 03:59:39 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\index.php
INFO - 2018-10-30 03:59:39 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-10-30 03:59:39 --> Final output sent to browser
DEBUG - 2018-10-30 03:59:39 --> Total execution time: 0.4139
INFO - 2018-10-30 03:59:39 --> Config Class Initialized
INFO - 2018-10-30 03:59:39 --> Config Class Initialized
INFO - 2018-10-30 03:59:39 --> Config Class Initialized
INFO - 2018-10-30 03:59:39 --> Hooks Class Initialized
INFO - 2018-10-30 03:59:39 --> Hooks Class Initialized
INFO - 2018-10-30 03:59:39 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2018-10-30 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2018-10-30 03:59:39 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:59:39 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:39 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:39 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:39 --> URI Class Initialized
INFO - 2018-10-30 03:59:39 --> URI Class Initialized
INFO - 2018-10-30 03:59:39 --> URI Class Initialized
INFO - 2018-10-30 03:59:39 --> Router Class Initialized
INFO - 2018-10-30 03:59:39 --> Router Class Initialized
INFO - 2018-10-30 03:59:39 --> Router Class Initialized
INFO - 2018-10-30 03:59:39 --> Output Class Initialized
INFO - 2018-10-30 03:59:39 --> Output Class Initialized
INFO - 2018-10-30 03:59:39 --> Output Class Initialized
INFO - 2018-10-30 03:59:39 --> Security Class Initialized
INFO - 2018-10-30 03:59:39 --> Security Class Initialized
INFO - 2018-10-30 03:59:39 --> Security Class Initialized
DEBUG - 2018-10-30 03:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-30 03:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-30 03:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:59:39 --> Input Class Initialized
INFO - 2018-10-30 03:59:39 --> Input Class Initialized
INFO - 2018-10-30 03:59:39 --> Input Class Initialized
INFO - 2018-10-30 03:59:39 --> Language Class Initialized
INFO - 2018-10-30 03:59:39 --> Language Class Initialized
INFO - 2018-10-30 03:59:39 --> Language Class Initialized
ERROR - 2018-10-30 03:59:39 --> 404 Page Not Found: Application/views
ERROR - 2018-10-30 03:59:39 --> 404 Page Not Found: Application/views
ERROR - 2018-10-30 03:59:39 --> 404 Page Not Found: Application/views
INFO - 2018-10-30 03:59:42 --> Config Class Initialized
INFO - 2018-10-30 03:59:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:59:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:59:42 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:42 --> URI Class Initialized
INFO - 2018-10-30 03:59:42 --> Router Class Initialized
INFO - 2018-10-30 03:59:42 --> Output Class Initialized
INFO - 2018-10-30 03:59:42 --> Security Class Initialized
DEBUG - 2018-10-30 03:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:59:42 --> Input Class Initialized
INFO - 2018-10-30 03:59:42 --> Language Class Initialized
INFO - 2018-10-30 03:59:42 --> Loader Class Initialized
INFO - 2018-10-30 03:59:42 --> Helper loaded: url_helper
INFO - 2018-10-30 03:59:42 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:42 --> Helper loaded: form_helper
INFO - 2018-10-30 03:59:42 --> Form Validation Class Initialized
INFO - 2018-10-30 03:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 03:59:42 --> Pagination Class Initialized
DEBUG - 2018-10-30 03:59:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 03:59:42 --> Email Class Initialized
INFO - 2018-10-30 03:59:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 03:59:42 --> Helper loaded: cookie_helper
INFO - 2018-10-30 03:59:42 --> Helper loaded: language_helper
DEBUG - 2018-10-30 03:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 03:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 03:59:42 --> Helper loaded: date_helper
INFO - 2018-10-30 03:59:42 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:42 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 03:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 03:59:42 --> Controller Class Initialized
INFO - 2018-10-30 03:59:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-30 03:59:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\login.php
INFO - 2018-10-30 03:59:42 --> Final output sent to browser
DEBUG - 2018-10-30 03:59:42 --> Total execution time: 0.3645
INFO - 2018-10-30 03:59:42 --> Config Class Initialized
INFO - 2018-10-30 03:59:42 --> Config Class Initialized
INFO - 2018-10-30 03:59:42 --> Config Class Initialized
INFO - 2018-10-30 03:59:42 --> Hooks Class Initialized
INFO - 2018-10-30 03:59:42 --> Hooks Class Initialized
INFO - 2018-10-30 03:59:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:59:42 --> UTF-8 Support Enabled
DEBUG - 2018-10-30 03:59:42 --> UTF-8 Support Enabled
DEBUG - 2018-10-30 03:59:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:59:42 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:42 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:42 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:42 --> URI Class Initialized
INFO - 2018-10-30 03:59:42 --> URI Class Initialized
INFO - 2018-10-30 03:59:42 --> URI Class Initialized
INFO - 2018-10-30 03:59:42 --> Router Class Initialized
INFO - 2018-10-30 03:59:42 --> Router Class Initialized
INFO - 2018-10-30 03:59:42 --> Router Class Initialized
INFO - 2018-10-30 03:59:42 --> Output Class Initialized
INFO - 2018-10-30 03:59:42 --> Output Class Initialized
INFO - 2018-10-30 03:59:42 --> Output Class Initialized
INFO - 2018-10-30 03:59:42 --> Security Class Initialized
INFO - 2018-10-30 03:59:42 --> Security Class Initialized
INFO - 2018-10-30 03:59:42 --> Security Class Initialized
DEBUG - 2018-10-30 03:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-30 03:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-30 03:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:59:42 --> Input Class Initialized
INFO - 2018-10-30 03:59:42 --> Input Class Initialized
INFO - 2018-10-30 03:59:42 --> Input Class Initialized
INFO - 2018-10-30 03:59:42 --> Language Class Initialized
INFO - 2018-10-30 03:59:42 --> Language Class Initialized
INFO - 2018-10-30 03:59:42 --> Language Class Initialized
ERROR - 2018-10-30 03:59:42 --> 404 Page Not Found: Application/views
ERROR - 2018-10-30 03:59:42 --> 404 Page Not Found: Application/views
ERROR - 2018-10-30 03:59:42 --> 404 Page Not Found: Application/views
INFO - 2018-10-30 03:59:48 --> Config Class Initialized
INFO - 2018-10-30 03:59:48 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:59:48 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:59:48 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:48 --> URI Class Initialized
INFO - 2018-10-30 03:59:48 --> Router Class Initialized
INFO - 2018-10-30 03:59:48 --> Output Class Initialized
INFO - 2018-10-30 03:59:48 --> Security Class Initialized
DEBUG - 2018-10-30 03:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:59:48 --> Input Class Initialized
INFO - 2018-10-30 03:59:48 --> Language Class Initialized
INFO - 2018-10-30 03:59:48 --> Loader Class Initialized
INFO - 2018-10-30 03:59:48 --> Helper loaded: url_helper
INFO - 2018-10-30 03:59:48 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:48 --> Helper loaded: form_helper
INFO - 2018-10-30 03:59:48 --> Form Validation Class Initialized
INFO - 2018-10-30 03:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 03:59:48 --> Pagination Class Initialized
DEBUG - 2018-10-30 03:59:48 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 03:59:48 --> Email Class Initialized
INFO - 2018-10-30 03:59:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 03:59:48 --> Helper loaded: cookie_helper
INFO - 2018-10-30 03:59:48 --> Helper loaded: language_helper
DEBUG - 2018-10-30 03:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 03:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 03:59:48 --> Helper loaded: date_helper
INFO - 2018-10-30 03:59:48 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:48 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 03:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 03:59:48 --> Controller Class Initialized
INFO - 2018-10-30 03:59:48 --> Config Class Initialized
INFO - 2018-10-30 03:59:48 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:59:48 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:59:48 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:48 --> URI Class Initialized
INFO - 2018-10-30 03:59:48 --> Router Class Initialized
INFO - 2018-10-30 03:59:48 --> Output Class Initialized
INFO - 2018-10-30 03:59:48 --> Security Class Initialized
DEBUG - 2018-10-30 03:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:59:48 --> Input Class Initialized
INFO - 2018-10-30 03:59:48 --> Language Class Initialized
INFO - 2018-10-30 03:59:48 --> Loader Class Initialized
INFO - 2018-10-30 03:59:48 --> Helper loaded: url_helper
INFO - 2018-10-30 03:59:48 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:48 --> Helper loaded: form_helper
INFO - 2018-10-30 03:59:48 --> Form Validation Class Initialized
INFO - 2018-10-30 03:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 03:59:48 --> Pagination Class Initialized
DEBUG - 2018-10-30 03:59:48 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 03:59:48 --> Email Class Initialized
INFO - 2018-10-30 03:59:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 03:59:48 --> Helper loaded: cookie_helper
INFO - 2018-10-30 03:59:48 --> Helper loaded: language_helper
DEBUG - 2018-10-30 03:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 03:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 03:59:48 --> Helper loaded: date_helper
INFO - 2018-10-30 03:59:48 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:49 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 03:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 03:59:49 --> Controller Class Initialized
INFO - 2018-10-30 03:59:49 --> Model "Item_model" initialized
INFO - 2018-10-30 03:59:49 --> Model "Jenis_model" initialized
INFO - 2018-10-30 03:59:49 --> Model "Vendor_model" initialized
INFO - 2018-10-30 03:59:49 --> Model "Nota_model" initialized
INFO - 2018-10-30 03:59:49 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 03:59:49 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 03:59:49 --> Final output sent to browser
DEBUG - 2018-10-30 03:59:49 --> Total execution time: 0.3699
INFO - 2018-10-30 03:59:57 --> Config Class Initialized
INFO - 2018-10-30 03:59:57 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:59:57 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:59:57 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:57 --> URI Class Initialized
INFO - 2018-10-30 03:59:57 --> Router Class Initialized
INFO - 2018-10-30 03:59:57 --> Output Class Initialized
INFO - 2018-10-30 03:59:57 --> Security Class Initialized
DEBUG - 2018-10-30 03:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:59:57 --> Input Class Initialized
INFO - 2018-10-30 03:59:57 --> Language Class Initialized
INFO - 2018-10-30 03:59:57 --> Loader Class Initialized
INFO - 2018-10-30 03:59:57 --> Helper loaded: url_helper
INFO - 2018-10-30 03:59:57 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:57 --> Helper loaded: form_helper
INFO - 2018-10-30 03:59:57 --> Form Validation Class Initialized
INFO - 2018-10-30 03:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 03:59:57 --> Pagination Class Initialized
DEBUG - 2018-10-30 03:59:57 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 03:59:57 --> Email Class Initialized
INFO - 2018-10-30 03:59:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 03:59:57 --> Helper loaded: cookie_helper
INFO - 2018-10-30 03:59:57 --> Helper loaded: language_helper
DEBUG - 2018-10-30 03:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 03:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 03:59:57 --> Helper loaded: date_helper
INFO - 2018-10-30 03:59:57 --> Database Driver Class Initialized
INFO - 2018-10-30 03:59:57 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 03:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 03:59:57 --> Controller Class Initialized
INFO - 2018-10-30 03:59:57 --> Model "Item_model" initialized
INFO - 2018-10-30 03:59:57 --> Model "Jenis_model" initialized
INFO - 2018-10-30 03:59:57 --> Model "Vendor_model" initialized
INFO - 2018-10-30 03:59:57 --> Model "Nota_model" initialized
INFO - 2018-10-30 03:59:57 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 03:59:57 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 03:59:57 --> Final output sent to browser
DEBUG - 2018-10-30 03:59:57 --> Total execution time: 0.3908
INFO - 2018-10-30 03:59:57 --> Config Class Initialized
INFO - 2018-10-30 03:59:57 --> Hooks Class Initialized
DEBUG - 2018-10-30 03:59:57 --> UTF-8 Support Enabled
INFO - 2018-10-30 03:59:57 --> Utf8 Class Initialized
INFO - 2018-10-30 03:59:57 --> URI Class Initialized
INFO - 2018-10-30 03:59:57 --> Router Class Initialized
INFO - 2018-10-30 03:59:58 --> Output Class Initialized
INFO - 2018-10-30 03:59:58 --> Security Class Initialized
DEBUG - 2018-10-30 03:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 03:59:58 --> Input Class Initialized
INFO - 2018-10-30 03:59:58 --> Language Class Initialized
ERROR - 2018-10-30 03:59:58 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:00:00 --> Config Class Initialized
INFO - 2018-10-30 04:00:00 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:00:00 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:00:00 --> Utf8 Class Initialized
INFO - 2018-10-30 04:00:00 --> URI Class Initialized
INFO - 2018-10-30 04:00:00 --> Router Class Initialized
INFO - 2018-10-30 04:00:00 --> Output Class Initialized
INFO - 2018-10-30 04:00:00 --> Security Class Initialized
DEBUG - 2018-10-30 04:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:00:00 --> Input Class Initialized
INFO - 2018-10-30 04:00:00 --> Language Class Initialized
INFO - 2018-10-30 04:00:00 --> Loader Class Initialized
INFO - 2018-10-30 04:00:00 --> Helper loaded: url_helper
INFO - 2018-10-30 04:00:00 --> Database Driver Class Initialized
INFO - 2018-10-30 04:00:00 --> Helper loaded: form_helper
INFO - 2018-10-30 04:00:00 --> Form Validation Class Initialized
INFO - 2018-10-30 04:00:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:00:00 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:00:00 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:00:00 --> Email Class Initialized
INFO - 2018-10-30 04:00:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:00:00 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:00:00 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:00:00 --> Helper loaded: date_helper
INFO - 2018-10-30 04:00:00 --> Database Driver Class Initialized
INFO - 2018-10-30 04:00:00 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:00:00 --> Controller Class Initialized
INFO - 2018-10-30 04:00:00 --> Model "Item_model" initialized
INFO - 2018-10-30 04:00:00 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:00:00 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:00:00 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:00:00 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 04:00:00 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`dbmasterwed`.`nota_detail`, CONSTRAINT `nota_detail_ibfk_1` FOREIGN KEY (`itemid`) REFERENCES `item` (`id`)) - Invalid query: INSERT INTO `nota_detail` (`notaid`, `subtotal`) VALUES (' 18103012', '15000000')
DEBUG - 2018-10-30 04:00:00 --> DB Transaction Failure
INFO - 2018-10-30 04:00:00 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-30 04:02:56 --> Config Class Initialized
INFO - 2018-10-30 04:02:56 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:02:56 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:02:56 --> Utf8 Class Initialized
INFO - 2018-10-30 04:02:56 --> URI Class Initialized
INFO - 2018-10-30 04:02:56 --> Router Class Initialized
INFO - 2018-10-30 04:02:56 --> Output Class Initialized
INFO - 2018-10-30 04:02:56 --> Security Class Initialized
DEBUG - 2018-10-30 04:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:02:56 --> Input Class Initialized
INFO - 2018-10-30 04:02:56 --> Language Class Initialized
INFO - 2018-10-30 04:02:56 --> Loader Class Initialized
INFO - 2018-10-30 04:02:56 --> Helper loaded: url_helper
INFO - 2018-10-30 04:02:56 --> Database Driver Class Initialized
INFO - 2018-10-30 04:02:56 --> Helper loaded: form_helper
INFO - 2018-10-30 04:02:56 --> Form Validation Class Initialized
INFO - 2018-10-30 04:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:02:56 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:02:56 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:02:56 --> Email Class Initialized
INFO - 2018-10-30 04:02:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:02:56 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:02:56 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:02:56 --> Helper loaded: date_helper
INFO - 2018-10-30 04:02:56 --> Database Driver Class Initialized
INFO - 2018-10-30 04:02:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:02:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:02:56 --> Controller Class Initialized
INFO - 2018-10-30 04:02:56 --> Model "Item_model" initialized
INFO - 2018-10-30 04:02:56 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:02:56 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:02:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:02:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:02:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:02:56 --> Final output sent to browser
DEBUG - 2018-10-30 04:02:56 --> Total execution time: 0.4262
INFO - 2018-10-30 04:03:00 --> Config Class Initialized
INFO - 2018-10-30 04:03:01 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:03:01 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:03:01 --> Utf8 Class Initialized
INFO - 2018-10-30 04:03:01 --> URI Class Initialized
INFO - 2018-10-30 04:03:01 --> Router Class Initialized
INFO - 2018-10-30 04:03:01 --> Output Class Initialized
INFO - 2018-10-30 04:03:01 --> Security Class Initialized
DEBUG - 2018-10-30 04:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:03:01 --> Input Class Initialized
INFO - 2018-10-30 04:03:01 --> Language Class Initialized
INFO - 2018-10-30 04:03:01 --> Loader Class Initialized
INFO - 2018-10-30 04:03:01 --> Helper loaded: url_helper
INFO - 2018-10-30 04:03:01 --> Database Driver Class Initialized
INFO - 2018-10-30 04:03:01 --> Helper loaded: form_helper
INFO - 2018-10-30 04:03:01 --> Form Validation Class Initialized
INFO - 2018-10-30 04:03:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:03:01 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:03:01 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:03:01 --> Email Class Initialized
INFO - 2018-10-30 04:03:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:03:01 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:03:01 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:03:01 --> Helper loaded: date_helper
INFO - 2018-10-30 04:03:01 --> Database Driver Class Initialized
INFO - 2018-10-30 04:03:01 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:03:01 --> Controller Class Initialized
INFO - 2018-10-30 04:03:01 --> Model "Item_model" initialized
INFO - 2018-10-30 04:03:01 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:03:01 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:03:01 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:03:01 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:03:01 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:03:01 --> Final output sent to browser
DEBUG - 2018-10-30 04:03:01 --> Total execution time: 0.4239
INFO - 2018-10-30 04:03:01 --> Config Class Initialized
INFO - 2018-10-30 04:03:01 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:03:01 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:03:01 --> Utf8 Class Initialized
INFO - 2018-10-30 04:03:01 --> URI Class Initialized
INFO - 2018-10-30 04:03:01 --> Router Class Initialized
INFO - 2018-10-30 04:03:01 --> Output Class Initialized
INFO - 2018-10-30 04:03:01 --> Security Class Initialized
DEBUG - 2018-10-30 04:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:03:01 --> Input Class Initialized
INFO - 2018-10-30 04:03:01 --> Language Class Initialized
ERROR - 2018-10-30 04:03:01 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:03:03 --> Config Class Initialized
INFO - 2018-10-30 04:03:03 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:03:03 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:03:03 --> Utf8 Class Initialized
INFO - 2018-10-30 04:03:03 --> URI Class Initialized
INFO - 2018-10-30 04:03:03 --> Router Class Initialized
INFO - 2018-10-30 04:03:03 --> Output Class Initialized
INFO - 2018-10-30 04:03:03 --> Security Class Initialized
DEBUG - 2018-10-30 04:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:03:03 --> Input Class Initialized
INFO - 2018-10-30 04:03:03 --> Language Class Initialized
INFO - 2018-10-30 04:03:03 --> Loader Class Initialized
INFO - 2018-10-30 04:03:03 --> Helper loaded: url_helper
INFO - 2018-10-30 04:03:03 --> Database Driver Class Initialized
INFO - 2018-10-30 04:03:03 --> Helper loaded: form_helper
INFO - 2018-10-30 04:03:03 --> Form Validation Class Initialized
INFO - 2018-10-30 04:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:03:03 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:03:03 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:03:03 --> Email Class Initialized
INFO - 2018-10-30 04:03:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:03:03 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:03:03 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:03:03 --> Helper loaded: date_helper
INFO - 2018-10-30 04:03:03 --> Database Driver Class Initialized
INFO - 2018-10-30 04:03:03 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:03:03 --> Controller Class Initialized
INFO - 2018-10-30 04:03:03 --> Model "Item_model" initialized
INFO - 2018-10-30 04:03:03 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:03:03 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:03:03 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:03:03 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 04:03:03 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`dbmasterwed`.`nota_detail`, CONSTRAINT `nota_detail_ibfk_1` FOREIGN KEY (`itemid`) REFERENCES `item` (`id`)) - Invalid query: INSERT INTO `nota_detail` (`notaid`, `itemid`, `subtotal`) VALUES (' 18103022', ' ', '45000000')
DEBUG - 2018-10-30 04:03:03 --> DB Transaction Failure
INFO - 2018-10-30 04:03:03 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-30 04:03:41 --> Config Class Initialized
INFO - 2018-10-30 04:03:41 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:03:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:03:42 --> Utf8 Class Initialized
INFO - 2018-10-30 04:03:42 --> URI Class Initialized
INFO - 2018-10-30 04:03:42 --> Router Class Initialized
INFO - 2018-10-30 04:03:42 --> Output Class Initialized
INFO - 2018-10-30 04:03:42 --> Security Class Initialized
DEBUG - 2018-10-30 04:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:03:42 --> Input Class Initialized
INFO - 2018-10-30 04:03:42 --> Language Class Initialized
INFO - 2018-10-30 04:03:42 --> Loader Class Initialized
INFO - 2018-10-30 04:03:42 --> Helper loaded: url_helper
INFO - 2018-10-30 04:03:42 --> Database Driver Class Initialized
INFO - 2018-10-30 04:03:42 --> Helper loaded: form_helper
INFO - 2018-10-30 04:03:42 --> Form Validation Class Initialized
INFO - 2018-10-30 04:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:03:42 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:03:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:03:42 --> Email Class Initialized
INFO - 2018-10-30 04:03:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:03:42 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:03:42 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:03:42 --> Helper loaded: date_helper
INFO - 2018-10-30 04:03:42 --> Database Driver Class Initialized
INFO - 2018-10-30 04:03:42 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:03:42 --> Controller Class Initialized
INFO - 2018-10-30 04:03:42 --> Model "Item_model" initialized
INFO - 2018-10-30 04:03:42 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:03:42 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:03:42 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:03:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:03:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:03:42 --> Final output sent to browser
DEBUG - 2018-10-30 04:03:42 --> Total execution time: 0.4335
INFO - 2018-10-30 04:03:48 --> Config Class Initialized
INFO - 2018-10-30 04:03:48 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:03:48 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:03:48 --> Utf8 Class Initialized
INFO - 2018-10-30 04:03:48 --> URI Class Initialized
INFO - 2018-10-30 04:03:48 --> Router Class Initialized
INFO - 2018-10-30 04:03:48 --> Output Class Initialized
INFO - 2018-10-30 04:03:48 --> Security Class Initialized
DEBUG - 2018-10-30 04:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:03:48 --> Input Class Initialized
INFO - 2018-10-30 04:03:48 --> Language Class Initialized
INFO - 2018-10-30 04:03:48 --> Loader Class Initialized
INFO - 2018-10-30 04:03:48 --> Helper loaded: url_helper
INFO - 2018-10-30 04:03:48 --> Database Driver Class Initialized
INFO - 2018-10-30 04:03:48 --> Helper loaded: form_helper
INFO - 2018-10-30 04:03:48 --> Form Validation Class Initialized
INFO - 2018-10-30 04:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:03:48 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:03:48 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:03:48 --> Email Class Initialized
INFO - 2018-10-30 04:03:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:03:48 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:03:48 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:03:48 --> Helper loaded: date_helper
INFO - 2018-10-30 04:03:48 --> Database Driver Class Initialized
INFO - 2018-10-30 04:03:48 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:03:48 --> Controller Class Initialized
INFO - 2018-10-30 04:03:48 --> Model "Item_model" initialized
INFO - 2018-10-30 04:03:48 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:03:48 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:03:48 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:03:48 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:03:48 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:03:48 --> Final output sent to browser
DEBUG - 2018-10-30 04:03:48 --> Total execution time: 0.4110
INFO - 2018-10-30 04:03:48 --> Config Class Initialized
INFO - 2018-10-30 04:03:48 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:03:48 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:03:49 --> Utf8 Class Initialized
INFO - 2018-10-30 04:03:49 --> URI Class Initialized
INFO - 2018-10-30 04:03:49 --> Router Class Initialized
INFO - 2018-10-30 04:03:49 --> Output Class Initialized
INFO - 2018-10-30 04:03:49 --> Security Class Initialized
DEBUG - 2018-10-30 04:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:03:49 --> Input Class Initialized
INFO - 2018-10-30 04:03:49 --> Language Class Initialized
ERROR - 2018-10-30 04:03:49 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:03:52 --> Config Class Initialized
INFO - 2018-10-30 04:03:52 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:03:52 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:03:52 --> Utf8 Class Initialized
INFO - 2018-10-30 04:03:52 --> URI Class Initialized
INFO - 2018-10-30 04:03:52 --> Router Class Initialized
INFO - 2018-10-30 04:03:52 --> Output Class Initialized
INFO - 2018-10-30 04:03:52 --> Security Class Initialized
DEBUG - 2018-10-30 04:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:03:52 --> Input Class Initialized
INFO - 2018-10-30 04:03:52 --> Language Class Initialized
INFO - 2018-10-30 04:03:52 --> Loader Class Initialized
INFO - 2018-10-30 04:03:52 --> Helper loaded: url_helper
INFO - 2018-10-30 04:03:52 --> Database Driver Class Initialized
INFO - 2018-10-30 04:03:52 --> Helper loaded: form_helper
INFO - 2018-10-30 04:03:52 --> Form Validation Class Initialized
INFO - 2018-10-30 04:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:03:52 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:03:52 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:03:52 --> Email Class Initialized
INFO - 2018-10-30 04:03:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:03:52 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:03:52 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:03:52 --> Helper loaded: date_helper
INFO - 2018-10-30 04:03:52 --> Database Driver Class Initialized
INFO - 2018-10-30 04:03:52 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:03:52 --> Controller Class Initialized
INFO - 2018-10-30 04:03:52 --> Model "Item_model" initialized
INFO - 2018-10-30 04:03:53 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:03:53 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:03:53 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:03:53 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:03:53 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 04:03:53 --> Final output sent to browser
DEBUG - 2018-10-30 04:03:53 --> Total execution time: 0.4370
INFO - 2018-10-30 04:03:53 --> Config Class Initialized
INFO - 2018-10-30 04:03:53 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:03:53 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:03:53 --> Utf8 Class Initialized
INFO - 2018-10-30 04:03:53 --> URI Class Initialized
INFO - 2018-10-30 04:03:53 --> Router Class Initialized
INFO - 2018-10-30 04:03:53 --> Output Class Initialized
INFO - 2018-10-30 04:03:53 --> Security Class Initialized
DEBUG - 2018-10-30 04:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:03:53 --> Input Class Initialized
INFO - 2018-10-30 04:03:53 --> Language Class Initialized
ERROR - 2018-10-30 04:03:53 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:04:04 --> Config Class Initialized
INFO - 2018-10-30 04:04:04 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:04:04 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:04:04 --> Utf8 Class Initialized
INFO - 2018-10-30 04:04:05 --> URI Class Initialized
INFO - 2018-10-30 04:04:05 --> Router Class Initialized
INFO - 2018-10-30 04:04:05 --> Output Class Initialized
INFO - 2018-10-30 04:04:05 --> Security Class Initialized
DEBUG - 2018-10-30 04:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:04:05 --> Input Class Initialized
INFO - 2018-10-30 04:04:05 --> Language Class Initialized
INFO - 2018-10-30 04:04:05 --> Loader Class Initialized
INFO - 2018-10-30 04:04:05 --> Helper loaded: url_helper
INFO - 2018-10-30 04:04:05 --> Database Driver Class Initialized
INFO - 2018-10-30 04:04:05 --> Helper loaded: form_helper
INFO - 2018-10-30 04:04:05 --> Form Validation Class Initialized
INFO - 2018-10-30 04:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:04:05 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:04:05 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:04:05 --> Email Class Initialized
INFO - 2018-10-30 04:04:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:04:05 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:04:05 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:04:05 --> Helper loaded: date_helper
INFO - 2018-10-30 04:04:05 --> Database Driver Class Initialized
INFO - 2018-10-30 04:04:05 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:04:05 --> Controller Class Initialized
INFO - 2018-10-30 04:04:05 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:04:05 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 04:04:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-30 04:04:05 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 04:04:05 --> Final output sent to browser
DEBUG - 2018-10-30 04:04:05 --> Total execution time: 0.4469
INFO - 2018-10-30 04:08:04 --> Config Class Initialized
INFO - 2018-10-30 04:08:05 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:08:05 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:08:05 --> Utf8 Class Initialized
INFO - 2018-10-30 04:08:05 --> URI Class Initialized
INFO - 2018-10-30 04:08:05 --> Router Class Initialized
INFO - 2018-10-30 04:08:05 --> Output Class Initialized
INFO - 2018-10-30 04:08:05 --> Security Class Initialized
DEBUG - 2018-10-30 04:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:08:05 --> Input Class Initialized
INFO - 2018-10-30 04:08:05 --> Language Class Initialized
INFO - 2018-10-30 04:08:05 --> Loader Class Initialized
INFO - 2018-10-30 04:08:05 --> Helper loaded: url_helper
INFO - 2018-10-30 04:08:05 --> Database Driver Class Initialized
INFO - 2018-10-30 04:08:05 --> Helper loaded: form_helper
INFO - 2018-10-30 04:08:05 --> Form Validation Class Initialized
INFO - 2018-10-30 04:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:08:05 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:08:05 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:08:05 --> Email Class Initialized
INFO - 2018-10-30 04:08:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:08:05 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:08:05 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:08:05 --> Helper loaded: date_helper
INFO - 2018-10-30 04:08:05 --> Database Driver Class Initialized
INFO - 2018-10-30 04:08:05 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:08:05 --> Controller Class Initialized
INFO - 2018-10-30 04:08:05 --> Model "Item_model" initialized
INFO - 2018-10-30 04:08:05 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:08:05 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:08:05 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:08:05 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:08:05 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:08:05 --> Final output sent to browser
DEBUG - 2018-10-30 04:08:05 --> Total execution time: 0.4059
INFO - 2018-10-30 04:08:19 --> Config Class Initialized
INFO - 2018-10-30 04:08:19 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:08:19 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:08:19 --> Utf8 Class Initialized
INFO - 2018-10-30 04:08:19 --> URI Class Initialized
INFO - 2018-10-30 04:08:19 --> Router Class Initialized
INFO - 2018-10-30 04:08:19 --> Output Class Initialized
INFO - 2018-10-30 04:08:19 --> Security Class Initialized
DEBUG - 2018-10-30 04:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:08:19 --> Input Class Initialized
INFO - 2018-10-30 04:08:19 --> Language Class Initialized
INFO - 2018-10-30 04:08:19 --> Loader Class Initialized
INFO - 2018-10-30 04:08:19 --> Helper loaded: url_helper
INFO - 2018-10-30 04:08:19 --> Database Driver Class Initialized
INFO - 2018-10-30 04:08:19 --> Helper loaded: form_helper
INFO - 2018-10-30 04:08:19 --> Form Validation Class Initialized
INFO - 2018-10-30 04:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:08:19 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:08:19 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:08:19 --> Email Class Initialized
INFO - 2018-10-30 04:08:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:08:19 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:08:19 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:08:19 --> Helper loaded: date_helper
INFO - 2018-10-30 04:08:19 --> Database Driver Class Initialized
INFO - 2018-10-30 04:08:19 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:08:19 --> Controller Class Initialized
INFO - 2018-10-30 04:08:19 --> Model "Item_model" initialized
INFO - 2018-10-30 04:08:19 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:08:19 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:08:19 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:08:19 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:08:19 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:08:19 --> Final output sent to browser
DEBUG - 2018-10-30 04:08:19 --> Total execution time: 0.4146
INFO - 2018-10-30 04:08:19 --> Config Class Initialized
INFO - 2018-10-30 04:08:19 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:08:19 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:08:19 --> Utf8 Class Initialized
INFO - 2018-10-30 04:08:19 --> URI Class Initialized
INFO - 2018-10-30 04:08:19 --> Router Class Initialized
INFO - 2018-10-30 04:08:19 --> Output Class Initialized
INFO - 2018-10-30 04:08:20 --> Security Class Initialized
DEBUG - 2018-10-30 04:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:08:20 --> Input Class Initialized
INFO - 2018-10-30 04:08:20 --> Language Class Initialized
ERROR - 2018-10-30 04:08:20 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:09:37 --> Config Class Initialized
INFO - 2018-10-30 04:09:37 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:09:37 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:09:37 --> Utf8 Class Initialized
INFO - 2018-10-30 04:09:37 --> URI Class Initialized
INFO - 2018-10-30 04:09:37 --> Router Class Initialized
INFO - 2018-10-30 04:09:37 --> Output Class Initialized
INFO - 2018-10-30 04:09:37 --> Security Class Initialized
DEBUG - 2018-10-30 04:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:09:37 --> Input Class Initialized
INFO - 2018-10-30 04:09:37 --> Language Class Initialized
INFO - 2018-10-30 04:09:37 --> Loader Class Initialized
INFO - 2018-10-30 04:09:37 --> Helper loaded: url_helper
INFO - 2018-10-30 04:09:37 --> Database Driver Class Initialized
INFO - 2018-10-30 04:09:37 --> Helper loaded: form_helper
INFO - 2018-10-30 04:09:37 --> Form Validation Class Initialized
INFO - 2018-10-30 04:09:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:09:37 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:09:37 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:09:37 --> Email Class Initialized
INFO - 2018-10-30 04:09:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:09:37 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:09:37 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:09:37 --> Helper loaded: date_helper
INFO - 2018-10-30 04:09:37 --> Database Driver Class Initialized
INFO - 2018-10-30 04:09:37 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:09:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:09:37 --> Controller Class Initialized
INFO - 2018-10-30 04:09:37 --> Model "Item_model" initialized
INFO - 2018-10-30 04:09:37 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:09:37 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:09:37 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:09:37 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:09:37 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:09:37 --> Final output sent to browser
DEBUG - 2018-10-30 04:09:37 --> Total execution time: 0.3872
INFO - 2018-10-30 04:09:41 --> Config Class Initialized
INFO - 2018-10-30 04:09:41 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:09:41 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:09:41 --> Utf8 Class Initialized
INFO - 2018-10-30 04:09:41 --> URI Class Initialized
INFO - 2018-10-30 04:09:41 --> Router Class Initialized
INFO - 2018-10-30 04:09:41 --> Output Class Initialized
INFO - 2018-10-30 04:09:41 --> Security Class Initialized
DEBUG - 2018-10-30 04:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:09:41 --> Input Class Initialized
INFO - 2018-10-30 04:09:41 --> Language Class Initialized
INFO - 2018-10-30 04:09:41 --> Loader Class Initialized
INFO - 2018-10-30 04:09:41 --> Helper loaded: url_helper
INFO - 2018-10-30 04:09:41 --> Database Driver Class Initialized
INFO - 2018-10-30 04:09:41 --> Helper loaded: form_helper
INFO - 2018-10-30 04:09:41 --> Form Validation Class Initialized
INFO - 2018-10-30 04:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:09:41 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:09:41 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:09:41 --> Email Class Initialized
INFO - 2018-10-30 04:09:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:09:41 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:09:41 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:09:42 --> Helper loaded: date_helper
INFO - 2018-10-30 04:09:42 --> Database Driver Class Initialized
INFO - 2018-10-30 04:09:42 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:09:42 --> Controller Class Initialized
INFO - 2018-10-30 04:09:42 --> Model "Item_model" initialized
INFO - 2018-10-30 04:09:42 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:09:42 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:09:42 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:09:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:09:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:09:42 --> Final output sent to browser
DEBUG - 2018-10-30 04:09:42 --> Total execution time: 0.3944
INFO - 2018-10-30 04:09:42 --> Config Class Initialized
INFO - 2018-10-30 04:09:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:09:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:09:42 --> Utf8 Class Initialized
INFO - 2018-10-30 04:09:42 --> URI Class Initialized
INFO - 2018-10-30 04:09:42 --> Router Class Initialized
INFO - 2018-10-30 04:09:42 --> Output Class Initialized
INFO - 2018-10-30 04:09:42 --> Security Class Initialized
DEBUG - 2018-10-30 04:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:09:42 --> Input Class Initialized
INFO - 2018-10-30 04:09:42 --> Language Class Initialized
ERROR - 2018-10-30 04:09:42 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:09:43 --> Config Class Initialized
INFO - 2018-10-30 04:09:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:09:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:09:43 --> Utf8 Class Initialized
INFO - 2018-10-30 04:09:43 --> URI Class Initialized
INFO - 2018-10-30 04:09:43 --> Router Class Initialized
INFO - 2018-10-30 04:09:43 --> Output Class Initialized
INFO - 2018-10-30 04:09:43 --> Security Class Initialized
DEBUG - 2018-10-30 04:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:09:43 --> Input Class Initialized
INFO - 2018-10-30 04:09:43 --> Language Class Initialized
INFO - 2018-10-30 04:09:43 --> Loader Class Initialized
INFO - 2018-10-30 04:09:43 --> Helper loaded: url_helper
INFO - 2018-10-30 04:09:43 --> Database Driver Class Initialized
INFO - 2018-10-30 04:09:43 --> Helper loaded: form_helper
INFO - 2018-10-30 04:09:43 --> Form Validation Class Initialized
INFO - 2018-10-30 04:09:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:09:43 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:09:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:09:43 --> Email Class Initialized
INFO - 2018-10-30 04:09:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:09:43 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:09:43 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:09:43 --> Helper loaded: date_helper
INFO - 2018-10-30 04:09:43 --> Database Driver Class Initialized
INFO - 2018-10-30 04:09:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:09:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:09:43 --> Controller Class Initialized
INFO - 2018-10-30 04:09:43 --> Model "Item_model" initialized
INFO - 2018-10-30 04:09:43 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:09:43 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:09:43 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:09:43 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:09:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-30 04:09:44 --> Severity: Notice --> Undefined variable: record D:\xampp\htdocs\masterwedding\application\controllers\Item.php 165
ERROR - 2018-10-30 04:09:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 53
ERROR - 2018-10-30 04:09:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 57
INFO - 2018-10-30 04:09:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:09:44 --> Final output sent to browser
DEBUG - 2018-10-30 04:09:44 --> Total execution time: 0.5132
INFO - 2018-10-30 04:09:44 --> Config Class Initialized
INFO - 2018-10-30 04:09:44 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:09:44 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:09:44 --> Utf8 Class Initialized
INFO - 2018-10-30 04:09:44 --> URI Class Initialized
INFO - 2018-10-30 04:09:44 --> Router Class Initialized
INFO - 2018-10-30 04:09:44 --> Output Class Initialized
INFO - 2018-10-30 04:09:44 --> Security Class Initialized
DEBUG - 2018-10-30 04:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:09:44 --> Input Class Initialized
INFO - 2018-10-30 04:09:44 --> Language Class Initialized
ERROR - 2018-10-30 04:09:44 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:09:44 --> Config Class Initialized
INFO - 2018-10-30 04:09:44 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:09:44 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:09:44 --> Utf8 Class Initialized
INFO - 2018-10-30 04:09:44 --> URI Class Initialized
INFO - 2018-10-30 04:09:44 --> Router Class Initialized
INFO - 2018-10-30 04:09:44 --> Output Class Initialized
INFO - 2018-10-30 04:09:44 --> Security Class Initialized
DEBUG - 2018-10-30 04:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:09:44 --> Input Class Initialized
INFO - 2018-10-30 04:09:44 --> Language Class Initialized
ERROR - 2018-10-30 04:09:44 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:10:30 --> Config Class Initialized
INFO - 2018-10-30 04:10:30 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:10:30 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:10:30 --> Utf8 Class Initialized
INFO - 2018-10-30 04:10:30 --> URI Class Initialized
INFO - 2018-10-30 04:10:30 --> Router Class Initialized
INFO - 2018-10-30 04:10:30 --> Output Class Initialized
INFO - 2018-10-30 04:10:30 --> Security Class Initialized
DEBUG - 2018-10-30 04:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:10:30 --> Input Class Initialized
INFO - 2018-10-30 04:10:30 --> Language Class Initialized
INFO - 2018-10-30 04:10:30 --> Loader Class Initialized
INFO - 2018-10-30 04:10:30 --> Helper loaded: url_helper
INFO - 2018-10-30 04:10:30 --> Database Driver Class Initialized
INFO - 2018-10-30 04:10:30 --> Helper loaded: form_helper
INFO - 2018-10-30 04:10:30 --> Form Validation Class Initialized
INFO - 2018-10-30 04:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:10:30 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:10:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:10:30 --> Email Class Initialized
INFO - 2018-10-30 04:10:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:10:30 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:10:30 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:10:30 --> Helper loaded: date_helper
INFO - 2018-10-30 04:10:30 --> Database Driver Class Initialized
INFO - 2018-10-30 04:10:30 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:10:30 --> Controller Class Initialized
INFO - 2018-10-30 04:10:30 --> Model "Item_model" initialized
INFO - 2018-10-30 04:10:30 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:10:30 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:10:30 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:10:30 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:10:30 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:10:30 --> Final output sent to browser
DEBUG - 2018-10-30 04:10:30 --> Total execution time: 0.4258
INFO - 2018-10-30 04:10:35 --> Config Class Initialized
INFO - 2018-10-30 04:10:35 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:10:35 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:10:35 --> Utf8 Class Initialized
INFO - 2018-10-30 04:10:35 --> URI Class Initialized
INFO - 2018-10-30 04:10:35 --> Router Class Initialized
INFO - 2018-10-30 04:10:35 --> Output Class Initialized
INFO - 2018-10-30 04:10:35 --> Security Class Initialized
DEBUG - 2018-10-30 04:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:10:35 --> Input Class Initialized
INFO - 2018-10-30 04:10:35 --> Language Class Initialized
INFO - 2018-10-30 04:10:35 --> Loader Class Initialized
INFO - 2018-10-30 04:10:35 --> Helper loaded: url_helper
INFO - 2018-10-30 04:10:35 --> Database Driver Class Initialized
INFO - 2018-10-30 04:10:35 --> Helper loaded: form_helper
INFO - 2018-10-30 04:10:35 --> Form Validation Class Initialized
INFO - 2018-10-30 04:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:10:35 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:10:35 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:10:35 --> Email Class Initialized
INFO - 2018-10-30 04:10:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:10:35 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:10:35 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:10:35 --> Helper loaded: date_helper
INFO - 2018-10-30 04:10:35 --> Database Driver Class Initialized
INFO - 2018-10-30 04:10:35 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:10:35 --> Controller Class Initialized
INFO - 2018-10-30 04:10:35 --> Model "Item_model" initialized
INFO - 2018-10-30 04:10:35 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:10:35 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:10:35 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:10:35 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:10:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:10:35 --> Final output sent to browser
DEBUG - 2018-10-30 04:10:35 --> Total execution time: 0.4262
INFO - 2018-10-30 04:10:35 --> Config Class Initialized
INFO - 2018-10-30 04:10:35 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:10:35 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:10:35 --> Utf8 Class Initialized
INFO - 2018-10-30 04:10:35 --> URI Class Initialized
INFO - 2018-10-30 04:10:35 --> Router Class Initialized
INFO - 2018-10-30 04:10:35 --> Output Class Initialized
INFO - 2018-10-30 04:10:35 --> Security Class Initialized
DEBUG - 2018-10-30 04:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:10:35 --> Input Class Initialized
INFO - 2018-10-30 04:10:35 --> Language Class Initialized
ERROR - 2018-10-30 04:10:35 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:10:36 --> Config Class Initialized
INFO - 2018-10-30 04:10:36 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:10:36 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:10:36 --> Utf8 Class Initialized
INFO - 2018-10-30 04:10:36 --> URI Class Initialized
INFO - 2018-10-30 04:10:37 --> Router Class Initialized
INFO - 2018-10-30 04:10:37 --> Output Class Initialized
INFO - 2018-10-30 04:10:37 --> Security Class Initialized
DEBUG - 2018-10-30 04:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:10:37 --> Input Class Initialized
INFO - 2018-10-30 04:10:37 --> Language Class Initialized
INFO - 2018-10-30 04:10:37 --> Loader Class Initialized
INFO - 2018-10-30 04:10:37 --> Helper loaded: url_helper
INFO - 2018-10-30 04:10:37 --> Database Driver Class Initialized
INFO - 2018-10-30 04:10:37 --> Helper loaded: form_helper
INFO - 2018-10-30 04:10:37 --> Form Validation Class Initialized
INFO - 2018-10-30 04:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:10:37 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:10:37 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:10:37 --> Email Class Initialized
INFO - 2018-10-30 04:10:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:10:37 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:10:37 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:10:37 --> Helper loaded: date_helper
INFO - 2018-10-30 04:10:37 --> Database Driver Class Initialized
INFO - 2018-10-30 04:10:37 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:10:37 --> Controller Class Initialized
INFO - 2018-10-30 04:10:37 --> Model "Item_model" initialized
INFO - 2018-10-30 04:10:37 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:10:37 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:10:37 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:10:37 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:10:37 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-30 04:10:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\controllers\Item.php 167
INFO - 2018-10-30 04:10:37 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:10:37 --> Final output sent to browser
DEBUG - 2018-10-30 04:10:37 --> Total execution time: 0.4596
INFO - 2018-10-30 04:10:37 --> Config Class Initialized
INFO - 2018-10-30 04:10:37 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:10:37 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:10:37 --> Utf8 Class Initialized
INFO - 2018-10-30 04:10:37 --> URI Class Initialized
INFO - 2018-10-30 04:10:37 --> Router Class Initialized
INFO - 2018-10-30 04:10:37 --> Output Class Initialized
INFO - 2018-10-30 04:10:37 --> Security Class Initialized
DEBUG - 2018-10-30 04:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:10:37 --> Input Class Initialized
INFO - 2018-10-30 04:10:37 --> Language Class Initialized
ERROR - 2018-10-30 04:10:37 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:10:37 --> Config Class Initialized
INFO - 2018-10-30 04:10:37 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:10:37 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:10:37 --> Utf8 Class Initialized
INFO - 2018-10-30 04:10:37 --> URI Class Initialized
INFO - 2018-10-30 04:10:37 --> Router Class Initialized
INFO - 2018-10-30 04:10:37 --> Output Class Initialized
INFO - 2018-10-30 04:10:37 --> Security Class Initialized
DEBUG - 2018-10-30 04:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:10:37 --> Input Class Initialized
INFO - 2018-10-30 04:10:37 --> Language Class Initialized
ERROR - 2018-10-30 04:10:37 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:11:36 --> Config Class Initialized
INFO - 2018-10-30 04:11:36 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:11:36 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:11:36 --> Utf8 Class Initialized
INFO - 2018-10-30 04:11:36 --> URI Class Initialized
INFO - 2018-10-30 04:11:36 --> Router Class Initialized
INFO - 2018-10-30 04:11:36 --> Output Class Initialized
INFO - 2018-10-30 04:11:36 --> Security Class Initialized
DEBUG - 2018-10-30 04:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:11:36 --> Input Class Initialized
INFO - 2018-10-30 04:11:36 --> Language Class Initialized
INFO - 2018-10-30 04:11:36 --> Loader Class Initialized
INFO - 2018-10-30 04:11:36 --> Helper loaded: url_helper
INFO - 2018-10-30 04:11:36 --> Database Driver Class Initialized
INFO - 2018-10-30 04:11:36 --> Helper loaded: form_helper
INFO - 2018-10-30 04:11:36 --> Form Validation Class Initialized
INFO - 2018-10-30 04:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:11:36 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:11:36 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:11:36 --> Email Class Initialized
INFO - 2018-10-30 04:11:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:11:36 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:11:36 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:11:36 --> Helper loaded: date_helper
INFO - 2018-10-30 04:11:36 --> Database Driver Class Initialized
INFO - 2018-10-30 04:11:36 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:11:36 --> Controller Class Initialized
INFO - 2018-10-30 04:11:36 --> Model "Item_model" initialized
INFO - 2018-10-30 04:11:36 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:11:36 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:11:36 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:11:36 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:11:36 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:11:36 --> Final output sent to browser
DEBUG - 2018-10-30 04:11:36 --> Total execution time: 0.4522
INFO - 2018-10-30 04:11:40 --> Config Class Initialized
INFO - 2018-10-30 04:11:40 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:11:40 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:11:40 --> Utf8 Class Initialized
INFO - 2018-10-30 04:11:40 --> URI Class Initialized
INFO - 2018-10-30 04:11:40 --> Router Class Initialized
INFO - 2018-10-30 04:11:40 --> Output Class Initialized
INFO - 2018-10-30 04:11:40 --> Security Class Initialized
DEBUG - 2018-10-30 04:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:11:40 --> Input Class Initialized
INFO - 2018-10-30 04:11:40 --> Language Class Initialized
INFO - 2018-10-30 04:11:40 --> Loader Class Initialized
INFO - 2018-10-30 04:11:40 --> Helper loaded: url_helper
INFO - 2018-10-30 04:11:40 --> Database Driver Class Initialized
INFO - 2018-10-30 04:11:40 --> Helper loaded: form_helper
INFO - 2018-10-30 04:11:40 --> Form Validation Class Initialized
INFO - 2018-10-30 04:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:11:40 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:11:40 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:11:40 --> Email Class Initialized
INFO - 2018-10-30 04:11:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:11:40 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:11:40 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:11:40 --> Helper loaded: date_helper
INFO - 2018-10-30 04:11:40 --> Database Driver Class Initialized
INFO - 2018-10-30 04:11:40 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:11:40 --> Controller Class Initialized
INFO - 2018-10-30 04:11:40 --> Model "Item_model" initialized
INFO - 2018-10-30 04:11:40 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:11:40 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:11:40 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:11:40 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:11:40 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:11:40 --> Final output sent to browser
DEBUG - 2018-10-30 04:11:40 --> Total execution time: 0.4089
INFO - 2018-10-30 04:11:40 --> Config Class Initialized
INFO - 2018-10-30 04:11:40 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:11:40 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:11:40 --> Utf8 Class Initialized
INFO - 2018-10-30 04:11:40 --> URI Class Initialized
INFO - 2018-10-30 04:11:40 --> Router Class Initialized
INFO - 2018-10-30 04:11:40 --> Output Class Initialized
INFO - 2018-10-30 04:11:40 --> Security Class Initialized
DEBUG - 2018-10-30 04:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:11:40 --> Input Class Initialized
INFO - 2018-10-30 04:11:40 --> Language Class Initialized
ERROR - 2018-10-30 04:11:40 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:11:42 --> Config Class Initialized
INFO - 2018-10-30 04:11:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:11:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:11:42 --> Utf8 Class Initialized
INFO - 2018-10-30 04:11:42 --> URI Class Initialized
INFO - 2018-10-30 04:11:42 --> Router Class Initialized
INFO - 2018-10-30 04:11:42 --> Output Class Initialized
INFO - 2018-10-30 04:11:42 --> Security Class Initialized
DEBUG - 2018-10-30 04:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:11:42 --> Input Class Initialized
INFO - 2018-10-30 04:11:42 --> Language Class Initialized
INFO - 2018-10-30 04:11:42 --> Loader Class Initialized
INFO - 2018-10-30 04:11:42 --> Helper loaded: url_helper
INFO - 2018-10-30 04:11:42 --> Database Driver Class Initialized
INFO - 2018-10-30 04:11:42 --> Helper loaded: form_helper
INFO - 2018-10-30 04:11:42 --> Form Validation Class Initialized
INFO - 2018-10-30 04:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:11:42 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:11:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:11:42 --> Email Class Initialized
INFO - 2018-10-30 04:11:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:11:42 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:11:42 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:11:42 --> Helper loaded: date_helper
INFO - 2018-10-30 04:11:42 --> Database Driver Class Initialized
INFO - 2018-10-30 04:11:42 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:11:42 --> Controller Class Initialized
INFO - 2018-10-30 04:11:42 --> Model "Item_model" initialized
INFO - 2018-10-30 04:11:42 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:11:42 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:11:42 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:11:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:11:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: userid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 64
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 65
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: typepaket D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 70
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 71
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: namavendor D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 72
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: nama D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 73
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: lokasi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 74
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: deskripsi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 75
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: starttime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 76
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: endtime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 77
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: quota D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 80
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: foto D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 81
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: harga D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 82
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: userid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 64
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 65
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: typepaket D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 70
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 71
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: namavendor D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 72
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: nama D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 73
ERROR - 2018-10-30 04:11:42 --> Severity: Notice --> Undefined index: lokasi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 74
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: deskripsi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 75
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: starttime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 76
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: endtime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 77
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: quota D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 80
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: foto D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 81
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: harga D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 82
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: userid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 64
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 65
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: typepaket D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 70
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 71
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: namavendor D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 72
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: nama D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 73
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: lokasi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 74
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: deskripsi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 75
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: starttime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 76
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: endtime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 77
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: quota D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 80
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: foto D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 81
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: harga D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 82
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: userid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 64
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 65
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: typepaket D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 70
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 71
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: namavendor D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 72
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: nama D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 73
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: lokasi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 74
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: deskripsi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 75
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: starttime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 76
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: endtime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 77
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: quota D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 80
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: foto D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 81
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: harga D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 82
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: userid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 64
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 65
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: typepaket D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 70
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 71
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: namavendor D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 72
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: nama D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 73
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: lokasi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 74
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: deskripsi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 75
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: starttime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 76
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: endtime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 77
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: quota D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 80
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: foto D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 81
ERROR - 2018-10-30 04:11:43 --> Severity: Notice --> Undefined index: harga D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 82
INFO - 2018-10-30 04:11:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:11:43 --> Final output sent to browser
DEBUG - 2018-10-30 04:11:43 --> Total execution time: 1.1053
INFO - 2018-10-30 04:11:43 --> Config Class Initialized
INFO - 2018-10-30 04:11:43 --> Hooks Class Initialized
INFO - 2018-10-30 04:11:43 --> Config Class Initialized
INFO - 2018-10-30 04:11:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:11:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:11:43 --> Utf8 Class Initialized
DEBUG - 2018-10-30 04:11:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:11:43 --> Utf8 Class Initialized
INFO - 2018-10-30 04:11:43 --> URI Class Initialized
INFO - 2018-10-30 04:11:43 --> Router Class Initialized
INFO - 2018-10-30 04:11:43 --> Output Class Initialized
INFO - 2018-10-30 04:11:43 --> Security Class Initialized
DEBUG - 2018-10-30 04:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:11:43 --> Input Class Initialized
INFO - 2018-10-30 04:11:43 --> Language Class Initialized
ERROR - 2018-10-30 04:11:43 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:11:43 --> Config Class Initialized
INFO - 2018-10-30 04:11:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:11:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:11:43 --> Utf8 Class Initialized
INFO - 2018-10-30 04:11:43 --> URI Class Initialized
INFO - 2018-10-30 04:11:43 --> Router Class Initialized
INFO - 2018-10-30 04:11:43 --> Output Class Initialized
INFO - 2018-10-30 04:11:43 --> Security Class Initialized
DEBUG - 2018-10-30 04:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:11:43 --> Input Class Initialized
INFO - 2018-10-30 04:11:43 --> Language Class Initialized
ERROR - 2018-10-30 04:11:43 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:11:43 --> Config Class Initialized
INFO - 2018-10-30 04:11:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:11:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:11:43 --> Utf8 Class Initialized
INFO - 2018-10-30 04:12:51 --> Config Class Initialized
INFO - 2018-10-30 04:12:51 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:12:51 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:12:51 --> Utf8 Class Initialized
INFO - 2018-10-30 04:12:51 --> URI Class Initialized
INFO - 2018-10-30 04:12:51 --> Router Class Initialized
INFO - 2018-10-30 04:12:51 --> Output Class Initialized
INFO - 2018-10-30 04:12:51 --> Security Class Initialized
DEBUG - 2018-10-30 04:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:12:51 --> Input Class Initialized
INFO - 2018-10-30 04:12:51 --> Language Class Initialized
INFO - 2018-10-30 04:12:51 --> Loader Class Initialized
INFO - 2018-10-30 04:12:51 --> Helper loaded: url_helper
INFO - 2018-10-30 04:12:51 --> Database Driver Class Initialized
INFO - 2018-10-30 04:12:51 --> Helper loaded: form_helper
INFO - 2018-10-30 04:12:51 --> Form Validation Class Initialized
INFO - 2018-10-30 04:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:12:51 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:12:51 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:12:51 --> Email Class Initialized
INFO - 2018-10-30 04:12:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:12:51 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:12:51 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:12:51 --> Helper loaded: date_helper
INFO - 2018-10-30 04:12:51 --> Database Driver Class Initialized
INFO - 2018-10-30 04:12:51 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:12:51 --> Controller Class Initialized
INFO - 2018-10-30 04:12:51 --> Model "Item_model" initialized
INFO - 2018-10-30 04:12:51 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:12:51 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:12:51 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:12:51 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:12:51 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:12:51 --> Final output sent to browser
DEBUG - 2018-10-30 04:12:51 --> Total execution time: 0.4291
INFO - 2018-10-30 04:12:55 --> Config Class Initialized
INFO - 2018-10-30 04:12:55 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:12:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:12:55 --> Utf8 Class Initialized
INFO - 2018-10-30 04:12:55 --> URI Class Initialized
INFO - 2018-10-30 04:12:55 --> Router Class Initialized
INFO - 2018-10-30 04:12:55 --> Output Class Initialized
INFO - 2018-10-30 04:12:55 --> Security Class Initialized
DEBUG - 2018-10-30 04:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:12:55 --> Input Class Initialized
INFO - 2018-10-30 04:12:55 --> Language Class Initialized
INFO - 2018-10-30 04:12:55 --> Loader Class Initialized
INFO - 2018-10-30 04:12:55 --> Helper loaded: url_helper
INFO - 2018-10-30 04:12:55 --> Database Driver Class Initialized
INFO - 2018-10-30 04:12:56 --> Helper loaded: form_helper
INFO - 2018-10-30 04:12:56 --> Form Validation Class Initialized
INFO - 2018-10-30 04:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:12:56 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:12:56 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:12:56 --> Email Class Initialized
INFO - 2018-10-30 04:12:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:12:56 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:12:56 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:12:56 --> Helper loaded: date_helper
INFO - 2018-10-30 04:12:56 --> Database Driver Class Initialized
INFO - 2018-10-30 04:12:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:12:56 --> Controller Class Initialized
INFO - 2018-10-30 04:12:56 --> Model "Item_model" initialized
INFO - 2018-10-30 04:12:56 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:12:56 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:12:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:12:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:12:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:12:56 --> Final output sent to browser
DEBUG - 2018-10-30 04:12:56 --> Total execution time: 0.4604
INFO - 2018-10-30 04:12:56 --> Config Class Initialized
INFO - 2018-10-30 04:12:56 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:12:56 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:12:56 --> Utf8 Class Initialized
INFO - 2018-10-30 04:12:56 --> URI Class Initialized
INFO - 2018-10-30 04:12:56 --> Router Class Initialized
INFO - 2018-10-30 04:12:56 --> Output Class Initialized
INFO - 2018-10-30 04:12:56 --> Security Class Initialized
DEBUG - 2018-10-30 04:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:12:56 --> Input Class Initialized
INFO - 2018-10-30 04:12:56 --> Language Class Initialized
ERROR - 2018-10-30 04:12:56 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:12:57 --> Config Class Initialized
INFO - 2018-10-30 04:12:57 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:12:57 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:12:57 --> Utf8 Class Initialized
INFO - 2018-10-30 04:12:57 --> URI Class Initialized
INFO - 2018-10-30 04:12:57 --> Router Class Initialized
INFO - 2018-10-30 04:12:57 --> Output Class Initialized
INFO - 2018-10-30 04:12:57 --> Security Class Initialized
DEBUG - 2018-10-30 04:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:12:57 --> Input Class Initialized
INFO - 2018-10-30 04:12:57 --> Language Class Initialized
INFO - 2018-10-30 04:12:57 --> Loader Class Initialized
INFO - 2018-10-30 04:12:57 --> Helper loaded: url_helper
INFO - 2018-10-30 04:12:57 --> Database Driver Class Initialized
INFO - 2018-10-30 04:12:57 --> Helper loaded: form_helper
INFO - 2018-10-30 04:12:57 --> Form Validation Class Initialized
INFO - 2018-10-30 04:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:12:57 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:12:57 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:12:57 --> Email Class Initialized
INFO - 2018-10-30 04:12:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:12:57 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:12:57 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:12:57 --> Helper loaded: date_helper
INFO - 2018-10-30 04:12:57 --> Database Driver Class Initialized
INFO - 2018-10-30 04:12:57 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:12:58 --> Controller Class Initialized
INFO - 2018-10-30 04:12:58 --> Model "Item_model" initialized
INFO - 2018-10-30 04:12:58 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:12:58 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:12:58 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:12:58 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:12:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-30 04:12:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\controllers\Item.php 167
INFO - 2018-10-30 04:12:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:12:58 --> Final output sent to browser
DEBUG - 2018-10-30 04:12:58 --> Total execution time: 0.4743
INFO - 2018-10-30 04:12:58 --> Config Class Initialized
INFO - 2018-10-30 04:12:58 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:12:58 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:12:58 --> Utf8 Class Initialized
INFO - 2018-10-30 04:12:58 --> URI Class Initialized
INFO - 2018-10-30 04:12:58 --> Router Class Initialized
INFO - 2018-10-30 04:12:58 --> Output Class Initialized
INFO - 2018-10-30 04:12:58 --> Security Class Initialized
DEBUG - 2018-10-30 04:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:12:58 --> Input Class Initialized
INFO - 2018-10-30 04:12:58 --> Language Class Initialized
ERROR - 2018-10-30 04:12:58 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:12:58 --> Config Class Initialized
INFO - 2018-10-30 04:12:58 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:12:58 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:12:58 --> Utf8 Class Initialized
INFO - 2018-10-30 04:12:58 --> URI Class Initialized
INFO - 2018-10-30 04:12:58 --> Router Class Initialized
INFO - 2018-10-30 04:12:58 --> Output Class Initialized
INFO - 2018-10-30 04:12:58 --> Security Class Initialized
DEBUG - 2018-10-30 04:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:12:58 --> Input Class Initialized
INFO - 2018-10-30 04:12:58 --> Language Class Initialized
ERROR - 2018-10-30 04:12:58 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:14:21 --> Config Class Initialized
INFO - 2018-10-30 04:14:21 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:14:21 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:14:21 --> Utf8 Class Initialized
INFO - 2018-10-30 04:14:21 --> URI Class Initialized
INFO - 2018-10-30 04:14:21 --> Router Class Initialized
INFO - 2018-10-30 04:14:21 --> Output Class Initialized
INFO - 2018-10-30 04:14:21 --> Security Class Initialized
DEBUG - 2018-10-30 04:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:14:21 --> Input Class Initialized
INFO - 2018-10-30 04:14:21 --> Language Class Initialized
INFO - 2018-10-30 04:14:21 --> Loader Class Initialized
INFO - 2018-10-30 04:14:21 --> Helper loaded: url_helper
INFO - 2018-10-30 04:14:21 --> Database Driver Class Initialized
INFO - 2018-10-30 04:14:21 --> Helper loaded: form_helper
INFO - 2018-10-30 04:14:21 --> Form Validation Class Initialized
INFO - 2018-10-30 04:14:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:14:21 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:14:21 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:14:21 --> Email Class Initialized
INFO - 2018-10-30 04:14:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:14:21 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:14:21 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:14:21 --> Helper loaded: date_helper
INFO - 2018-10-30 04:14:21 --> Database Driver Class Initialized
INFO - 2018-10-30 04:14:21 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:14:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:14:21 --> Controller Class Initialized
INFO - 2018-10-30 04:14:21 --> Model "Item_model" initialized
INFO - 2018-10-30 04:14:21 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:14:21 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:14:21 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:14:21 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:14:21 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:14:21 --> Final output sent to browser
DEBUG - 2018-10-30 04:14:21 --> Total execution time: 0.4679
INFO - 2018-10-30 04:14:30 --> Config Class Initialized
INFO - 2018-10-30 04:14:30 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:14:30 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:14:30 --> Utf8 Class Initialized
INFO - 2018-10-30 04:14:30 --> URI Class Initialized
INFO - 2018-10-30 04:14:30 --> Router Class Initialized
INFO - 2018-10-30 04:14:30 --> Output Class Initialized
INFO - 2018-10-30 04:14:30 --> Security Class Initialized
DEBUG - 2018-10-30 04:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:14:30 --> Input Class Initialized
INFO - 2018-10-30 04:14:30 --> Language Class Initialized
INFO - 2018-10-30 04:14:30 --> Loader Class Initialized
INFO - 2018-10-30 04:14:30 --> Helper loaded: url_helper
INFO - 2018-10-30 04:14:30 --> Database Driver Class Initialized
INFO - 2018-10-30 04:14:30 --> Helper loaded: form_helper
INFO - 2018-10-30 04:14:30 --> Form Validation Class Initialized
INFO - 2018-10-30 04:14:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:14:30 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:14:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:14:30 --> Email Class Initialized
INFO - 2018-10-30 04:14:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:14:30 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:14:30 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:14:30 --> Helper loaded: date_helper
INFO - 2018-10-30 04:14:30 --> Database Driver Class Initialized
INFO - 2018-10-30 04:14:30 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:14:30 --> Controller Class Initialized
INFO - 2018-10-30 04:14:30 --> Model "Item_model" initialized
INFO - 2018-10-30 04:14:30 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:14:30 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:14:30 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:14:30 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:14:30 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:14:30 --> Final output sent to browser
DEBUG - 2018-10-30 04:14:30 --> Total execution time: 0.4367
INFO - 2018-10-30 04:14:30 --> Config Class Initialized
INFO - 2018-10-30 04:14:30 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:14:30 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:14:30 --> Utf8 Class Initialized
INFO - 2018-10-30 04:14:30 --> URI Class Initialized
INFO - 2018-10-30 04:14:30 --> Router Class Initialized
INFO - 2018-10-30 04:14:30 --> Output Class Initialized
INFO - 2018-10-30 04:14:30 --> Security Class Initialized
DEBUG - 2018-10-30 04:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:14:30 --> Input Class Initialized
INFO - 2018-10-30 04:14:30 --> Language Class Initialized
ERROR - 2018-10-30 04:14:30 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:14:32 --> Config Class Initialized
INFO - 2018-10-30 04:14:32 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:14:32 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:14:32 --> Utf8 Class Initialized
INFO - 2018-10-30 04:14:32 --> URI Class Initialized
INFO - 2018-10-30 04:14:32 --> Router Class Initialized
INFO - 2018-10-30 04:14:32 --> Output Class Initialized
INFO - 2018-10-30 04:14:32 --> Security Class Initialized
DEBUG - 2018-10-30 04:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:14:32 --> Input Class Initialized
INFO - 2018-10-30 04:14:32 --> Language Class Initialized
INFO - 2018-10-30 04:14:32 --> Loader Class Initialized
INFO - 2018-10-30 04:14:32 --> Helper loaded: url_helper
INFO - 2018-10-30 04:14:32 --> Database Driver Class Initialized
INFO - 2018-10-30 04:14:32 --> Helper loaded: form_helper
INFO - 2018-10-30 04:14:32 --> Form Validation Class Initialized
INFO - 2018-10-30 04:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:14:32 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:14:32 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:14:32 --> Email Class Initialized
INFO - 2018-10-30 04:14:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:14:32 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:14:32 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:14:32 --> Helper loaded: date_helper
INFO - 2018-10-30 04:14:32 --> Database Driver Class Initialized
INFO - 2018-10-30 04:14:32 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:14:32 --> Controller Class Initialized
INFO - 2018-10-30 04:14:32 --> Model "Item_model" initialized
INFO - 2018-10-30 04:14:32 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:14:32 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:14:32 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:14:32 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:14:32 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-30 04:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\controllers\Item.php 167
INFO - 2018-10-30 04:14:32 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:14:32 --> Final output sent to browser
DEBUG - 2018-10-30 04:14:32 --> Total execution time: 0.4648
INFO - 2018-10-30 04:14:32 --> Config Class Initialized
INFO - 2018-10-30 04:14:32 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:14:33 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:14:33 --> Utf8 Class Initialized
INFO - 2018-10-30 04:14:33 --> URI Class Initialized
INFO - 2018-10-30 04:14:33 --> Router Class Initialized
INFO - 2018-10-30 04:14:33 --> Output Class Initialized
INFO - 2018-10-30 04:14:33 --> Security Class Initialized
DEBUG - 2018-10-30 04:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:14:33 --> Input Class Initialized
INFO - 2018-10-30 04:14:33 --> Language Class Initialized
ERROR - 2018-10-30 04:14:33 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:14:33 --> Config Class Initialized
INFO - 2018-10-30 04:14:33 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:14:33 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:14:33 --> Utf8 Class Initialized
INFO - 2018-10-30 04:14:33 --> URI Class Initialized
INFO - 2018-10-30 04:14:33 --> Router Class Initialized
INFO - 2018-10-30 04:14:33 --> Output Class Initialized
INFO - 2018-10-30 04:14:33 --> Security Class Initialized
DEBUG - 2018-10-30 04:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:14:33 --> Input Class Initialized
INFO - 2018-10-30 04:14:33 --> Language Class Initialized
ERROR - 2018-10-30 04:14:33 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:15:09 --> Config Class Initialized
INFO - 2018-10-30 04:15:09 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:15:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:15:09 --> Utf8 Class Initialized
INFO - 2018-10-30 04:15:09 --> URI Class Initialized
INFO - 2018-10-30 04:15:09 --> Router Class Initialized
INFO - 2018-10-30 04:15:09 --> Output Class Initialized
INFO - 2018-10-30 04:15:09 --> Security Class Initialized
DEBUG - 2018-10-30 04:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:15:09 --> Input Class Initialized
INFO - 2018-10-30 04:15:09 --> Language Class Initialized
INFO - 2018-10-30 04:15:09 --> Loader Class Initialized
INFO - 2018-10-30 04:15:09 --> Helper loaded: url_helper
INFO - 2018-10-30 04:15:09 --> Database Driver Class Initialized
INFO - 2018-10-30 04:15:09 --> Helper loaded: form_helper
INFO - 2018-10-30 04:15:09 --> Form Validation Class Initialized
INFO - 2018-10-30 04:15:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:15:09 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:15:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:15:09 --> Email Class Initialized
INFO - 2018-10-30 04:15:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:15:09 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:15:09 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:15:09 --> Helper loaded: date_helper
INFO - 2018-10-30 04:15:09 --> Database Driver Class Initialized
INFO - 2018-10-30 04:15:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:15:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:15:09 --> Controller Class Initialized
INFO - 2018-10-30 04:15:09 --> Model "Item_model" initialized
INFO - 2018-10-30 04:15:09 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:15:09 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:15:09 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:15:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:15:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:15:10 --> Final output sent to browser
DEBUG - 2018-10-30 04:15:10 --> Total execution time: 0.4553
INFO - 2018-10-30 04:15:13 --> Config Class Initialized
INFO - 2018-10-30 04:15:13 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:15:13 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:15:13 --> Utf8 Class Initialized
INFO - 2018-10-30 04:15:13 --> URI Class Initialized
INFO - 2018-10-30 04:15:13 --> Router Class Initialized
INFO - 2018-10-30 04:15:13 --> Output Class Initialized
INFO - 2018-10-30 04:15:13 --> Security Class Initialized
DEBUG - 2018-10-30 04:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:15:13 --> Input Class Initialized
INFO - 2018-10-30 04:15:13 --> Language Class Initialized
INFO - 2018-10-30 04:15:13 --> Loader Class Initialized
INFO - 2018-10-30 04:15:13 --> Helper loaded: url_helper
INFO - 2018-10-30 04:15:13 --> Database Driver Class Initialized
INFO - 2018-10-30 04:15:14 --> Helper loaded: form_helper
INFO - 2018-10-30 04:15:14 --> Form Validation Class Initialized
INFO - 2018-10-30 04:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:15:14 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:15:14 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:15:14 --> Email Class Initialized
INFO - 2018-10-30 04:15:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:15:14 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:15:14 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:15:14 --> Helper loaded: date_helper
INFO - 2018-10-30 04:15:14 --> Database Driver Class Initialized
INFO - 2018-10-30 04:15:14 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:15:14 --> Controller Class Initialized
INFO - 2018-10-30 04:15:14 --> Model "Item_model" initialized
INFO - 2018-10-30 04:15:14 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:15:14 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:15:14 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:15:14 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:15:14 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:15:14 --> Final output sent to browser
DEBUG - 2018-10-30 04:15:14 --> Total execution time: 0.4787
INFO - 2018-10-30 04:15:14 --> Config Class Initialized
INFO - 2018-10-30 04:15:14 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:15:14 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:15:14 --> Utf8 Class Initialized
INFO - 2018-10-30 04:15:14 --> URI Class Initialized
INFO - 2018-10-30 04:15:14 --> Router Class Initialized
INFO - 2018-10-30 04:15:14 --> Output Class Initialized
INFO - 2018-10-30 04:15:14 --> Security Class Initialized
DEBUG - 2018-10-30 04:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:15:14 --> Input Class Initialized
INFO - 2018-10-30 04:15:14 --> Language Class Initialized
ERROR - 2018-10-30 04:15:14 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:15:15 --> Config Class Initialized
INFO - 2018-10-30 04:15:15 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:15:15 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:15:15 --> Utf8 Class Initialized
INFO - 2018-10-30 04:15:15 --> URI Class Initialized
INFO - 2018-10-30 04:15:15 --> Router Class Initialized
INFO - 2018-10-30 04:15:15 --> Output Class Initialized
INFO - 2018-10-30 04:15:15 --> Security Class Initialized
DEBUG - 2018-10-30 04:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:15:15 --> Input Class Initialized
INFO - 2018-10-30 04:15:16 --> Language Class Initialized
INFO - 2018-10-30 04:15:16 --> Loader Class Initialized
INFO - 2018-10-30 04:15:16 --> Helper loaded: url_helper
INFO - 2018-10-30 04:15:16 --> Database Driver Class Initialized
INFO - 2018-10-30 04:15:16 --> Helper loaded: form_helper
INFO - 2018-10-30 04:15:16 --> Form Validation Class Initialized
INFO - 2018-10-30 04:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:15:16 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:15:16 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:15:16 --> Email Class Initialized
INFO - 2018-10-30 04:15:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:15:16 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:15:16 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:15:16 --> Helper loaded: date_helper
INFO - 2018-10-30 04:15:16 --> Database Driver Class Initialized
INFO - 2018-10-30 04:15:16 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:15:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:15:16 --> Controller Class Initialized
INFO - 2018-10-30 04:15:16 --> Model "Item_model" initialized
INFO - 2018-10-30 04:15:16 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:15:16 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:15:16 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:15:16 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:15:16 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-30 04:15:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\controllers\Item.php 167
INFO - 2018-10-30 04:15:16 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:15:16 --> Final output sent to browser
DEBUG - 2018-10-30 04:15:16 --> Total execution time: 0.5110
INFO - 2018-10-30 04:15:16 --> Config Class Initialized
INFO - 2018-10-30 04:15:16 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:15:16 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:15:16 --> Utf8 Class Initialized
INFO - 2018-10-30 04:15:16 --> URI Class Initialized
INFO - 2018-10-30 04:15:16 --> Router Class Initialized
INFO - 2018-10-30 04:15:16 --> Output Class Initialized
INFO - 2018-10-30 04:15:16 --> Security Class Initialized
DEBUG - 2018-10-30 04:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:15:16 --> Input Class Initialized
INFO - 2018-10-30 04:15:16 --> Language Class Initialized
ERROR - 2018-10-30 04:15:16 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:15:16 --> Config Class Initialized
INFO - 2018-10-30 04:15:16 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:15:16 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:15:16 --> Utf8 Class Initialized
INFO - 2018-10-30 04:15:16 --> URI Class Initialized
INFO - 2018-10-30 04:15:16 --> Router Class Initialized
INFO - 2018-10-30 04:15:16 --> Output Class Initialized
INFO - 2018-10-30 04:15:16 --> Security Class Initialized
DEBUG - 2018-10-30 04:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:15:16 --> Input Class Initialized
INFO - 2018-10-30 04:15:16 --> Language Class Initialized
ERROR - 2018-10-30 04:15:16 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:16:38 --> Config Class Initialized
INFO - 2018-10-30 04:16:38 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:16:38 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:16:38 --> Utf8 Class Initialized
INFO - 2018-10-30 04:16:38 --> URI Class Initialized
INFO - 2018-10-30 04:16:38 --> Router Class Initialized
INFO - 2018-10-30 04:16:38 --> Output Class Initialized
INFO - 2018-10-30 04:16:38 --> Security Class Initialized
DEBUG - 2018-10-30 04:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:16:38 --> Input Class Initialized
INFO - 2018-10-30 04:16:38 --> Language Class Initialized
INFO - 2018-10-30 04:16:38 --> Loader Class Initialized
INFO - 2018-10-30 04:16:38 --> Helper loaded: url_helper
INFO - 2018-10-30 04:16:38 --> Database Driver Class Initialized
INFO - 2018-10-30 04:16:38 --> Helper loaded: form_helper
INFO - 2018-10-30 04:16:38 --> Form Validation Class Initialized
INFO - 2018-10-30 04:16:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:16:38 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:16:38 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:16:38 --> Email Class Initialized
INFO - 2018-10-30 04:16:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:16:38 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:16:38 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:16:38 --> Helper loaded: date_helper
INFO - 2018-10-30 04:16:38 --> Database Driver Class Initialized
INFO - 2018-10-30 04:16:38 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:16:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:16:38 --> Controller Class Initialized
INFO - 2018-10-30 04:16:38 --> Model "Item_model" initialized
INFO - 2018-10-30 04:16:38 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:16:38 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:16:38 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:16:38 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:16:38 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:16:38 --> Final output sent to browser
DEBUG - 2018-10-30 04:16:38 --> Total execution time: 0.4583
INFO - 2018-10-30 04:16:43 --> Config Class Initialized
INFO - 2018-10-30 04:16:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:16:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:16:43 --> Utf8 Class Initialized
INFO - 2018-10-30 04:16:43 --> URI Class Initialized
INFO - 2018-10-30 04:16:43 --> Router Class Initialized
INFO - 2018-10-30 04:16:43 --> Output Class Initialized
INFO - 2018-10-30 04:16:43 --> Security Class Initialized
DEBUG - 2018-10-30 04:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:16:43 --> Input Class Initialized
INFO - 2018-10-30 04:16:43 --> Language Class Initialized
INFO - 2018-10-30 04:16:43 --> Loader Class Initialized
INFO - 2018-10-30 04:16:43 --> Helper loaded: url_helper
INFO - 2018-10-30 04:16:43 --> Database Driver Class Initialized
INFO - 2018-10-30 04:16:43 --> Helper loaded: form_helper
INFO - 2018-10-30 04:16:43 --> Form Validation Class Initialized
INFO - 2018-10-30 04:16:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:16:43 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:16:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:16:43 --> Email Class Initialized
INFO - 2018-10-30 04:16:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:16:43 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:16:43 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:16:43 --> Helper loaded: date_helper
INFO - 2018-10-30 04:16:43 --> Database Driver Class Initialized
INFO - 2018-10-30 04:16:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:16:43 --> Controller Class Initialized
INFO - 2018-10-30 04:16:43 --> Model "Item_model" initialized
INFO - 2018-10-30 04:16:43 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:16:43 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:16:43 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:16:43 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:16:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:16:43 --> Final output sent to browser
DEBUG - 2018-10-30 04:16:43 --> Total execution time: 0.4622
INFO - 2018-10-30 04:16:43 --> Config Class Initialized
INFO - 2018-10-30 04:16:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:16:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:16:43 --> Utf8 Class Initialized
INFO - 2018-10-30 04:16:43 --> URI Class Initialized
INFO - 2018-10-30 04:16:43 --> Router Class Initialized
INFO - 2018-10-30 04:16:43 --> Output Class Initialized
INFO - 2018-10-30 04:16:43 --> Security Class Initialized
DEBUG - 2018-10-30 04:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:16:43 --> Input Class Initialized
INFO - 2018-10-30 04:16:43 --> Language Class Initialized
ERROR - 2018-10-30 04:16:43 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:16:45 --> Config Class Initialized
INFO - 2018-10-30 04:16:45 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:16:45 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:16:45 --> Utf8 Class Initialized
INFO - 2018-10-30 04:16:45 --> URI Class Initialized
INFO - 2018-10-30 04:16:45 --> Router Class Initialized
INFO - 2018-10-30 04:16:45 --> Output Class Initialized
INFO - 2018-10-30 04:16:45 --> Security Class Initialized
DEBUG - 2018-10-30 04:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:16:45 --> Input Class Initialized
INFO - 2018-10-30 04:16:45 --> Language Class Initialized
INFO - 2018-10-30 04:16:45 --> Loader Class Initialized
INFO - 2018-10-30 04:16:45 --> Helper loaded: url_helper
INFO - 2018-10-30 04:16:45 --> Database Driver Class Initialized
INFO - 2018-10-30 04:16:45 --> Helper loaded: form_helper
INFO - 2018-10-30 04:16:45 --> Form Validation Class Initialized
INFO - 2018-10-30 04:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:16:45 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:16:45 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:16:45 --> Email Class Initialized
INFO - 2018-10-30 04:16:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:16:45 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:16:45 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:16:45 --> Helper loaded: date_helper
INFO - 2018-10-30 04:16:45 --> Database Driver Class Initialized
INFO - 2018-10-30 04:16:45 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:16:45 --> Controller Class Initialized
INFO - 2018-10-30 04:16:45 --> Model "Item_model" initialized
INFO - 2018-10-30 04:16:45 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:16:45 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:16:45 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:16:45 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:16:45 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: userid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 64
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 65
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: typepaket D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 70
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 71
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: namavendor D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 72
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: nama D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 73
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: lokasi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 74
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: deskripsi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 75
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: starttime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 76
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: endtime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 77
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: quota D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 80
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: foto D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 81
ERROR - 2018-10-30 04:16:45 --> Severity: Notice --> Undefined index: harga D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 82
INFO - 2018-10-30 04:16:45 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:16:45 --> Final output sent to browser
DEBUG - 2018-10-30 04:16:45 --> Total execution time: 0.6159
INFO - 2018-10-30 04:16:45 --> Config Class Initialized
INFO - 2018-10-30 04:16:45 --> Config Class Initialized
INFO - 2018-10-30 04:16:45 --> Hooks Class Initialized
INFO - 2018-10-30 04:16:45 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:16:45 --> UTF-8 Support Enabled
DEBUG - 2018-10-30 04:16:45 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:16:45 --> Utf8 Class Initialized
INFO - 2018-10-30 04:16:45 --> Utf8 Class Initialized
INFO - 2018-10-30 04:16:45 --> URI Class Initialized
INFO - 2018-10-30 04:16:45 --> Router Class Initialized
INFO - 2018-10-30 04:16:45 --> Output Class Initialized
INFO - 2018-10-30 04:16:45 --> Security Class Initialized
DEBUG - 2018-10-30 04:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:16:45 --> Input Class Initialized
INFO - 2018-10-30 04:16:45 --> Language Class Initialized
ERROR - 2018-10-30 04:16:45 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:16:45 --> Config Class Initialized
INFO - 2018-10-30 04:16:45 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:16:45 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:16:45 --> Utf8 Class Initialized
INFO - 2018-10-30 04:16:45 --> URI Class Initialized
INFO - 2018-10-30 04:16:45 --> Router Class Initialized
INFO - 2018-10-30 04:16:45 --> Output Class Initialized
INFO - 2018-10-30 04:16:45 --> Security Class Initialized
DEBUG - 2018-10-30 04:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:16:45 --> Input Class Initialized
INFO - 2018-10-30 04:16:45 --> Language Class Initialized
ERROR - 2018-10-30 04:16:46 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:17:24 --> Config Class Initialized
INFO - 2018-10-30 04:17:24 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:17:24 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:17:24 --> Utf8 Class Initialized
INFO - 2018-10-30 04:17:24 --> URI Class Initialized
INFO - 2018-10-30 04:17:24 --> Router Class Initialized
INFO - 2018-10-30 04:17:24 --> Output Class Initialized
INFO - 2018-10-30 04:17:24 --> Security Class Initialized
DEBUG - 2018-10-30 04:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:17:24 --> Input Class Initialized
INFO - 2018-10-30 04:17:24 --> Language Class Initialized
INFO - 2018-10-30 04:17:24 --> Loader Class Initialized
INFO - 2018-10-30 04:17:24 --> Helper loaded: url_helper
INFO - 2018-10-30 04:17:24 --> Database Driver Class Initialized
INFO - 2018-10-30 04:17:24 --> Helper loaded: form_helper
INFO - 2018-10-30 04:17:24 --> Form Validation Class Initialized
INFO - 2018-10-30 04:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:17:24 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:17:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:17:24 --> Email Class Initialized
INFO - 2018-10-30 04:17:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:17:24 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:17:24 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:17:24 --> Helper loaded: date_helper
INFO - 2018-10-30 04:17:24 --> Database Driver Class Initialized
INFO - 2018-10-30 04:17:24 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:17:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:17:24 --> Controller Class Initialized
INFO - 2018-10-30 04:17:24 --> Model "Item_model" initialized
INFO - 2018-10-30 04:17:24 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:17:24 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:17:24 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:17:24 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:17:24 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:17:24 --> Final output sent to browser
DEBUG - 2018-10-30 04:17:24 --> Total execution time: 0.4867
INFO - 2018-10-30 04:17:28 --> Config Class Initialized
INFO - 2018-10-30 04:17:28 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:17:28 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:17:28 --> Utf8 Class Initialized
INFO - 2018-10-30 04:17:28 --> URI Class Initialized
INFO - 2018-10-30 04:17:28 --> Router Class Initialized
INFO - 2018-10-30 04:17:28 --> Output Class Initialized
INFO - 2018-10-30 04:17:28 --> Security Class Initialized
DEBUG - 2018-10-30 04:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:17:28 --> Input Class Initialized
INFO - 2018-10-30 04:17:28 --> Language Class Initialized
INFO - 2018-10-30 04:17:29 --> Loader Class Initialized
INFO - 2018-10-30 04:17:29 --> Helper loaded: url_helper
INFO - 2018-10-30 04:17:29 --> Database Driver Class Initialized
INFO - 2018-10-30 04:17:29 --> Helper loaded: form_helper
INFO - 2018-10-30 04:17:29 --> Form Validation Class Initialized
INFO - 2018-10-30 04:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:17:29 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:17:29 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:17:29 --> Email Class Initialized
INFO - 2018-10-30 04:17:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:17:29 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:17:29 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:17:29 --> Helper loaded: date_helper
INFO - 2018-10-30 04:17:29 --> Database Driver Class Initialized
INFO - 2018-10-30 04:17:29 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:17:29 --> Controller Class Initialized
INFO - 2018-10-30 04:17:29 --> Model "Item_model" initialized
INFO - 2018-10-30 04:17:29 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:17:29 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:17:29 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:17:29 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:17:29 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:17:29 --> Final output sent to browser
DEBUG - 2018-10-30 04:17:29 --> Total execution time: 0.4903
INFO - 2018-10-30 04:17:29 --> Config Class Initialized
INFO - 2018-10-30 04:17:29 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:17:29 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:17:29 --> Utf8 Class Initialized
INFO - 2018-10-30 04:17:29 --> URI Class Initialized
INFO - 2018-10-30 04:17:29 --> Router Class Initialized
INFO - 2018-10-30 04:17:29 --> Output Class Initialized
INFO - 2018-10-30 04:17:29 --> Security Class Initialized
DEBUG - 2018-10-30 04:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:17:29 --> Input Class Initialized
INFO - 2018-10-30 04:17:29 --> Language Class Initialized
ERROR - 2018-10-30 04:17:29 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:17:30 --> Config Class Initialized
INFO - 2018-10-30 04:17:30 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:17:30 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:17:30 --> Utf8 Class Initialized
INFO - 2018-10-30 04:17:30 --> URI Class Initialized
INFO - 2018-10-30 04:17:30 --> Router Class Initialized
INFO - 2018-10-30 04:17:30 --> Output Class Initialized
INFO - 2018-10-30 04:17:30 --> Security Class Initialized
DEBUG - 2018-10-30 04:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:17:30 --> Input Class Initialized
INFO - 2018-10-30 04:17:30 --> Language Class Initialized
INFO - 2018-10-30 04:17:30 --> Loader Class Initialized
INFO - 2018-10-30 04:17:30 --> Helper loaded: url_helper
INFO - 2018-10-30 04:17:30 --> Database Driver Class Initialized
INFO - 2018-10-30 04:17:30 --> Helper loaded: form_helper
INFO - 2018-10-30 04:17:30 --> Form Validation Class Initialized
INFO - 2018-10-30 04:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:17:30 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:17:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:17:31 --> Email Class Initialized
INFO - 2018-10-30 04:17:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:17:31 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:17:31 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:17:31 --> Helper loaded: date_helper
INFO - 2018-10-30 04:17:31 --> Database Driver Class Initialized
INFO - 2018-10-30 04:17:31 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:17:31 --> Controller Class Initialized
INFO - 2018-10-30 04:17:31 --> Model "Item_model" initialized
INFO - 2018-10-30 04:17:31 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:17:31 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:17:31 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:17:31 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:17:31 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: userid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 64
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 65
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: typepaket D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 70
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: vendorid D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 71
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: namavendor D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 72
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: nama D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 73
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: lokasi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 74
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: deskripsi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 75
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: starttime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 76
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: endtime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 77
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: quota D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 80
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: foto D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 81
ERROR - 2018-10-30 04:17:31 --> Severity: Notice --> Undefined index: harga D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 82
INFO - 2018-10-30 04:17:31 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:17:31 --> Final output sent to browser
DEBUG - 2018-10-30 04:17:31 --> Total execution time: 0.6551
INFO - 2018-10-30 04:17:31 --> Config Class Initialized
INFO - 2018-10-30 04:17:31 --> Config Class Initialized
INFO - 2018-10-30 04:17:31 --> Hooks Class Initialized
INFO - 2018-10-30 04:17:31 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:17:31 --> UTF-8 Support Enabled
DEBUG - 2018-10-30 04:17:31 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:17:31 --> Utf8 Class Initialized
INFO - 2018-10-30 04:17:31 --> Utf8 Class Initialized
INFO - 2018-10-30 04:17:31 --> URI Class Initialized
INFO - 2018-10-30 04:17:31 --> Router Class Initialized
INFO - 2018-10-30 04:17:31 --> Output Class Initialized
INFO - 2018-10-30 04:17:31 --> Security Class Initialized
DEBUG - 2018-10-30 04:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:17:31 --> Input Class Initialized
INFO - 2018-10-30 04:17:31 --> Language Class Initialized
ERROR - 2018-10-30 04:17:31 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:17:31 --> Config Class Initialized
INFO - 2018-10-30 04:17:31 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:17:31 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:17:31 --> Utf8 Class Initialized
INFO - 2018-10-30 04:17:31 --> URI Class Initialized
INFO - 2018-10-30 04:17:31 --> Router Class Initialized
INFO - 2018-10-30 04:17:31 --> Output Class Initialized
INFO - 2018-10-30 04:17:31 --> Security Class Initialized
DEBUG - 2018-10-30 04:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:17:31 --> Input Class Initialized
INFO - 2018-10-30 04:17:31 --> Language Class Initialized
ERROR - 2018-10-30 04:17:31 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:19:00 --> Config Class Initialized
INFO - 2018-10-30 04:19:00 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:19:00 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:19:00 --> Utf8 Class Initialized
INFO - 2018-10-30 04:19:00 --> URI Class Initialized
INFO - 2018-10-30 04:19:00 --> Router Class Initialized
INFO - 2018-10-30 04:19:00 --> Output Class Initialized
INFO - 2018-10-30 04:19:00 --> Security Class Initialized
DEBUG - 2018-10-30 04:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:19:00 --> Input Class Initialized
INFO - 2018-10-30 04:19:00 --> Language Class Initialized
INFO - 2018-10-30 04:19:00 --> Loader Class Initialized
INFO - 2018-10-30 04:19:00 --> Helper loaded: url_helper
INFO - 2018-10-30 04:19:00 --> Database Driver Class Initialized
INFO - 2018-10-30 04:19:00 --> Helper loaded: form_helper
INFO - 2018-10-30 04:19:00 --> Form Validation Class Initialized
INFO - 2018-10-30 04:19:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:19:00 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:19:01 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:19:01 --> Email Class Initialized
INFO - 2018-10-30 04:19:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:19:01 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:19:01 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:19:01 --> Helper loaded: date_helper
INFO - 2018-10-30 04:19:01 --> Database Driver Class Initialized
INFO - 2018-10-30 04:19:01 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:19:01 --> Controller Class Initialized
INFO - 2018-10-30 04:19:01 --> Model "Item_model" initialized
INFO - 2018-10-30 04:19:01 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:19:01 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:19:01 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:19:01 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:19:01 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:19:01 --> Final output sent to browser
DEBUG - 2018-10-30 04:19:01 --> Total execution time: 0.4746
INFO - 2018-10-30 04:19:04 --> Config Class Initialized
INFO - 2018-10-30 04:19:04 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:19:04 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:19:04 --> Utf8 Class Initialized
INFO - 2018-10-30 04:19:04 --> URI Class Initialized
INFO - 2018-10-30 04:19:04 --> Router Class Initialized
INFO - 2018-10-30 04:19:04 --> Output Class Initialized
INFO - 2018-10-30 04:19:04 --> Security Class Initialized
DEBUG - 2018-10-30 04:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:19:04 --> Input Class Initialized
INFO - 2018-10-30 04:19:04 --> Language Class Initialized
INFO - 2018-10-30 04:19:04 --> Loader Class Initialized
INFO - 2018-10-30 04:19:04 --> Helper loaded: url_helper
INFO - 2018-10-30 04:19:04 --> Database Driver Class Initialized
INFO - 2018-10-30 04:19:04 --> Helper loaded: form_helper
INFO - 2018-10-30 04:19:04 --> Form Validation Class Initialized
INFO - 2018-10-30 04:19:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:19:04 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:19:04 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:19:04 --> Email Class Initialized
INFO - 2018-10-30 04:19:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:19:04 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:19:04 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:19:04 --> Helper loaded: date_helper
INFO - 2018-10-30 04:19:04 --> Database Driver Class Initialized
INFO - 2018-10-30 04:19:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:19:04 --> Controller Class Initialized
INFO - 2018-10-30 04:19:04 --> Model "Item_model" initialized
INFO - 2018-10-30 04:19:04 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:19:04 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:19:04 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:19:04 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:19:04 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:19:04 --> Final output sent to browser
INFO - 2018-10-30 04:19:04 --> Config Class Initialized
INFO - 2018-10-30 04:19:04 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:19:04 --> Total execution time: 0.4892
DEBUG - 2018-10-30 04:19:05 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:19:05 --> Utf8 Class Initialized
INFO - 2018-10-30 04:19:05 --> URI Class Initialized
INFO - 2018-10-30 04:19:05 --> Router Class Initialized
INFO - 2018-10-30 04:19:05 --> Output Class Initialized
INFO - 2018-10-30 04:19:05 --> Security Class Initialized
DEBUG - 2018-10-30 04:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:19:05 --> Input Class Initialized
INFO - 2018-10-30 04:19:05 --> Language Class Initialized
ERROR - 2018-10-30 04:19:05 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:19:06 --> Config Class Initialized
INFO - 2018-10-30 04:19:06 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:19:06 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:19:06 --> Utf8 Class Initialized
INFO - 2018-10-30 04:19:07 --> URI Class Initialized
INFO - 2018-10-30 04:19:07 --> Router Class Initialized
INFO - 2018-10-30 04:19:07 --> Output Class Initialized
INFO - 2018-10-30 04:19:07 --> Security Class Initialized
DEBUG - 2018-10-30 04:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:19:07 --> Input Class Initialized
INFO - 2018-10-30 04:19:07 --> Language Class Initialized
INFO - 2018-10-30 04:19:07 --> Loader Class Initialized
INFO - 2018-10-30 04:19:07 --> Helper loaded: url_helper
INFO - 2018-10-30 04:19:07 --> Database Driver Class Initialized
INFO - 2018-10-30 04:19:07 --> Helper loaded: form_helper
INFO - 2018-10-30 04:19:07 --> Form Validation Class Initialized
INFO - 2018-10-30 04:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:19:07 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:19:07 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:19:07 --> Email Class Initialized
INFO - 2018-10-30 04:19:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:19:07 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:19:07 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:19:07 --> Helper loaded: date_helper
INFO - 2018-10-30 04:19:07 --> Database Driver Class Initialized
INFO - 2018-10-30 04:19:07 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:19:07 --> Controller Class Initialized
INFO - 2018-10-30 04:19:07 --> Model "Item_model" initialized
INFO - 2018-10-30 04:19:07 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:19:07 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:19:07 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:19:07 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:19:07 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
ERROR - 2018-10-30 04:19:07 --> Severity: Notice --> Undefined index: harga D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 54
ERROR - 2018-10-30 04:19:07 --> Severity: Notice --> Undefined index: typepaket D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 70
ERROR - 2018-10-30 04:19:07 --> Severity: Notice --> Undefined index: namavendor D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 72
ERROR - 2018-10-30 04:19:07 --> Severity: Notice --> Undefined index: nama D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 73
ERROR - 2018-10-30 04:19:07 --> Severity: Notice --> Undefined index: lokasi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 74
ERROR - 2018-10-30 04:19:07 --> Severity: Notice --> Undefined index: deskripsi D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 75
ERROR - 2018-10-30 04:19:07 --> Severity: Notice --> Undefined index: starttime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 76
ERROR - 2018-10-30 04:19:07 --> Severity: Notice --> Undefined index: endtime D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 77
ERROR - 2018-10-30 04:19:07 --> Severity: Notice --> Undefined index: quota D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 80
ERROR - 2018-10-30 04:19:07 --> Severity: Notice --> Undefined index: foto D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 81
ERROR - 2018-10-30 04:19:07 --> Severity: Notice --> Undefined index: harga D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 82
INFO - 2018-10-30 04:19:07 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:19:07 --> Final output sent to browser
DEBUG - 2018-10-30 04:19:07 --> Total execution time: 0.6103
INFO - 2018-10-30 04:19:07 --> Config Class Initialized
INFO - 2018-10-30 04:19:07 --> Config Class Initialized
INFO - 2018-10-30 04:19:07 --> Hooks Class Initialized
INFO - 2018-10-30 04:19:07 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:19:07 --> UTF-8 Support Enabled
DEBUG - 2018-10-30 04:19:07 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:19:07 --> Utf8 Class Initialized
INFO - 2018-10-30 04:19:07 --> Utf8 Class Initialized
INFO - 2018-10-30 04:19:07 --> URI Class Initialized
INFO - 2018-10-30 04:19:07 --> Router Class Initialized
INFO - 2018-10-30 04:19:07 --> Output Class Initialized
INFO - 2018-10-30 04:19:07 --> Security Class Initialized
DEBUG - 2018-10-30 04:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:19:07 --> Input Class Initialized
INFO - 2018-10-30 04:19:07 --> Language Class Initialized
ERROR - 2018-10-30 04:19:07 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:19:07 --> Config Class Initialized
INFO - 2018-10-30 04:19:07 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:19:07 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:19:07 --> Utf8 Class Initialized
INFO - 2018-10-30 04:19:07 --> URI Class Initialized
INFO - 2018-10-30 04:19:07 --> Router Class Initialized
INFO - 2018-10-30 04:19:07 --> Output Class Initialized
INFO - 2018-10-30 04:19:07 --> Security Class Initialized
DEBUG - 2018-10-30 04:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:19:07 --> Input Class Initialized
INFO - 2018-10-30 04:19:07 --> Language Class Initialized
ERROR - 2018-10-30 04:19:07 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:20:55 --> Config Class Initialized
INFO - 2018-10-30 04:20:55 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:20:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:20:55 --> Utf8 Class Initialized
INFO - 2018-10-30 04:20:55 --> URI Class Initialized
INFO - 2018-10-30 04:20:56 --> Router Class Initialized
INFO - 2018-10-30 04:20:56 --> Output Class Initialized
INFO - 2018-10-30 04:20:56 --> Security Class Initialized
DEBUG - 2018-10-30 04:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:20:56 --> Input Class Initialized
INFO - 2018-10-30 04:20:56 --> Language Class Initialized
INFO - 2018-10-30 04:20:56 --> Loader Class Initialized
INFO - 2018-10-30 04:20:56 --> Helper loaded: url_helper
INFO - 2018-10-30 04:20:56 --> Database Driver Class Initialized
INFO - 2018-10-30 04:20:56 --> Helper loaded: form_helper
INFO - 2018-10-30 04:20:56 --> Form Validation Class Initialized
INFO - 2018-10-30 04:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:20:56 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:20:56 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:20:56 --> Email Class Initialized
INFO - 2018-10-30 04:20:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:20:56 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:20:56 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:20:56 --> Helper loaded: date_helper
INFO - 2018-10-30 04:20:56 --> Database Driver Class Initialized
INFO - 2018-10-30 04:20:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:20:56 --> Controller Class Initialized
INFO - 2018-10-30 04:20:56 --> Model "Item_model" initialized
INFO - 2018-10-30 04:20:56 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:20:56 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:20:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:20:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:20:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:20:56 --> Final output sent to browser
DEBUG - 2018-10-30 04:20:56 --> Total execution time: 0.5149
INFO - 2018-10-30 04:21:00 --> Config Class Initialized
INFO - 2018-10-30 04:21:00 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:21:00 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:21:00 --> Utf8 Class Initialized
INFO - 2018-10-30 04:21:00 --> URI Class Initialized
INFO - 2018-10-30 04:21:00 --> Router Class Initialized
INFO - 2018-10-30 04:21:00 --> Output Class Initialized
INFO - 2018-10-30 04:21:00 --> Security Class Initialized
DEBUG - 2018-10-30 04:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:21:00 --> Input Class Initialized
INFO - 2018-10-30 04:21:00 --> Language Class Initialized
INFO - 2018-10-30 04:21:00 --> Loader Class Initialized
INFO - 2018-10-30 04:21:00 --> Helper loaded: url_helper
INFO - 2018-10-30 04:21:00 --> Database Driver Class Initialized
INFO - 2018-10-30 04:21:00 --> Helper loaded: form_helper
INFO - 2018-10-30 04:21:00 --> Form Validation Class Initialized
INFO - 2018-10-30 04:21:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:21:00 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:21:00 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:21:00 --> Email Class Initialized
INFO - 2018-10-30 04:21:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:21:00 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:21:01 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:21:01 --> Helper loaded: date_helper
INFO - 2018-10-30 04:21:01 --> Database Driver Class Initialized
INFO - 2018-10-30 04:21:01 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:21:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:21:01 --> Controller Class Initialized
INFO - 2018-10-30 04:21:01 --> Model "Item_model" initialized
INFO - 2018-10-30 04:21:01 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:21:01 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:21:01 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:21:01 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:21:01 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:21:01 --> Final output sent to browser
DEBUG - 2018-10-30 04:21:01 --> Total execution time: 0.4961
INFO - 2018-10-30 04:21:01 --> Config Class Initialized
INFO - 2018-10-30 04:21:01 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:21:01 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:21:01 --> Utf8 Class Initialized
INFO - 2018-10-30 04:21:01 --> URI Class Initialized
INFO - 2018-10-30 04:21:01 --> Router Class Initialized
INFO - 2018-10-30 04:21:01 --> Output Class Initialized
INFO - 2018-10-30 04:21:01 --> Security Class Initialized
DEBUG - 2018-10-30 04:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:21:01 --> Input Class Initialized
INFO - 2018-10-30 04:21:01 --> Language Class Initialized
ERROR - 2018-10-30 04:21:01 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:21:02 --> Config Class Initialized
INFO - 2018-10-30 04:21:02 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:21:02 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:21:02 --> Utf8 Class Initialized
INFO - 2018-10-30 04:21:02 --> URI Class Initialized
INFO - 2018-10-30 04:21:02 --> Router Class Initialized
INFO - 2018-10-30 04:21:02 --> Output Class Initialized
INFO - 2018-10-30 04:21:02 --> Security Class Initialized
DEBUG - 2018-10-30 04:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:21:02 --> Input Class Initialized
INFO - 2018-10-30 04:21:02 --> Language Class Initialized
INFO - 2018-10-30 04:21:02 --> Loader Class Initialized
INFO - 2018-10-30 04:21:02 --> Helper loaded: url_helper
INFO - 2018-10-30 04:21:02 --> Database Driver Class Initialized
INFO - 2018-10-30 04:21:02 --> Helper loaded: form_helper
INFO - 2018-10-30 04:21:02 --> Form Validation Class Initialized
INFO - 2018-10-30 04:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:21:02 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:21:02 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:21:02 --> Email Class Initialized
INFO - 2018-10-30 04:21:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:21:02 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:21:02 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:21:02 --> Helper loaded: date_helper
INFO - 2018-10-30 04:21:02 --> Database Driver Class Initialized
INFO - 2018-10-30 04:21:02 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:21:03 --> Controller Class Initialized
INFO - 2018-10-30 04:21:03 --> Model "Item_model" initialized
INFO - 2018-10-30 04:21:03 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:21:03 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:21:03 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:21:03 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:21:03 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 04:21:03 --> Final output sent to browser
DEBUG - 2018-10-30 04:21:03 --> Total execution time: 0.4668
INFO - 2018-10-30 04:21:03 --> Config Class Initialized
INFO - 2018-10-30 04:21:03 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:21:03 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:21:03 --> Utf8 Class Initialized
INFO - 2018-10-30 04:21:03 --> URI Class Initialized
INFO - 2018-10-30 04:21:03 --> Router Class Initialized
INFO - 2018-10-30 04:21:03 --> Output Class Initialized
INFO - 2018-10-30 04:21:03 --> Security Class Initialized
DEBUG - 2018-10-30 04:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:21:03 --> Input Class Initialized
INFO - 2018-10-30 04:21:03 --> Language Class Initialized
ERROR - 2018-10-30 04:21:03 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:21:06 --> Config Class Initialized
INFO - 2018-10-30 04:21:06 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:21:06 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:21:06 --> Utf8 Class Initialized
INFO - 2018-10-30 04:21:06 --> URI Class Initialized
INFO - 2018-10-30 04:21:06 --> Router Class Initialized
INFO - 2018-10-30 04:21:06 --> Output Class Initialized
INFO - 2018-10-30 04:21:06 --> Security Class Initialized
DEBUG - 2018-10-30 04:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:21:06 --> Input Class Initialized
INFO - 2018-10-30 04:21:06 --> Language Class Initialized
INFO - 2018-10-30 04:21:06 --> Loader Class Initialized
INFO - 2018-10-30 04:21:06 --> Helper loaded: url_helper
INFO - 2018-10-30 04:21:06 --> Database Driver Class Initialized
INFO - 2018-10-30 04:21:06 --> Helper loaded: form_helper
INFO - 2018-10-30 04:21:06 --> Form Validation Class Initialized
INFO - 2018-10-30 04:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:21:06 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:21:06 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:21:06 --> Email Class Initialized
INFO - 2018-10-30 04:21:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:21:06 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:21:06 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:21:06 --> Helper loaded: date_helper
INFO - 2018-10-30 04:21:06 --> Database Driver Class Initialized
INFO - 2018-10-30 04:21:06 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:21:06 --> Controller Class Initialized
INFO - 2018-10-30 04:21:06 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:21:06 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 04:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-30 04:21:06 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 04:21:06 --> Final output sent to browser
DEBUG - 2018-10-30 04:21:06 --> Total execution time: 0.5960
INFO - 2018-10-30 04:21:20 --> Config Class Initialized
INFO - 2018-10-30 04:21:20 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:21:20 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:21:20 --> Utf8 Class Initialized
INFO - 2018-10-30 04:21:20 --> URI Class Initialized
INFO - 2018-10-30 04:21:20 --> Router Class Initialized
INFO - 2018-10-30 04:21:20 --> Output Class Initialized
INFO - 2018-10-30 04:21:20 --> Security Class Initialized
DEBUG - 2018-10-30 04:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:21:20 --> Input Class Initialized
INFO - 2018-10-30 04:21:20 --> Language Class Initialized
INFO - 2018-10-30 04:21:20 --> Loader Class Initialized
INFO - 2018-10-30 04:21:20 --> Helper loaded: url_helper
INFO - 2018-10-30 04:21:20 --> Database Driver Class Initialized
INFO - 2018-10-30 04:21:20 --> Helper loaded: form_helper
INFO - 2018-10-30 04:21:20 --> Form Validation Class Initialized
INFO - 2018-10-30 04:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:21:20 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:21:21 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:21:21 --> Email Class Initialized
INFO - 2018-10-30 04:21:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:21:21 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:21:21 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:21:21 --> Helper loaded: date_helper
INFO - 2018-10-30 04:21:21 --> Database Driver Class Initialized
INFO - 2018-10-30 04:21:21 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:21:21 --> Controller Class Initialized
INFO - 2018-10-30 04:21:21 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:21:21 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:21:21 --> Model "Item_model" initialized
INFO - 2018-10-30 04:21:21 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\vendor/index.php
INFO - 2018-10-30 04:21:21 --> Final output sent to browser
DEBUG - 2018-10-30 04:21:21 --> Total execution time: 0.4839
INFO - 2018-10-30 04:21:23 --> Config Class Initialized
INFO - 2018-10-30 04:21:23 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:21:23 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:21:23 --> Utf8 Class Initialized
INFO - 2018-10-30 04:21:23 --> URI Class Initialized
INFO - 2018-10-30 04:21:23 --> Router Class Initialized
INFO - 2018-10-30 04:21:23 --> Output Class Initialized
INFO - 2018-10-30 04:21:23 --> Security Class Initialized
DEBUG - 2018-10-30 04:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:21:23 --> Input Class Initialized
INFO - 2018-10-30 04:21:23 --> Language Class Initialized
INFO - 2018-10-30 04:21:23 --> Loader Class Initialized
INFO - 2018-10-30 04:21:23 --> Helper loaded: url_helper
INFO - 2018-10-30 04:21:23 --> Database Driver Class Initialized
INFO - 2018-10-30 04:21:23 --> Helper loaded: form_helper
INFO - 2018-10-30 04:21:23 --> Form Validation Class Initialized
INFO - 2018-10-30 04:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:21:23 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:21:23 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:21:23 --> Email Class Initialized
INFO - 2018-10-30 04:21:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:21:23 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:21:23 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:21:23 --> Helper loaded: date_helper
INFO - 2018-10-30 04:21:23 --> Database Driver Class Initialized
INFO - 2018-10-30 04:21:23 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:21:23 --> Controller Class Initialized
INFO - 2018-10-30 04:21:23 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:21:23 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 04:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 04:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-30 04:21:23 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 04:21:23 --> Final output sent to browser
DEBUG - 2018-10-30 04:21:23 --> Total execution time: 0.6138
INFO - 2018-10-30 04:23:40 --> Config Class Initialized
INFO - 2018-10-30 04:23:40 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:23:40 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:23:40 --> Utf8 Class Initialized
INFO - 2018-10-30 04:23:40 --> URI Class Initialized
INFO - 2018-10-30 04:23:40 --> Router Class Initialized
INFO - 2018-10-30 04:23:40 --> Output Class Initialized
INFO - 2018-10-30 04:23:40 --> Security Class Initialized
DEBUG - 2018-10-30 04:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:23:40 --> Input Class Initialized
INFO - 2018-10-30 04:23:40 --> Language Class Initialized
INFO - 2018-10-30 04:23:40 --> Loader Class Initialized
INFO - 2018-10-30 04:23:40 --> Helper loaded: url_helper
INFO - 2018-10-30 04:23:40 --> Database Driver Class Initialized
INFO - 2018-10-30 04:23:40 --> Helper loaded: form_helper
INFO - 2018-10-30 04:23:40 --> Form Validation Class Initialized
INFO - 2018-10-30 04:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:23:40 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:23:40 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:23:40 --> Email Class Initialized
INFO - 2018-10-30 04:23:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:23:40 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:23:40 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:23:40 --> Helper loaded: date_helper
INFO - 2018-10-30 04:23:40 --> Database Driver Class Initialized
INFO - 2018-10-30 04:23:40 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:23:40 --> Controller Class Initialized
INFO - 2018-10-30 04:23:40 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:23:40 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:23:40 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 04:23:40 --> Final output sent to browser
DEBUG - 2018-10-30 04:23:40 --> Total execution time: 0.4465
INFO - 2018-10-30 04:23:53 --> Config Class Initialized
INFO - 2018-10-30 04:23:54 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:23:54 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:23:54 --> Utf8 Class Initialized
INFO - 2018-10-30 04:23:54 --> URI Class Initialized
INFO - 2018-10-30 04:23:54 --> Router Class Initialized
INFO - 2018-10-30 04:23:54 --> Output Class Initialized
INFO - 2018-10-30 04:23:54 --> Security Class Initialized
DEBUG - 2018-10-30 04:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:23:54 --> Input Class Initialized
INFO - 2018-10-30 04:23:54 --> Language Class Initialized
INFO - 2018-10-30 04:23:54 --> Loader Class Initialized
INFO - 2018-10-30 04:23:54 --> Helper loaded: url_helper
INFO - 2018-10-30 04:23:54 --> Database Driver Class Initialized
INFO - 2018-10-30 04:23:54 --> Helper loaded: form_helper
INFO - 2018-10-30 04:23:54 --> Form Validation Class Initialized
INFO - 2018-10-30 04:23:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:23:54 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:23:54 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:23:54 --> Email Class Initialized
INFO - 2018-10-30 04:23:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:23:54 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:23:54 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:23:54 --> Helper loaded: date_helper
INFO - 2018-10-30 04:23:54 --> Database Driver Class Initialized
INFO - 2018-10-30 04:23:54 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:23:54 --> Controller Class Initialized
INFO - 2018-10-30 04:23:54 --> Model "Item_model" initialized
INFO - 2018-10-30 04:23:54 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:23:54 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:23:54 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:23:54 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:23:54 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:23:54 --> Final output sent to browser
DEBUG - 2018-10-30 04:23:54 --> Total execution time: 0.5117
INFO - 2018-10-30 04:23:58 --> Config Class Initialized
INFO - 2018-10-30 04:23:58 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:23:58 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:23:58 --> Utf8 Class Initialized
INFO - 2018-10-30 04:23:58 --> URI Class Initialized
INFO - 2018-10-30 04:23:58 --> Router Class Initialized
INFO - 2018-10-30 04:23:59 --> Output Class Initialized
INFO - 2018-10-30 04:23:59 --> Security Class Initialized
DEBUG - 2018-10-30 04:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:23:59 --> Input Class Initialized
INFO - 2018-10-30 04:23:59 --> Language Class Initialized
INFO - 2018-10-30 04:23:59 --> Loader Class Initialized
INFO - 2018-10-30 04:23:59 --> Helper loaded: url_helper
INFO - 2018-10-30 04:23:59 --> Database Driver Class Initialized
INFO - 2018-10-30 04:23:59 --> Helper loaded: form_helper
INFO - 2018-10-30 04:23:59 --> Form Validation Class Initialized
INFO - 2018-10-30 04:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:23:59 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:23:59 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:23:59 --> Email Class Initialized
INFO - 2018-10-30 04:23:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:23:59 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:23:59 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:23:59 --> Helper loaded: date_helper
INFO - 2018-10-30 04:23:59 --> Database Driver Class Initialized
INFO - 2018-10-30 04:23:59 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:23:59 --> Controller Class Initialized
INFO - 2018-10-30 04:23:59 --> Model "Item_model" initialized
INFO - 2018-10-30 04:23:59 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:23:59 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:23:59 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:23:59 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:23:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:23:59 --> Final output sent to browser
DEBUG - 2018-10-30 04:23:59 --> Total execution time: 0.4858
INFO - 2018-10-30 04:23:59 --> Config Class Initialized
INFO - 2018-10-30 04:23:59 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:23:59 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:23:59 --> Utf8 Class Initialized
INFO - 2018-10-30 04:23:59 --> URI Class Initialized
INFO - 2018-10-30 04:23:59 --> Router Class Initialized
INFO - 2018-10-30 04:23:59 --> Output Class Initialized
INFO - 2018-10-30 04:23:59 --> Security Class Initialized
DEBUG - 2018-10-30 04:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:23:59 --> Input Class Initialized
INFO - 2018-10-30 04:23:59 --> Language Class Initialized
ERROR - 2018-10-30 04:23:59 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:24:00 --> Config Class Initialized
INFO - 2018-10-30 04:24:00 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:24:00 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:24:00 --> Utf8 Class Initialized
INFO - 2018-10-30 04:24:00 --> URI Class Initialized
INFO - 2018-10-30 04:24:00 --> Router Class Initialized
INFO - 2018-10-30 04:24:00 --> Output Class Initialized
INFO - 2018-10-30 04:24:00 --> Security Class Initialized
DEBUG - 2018-10-30 04:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:24:00 --> Input Class Initialized
INFO - 2018-10-30 04:24:00 --> Language Class Initialized
INFO - 2018-10-30 04:24:00 --> Loader Class Initialized
INFO - 2018-10-30 04:24:00 --> Helper loaded: url_helper
INFO - 2018-10-30 04:24:01 --> Database Driver Class Initialized
INFO - 2018-10-30 04:24:01 --> Helper loaded: form_helper
INFO - 2018-10-30 04:24:01 --> Form Validation Class Initialized
INFO - 2018-10-30 04:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:24:01 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:24:01 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:24:01 --> Email Class Initialized
INFO - 2018-10-30 04:24:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:24:01 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:24:01 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:24:01 --> Helper loaded: date_helper
INFO - 2018-10-30 04:24:01 --> Database Driver Class Initialized
INFO - 2018-10-30 04:24:01 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:24:01 --> Controller Class Initialized
INFO - 2018-10-30 04:24:01 --> Model "Item_model" initialized
INFO - 2018-10-30 04:24:01 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:24:01 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:24:01 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:24:01 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:24:01 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 04:24:01 --> Final output sent to browser
DEBUG - 2018-10-30 04:24:01 --> Total execution time: 0.5369
INFO - 2018-10-30 04:24:01 --> Config Class Initialized
INFO - 2018-10-30 04:24:01 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:24:01 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:24:01 --> Utf8 Class Initialized
INFO - 2018-10-30 04:24:01 --> URI Class Initialized
INFO - 2018-10-30 04:24:01 --> Router Class Initialized
INFO - 2018-10-30 04:24:01 --> Output Class Initialized
INFO - 2018-10-30 04:24:01 --> Security Class Initialized
DEBUG - 2018-10-30 04:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:24:01 --> Input Class Initialized
INFO - 2018-10-30 04:24:01 --> Language Class Initialized
ERROR - 2018-10-30 04:24:01 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:24:03 --> Config Class Initialized
INFO - 2018-10-30 04:24:03 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:24:03 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:24:03 --> Utf8 Class Initialized
INFO - 2018-10-30 04:24:03 --> URI Class Initialized
INFO - 2018-10-30 04:24:03 --> Router Class Initialized
INFO - 2018-10-30 04:24:03 --> Output Class Initialized
INFO - 2018-10-30 04:24:03 --> Security Class Initialized
DEBUG - 2018-10-30 04:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:24:03 --> Input Class Initialized
INFO - 2018-10-30 04:24:03 --> Language Class Initialized
INFO - 2018-10-30 04:24:03 --> Loader Class Initialized
INFO - 2018-10-30 04:24:03 --> Helper loaded: url_helper
INFO - 2018-10-30 04:24:03 --> Database Driver Class Initialized
INFO - 2018-10-30 04:24:03 --> Helper loaded: form_helper
INFO - 2018-10-30 04:24:03 --> Form Validation Class Initialized
INFO - 2018-10-30 04:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:24:03 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:24:03 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:24:03 --> Email Class Initialized
INFO - 2018-10-30 04:24:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:24:03 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:24:03 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:24:03 --> Helper loaded: date_helper
INFO - 2018-10-30 04:24:03 --> Database Driver Class Initialized
INFO - 2018-10-30 04:24:03 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:24:03 --> Controller Class Initialized
INFO - 2018-10-30 04:24:03 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:24:03 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 04:24:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-30 04:24:03 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 04:24:03 --> Final output sent to browser
DEBUG - 2018-10-30 04:24:03 --> Total execution time: 0.4704
INFO - 2018-10-30 04:28:29 --> Config Class Initialized
INFO - 2018-10-30 04:28:29 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:28:29 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:28:29 --> Utf8 Class Initialized
INFO - 2018-10-30 04:28:29 --> URI Class Initialized
INFO - 2018-10-30 04:28:29 --> Router Class Initialized
INFO - 2018-10-30 04:28:29 --> Output Class Initialized
INFO - 2018-10-30 04:28:29 --> Security Class Initialized
DEBUG - 2018-10-30 04:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:28:30 --> Input Class Initialized
INFO - 2018-10-30 04:28:30 --> Language Class Initialized
INFO - 2018-10-30 04:28:30 --> Loader Class Initialized
INFO - 2018-10-30 04:28:30 --> Helper loaded: url_helper
INFO - 2018-10-30 04:28:30 --> Database Driver Class Initialized
INFO - 2018-10-30 04:28:30 --> Helper loaded: form_helper
INFO - 2018-10-30 04:28:30 --> Form Validation Class Initialized
INFO - 2018-10-30 04:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:28:30 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:28:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:28:30 --> Email Class Initialized
INFO - 2018-10-30 04:28:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:28:30 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:28:30 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:28:30 --> Helper loaded: date_helper
INFO - 2018-10-30 04:28:30 --> Database Driver Class Initialized
INFO - 2018-10-30 04:28:30 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:28:30 --> Controller Class Initialized
INFO - 2018-10-30 04:28:30 --> Model "Item_model" initialized
INFO - 2018-10-30 04:28:30 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:28:30 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:28:30 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:28:30 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:28:30 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:28:30 --> Final output sent to browser
DEBUG - 2018-10-30 04:28:30 --> Total execution time: 0.4807
INFO - 2018-10-30 04:28:34 --> Config Class Initialized
INFO - 2018-10-30 04:28:34 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:28:34 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:28:34 --> Utf8 Class Initialized
INFO - 2018-10-30 04:28:34 --> URI Class Initialized
INFO - 2018-10-30 04:28:34 --> Router Class Initialized
INFO - 2018-10-30 04:28:34 --> Output Class Initialized
INFO - 2018-10-30 04:28:34 --> Security Class Initialized
DEBUG - 2018-10-30 04:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:28:34 --> Input Class Initialized
INFO - 2018-10-30 04:28:34 --> Language Class Initialized
INFO - 2018-10-30 04:28:34 --> Loader Class Initialized
INFO - 2018-10-30 04:28:34 --> Helper loaded: url_helper
INFO - 2018-10-30 04:28:34 --> Database Driver Class Initialized
INFO - 2018-10-30 04:28:34 --> Helper loaded: form_helper
INFO - 2018-10-30 04:28:34 --> Form Validation Class Initialized
INFO - 2018-10-30 04:28:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:28:34 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:28:34 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:28:34 --> Email Class Initialized
INFO - 2018-10-30 04:28:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:28:35 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:28:35 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:28:35 --> Helper loaded: date_helper
INFO - 2018-10-30 04:28:35 --> Database Driver Class Initialized
INFO - 2018-10-30 04:28:35 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:28:35 --> Controller Class Initialized
INFO - 2018-10-30 04:28:35 --> Model "Item_model" initialized
INFO - 2018-10-30 04:28:35 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:28:35 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:28:35 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:28:35 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:28:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:28:35 --> Final output sent to browser
DEBUG - 2018-10-30 04:28:35 --> Total execution time: 0.5127
INFO - 2018-10-30 04:28:35 --> Config Class Initialized
INFO - 2018-10-30 04:28:35 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:28:35 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:28:35 --> Utf8 Class Initialized
INFO - 2018-10-30 04:28:35 --> URI Class Initialized
INFO - 2018-10-30 04:28:35 --> Router Class Initialized
INFO - 2018-10-30 04:28:35 --> Output Class Initialized
INFO - 2018-10-30 04:28:35 --> Security Class Initialized
DEBUG - 2018-10-30 04:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:28:35 --> Input Class Initialized
INFO - 2018-10-30 04:28:35 --> Language Class Initialized
ERROR - 2018-10-30 04:28:35 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:28:36 --> Config Class Initialized
INFO - 2018-10-30 04:28:36 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:28:36 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:28:36 --> Utf8 Class Initialized
INFO - 2018-10-30 04:28:36 --> URI Class Initialized
INFO - 2018-10-30 04:28:36 --> Router Class Initialized
INFO - 2018-10-30 04:28:36 --> Output Class Initialized
INFO - 2018-10-30 04:28:36 --> Security Class Initialized
DEBUG - 2018-10-30 04:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:28:36 --> Input Class Initialized
INFO - 2018-10-30 04:28:36 --> Language Class Initialized
INFO - 2018-10-30 04:28:36 --> Loader Class Initialized
INFO - 2018-10-30 04:28:36 --> Helper loaded: url_helper
INFO - 2018-10-30 04:28:36 --> Database Driver Class Initialized
INFO - 2018-10-30 04:28:36 --> Helper loaded: form_helper
INFO - 2018-10-30 04:28:36 --> Form Validation Class Initialized
INFO - 2018-10-30 04:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:28:36 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:28:36 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:28:36 --> Email Class Initialized
INFO - 2018-10-30 04:28:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:28:36 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:28:36 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:28:37 --> Helper loaded: date_helper
INFO - 2018-10-30 04:28:37 --> Database Driver Class Initialized
INFO - 2018-10-30 04:28:37 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:28:37 --> Controller Class Initialized
INFO - 2018-10-30 04:28:37 --> Model "Item_model" initialized
INFO - 2018-10-30 04:28:37 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:28:37 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:28:37 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:28:37 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 04:28:37 --> Query error: Column 'idvendor' cannot be null - Invalid query: INSERT INTO `nota` (`no_nota`, `tanggal`, `userid`, `idvendor`) VALUES (' 18103034', '2018-10-30', ' 3 ', NULL)
DEBUG - 2018-10-30 04:28:37 --> DB Transaction Failure
INFO - 2018-10-30 04:28:37 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-30 04:30:06 --> Config Class Initialized
INFO - 2018-10-30 04:30:06 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:30:06 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:30:06 --> Utf8 Class Initialized
INFO - 2018-10-30 04:30:06 --> URI Class Initialized
INFO - 2018-10-30 04:30:06 --> Router Class Initialized
INFO - 2018-10-30 04:30:06 --> Output Class Initialized
INFO - 2018-10-30 04:30:06 --> Security Class Initialized
DEBUG - 2018-10-30 04:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:30:06 --> Input Class Initialized
INFO - 2018-10-30 04:30:06 --> Language Class Initialized
INFO - 2018-10-30 04:30:06 --> Loader Class Initialized
INFO - 2018-10-30 04:30:06 --> Helper loaded: url_helper
INFO - 2018-10-30 04:30:06 --> Database Driver Class Initialized
INFO - 2018-10-30 04:30:06 --> Helper loaded: form_helper
INFO - 2018-10-30 04:30:06 --> Form Validation Class Initialized
INFO - 2018-10-30 04:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:30:06 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:30:06 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:30:06 --> Email Class Initialized
INFO - 2018-10-30 04:30:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:30:06 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:30:06 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:30:06 --> Helper loaded: date_helper
INFO - 2018-10-30 04:30:06 --> Database Driver Class Initialized
INFO - 2018-10-30 04:30:06 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:30:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:30:06 --> Controller Class Initialized
INFO - 2018-10-30 04:30:06 --> Model "Item_model" initialized
INFO - 2018-10-30 04:30:06 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:30:06 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:30:06 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:30:06 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:30:06 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 04:30:06 --> Final output sent to browser
DEBUG - 2018-10-30 04:30:06 --> Total execution time: 0.5028
INFO - 2018-10-30 04:30:22 --> Config Class Initialized
INFO - 2018-10-30 04:30:22 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:30:22 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:30:22 --> Utf8 Class Initialized
INFO - 2018-10-30 04:30:22 --> URI Class Initialized
INFO - 2018-10-30 04:30:22 --> Router Class Initialized
INFO - 2018-10-30 04:30:22 --> Output Class Initialized
INFO - 2018-10-30 04:30:22 --> Security Class Initialized
DEBUG - 2018-10-30 04:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:30:22 --> Input Class Initialized
INFO - 2018-10-30 04:30:22 --> Language Class Initialized
INFO - 2018-10-30 04:30:22 --> Loader Class Initialized
INFO - 2018-10-30 04:30:22 --> Helper loaded: url_helper
INFO - 2018-10-30 04:30:22 --> Database Driver Class Initialized
INFO - 2018-10-30 04:30:22 --> Helper loaded: form_helper
INFO - 2018-10-30 04:30:22 --> Form Validation Class Initialized
INFO - 2018-10-30 04:30:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:30:22 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:30:22 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:30:22 --> Email Class Initialized
INFO - 2018-10-30 04:30:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:30:22 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:30:22 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:30:22 --> Helper loaded: date_helper
INFO - 2018-10-30 04:30:22 --> Database Driver Class Initialized
INFO - 2018-10-30 04:30:22 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:30:22 --> Controller Class Initialized
INFO - 2018-10-30 04:30:22 --> Model "Item_model" initialized
INFO - 2018-10-30 04:30:22 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:30:22 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:30:22 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:30:22 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:30:22 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 04:30:22 --> Final output sent to browser
DEBUG - 2018-10-30 04:30:22 --> Total execution time: 0.4998
INFO - 2018-10-30 04:30:22 --> Config Class Initialized
INFO - 2018-10-30 04:30:22 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:30:22 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:30:22 --> Utf8 Class Initialized
INFO - 2018-10-30 04:30:22 --> URI Class Initialized
INFO - 2018-10-30 04:30:22 --> Router Class Initialized
INFO - 2018-10-30 04:30:22 --> Output Class Initialized
INFO - 2018-10-30 04:30:22 --> Security Class Initialized
DEBUG - 2018-10-30 04:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:30:22 --> Input Class Initialized
INFO - 2018-10-30 04:30:22 --> Language Class Initialized
ERROR - 2018-10-30 04:30:22 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:30:24 --> Config Class Initialized
INFO - 2018-10-30 04:30:24 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:30:24 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:30:24 --> Utf8 Class Initialized
INFO - 2018-10-30 04:30:24 --> URI Class Initialized
INFO - 2018-10-30 04:30:24 --> Router Class Initialized
INFO - 2018-10-30 04:30:24 --> Output Class Initialized
INFO - 2018-10-30 04:30:24 --> Security Class Initialized
DEBUG - 2018-10-30 04:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:30:24 --> Input Class Initialized
INFO - 2018-10-30 04:30:24 --> Language Class Initialized
INFO - 2018-10-30 04:30:24 --> Loader Class Initialized
INFO - 2018-10-30 04:30:24 --> Helper loaded: url_helper
INFO - 2018-10-30 04:30:24 --> Database Driver Class Initialized
INFO - 2018-10-30 04:30:24 --> Helper loaded: form_helper
INFO - 2018-10-30 04:30:24 --> Form Validation Class Initialized
INFO - 2018-10-30 04:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:30:24 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:30:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:30:24 --> Email Class Initialized
INFO - 2018-10-30 04:30:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:30:24 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:30:24 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:30:24 --> Helper loaded: date_helper
INFO - 2018-10-30 04:30:24 --> Database Driver Class Initialized
INFO - 2018-10-30 04:30:24 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:30:24 --> Controller Class Initialized
INFO - 2018-10-30 04:30:24 --> Model "Item_model" initialized
INFO - 2018-10-30 04:30:24 --> Model "Jenis_model" initialized
INFO - 2018-10-30 04:30:24 --> Model "Vendor_model" initialized
INFO - 2018-10-30 04:30:24 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:30:24 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 04:30:24 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 04:30:24 --> Final output sent to browser
DEBUG - 2018-10-30 04:30:24 --> Total execution time: 0.5331
INFO - 2018-10-30 04:30:24 --> Config Class Initialized
INFO - 2018-10-30 04:30:24 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:30:24 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:30:24 --> Utf8 Class Initialized
INFO - 2018-10-30 04:30:24 --> URI Class Initialized
INFO - 2018-10-30 04:30:24 --> Router Class Initialized
INFO - 2018-10-30 04:30:24 --> Output Class Initialized
INFO - 2018-10-30 04:30:24 --> Security Class Initialized
DEBUG - 2018-10-30 04:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:30:24 --> Input Class Initialized
INFO - 2018-10-30 04:30:24 --> Language Class Initialized
ERROR - 2018-10-30 04:30:24 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 04:30:30 --> Config Class Initialized
INFO - 2018-10-30 04:30:30 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:30:30 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:30:30 --> Utf8 Class Initialized
INFO - 2018-10-30 04:30:30 --> URI Class Initialized
INFO - 2018-10-30 04:30:30 --> Router Class Initialized
INFO - 2018-10-30 04:30:30 --> Output Class Initialized
INFO - 2018-10-30 04:30:30 --> Security Class Initialized
DEBUG - 2018-10-30 04:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:30:30 --> Input Class Initialized
INFO - 2018-10-30 04:30:30 --> Language Class Initialized
INFO - 2018-10-30 04:30:30 --> Loader Class Initialized
INFO - 2018-10-30 04:30:30 --> Helper loaded: url_helper
INFO - 2018-10-30 04:30:30 --> Database Driver Class Initialized
INFO - 2018-10-30 04:30:30 --> Helper loaded: form_helper
INFO - 2018-10-30 04:30:30 --> Form Validation Class Initialized
INFO - 2018-10-30 04:30:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:30:30 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:30:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:30:30 --> Email Class Initialized
INFO - 2018-10-30 04:30:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:30:30 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:30:30 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:30:30 --> Helper loaded: date_helper
INFO - 2018-10-30 04:30:30 --> Database Driver Class Initialized
INFO - 2018-10-30 04:30:30 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:30:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:30:30 --> Controller Class Initialized
INFO - 2018-10-30 04:30:30 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:30:30 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 04:30:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-30 04:30:30 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 04:30:30 --> Final output sent to browser
DEBUG - 2018-10-30 04:30:30 --> Total execution time: 0.5223
INFO - 2018-10-30 04:33:02 --> Config Class Initialized
INFO - 2018-10-30 04:33:02 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:33:02 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:33:02 --> Utf8 Class Initialized
INFO - 2018-10-30 04:33:02 --> URI Class Initialized
INFO - 2018-10-30 04:33:02 --> Router Class Initialized
INFO - 2018-10-30 04:33:02 --> Output Class Initialized
INFO - 2018-10-30 04:33:02 --> Security Class Initialized
DEBUG - 2018-10-30 04:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:33:02 --> Input Class Initialized
INFO - 2018-10-30 04:33:02 --> Language Class Initialized
INFO - 2018-10-30 04:33:02 --> Loader Class Initialized
INFO - 2018-10-30 04:33:02 --> Helper loaded: url_helper
INFO - 2018-10-30 04:33:02 --> Database Driver Class Initialized
INFO - 2018-10-30 04:33:02 --> Helper loaded: form_helper
INFO - 2018-10-30 04:33:02 --> Form Validation Class Initialized
INFO - 2018-10-30 04:33:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:33:02 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:33:02 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:33:02 --> Email Class Initialized
INFO - 2018-10-30 04:33:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:33:02 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:33:02 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:33:02 --> Helper loaded: date_helper
INFO - 2018-10-30 04:33:02 --> Database Driver Class Initialized
INFO - 2018-10-30 04:33:02 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:33:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:33:02 --> Controller Class Initialized
INFO - 2018-10-30 04:33:02 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:33:02 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 04:33:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-30 04:33:02 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 04:33:02 --> Final output sent to browser
DEBUG - 2018-10-30 04:33:02 --> Total execution time: 0.4848
INFO - 2018-10-30 04:33:06 --> Config Class Initialized
INFO - 2018-10-30 04:33:06 --> Hooks Class Initialized
DEBUG - 2018-10-30 04:33:06 --> UTF-8 Support Enabled
INFO - 2018-10-30 04:33:06 --> Utf8 Class Initialized
INFO - 2018-10-30 04:33:06 --> URI Class Initialized
INFO - 2018-10-30 04:33:06 --> Router Class Initialized
INFO - 2018-10-30 04:33:06 --> Output Class Initialized
INFO - 2018-10-30 04:33:06 --> Security Class Initialized
DEBUG - 2018-10-30 04:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 04:33:06 --> Input Class Initialized
INFO - 2018-10-30 04:33:06 --> Language Class Initialized
INFO - 2018-10-30 04:33:06 --> Loader Class Initialized
INFO - 2018-10-30 04:33:06 --> Helper loaded: url_helper
INFO - 2018-10-30 04:33:06 --> Database Driver Class Initialized
INFO - 2018-10-30 04:33:06 --> Helper loaded: form_helper
INFO - 2018-10-30 04:33:06 --> Form Validation Class Initialized
INFO - 2018-10-30 04:33:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 04:33:06 --> Pagination Class Initialized
DEBUG - 2018-10-30 04:33:06 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 04:33:06 --> Email Class Initialized
INFO - 2018-10-30 04:33:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 04:33:06 --> Helper loaded: cookie_helper
INFO - 2018-10-30 04:33:06 --> Helper loaded: language_helper
DEBUG - 2018-10-30 04:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 04:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 04:33:06 --> Helper loaded: date_helper
INFO - 2018-10-30 04:33:06 --> Database Driver Class Initialized
INFO - 2018-10-30 04:33:06 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 04:33:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 04:33:06 --> Controller Class Initialized
INFO - 2018-10-30 04:33:06 --> Model "Nota_model" initialized
INFO - 2018-10-30 04:33:06 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 04:33:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-30 04:33:06 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 04:33:06 --> Final output sent to browser
DEBUG - 2018-10-30 04:33:06 --> Total execution time: 0.4779
INFO - 2018-10-30 05:08:10 --> Config Class Initialized
INFO - 2018-10-30 05:08:10 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:08:10 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:08:10 --> Utf8 Class Initialized
INFO - 2018-10-30 05:08:10 --> URI Class Initialized
INFO - 2018-10-30 05:08:10 --> Router Class Initialized
INFO - 2018-10-30 05:08:10 --> Output Class Initialized
INFO - 2018-10-30 05:08:10 --> Security Class Initialized
DEBUG - 2018-10-30 05:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:08:10 --> Input Class Initialized
INFO - 2018-10-30 05:08:10 --> Language Class Initialized
INFO - 2018-10-30 05:08:10 --> Loader Class Initialized
INFO - 2018-10-30 05:08:10 --> Helper loaded: url_helper
INFO - 2018-10-30 05:08:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:08:10 --> Helper loaded: form_helper
INFO - 2018-10-30 05:08:10 --> Form Validation Class Initialized
INFO - 2018-10-30 05:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:08:10 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:08:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:08:10 --> Email Class Initialized
INFO - 2018-10-30 05:08:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:08:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:08:10 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:08:10 --> Helper loaded: date_helper
INFO - 2018-10-30 05:08:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:08:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:08:10 --> Controller Class Initialized
INFO - 2018-10-30 05:08:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:08:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:08:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:08:10 --> Final output sent to browser
DEBUG - 2018-10-30 05:08:10 --> Total execution time: 0.4596
INFO - 2018-10-30 05:09:40 --> Config Class Initialized
INFO - 2018-10-30 05:09:40 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:09:40 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:09:40 --> Utf8 Class Initialized
INFO - 2018-10-30 05:09:40 --> URI Class Initialized
INFO - 2018-10-30 05:09:40 --> Router Class Initialized
INFO - 2018-10-30 05:09:40 --> Output Class Initialized
INFO - 2018-10-30 05:09:40 --> Security Class Initialized
DEBUG - 2018-10-30 05:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:09:40 --> Input Class Initialized
INFO - 2018-10-30 05:09:40 --> Language Class Initialized
INFO - 2018-10-30 05:09:40 --> Loader Class Initialized
INFO - 2018-10-30 05:09:40 --> Helper loaded: url_helper
INFO - 2018-10-30 05:09:40 --> Database Driver Class Initialized
INFO - 2018-10-30 05:09:40 --> Helper loaded: form_helper
INFO - 2018-10-30 05:09:40 --> Form Validation Class Initialized
INFO - 2018-10-30 05:09:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:09:40 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:09:40 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:09:41 --> Email Class Initialized
INFO - 2018-10-30 05:09:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:09:41 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:09:41 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:09:41 --> Helper loaded: date_helper
INFO - 2018-10-30 05:09:41 --> Database Driver Class Initialized
INFO - 2018-10-30 05:09:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:09:41 --> Controller Class Initialized
INFO - 2018-10-30 05:09:41 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:09:41 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:09:41 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:09:41 --> Final output sent to browser
DEBUG - 2018-10-30 05:09:41 --> Total execution time: 0.4807
INFO - 2018-10-30 05:09:56 --> Config Class Initialized
INFO - 2018-10-30 05:09:56 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:09:56 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:09:56 --> Utf8 Class Initialized
INFO - 2018-10-30 05:09:56 --> URI Class Initialized
INFO - 2018-10-30 05:09:56 --> Router Class Initialized
INFO - 2018-10-30 05:09:56 --> Output Class Initialized
INFO - 2018-10-30 05:09:56 --> Security Class Initialized
DEBUG - 2018-10-30 05:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:09:56 --> Input Class Initialized
INFO - 2018-10-30 05:09:56 --> Language Class Initialized
INFO - 2018-10-30 05:09:56 --> Loader Class Initialized
INFO - 2018-10-30 05:09:56 --> Helper loaded: url_helper
INFO - 2018-10-30 05:09:56 --> Database Driver Class Initialized
INFO - 2018-10-30 05:09:56 --> Helper loaded: form_helper
INFO - 2018-10-30 05:09:56 --> Form Validation Class Initialized
INFO - 2018-10-30 05:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:09:56 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:09:56 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:09:56 --> Email Class Initialized
INFO - 2018-10-30 05:09:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:09:56 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:09:56 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:09:57 --> Helper loaded: date_helper
INFO - 2018-10-30 05:09:57 --> Database Driver Class Initialized
INFO - 2018-10-30 05:09:57 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:09:57 --> Controller Class Initialized
INFO - 2018-10-30 05:09:57 --> Model "Item_model" initialized
INFO - 2018-10-30 05:09:57 --> Model "Jenis_model" initialized
INFO - 2018-10-30 05:09:57 --> Model "Vendor_model" initialized
INFO - 2018-10-30 05:09:57 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:09:57 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:09:57 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 05:09:57 --> Final output sent to browser
DEBUG - 2018-10-30 05:09:57 --> Total execution time: 0.5284
INFO - 2018-10-30 05:10:02 --> Config Class Initialized
INFO - 2018-10-30 05:10:02 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:10:02 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:10:02 --> Utf8 Class Initialized
INFO - 2018-10-30 05:10:02 --> URI Class Initialized
INFO - 2018-10-30 05:10:02 --> Router Class Initialized
INFO - 2018-10-30 05:10:02 --> Output Class Initialized
INFO - 2018-10-30 05:10:02 --> Security Class Initialized
DEBUG - 2018-10-30 05:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:10:02 --> Input Class Initialized
INFO - 2018-10-30 05:10:02 --> Language Class Initialized
INFO - 2018-10-30 05:10:02 --> Loader Class Initialized
INFO - 2018-10-30 05:10:02 --> Helper loaded: url_helper
INFO - 2018-10-30 05:10:02 --> Database Driver Class Initialized
INFO - 2018-10-30 05:10:02 --> Helper loaded: form_helper
INFO - 2018-10-30 05:10:02 --> Form Validation Class Initialized
INFO - 2018-10-30 05:10:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:10:02 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:10:02 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:10:02 --> Email Class Initialized
INFO - 2018-10-30 05:10:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:10:02 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:10:02 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:10:02 --> Helper loaded: date_helper
INFO - 2018-10-30 05:10:02 --> Database Driver Class Initialized
INFO - 2018-10-30 05:10:02 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:10:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:10:02 --> Controller Class Initialized
INFO - 2018-10-30 05:10:03 --> Model "Item_model" initialized
INFO - 2018-10-30 05:10:03 --> Model "Jenis_model" initialized
INFO - 2018-10-30 05:10:03 --> Model "Vendor_model" initialized
INFO - 2018-10-30 05:10:03 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:10:03 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:10:03 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 05:10:03 --> Final output sent to browser
DEBUG - 2018-10-30 05:10:03 --> Total execution time: 0.5204
INFO - 2018-10-30 05:10:03 --> Config Class Initialized
INFO - 2018-10-30 05:10:03 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:10:03 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:10:03 --> Utf8 Class Initialized
INFO - 2018-10-30 05:10:03 --> URI Class Initialized
INFO - 2018-10-30 05:10:03 --> Router Class Initialized
INFO - 2018-10-30 05:10:03 --> Output Class Initialized
INFO - 2018-10-30 05:10:03 --> Security Class Initialized
DEBUG - 2018-10-30 05:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:10:03 --> Input Class Initialized
INFO - 2018-10-30 05:10:03 --> Language Class Initialized
ERROR - 2018-10-30 05:10:03 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 05:10:05 --> Config Class Initialized
INFO - 2018-10-30 05:10:05 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:10:05 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:10:05 --> Utf8 Class Initialized
INFO - 2018-10-30 05:10:05 --> URI Class Initialized
INFO - 2018-10-30 05:10:05 --> Router Class Initialized
INFO - 2018-10-30 05:10:05 --> Output Class Initialized
INFO - 2018-10-30 05:10:05 --> Security Class Initialized
DEBUG - 2018-10-30 05:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:10:05 --> Input Class Initialized
INFO - 2018-10-30 05:10:05 --> Language Class Initialized
INFO - 2018-10-30 05:10:05 --> Loader Class Initialized
INFO - 2018-10-30 05:10:05 --> Helper loaded: url_helper
INFO - 2018-10-30 05:10:05 --> Database Driver Class Initialized
INFO - 2018-10-30 05:10:05 --> Helper loaded: form_helper
INFO - 2018-10-30 05:10:05 --> Form Validation Class Initialized
INFO - 2018-10-30 05:10:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:10:05 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:10:05 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:10:05 --> Email Class Initialized
INFO - 2018-10-30 05:10:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:10:05 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:10:05 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:10:05 --> Helper loaded: date_helper
INFO - 2018-10-30 05:10:05 --> Database Driver Class Initialized
INFO - 2018-10-30 05:10:05 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:10:05 --> Controller Class Initialized
INFO - 2018-10-30 05:10:05 --> Model "Item_model" initialized
INFO - 2018-10-30 05:10:05 --> Model "Jenis_model" initialized
INFO - 2018-10-30 05:10:05 --> Model "Vendor_model" initialized
INFO - 2018-10-30 05:10:05 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:10:05 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:10:05 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 05:10:05 --> Final output sent to browser
DEBUG - 2018-10-30 05:10:06 --> Total execution time: 0.5534
INFO - 2018-10-30 05:10:06 --> Config Class Initialized
INFO - 2018-10-30 05:10:06 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:10:06 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:10:06 --> Utf8 Class Initialized
INFO - 2018-10-30 05:10:06 --> URI Class Initialized
INFO - 2018-10-30 05:10:06 --> Router Class Initialized
INFO - 2018-10-30 05:10:06 --> Output Class Initialized
INFO - 2018-10-30 05:10:06 --> Security Class Initialized
DEBUG - 2018-10-30 05:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:10:06 --> Input Class Initialized
INFO - 2018-10-30 05:10:06 --> Language Class Initialized
ERROR - 2018-10-30 05:10:06 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 05:10:07 --> Config Class Initialized
INFO - 2018-10-30 05:10:07 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:10:07 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:10:07 --> Utf8 Class Initialized
INFO - 2018-10-30 05:10:07 --> URI Class Initialized
INFO - 2018-10-30 05:10:07 --> Router Class Initialized
INFO - 2018-10-30 05:10:07 --> Output Class Initialized
INFO - 2018-10-30 05:10:07 --> Security Class Initialized
DEBUG - 2018-10-30 05:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:10:07 --> Input Class Initialized
INFO - 2018-10-30 05:10:07 --> Language Class Initialized
INFO - 2018-10-30 05:10:07 --> Loader Class Initialized
INFO - 2018-10-30 05:10:07 --> Helper loaded: url_helper
INFO - 2018-10-30 05:10:07 --> Database Driver Class Initialized
INFO - 2018-10-30 05:10:08 --> Helper loaded: form_helper
INFO - 2018-10-30 05:10:08 --> Form Validation Class Initialized
INFO - 2018-10-30 05:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:10:08 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:10:08 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:10:08 --> Email Class Initialized
INFO - 2018-10-30 05:10:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:10:08 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:10:08 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:10:08 --> Helper loaded: date_helper
INFO - 2018-10-30 05:10:08 --> Database Driver Class Initialized
INFO - 2018-10-30 05:10:08 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:10:08 --> Controller Class Initialized
INFO - 2018-10-30 05:10:08 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:10:08 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:10:08 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:10:08 --> Final output sent to browser
DEBUG - 2018-10-30 05:10:08 --> Total execution time: 0.5112
INFO - 2018-10-30 05:11:52 --> Config Class Initialized
INFO - 2018-10-30 05:11:52 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:11:52 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:11:52 --> Utf8 Class Initialized
INFO - 2018-10-30 05:11:52 --> URI Class Initialized
INFO - 2018-10-30 05:11:52 --> Router Class Initialized
INFO - 2018-10-30 05:11:52 --> Output Class Initialized
INFO - 2018-10-30 05:11:52 --> Security Class Initialized
DEBUG - 2018-10-30 05:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:11:52 --> Input Class Initialized
INFO - 2018-10-30 05:11:52 --> Language Class Initialized
INFO - 2018-10-30 05:11:52 --> Loader Class Initialized
INFO - 2018-10-30 05:11:52 --> Helper loaded: url_helper
INFO - 2018-10-30 05:11:52 --> Database Driver Class Initialized
INFO - 2018-10-30 05:11:52 --> Helper loaded: form_helper
INFO - 2018-10-30 05:11:52 --> Form Validation Class Initialized
INFO - 2018-10-30 05:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:11:52 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:11:52 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:11:52 --> Email Class Initialized
INFO - 2018-10-30 05:11:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:11:52 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:11:52 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:11:52 --> Helper loaded: date_helper
INFO - 2018-10-30 05:11:52 --> Database Driver Class Initialized
INFO - 2018-10-30 05:11:52 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:11:52 --> Controller Class Initialized
INFO - 2018-10-30 05:11:52 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:11:52 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 05:11:52 --> Severity: Notice --> Undefined index: no_nota D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 75
ERROR - 2018-10-30 05:11:52 --> Severity: Notice --> Undefined index: no_nota D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 75
INFO - 2018-10-30 05:11:52 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:11:52 --> Final output sent to browser
DEBUG - 2018-10-30 05:11:52 --> Total execution time: 0.5291
INFO - 2018-10-30 05:12:05 --> Config Class Initialized
INFO - 2018-10-30 05:12:05 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:12:05 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:12:05 --> Utf8 Class Initialized
INFO - 2018-10-30 05:12:05 --> URI Class Initialized
INFO - 2018-10-30 05:12:05 --> Router Class Initialized
INFO - 2018-10-30 05:12:05 --> Output Class Initialized
INFO - 2018-10-30 05:12:05 --> Security Class Initialized
DEBUG - 2018-10-30 05:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:12:05 --> Input Class Initialized
INFO - 2018-10-30 05:12:05 --> Language Class Initialized
INFO - 2018-10-30 05:12:05 --> Loader Class Initialized
INFO - 2018-10-30 05:12:05 --> Helper loaded: url_helper
INFO - 2018-10-30 05:12:05 --> Database Driver Class Initialized
INFO - 2018-10-30 05:12:05 --> Helper loaded: form_helper
INFO - 2018-10-30 05:12:05 --> Form Validation Class Initialized
INFO - 2018-10-30 05:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:12:05 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:12:05 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:12:05 --> Email Class Initialized
INFO - 2018-10-30 05:12:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:12:06 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:12:06 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:12:06 --> Helper loaded: date_helper
INFO - 2018-10-30 05:12:06 --> Database Driver Class Initialized
INFO - 2018-10-30 05:12:06 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:12:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:12:06 --> Controller Class Initialized
INFO - 2018-10-30 05:12:06 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:12:06 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:12:06 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:12:06 --> Final output sent to browser
DEBUG - 2018-10-30 05:12:06 --> Total execution time: 0.4817
INFO - 2018-10-30 05:12:48 --> Config Class Initialized
INFO - 2018-10-30 05:12:48 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:12:48 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:12:48 --> Utf8 Class Initialized
INFO - 2018-10-30 05:12:48 --> URI Class Initialized
INFO - 2018-10-30 05:12:48 --> Router Class Initialized
INFO - 2018-10-30 05:12:48 --> Output Class Initialized
INFO - 2018-10-30 05:12:48 --> Security Class Initialized
DEBUG - 2018-10-30 05:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:12:48 --> Input Class Initialized
INFO - 2018-10-30 05:12:48 --> Language Class Initialized
INFO - 2018-10-30 05:12:48 --> Loader Class Initialized
INFO - 2018-10-30 05:12:48 --> Helper loaded: url_helper
INFO - 2018-10-30 05:12:48 --> Database Driver Class Initialized
INFO - 2018-10-30 05:12:48 --> Helper loaded: form_helper
INFO - 2018-10-30 05:12:48 --> Form Validation Class Initialized
INFO - 2018-10-30 05:12:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:12:49 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:12:49 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:12:49 --> Email Class Initialized
INFO - 2018-10-30 05:12:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:12:49 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:12:49 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:12:49 --> Helper loaded: date_helper
INFO - 2018-10-30 05:12:49 --> Database Driver Class Initialized
INFO - 2018-10-30 05:12:49 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:12:49 --> Controller Class Initialized
INFO - 2018-10-30 05:12:49 --> Model "Item_model" initialized
INFO - 2018-10-30 05:12:49 --> Model "Jenis_model" initialized
INFO - 2018-10-30 05:12:49 --> Model "Vendor_model" initialized
INFO - 2018-10-30 05:12:49 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:12:49 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:12:49 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 05:12:49 --> Final output sent to browser
DEBUG - 2018-10-30 05:12:49 --> Total execution time: 0.5198
INFO - 2018-10-30 05:12:52 --> Config Class Initialized
INFO - 2018-10-30 05:12:52 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:12:52 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:12:52 --> Utf8 Class Initialized
INFO - 2018-10-30 05:12:52 --> URI Class Initialized
INFO - 2018-10-30 05:12:52 --> Router Class Initialized
INFO - 2018-10-30 05:12:52 --> Output Class Initialized
INFO - 2018-10-30 05:12:52 --> Security Class Initialized
DEBUG - 2018-10-30 05:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:12:52 --> Input Class Initialized
INFO - 2018-10-30 05:12:52 --> Language Class Initialized
INFO - 2018-10-30 05:12:52 --> Loader Class Initialized
INFO - 2018-10-30 05:12:52 --> Helper loaded: url_helper
INFO - 2018-10-30 05:12:52 --> Database Driver Class Initialized
INFO - 2018-10-30 05:12:52 --> Helper loaded: form_helper
INFO - 2018-10-30 05:12:52 --> Form Validation Class Initialized
INFO - 2018-10-30 05:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:12:52 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:12:52 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:12:52 --> Email Class Initialized
INFO - 2018-10-30 05:12:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:12:52 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:12:52 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:12:52 --> Helper loaded: date_helper
INFO - 2018-10-30 05:12:52 --> Database Driver Class Initialized
INFO - 2018-10-30 05:12:52 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:12:52 --> Controller Class Initialized
INFO - 2018-10-30 05:12:52 --> Model "Item_model" initialized
INFO - 2018-10-30 05:12:53 --> Model "Jenis_model" initialized
INFO - 2018-10-30 05:12:53 --> Model "Vendor_model" initialized
INFO - 2018-10-30 05:12:53 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:12:53 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:12:53 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 05:12:53 --> Final output sent to browser
DEBUG - 2018-10-30 05:12:53 --> Total execution time: 0.5192
INFO - 2018-10-30 05:12:53 --> Config Class Initialized
INFO - 2018-10-30 05:12:53 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:12:53 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:12:53 --> Utf8 Class Initialized
INFO - 2018-10-30 05:12:53 --> URI Class Initialized
INFO - 2018-10-30 05:12:53 --> Router Class Initialized
INFO - 2018-10-30 05:12:53 --> Output Class Initialized
INFO - 2018-10-30 05:12:53 --> Security Class Initialized
DEBUG - 2018-10-30 05:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:12:53 --> Input Class Initialized
INFO - 2018-10-30 05:12:53 --> Language Class Initialized
ERROR - 2018-10-30 05:12:53 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 05:12:54 --> Config Class Initialized
INFO - 2018-10-30 05:12:54 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:12:54 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:12:54 --> Utf8 Class Initialized
INFO - 2018-10-30 05:12:54 --> URI Class Initialized
INFO - 2018-10-30 05:12:54 --> Router Class Initialized
INFO - 2018-10-30 05:12:54 --> Output Class Initialized
INFO - 2018-10-30 05:12:54 --> Security Class Initialized
DEBUG - 2018-10-30 05:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:12:54 --> Input Class Initialized
INFO - 2018-10-30 05:12:54 --> Language Class Initialized
INFO - 2018-10-30 05:12:54 --> Loader Class Initialized
INFO - 2018-10-30 05:12:54 --> Helper loaded: url_helper
INFO - 2018-10-30 05:12:54 --> Database Driver Class Initialized
INFO - 2018-10-30 05:12:54 --> Helper loaded: form_helper
INFO - 2018-10-30 05:12:54 --> Form Validation Class Initialized
INFO - 2018-10-30 05:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:12:54 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:12:54 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:12:54 --> Email Class Initialized
INFO - 2018-10-30 05:12:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:12:54 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:12:54 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:12:54 --> Helper loaded: date_helper
INFO - 2018-10-30 05:12:54 --> Database Driver Class Initialized
INFO - 2018-10-30 05:12:54 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:12:54 --> Controller Class Initialized
INFO - 2018-10-30 05:12:54 --> Model "Item_model" initialized
INFO - 2018-10-30 05:12:54 --> Model "Jenis_model" initialized
INFO - 2018-10-30 05:12:54 --> Model "Vendor_model" initialized
INFO - 2018-10-30 05:12:54 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:12:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:12:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 05:12:55 --> Final output sent to browser
DEBUG - 2018-10-30 05:12:55 --> Total execution time: 0.5170
INFO - 2018-10-30 05:12:55 --> Config Class Initialized
INFO - 2018-10-30 05:12:55 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:12:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:12:55 --> Utf8 Class Initialized
INFO - 2018-10-30 05:12:55 --> URI Class Initialized
INFO - 2018-10-30 05:12:55 --> Router Class Initialized
INFO - 2018-10-30 05:12:55 --> Output Class Initialized
INFO - 2018-10-30 05:12:55 --> Security Class Initialized
DEBUG - 2018-10-30 05:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:12:55 --> Input Class Initialized
INFO - 2018-10-30 05:12:55 --> Language Class Initialized
ERROR - 2018-10-30 05:12:55 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 05:12:57 --> Config Class Initialized
INFO - 2018-10-30 05:12:57 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:12:57 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:12:57 --> Utf8 Class Initialized
INFO - 2018-10-30 05:12:57 --> URI Class Initialized
INFO - 2018-10-30 05:12:57 --> Router Class Initialized
INFO - 2018-10-30 05:12:57 --> Output Class Initialized
INFO - 2018-10-30 05:12:57 --> Security Class Initialized
DEBUG - 2018-10-30 05:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:12:57 --> Input Class Initialized
INFO - 2018-10-30 05:12:57 --> Language Class Initialized
INFO - 2018-10-30 05:12:57 --> Loader Class Initialized
INFO - 2018-10-30 05:12:57 --> Helper loaded: url_helper
INFO - 2018-10-30 05:12:57 --> Database Driver Class Initialized
INFO - 2018-10-30 05:12:57 --> Helper loaded: form_helper
INFO - 2018-10-30 05:12:57 --> Form Validation Class Initialized
INFO - 2018-10-30 05:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:12:57 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:12:57 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:12:57 --> Email Class Initialized
INFO - 2018-10-30 05:12:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:12:57 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:12:57 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:12:57 --> Helper loaded: date_helper
INFO - 2018-10-30 05:12:57 --> Database Driver Class Initialized
INFO - 2018-10-30 05:12:57 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:12:57 --> Controller Class Initialized
INFO - 2018-10-30 05:12:57 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:12:57 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:12:57 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:12:57 --> Final output sent to browser
DEBUG - 2018-10-30 05:12:57 --> Total execution time: 0.5053
INFO - 2018-10-30 05:13:46 --> Config Class Initialized
INFO - 2018-10-30 05:13:46 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:13:46 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:13:46 --> Utf8 Class Initialized
INFO - 2018-10-30 05:13:46 --> URI Class Initialized
INFO - 2018-10-30 05:13:46 --> Router Class Initialized
INFO - 2018-10-30 05:13:46 --> Output Class Initialized
INFO - 2018-10-30 05:13:47 --> Security Class Initialized
DEBUG - 2018-10-30 05:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:13:47 --> Input Class Initialized
INFO - 2018-10-30 05:13:47 --> Language Class Initialized
INFO - 2018-10-30 05:13:47 --> Loader Class Initialized
INFO - 2018-10-30 05:13:47 --> Helper loaded: url_helper
INFO - 2018-10-30 05:13:47 --> Database Driver Class Initialized
INFO - 2018-10-30 05:13:47 --> Helper loaded: form_helper
INFO - 2018-10-30 05:13:47 --> Form Validation Class Initialized
INFO - 2018-10-30 05:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:13:47 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:13:47 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:13:47 --> Email Class Initialized
INFO - 2018-10-30 05:13:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:13:47 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:13:47 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:13:47 --> Helper loaded: date_helper
INFO - 2018-10-30 05:13:47 --> Database Driver Class Initialized
INFO - 2018-10-30 05:13:47 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:13:47 --> Controller Class Initialized
INFO - 2018-10-30 05:13:47 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:13:47 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 05:13:47 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 68
ERROR - 2018-10-30 05:13:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 05:13:47 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 68
ERROR - 2018-10-30 05:13:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 05:13:47 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 68
ERROR - 2018-10-30 05:13:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-30 05:13:47 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:13:47 --> Final output sent to browser
DEBUG - 2018-10-30 05:13:47 --> Total execution time: 0.6014
INFO - 2018-10-30 05:13:48 --> Config Class Initialized
INFO - 2018-10-30 05:13:48 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:13:48 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:13:48 --> Utf8 Class Initialized
INFO - 2018-10-30 05:13:48 --> URI Class Initialized
INFO - 2018-10-30 05:13:48 --> Router Class Initialized
INFO - 2018-10-30 05:13:48 --> Output Class Initialized
INFO - 2018-10-30 05:13:48 --> Security Class Initialized
DEBUG - 2018-10-30 05:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:13:48 --> Input Class Initialized
INFO - 2018-10-30 05:13:48 --> Language Class Initialized
INFO - 2018-10-30 05:13:48 --> Loader Class Initialized
INFO - 2018-10-30 05:13:48 --> Helper loaded: url_helper
INFO - 2018-10-30 05:13:48 --> Database Driver Class Initialized
INFO - 2018-10-30 05:13:48 --> Helper loaded: form_helper
INFO - 2018-10-30 05:13:48 --> Form Validation Class Initialized
INFO - 2018-10-30 05:13:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:13:49 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:13:49 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:13:49 --> Email Class Initialized
INFO - 2018-10-30 05:13:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:13:49 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:13:49 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:13:49 --> Helper loaded: date_helper
INFO - 2018-10-30 05:13:49 --> Database Driver Class Initialized
INFO - 2018-10-30 05:13:49 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:13:49 --> Controller Class Initialized
INFO - 2018-10-30 05:13:49 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:13:49 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 05:13:49 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 68
ERROR - 2018-10-30 05:13:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 05:13:49 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 68
ERROR - 2018-10-30 05:13:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 05:13:49 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 68
ERROR - 2018-10-30 05:13:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-30 05:13:49 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:13:49 --> Final output sent to browser
DEBUG - 2018-10-30 05:13:49 --> Total execution time: 0.6155
INFO - 2018-10-30 05:14:49 --> Config Class Initialized
INFO - 2018-10-30 05:14:50 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:14:50 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:14:50 --> Utf8 Class Initialized
INFO - 2018-10-30 05:14:50 --> URI Class Initialized
INFO - 2018-10-30 05:14:50 --> Router Class Initialized
INFO - 2018-10-30 05:14:50 --> Output Class Initialized
INFO - 2018-10-30 05:14:50 --> Security Class Initialized
DEBUG - 2018-10-30 05:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:14:50 --> Input Class Initialized
INFO - 2018-10-30 05:14:50 --> Language Class Initialized
INFO - 2018-10-30 05:14:50 --> Loader Class Initialized
INFO - 2018-10-30 05:14:50 --> Helper loaded: url_helper
INFO - 2018-10-30 05:14:50 --> Database Driver Class Initialized
INFO - 2018-10-30 05:14:50 --> Helper loaded: form_helper
INFO - 2018-10-30 05:14:50 --> Form Validation Class Initialized
INFO - 2018-10-30 05:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:14:50 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:14:50 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:14:50 --> Email Class Initialized
INFO - 2018-10-30 05:14:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:14:50 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:14:50 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:14:50 --> Helper loaded: date_helper
INFO - 2018-10-30 05:14:50 --> Database Driver Class Initialized
INFO - 2018-10-30 05:14:50 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:14:50 --> Controller Class Initialized
INFO - 2018-10-30 05:14:50 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:14:50 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:14:50 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:14:50 --> Final output sent to browser
DEBUG - 2018-10-30 05:14:50 --> Total execution time: 0.4826
INFO - 2018-10-30 05:17:12 --> Config Class Initialized
INFO - 2018-10-30 05:17:12 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:12 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:12 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:12 --> URI Class Initialized
INFO - 2018-10-30 05:17:12 --> Router Class Initialized
INFO - 2018-10-30 05:17:12 --> Output Class Initialized
INFO - 2018-10-30 05:17:12 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:12 --> Input Class Initialized
INFO - 2018-10-30 05:17:12 --> Language Class Initialized
INFO - 2018-10-30 05:17:12 --> Loader Class Initialized
INFO - 2018-10-30 05:17:12 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:12 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:12 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:12 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:12 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:12 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:12 --> Email Class Initialized
INFO - 2018-10-30 05:17:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:12 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:12 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:12 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:12 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:12 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:12 --> Controller Class Initialized
INFO - 2018-10-30 05:17:12 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:12 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:12 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:12 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:12 --> Total execution time: 0.4941
INFO - 2018-10-30 05:17:13 --> Config Class Initialized
INFO - 2018-10-30 05:17:13 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:13 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:13 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:13 --> URI Class Initialized
INFO - 2018-10-30 05:17:13 --> Router Class Initialized
INFO - 2018-10-30 05:17:13 --> Output Class Initialized
INFO - 2018-10-30 05:17:13 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:13 --> Input Class Initialized
INFO - 2018-10-30 05:17:13 --> Language Class Initialized
INFO - 2018-10-30 05:17:13 --> Loader Class Initialized
INFO - 2018-10-30 05:17:13 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:13 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:13 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:13 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:13 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:13 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:13 --> Email Class Initialized
INFO - 2018-10-30 05:17:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:13 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:13 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:13 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:13 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:13 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:13 --> Controller Class Initialized
INFO - 2018-10-30 05:17:14 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:14 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:14 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:14 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:14 --> Total execution time: 0.4958
INFO - 2018-10-30 05:17:15 --> Config Class Initialized
INFO - 2018-10-30 05:17:15 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:15 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:15 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:15 --> URI Class Initialized
INFO - 2018-10-30 05:17:15 --> Router Class Initialized
INFO - 2018-10-30 05:17:15 --> Output Class Initialized
INFO - 2018-10-30 05:17:15 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:15 --> Input Class Initialized
INFO - 2018-10-30 05:17:15 --> Language Class Initialized
INFO - 2018-10-30 05:17:15 --> Loader Class Initialized
INFO - 2018-10-30 05:17:15 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:15 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:15 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:15 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:15 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:15 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:15 --> Email Class Initialized
INFO - 2018-10-30 05:17:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:15 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:15 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:16 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:16 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:16 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:16 --> Controller Class Initialized
INFO - 2018-10-30 05:17:16 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:16 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:16 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:16 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:16 --> Total execution time: 0.5249
INFO - 2018-10-30 05:17:17 --> Config Class Initialized
INFO - 2018-10-30 05:17:17 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:17 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:17 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:17 --> URI Class Initialized
INFO - 2018-10-30 05:17:17 --> Router Class Initialized
INFO - 2018-10-30 05:17:18 --> Output Class Initialized
INFO - 2018-10-30 05:17:18 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:18 --> Input Class Initialized
INFO - 2018-10-30 05:17:18 --> Language Class Initialized
INFO - 2018-10-30 05:17:18 --> Loader Class Initialized
INFO - 2018-10-30 05:17:18 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:18 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:18 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:18 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:18 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:18 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:18 --> Email Class Initialized
INFO - 2018-10-30 05:17:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:18 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:18 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:18 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:18 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:18 --> Controller Class Initialized
INFO - 2018-10-30 05:17:18 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:18 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:18 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:18 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:18 --> Total execution time: 0.4965
INFO - 2018-10-30 05:17:40 --> Config Class Initialized
INFO - 2018-10-30 05:17:40 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:40 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:40 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:40 --> URI Class Initialized
INFO - 2018-10-30 05:17:40 --> Router Class Initialized
INFO - 2018-10-30 05:17:40 --> Output Class Initialized
INFO - 2018-10-30 05:17:40 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:40 --> Input Class Initialized
INFO - 2018-10-30 05:17:40 --> Language Class Initialized
INFO - 2018-10-30 05:17:40 --> Loader Class Initialized
INFO - 2018-10-30 05:17:40 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:40 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:40 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:40 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:41 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:41 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:41 --> Email Class Initialized
INFO - 2018-10-30 05:17:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:41 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:41 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:41 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:41 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:41 --> Controller Class Initialized
INFO - 2018-10-30 05:17:41 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:41 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:41 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:41 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:41 --> Total execution time: 0.4893
INFO - 2018-10-30 05:17:42 --> Config Class Initialized
INFO - 2018-10-30 05:17:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:42 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:42 --> URI Class Initialized
INFO - 2018-10-30 05:17:43 --> Router Class Initialized
INFO - 2018-10-30 05:17:43 --> Output Class Initialized
INFO - 2018-10-30 05:17:43 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:43 --> Input Class Initialized
INFO - 2018-10-30 05:17:43 --> Language Class Initialized
INFO - 2018-10-30 05:17:43 --> Loader Class Initialized
INFO - 2018-10-30 05:17:43 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:43 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:43 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:43 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:43 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:43 --> Email Class Initialized
INFO - 2018-10-30 05:17:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:43 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:43 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:43 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:43 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:43 --> Controller Class Initialized
INFO - 2018-10-30 05:17:43 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:43 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:43 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:43 --> Total execution time: 0.4794
INFO - 2018-10-30 05:17:50 --> Config Class Initialized
INFO - 2018-10-30 05:17:50 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:50 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:50 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:50 --> URI Class Initialized
INFO - 2018-10-30 05:17:50 --> Router Class Initialized
INFO - 2018-10-30 05:17:50 --> Output Class Initialized
INFO - 2018-10-30 05:17:50 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:50 --> Input Class Initialized
INFO - 2018-10-30 05:17:50 --> Language Class Initialized
INFO - 2018-10-30 05:17:50 --> Loader Class Initialized
INFO - 2018-10-30 05:17:50 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:50 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:50 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:50 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:50 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:50 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:50 --> Email Class Initialized
INFO - 2018-10-30 05:17:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:50 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:50 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:50 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:50 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:50 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:50 --> Controller Class Initialized
INFO - 2018-10-30 05:17:50 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:50 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:50 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:50 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:50 --> Total execution time: 0.4805
INFO - 2018-10-30 05:17:51 --> Config Class Initialized
INFO - 2018-10-30 05:17:52 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:52 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:52 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:52 --> URI Class Initialized
INFO - 2018-10-30 05:17:52 --> Router Class Initialized
INFO - 2018-10-30 05:17:52 --> Output Class Initialized
INFO - 2018-10-30 05:17:52 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:52 --> Input Class Initialized
INFO - 2018-10-30 05:17:52 --> Language Class Initialized
INFO - 2018-10-30 05:17:52 --> Loader Class Initialized
INFO - 2018-10-30 05:17:52 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:52 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:52 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:52 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:52 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:52 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:52 --> Email Class Initialized
INFO - 2018-10-30 05:17:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:52 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:52 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:52 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:52 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:52 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:52 --> Controller Class Initialized
INFO - 2018-10-30 05:17:52 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:52 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:52 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:52 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:52 --> Total execution time: 0.4823
INFO - 2018-10-30 05:17:52 --> Config Class Initialized
INFO - 2018-10-30 05:17:53 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:53 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:53 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:53 --> URI Class Initialized
INFO - 2018-10-30 05:17:53 --> Router Class Initialized
INFO - 2018-10-30 05:17:53 --> Output Class Initialized
INFO - 2018-10-30 05:17:53 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:53 --> Input Class Initialized
INFO - 2018-10-30 05:17:53 --> Language Class Initialized
INFO - 2018-10-30 05:17:53 --> Loader Class Initialized
INFO - 2018-10-30 05:17:53 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:53 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:53 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:53 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:53 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:53 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:53 --> Email Class Initialized
INFO - 2018-10-30 05:17:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:53 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:53 --> Config Class Initialized
INFO - 2018-10-30 05:17:53 --> Hooks Class Initialized
INFO - 2018-10-30 05:17:53 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:53 --> UTF-8 Support Enabled
DEBUG - 2018-10-30 05:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:53 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:53 --> URI Class Initialized
INFO - 2018-10-30 05:17:53 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:53 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:53 --> Router Class Initialized
INFO - 2018-10-30 05:17:53 --> Output Class Initialized
INFO - 2018-10-30 05:17:53 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:53 --> Security Class Initialized
INFO - 2018-10-30 05:17:53 --> Controller Class Initialized
DEBUG - 2018-10-30 05:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:53 --> Input Class Initialized
INFO - 2018-10-30 05:17:53 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:53 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:53 --> Language Class Initialized
INFO - 2018-10-30 05:17:53 --> Loader Class Initialized
INFO - 2018-10-30 05:17:53 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:53 --> Final output sent to browser
INFO - 2018-10-30 05:17:53 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:53 --> Config Class Initialized
INFO - 2018-10-30 05:17:53 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:53 --> Total execution time: 0.4879
INFO - 2018-10-30 05:17:53 --> Database Driver Class Initialized
DEBUG - 2018-10-30 05:17:53 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:53 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:53 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:53 --> URI Class Initialized
INFO - 2018-10-30 05:17:53 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:53 --> Router Class Initialized
INFO - 2018-10-30 05:17:53 --> Output Class Initialized
INFO - 2018-10-30 05:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:53 --> Pagination Class Initialized
INFO - 2018-10-30 05:17:53 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-30 05:17:53 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:53 --> Input Class Initialized
INFO - 2018-10-30 05:17:53 --> Email Class Initialized
INFO - 2018-10-30 05:17:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:53 --> Language Class Initialized
INFO - 2018-10-30 05:17:53 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:53 --> Loader Class Initialized
INFO - 2018-10-30 05:17:53 --> Helper loaded: language_helper
INFO - 2018-10-30 05:17:53 --> Helper loaded: url_helper
DEBUG - 2018-10-30 05:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:53 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:53 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:53 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:53 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:53 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:53 --> Config Class Initialized
INFO - 2018-10-30 05:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:53 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 05:17:53 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:53 --> Pagination Class Initialized
INFO - 2018-10-30 05:17:53 --> Controller Class Initialized
DEBUG - 2018-10-30 05:17:53 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
DEBUG - 2018-10-30 05:17:53 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:53 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:53 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:53 --> Email Class Initialized
INFO - 2018-10-30 05:17:53 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:53 --> URI Class Initialized
INFO - 2018-10-30 05:17:53 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:53 --> Router Class Initialized
INFO - 2018-10-30 05:17:53 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:53 --> Final output sent to browser
INFO - 2018-10-30 05:17:53 --> Helper loaded: language_helper
INFO - 2018-10-30 05:17:53 --> Output Class Initialized
DEBUG - 2018-10-30 05:17:53 --> Total execution time: 0.4971
INFO - 2018-10-30 05:17:53 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-30 05:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:53 --> Input Class Initialized
INFO - 2018-10-30 05:17:53 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:53 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:53 --> Language Class Initialized
INFO - 2018-10-30 05:17:53 --> Loader Class Initialized
INFO - 2018-10-30 05:17:53 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:53 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:53 --> Controller Class Initialized
INFO - 2018-10-30 05:17:53 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:53 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:53 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:53 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:53 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:53 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:53 --> Config Class Initialized
INFO - 2018-10-30 05:17:53 --> Hooks Class Initialized
INFO - 2018-10-30 05:17:53 --> Final output sent to browser
INFO - 2018-10-30 05:17:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2018-10-30 05:17:54 --> Total execution time: 0.5074
INFO - 2018-10-30 05:17:54 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:54 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:54 --> Utf8 Class Initialized
DEBUG - 2018-10-30 05:17:54 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:54 --> URI Class Initialized
INFO - 2018-10-30 05:17:54 --> Email Class Initialized
INFO - 2018-10-30 05:17:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:54 --> Router Class Initialized
INFO - 2018-10-30 05:17:54 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:54 --> Output Class Initialized
INFO - 2018-10-30 05:17:54 --> Helper loaded: language_helper
INFO - 2018-10-30 05:17:54 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-30 05:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:54 --> Input Class Initialized
INFO - 2018-10-30 05:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:54 --> Language Class Initialized
INFO - 2018-10-30 05:17:54 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:54 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:54 --> Loader Class Initialized
INFO - 2018-10-30 05:17:54 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:54 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:54 --> Controller Class Initialized
INFO - 2018-10-30 05:17:54 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:54 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:54 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:54 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:54 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:54 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:54 --> Pagination Class Initialized
INFO - 2018-10-30 05:17:54 --> Final output sent to browser
INFO - 2018-10-30 05:17:54 --> Config Class Initialized
DEBUG - 2018-10-30 05:17:54 --> Total execution time: 0.5083
INFO - 2018-10-30 05:17:54 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:17:54 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
DEBUG - 2018-10-30 05:17:54 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:54 --> Email Class Initialized
INFO - 2018-10-30 05:17:54 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:54 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:54 --> URI Class Initialized
INFO - 2018-10-30 05:17:54 --> Helper loaded: language_helper
INFO - 2018-10-30 05:17:54 --> Router Class Initialized
INFO - 2018-10-30 05:17:54 --> Output Class Initialized
DEBUG - 2018-10-30 05:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:54 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:54 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:54 --> Input Class Initialized
INFO - 2018-10-30 05:17:54 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:54 --> Language Class Initialized
INFO - 2018-10-30 05:17:54 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:54 --> Loader Class Initialized
INFO - 2018-10-30 05:17:54 --> Controller Class Initialized
INFO - 2018-10-30 05:17:54 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:54 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:54 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:54 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:54 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:54 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:54 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:54 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:54 --> Total execution time: 0.4863
INFO - 2018-10-30 05:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:54 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:54 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:54 --> Email Class Initialized
INFO - 2018-10-30 05:17:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:54 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:54 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:54 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:54 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:54 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:54 --> Controller Class Initialized
INFO - 2018-10-30 05:17:54 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:54 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:54 --> Config Class Initialized
INFO - 2018-10-30 05:17:54 --> Hooks Class Initialized
INFO - 2018-10-30 05:17:54 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:54 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:54 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:54 --> Utf8 Class Initialized
DEBUG - 2018-10-30 05:17:54 --> Total execution time: 0.4951
INFO - 2018-10-30 05:17:54 --> URI Class Initialized
INFO - 2018-10-30 05:17:54 --> Router Class Initialized
INFO - 2018-10-30 05:17:54 --> Output Class Initialized
INFO - 2018-10-30 05:17:54 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:54 --> Input Class Initialized
INFO - 2018-10-30 05:17:54 --> Language Class Initialized
INFO - 2018-10-30 05:17:54 --> Loader Class Initialized
INFO - 2018-10-30 05:17:54 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:54 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:54 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:54 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:54 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:54 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:54 --> Config Class Initialized
INFO - 2018-10-30 05:17:54 --> Hooks Class Initialized
INFO - 2018-10-30 05:17:54 --> Email Class Initialized
INFO - 2018-10-30 05:17:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2018-10-30 05:17:54 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:55 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:55 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:55 --> Helper loaded: language_helper
INFO - 2018-10-30 05:17:55 --> URI Class Initialized
INFO - 2018-10-30 05:17:55 --> Router Class Initialized
DEBUG - 2018-10-30 05:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:55 --> Output Class Initialized
INFO - 2018-10-30 05:17:55 --> Security Class Initialized
INFO - 2018-10-30 05:17:55 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:55 --> Database Driver Class Initialized
DEBUG - 2018-10-30 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:55 --> Input Class Initialized
INFO - 2018-10-30 05:17:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:55 --> Language Class Initialized
INFO - 2018-10-30 05:17:55 --> Controller Class Initialized
INFO - 2018-10-30 05:17:55 --> Loader Class Initialized
INFO - 2018-10-30 05:17:55 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:55 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:55 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:55 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:55 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:55 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:55 --> Total execution time: 0.4879
INFO - 2018-10-30 05:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:55 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:55 --> Email Class Initialized
INFO - 2018-10-30 05:17:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:55 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:55 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:55 --> Config Class Initialized
INFO - 2018-10-30 05:17:55 --> Hooks Class Initialized
INFO - 2018-10-30 05:17:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-30 05:17:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:55 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:55 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:55 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:55 --> URI Class Initialized
INFO - 2018-10-30 05:17:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:55 --> Router Class Initialized
INFO - 2018-10-30 05:17:55 --> Controller Class Initialized
INFO - 2018-10-30 05:17:55 --> Output Class Initialized
INFO - 2018-10-30 05:17:55 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:55 --> Security Class Initialized
INFO - 2018-10-30 05:17:55 --> Model "Notadetail_model" initialized
DEBUG - 2018-10-30 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:55 --> Input Class Initialized
INFO - 2018-10-30 05:17:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:55 --> Final output sent to browser
INFO - 2018-10-30 05:17:55 --> Language Class Initialized
DEBUG - 2018-10-30 05:17:55 --> Total execution time: 0.4860
INFO - 2018-10-30 05:17:55 --> Loader Class Initialized
INFO - 2018-10-30 05:17:55 --> Config Class Initialized
INFO - 2018-10-30 05:17:55 --> Hooks Class Initialized
INFO - 2018-10-30 05:17:55 --> Helper loaded: url_helper
DEBUG - 2018-10-30 05:17:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:55 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:55 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:55 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:55 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:55 --> URI Class Initialized
INFO - 2018-10-30 05:17:55 --> Router Class Initialized
INFO - 2018-10-30 05:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:55 --> Pagination Class Initialized
INFO - 2018-10-30 05:17:55 --> Output Class Initialized
INFO - 2018-10-30 05:17:55 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
DEBUG - 2018-10-30 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:55 --> Email Class Initialized
INFO - 2018-10-30 05:17:55 --> Input Class Initialized
INFO - 2018-10-30 05:17:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:55 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:55 --> Language Class Initialized
INFO - 2018-10-30 05:17:55 --> Helper loaded: language_helper
INFO - 2018-10-30 05:17:55 --> Loader Class Initialized
INFO - 2018-10-30 05:17:55 --> Helper loaded: url_helper
DEBUG - 2018-10-30 05:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:55 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:55 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:55 --> Config Class Initialized
INFO - 2018-10-30 05:17:55 --> Hooks Class Initialized
INFO - 2018-10-30 05:17:55 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:55 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:55 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:55 --> Utf8 Class Initialized
DEBUG - 2018-10-30 05:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:55 --> Pagination Class Initialized
INFO - 2018-10-30 05:17:55 --> Controller Class Initialized
INFO - 2018-10-30 05:17:55 --> URI Class Initialized
INFO - 2018-10-30 05:17:55 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:55 --> Router Class Initialized
DEBUG - 2018-10-30 05:17:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:55 --> Output Class Initialized
INFO - 2018-10-30 05:17:55 --> Email Class Initialized
INFO - 2018-10-30 05:17:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:55 --> Security Class Initialized
INFO - 2018-10-30 05:17:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:55 --> Final output sent to browser
INFO - 2018-10-30 05:17:55 --> Helper loaded: cookie_helper
DEBUG - 2018-10-30 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:55 --> Input Class Initialized
DEBUG - 2018-10-30 05:17:55 --> Total execution time: 0.4960
INFO - 2018-10-30 05:17:55 --> Helper loaded: language_helper
INFO - 2018-10-30 05:17:55 --> Language Class Initialized
DEBUG - 2018-10-30 05:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:55 --> Loader Class Initialized
INFO - 2018-10-30 05:17:55 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:55 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:55 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:55 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:55 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:55 --> Config Class Initialized
INFO - 2018-10-30 05:17:55 --> Controller Class Initialized
INFO - 2018-10-30 05:17:55 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:55 --> Hooks Class Initialized
INFO - 2018-10-30 05:17:55 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2018-10-30 05:17:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:55 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:55 --> Pagination Class Initialized
INFO - 2018-10-30 05:17:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:55 --> URI Class Initialized
DEBUG - 2018-10-30 05:17:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:17:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:55 --> Final output sent to browser
INFO - 2018-10-30 05:17:55 --> Router Class Initialized
INFO - 2018-10-30 05:17:56 --> Email Class Initialized
DEBUG - 2018-10-30 05:17:56 --> Total execution time: 0.5033
INFO - 2018-10-30 05:17:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:56 --> Output Class Initialized
INFO - 2018-10-30 05:17:56 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:56 --> Security Class Initialized
INFO - 2018-10-30 05:17:56 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:17:56 --> Input Class Initialized
DEBUG - 2018-10-30 05:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:56 --> Language Class Initialized
INFO - 2018-10-30 05:17:56 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:56 --> Loader Class Initialized
INFO - 2018-10-30 05:17:56 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:56 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:56 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:56 --> Controller Class Initialized
INFO - 2018-10-30 05:17:56 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:56 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:56 --> Config Class Initialized
INFO - 2018-10-30 05:17:56 --> Hooks Class Initialized
INFO - 2018-10-30 05:17:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:56 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:17:56 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:17:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:56 --> Utf8 Class Initialized
INFO - 2018-10-30 05:17:56 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:56 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
DEBUG - 2018-10-30 05:17:56 --> Total execution time: 0.4816
INFO - 2018-10-30 05:17:56 --> URI Class Initialized
INFO - 2018-10-30 05:17:56 --> Email Class Initialized
INFO - 2018-10-30 05:17:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:56 --> Router Class Initialized
INFO - 2018-10-30 05:17:56 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:56 --> Output Class Initialized
INFO - 2018-10-30 05:17:56 --> Helper loaded: language_helper
INFO - 2018-10-30 05:17:56 --> Security Class Initialized
DEBUG - 2018-10-30 05:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-30 05:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:56 --> Input Class Initialized
INFO - 2018-10-30 05:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:56 --> Language Class Initialized
INFO - 2018-10-30 05:17:56 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:56 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:56 --> Loader Class Initialized
INFO - 2018-10-30 05:17:56 --> Helper loaded: url_helper
INFO - 2018-10-30 05:17:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:56 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:56 --> Controller Class Initialized
INFO - 2018-10-30 05:17:56 --> Helper loaded: form_helper
INFO - 2018-10-30 05:17:56 --> Form Validation Class Initialized
INFO - 2018-10-30 05:17:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:17:56 --> Pagination Class Initialized
INFO - 2018-10-30 05:17:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:56 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:56 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
DEBUG - 2018-10-30 05:17:56 --> Total execution time: 0.4841
INFO - 2018-10-30 05:17:56 --> Email Class Initialized
INFO - 2018-10-30 05:17:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:17:56 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:17:56 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:17:56 --> Helper loaded: date_helper
INFO - 2018-10-30 05:17:56 --> Database Driver Class Initialized
INFO - 2018-10-30 05:17:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:17:56 --> Controller Class Initialized
INFO - 2018-10-30 05:17:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:17:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:17:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:17:56 --> Final output sent to browser
DEBUG - 2018-10-30 05:17:56 --> Total execution time: 0.5033
INFO - 2018-10-30 05:18:06 --> Config Class Initialized
INFO - 2018-10-30 05:18:06 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:18:06 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:06 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:06 --> URI Class Initialized
INFO - 2018-10-30 05:18:06 --> Router Class Initialized
INFO - 2018-10-30 05:18:06 --> Output Class Initialized
INFO - 2018-10-30 05:18:06 --> Security Class Initialized
DEBUG - 2018-10-30 05:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:06 --> Input Class Initialized
INFO - 2018-10-30 05:18:06 --> Language Class Initialized
INFO - 2018-10-30 05:18:06 --> Loader Class Initialized
INFO - 2018-10-30 05:18:06 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:06 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:06 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:06 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:06 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:18:06 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:06 --> Email Class Initialized
INFO - 2018-10-30 05:18:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:07 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:07 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:07 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:07 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:07 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:07 --> Controller Class Initialized
INFO - 2018-10-30 05:18:07 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:07 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:07 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:07 --> Final output sent to browser
DEBUG - 2018-10-30 05:18:07 --> Total execution time: 0.5445
INFO - 2018-10-30 05:18:08 --> Config Class Initialized
INFO - 2018-10-30 05:18:08 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:18:08 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:08 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:08 --> URI Class Initialized
INFO - 2018-10-30 05:18:08 --> Router Class Initialized
INFO - 2018-10-30 05:18:08 --> Output Class Initialized
INFO - 2018-10-30 05:18:08 --> Security Class Initialized
DEBUG - 2018-10-30 05:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:08 --> Input Class Initialized
INFO - 2018-10-30 05:18:08 --> Language Class Initialized
INFO - 2018-10-30 05:18:08 --> Loader Class Initialized
INFO - 2018-10-30 05:18:08 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:08 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:08 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:08 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:08 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:18:08 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:08 --> Config Class Initialized
INFO - 2018-10-30 05:18:08 --> Hooks Class Initialized
INFO - 2018-10-30 05:18:08 --> Email Class Initialized
INFO - 2018-10-30 05:18:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2018-10-30 05:18:08 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:08 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:08 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:08 --> Helper loaded: language_helper
INFO - 2018-10-30 05:18:08 --> URI Class Initialized
INFO - 2018-10-30 05:18:08 --> Router Class Initialized
DEBUG - 2018-10-30 05:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:08 --> Output Class Initialized
INFO - 2018-10-30 05:18:08 --> Security Class Initialized
INFO - 2018-10-30 05:18:08 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:08 --> Database Driver Class Initialized
DEBUG - 2018-10-30 05:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:08 --> Input Class Initialized
INFO - 2018-10-30 05:18:08 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:08 --> Language Class Initialized
INFO - 2018-10-30 05:18:08 --> Controller Class Initialized
INFO - 2018-10-30 05:18:08 --> Loader Class Initialized
INFO - 2018-10-30 05:18:08 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:08 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:08 --> Config Class Initialized
INFO - 2018-10-30 05:18:08 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:08 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:09 --> Hooks Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:09 --> Final output sent to browser
INFO - 2018-10-30 05:18:09 --> Form Validation Class Initialized
DEBUG - 2018-10-30 05:18:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:09 --> Utf8 Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Total execution time: 0.5103
INFO - 2018-10-30 05:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:09 --> Pagination Class Initialized
INFO - 2018-10-30 05:18:09 --> URI Class Initialized
INFO - 2018-10-30 05:18:09 --> Router Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:09 --> Output Class Initialized
INFO - 2018-10-30 05:18:09 --> Email Class Initialized
INFO - 2018-10-30 05:18:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:09 --> Security Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: cookie_helper
DEBUG - 2018-10-30 05:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:09 --> Input Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: language_helper
INFO - 2018-10-30 05:18:09 --> Language Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:09 --> Loader Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:09 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:09 --> Config Class Initialized
INFO - 2018-10-30 05:18:09 --> Hooks Class Initialized
INFO - 2018-10-30 05:18:09 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:09 --> Database Driver Class Initialized
DEBUG - 2018-10-30 05:18:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:09 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:09 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:09 --> Form Validation Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:09 --> Controller Class Initialized
INFO - 2018-10-30 05:18:09 --> URI Class Initialized
INFO - 2018-10-30 05:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:09 --> Pagination Class Initialized
INFO - 2018-10-30 05:18:09 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:09 --> Router Class Initialized
INFO - 2018-10-30 05:18:09 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:09 --> Output Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:09 --> Security Class Initialized
INFO - 2018-10-30 05:18:09 --> Email Class Initialized
INFO - 2018-10-30 05:18:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:09 --> Final output sent to browser
INFO - 2018-10-30 05:18:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2018-10-30 05:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-30 05:18:09 --> Total execution time: 0.5379
INFO - 2018-10-30 05:18:09 --> Input Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:09 --> Language Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:09 --> Loader Class Initialized
INFO - 2018-10-30 05:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:09 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:09 --> Config Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:09 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:09 --> Hooks Class Initialized
INFO - 2018-10-30 05:18:09 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:09 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:09 --> Utf8 Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:09 --> Pagination Class Initialized
INFO - 2018-10-30 05:18:09 --> Controller Class Initialized
INFO - 2018-10-30 05:18:09 --> URI Class Initialized
INFO - 2018-10-30 05:18:09 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:09 --> Router Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:09 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:09 --> Output Class Initialized
INFO - 2018-10-30 05:18:09 --> Email Class Initialized
INFO - 2018-10-30 05:18:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:09 --> Security Class Initialized
INFO - 2018-10-30 05:18:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:09 --> Final output sent to browser
INFO - 2018-10-30 05:18:09 --> Helper loaded: cookie_helper
DEBUG - 2018-10-30 05:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:09 --> Input Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Total execution time: 0.5480
INFO - 2018-10-30 05:18:09 --> Helper loaded: language_helper
INFO - 2018-10-30 05:18:09 --> Language Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:09 --> Loader Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:09 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:09 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:09 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:09 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:09 --> Config Class Initialized
INFO - 2018-10-30 05:18:09 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:09 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:09 --> Controller Class Initialized
INFO - 2018-10-30 05:18:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2018-10-30 05:18:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:09 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:09 --> Pagination Class Initialized
INFO - 2018-10-30 05:18:09 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:09 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:09 --> URI Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:09 --> Router Class Initialized
INFO - 2018-10-30 05:18:09 --> Email Class Initialized
INFO - 2018-10-30 05:18:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:09 --> Final output sent to browser
INFO - 2018-10-30 05:18:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:09 --> Output Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Total execution time: 0.5175
INFO - 2018-10-30 05:18:09 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:09 --> Security Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:09 --> Input Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:09 --> Language Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:09 --> Loader Class Initialized
INFO - 2018-10-30 05:18:09 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:09 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:09 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 05:18:09 --> Database Driver Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:09 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:09 --> Controller Class Initialized
INFO - 2018-10-30 05:18:09 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:09 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:09 --> Pagination Class Initialized
INFO - 2018-10-30 05:18:09 --> Model "Notadetail_model" initialized
DEBUG - 2018-10-30 05:18:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:09 --> Final output sent to browser
INFO - 2018-10-30 05:18:09 --> Email Class Initialized
DEBUG - 2018-10-30 05:18:09 --> Total execution time: 0.5223
INFO - 2018-10-30 05:18:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:09 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:09 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:10 --> Config Class Initialized
INFO - 2018-10-30 05:18:10 --> Hooks Class Initialized
INFO - 2018-10-30 05:18:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-30 05:18:10 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:10 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:10 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:10 --> URI Class Initialized
INFO - 2018-10-30 05:18:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:10 --> Router Class Initialized
INFO - 2018-10-30 05:18:10 --> Controller Class Initialized
INFO - 2018-10-30 05:18:10 --> Output Class Initialized
INFO - 2018-10-30 05:18:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:10 --> Security Class Initialized
INFO - 2018-10-30 05:18:10 --> Model "Notadetail_model" initialized
DEBUG - 2018-10-30 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:10 --> Input Class Initialized
INFO - 2018-10-30 05:18:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:10 --> Final output sent to browser
INFO - 2018-10-30 05:18:10 --> Language Class Initialized
DEBUG - 2018-10-30 05:18:10 --> Total execution time: 0.5326
INFO - 2018-10-30 05:18:10 --> Loader Class Initialized
INFO - 2018-10-30 05:18:10 --> Config Class Initialized
INFO - 2018-10-30 05:18:10 --> Hooks Class Initialized
INFO - 2018-10-30 05:18:10 --> Helper loaded: url_helper
DEBUG - 2018-10-30 05:18:10 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:10 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:10 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:10 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:10 --> URI Class Initialized
INFO - 2018-10-30 05:18:10 --> Router Class Initialized
INFO - 2018-10-30 05:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:10 --> Pagination Class Initialized
INFO - 2018-10-30 05:18:10 --> Output Class Initialized
INFO - 2018-10-30 05:18:10 --> Security Class Initialized
DEBUG - 2018-10-30 05:18:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
DEBUG - 2018-10-30 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:10 --> Email Class Initialized
INFO - 2018-10-30 05:18:10 --> Input Class Initialized
INFO - 2018-10-30 05:18:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:10 --> Language Class Initialized
INFO - 2018-10-30 05:18:10 --> Helper loaded: language_helper
INFO - 2018-10-30 05:18:10 --> Loader Class Initialized
INFO - 2018-10-30 05:18:10 --> Helper loaded: url_helper
DEBUG - 2018-10-30 05:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:10 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:10 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:10 --> Config Class Initialized
INFO - 2018-10-30 05:18:10 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:10 --> Hooks Class Initialized
INFO - 2018-10-30 05:18:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:10 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:10 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:10 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:10 --> Controller Class Initialized
INFO - 2018-10-30 05:18:10 --> URI Class Initialized
DEBUG - 2018-10-30 05:18:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:10 --> Router Class Initialized
INFO - 2018-10-30 05:18:10 --> Email Class Initialized
INFO - 2018-10-30 05:18:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:10 --> Output Class Initialized
INFO - 2018-10-30 05:18:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:10 --> Security Class Initialized
INFO - 2018-10-30 05:18:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:10 --> Final output sent to browser
INFO - 2018-10-30 05:18:10 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:10 --> Input Class Initialized
DEBUG - 2018-10-30 05:18:10 --> Total execution time: 0.5087
DEBUG - 2018-10-30 05:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:10 --> Language Class Initialized
INFO - 2018-10-30 05:18:10 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:10 --> Loader Class Initialized
INFO - 2018-10-30 05:18:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:10 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:10 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 05:18:10 --> Database Driver Class Initialized
DEBUG - 2018-10-30 05:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:10 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:10 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:10 --> Controller Class Initialized
INFO - 2018-10-30 05:18:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:10 --> Pagination Class Initialized
INFO - 2018-10-30 05:18:10 --> Model "Notadetail_model" initialized
DEBUG - 2018-10-30 05:18:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:10 --> Final output sent to browser
INFO - 2018-10-30 05:18:10 --> Email Class Initialized
DEBUG - 2018-10-30 05:18:10 --> Total execution time: 0.5039
INFO - 2018-10-30 05:18:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:10 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:10 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:10 --> Controller Class Initialized
INFO - 2018-10-30 05:18:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:10 --> Final output sent to browser
DEBUG - 2018-10-30 05:18:10 --> Total execution time: 0.5184
INFO - 2018-10-30 05:18:14 --> Config Class Initialized
INFO - 2018-10-30 05:18:14 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:18:14 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:14 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:14 --> URI Class Initialized
INFO - 2018-10-30 05:18:14 --> Router Class Initialized
INFO - 2018-10-30 05:18:14 --> Output Class Initialized
INFO - 2018-10-30 05:18:14 --> Security Class Initialized
DEBUG - 2018-10-30 05:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:14 --> Input Class Initialized
INFO - 2018-10-30 05:18:14 --> Language Class Initialized
INFO - 2018-10-30 05:18:14 --> Loader Class Initialized
INFO - 2018-10-30 05:18:14 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:14 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:14 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:14 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:14 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:18:14 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:14 --> Email Class Initialized
INFO - 2018-10-30 05:18:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:14 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:14 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:14 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:14 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:14 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:14 --> Controller Class Initialized
INFO - 2018-10-30 05:18:14 --> Model "Item_model" initialized
INFO - 2018-10-30 05:18:14 --> Model "Jenis_model" initialized
INFO - 2018-10-30 05:18:14 --> Model "Vendor_model" initialized
INFO - 2018-10-30 05:18:15 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:15 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:15 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 05:18:15 --> Final output sent to browser
DEBUG - 2018-10-30 05:18:15 --> Total execution time: 0.6054
INFO - 2018-10-30 05:18:15 --> Config Class Initialized
INFO - 2018-10-30 05:18:15 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:18:15 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:15 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:15 --> URI Class Initialized
INFO - 2018-10-30 05:18:15 --> Router Class Initialized
INFO - 2018-10-30 05:18:15 --> Output Class Initialized
INFO - 2018-10-30 05:18:15 --> Security Class Initialized
DEBUG - 2018-10-30 05:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:16 --> Input Class Initialized
INFO - 2018-10-30 05:18:16 --> Language Class Initialized
INFO - 2018-10-30 05:18:16 --> Loader Class Initialized
INFO - 2018-10-30 05:18:16 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:16 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:16 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:16 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:16 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:18:16 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:16 --> Email Class Initialized
INFO - 2018-10-30 05:18:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:16 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:16 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:16 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:16 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:16 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:16 --> Controller Class Initialized
INFO - 2018-10-30 05:18:16 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:16 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:16 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:16 --> Final output sent to browser
DEBUG - 2018-10-30 05:18:16 --> Total execution time: 0.5537
INFO - 2018-10-30 05:18:22 --> Config Class Initialized
INFO - 2018-10-30 05:18:22 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:18:22 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:22 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:22 --> URI Class Initialized
INFO - 2018-10-30 05:18:22 --> Router Class Initialized
INFO - 2018-10-30 05:18:22 --> Output Class Initialized
INFO - 2018-10-30 05:18:22 --> Security Class Initialized
DEBUG - 2018-10-30 05:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:22 --> Input Class Initialized
INFO - 2018-10-30 05:18:22 --> Language Class Initialized
INFO - 2018-10-30 05:18:22 --> Loader Class Initialized
INFO - 2018-10-30 05:18:22 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:22 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:23 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:23 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:23 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:18:23 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:23 --> Email Class Initialized
INFO - 2018-10-30 05:18:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:23 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:23 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:23 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:23 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:23 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:23 --> Controller Class Initialized
INFO - 2018-10-30 05:18:23 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:23 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:23 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:23 --> Final output sent to browser
DEBUG - 2018-10-30 05:18:23 --> Total execution time: 0.5638
INFO - 2018-10-30 05:18:24 --> Config Class Initialized
INFO - 2018-10-30 05:18:24 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:18:24 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:24 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:24 --> URI Class Initialized
INFO - 2018-10-30 05:18:24 --> Router Class Initialized
INFO - 2018-10-30 05:18:24 --> Output Class Initialized
INFO - 2018-10-30 05:18:24 --> Security Class Initialized
DEBUG - 2018-10-30 05:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:24 --> Input Class Initialized
INFO - 2018-10-30 05:18:24 --> Language Class Initialized
INFO - 2018-10-30 05:18:24 --> Loader Class Initialized
INFO - 2018-10-30 05:18:24 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:24 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:24 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:24 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:24 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:18:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:24 --> Email Class Initialized
INFO - 2018-10-30 05:18:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:24 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:24 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:25 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:25 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:25 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:25 --> Controller Class Initialized
INFO - 2018-10-30 05:18:25 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:25 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:25 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:25 --> Final output sent to browser
DEBUG - 2018-10-30 05:18:25 --> Total execution time: 0.5267
INFO - 2018-10-30 05:18:25 --> Config Class Initialized
INFO - 2018-10-30 05:18:25 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:18:25 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:25 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:25 --> URI Class Initialized
INFO - 2018-10-30 05:18:25 --> Router Class Initialized
INFO - 2018-10-30 05:18:25 --> Output Class Initialized
INFO - 2018-10-30 05:18:25 --> Security Class Initialized
DEBUG - 2018-10-30 05:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:25 --> Input Class Initialized
INFO - 2018-10-30 05:18:25 --> Language Class Initialized
INFO - 2018-10-30 05:18:25 --> Loader Class Initialized
INFO - 2018-10-30 05:18:25 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:25 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:25 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:25 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:25 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:18:25 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:25 --> Email Class Initialized
INFO - 2018-10-30 05:18:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:25 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:25 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:26 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:26 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:26 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:26 --> Controller Class Initialized
INFO - 2018-10-30 05:18:26 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:26 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:26 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:26 --> Final output sent to browser
DEBUG - 2018-10-30 05:18:26 --> Total execution time: 0.5541
INFO - 2018-10-30 05:18:26 --> Config Class Initialized
INFO - 2018-10-30 05:18:26 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:18:26 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:18:26 --> Utf8 Class Initialized
INFO - 2018-10-30 05:18:26 --> URI Class Initialized
INFO - 2018-10-30 05:18:26 --> Router Class Initialized
INFO - 2018-10-30 05:18:26 --> Output Class Initialized
INFO - 2018-10-30 05:18:26 --> Security Class Initialized
DEBUG - 2018-10-30 05:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:18:26 --> Input Class Initialized
INFO - 2018-10-30 05:18:26 --> Language Class Initialized
INFO - 2018-10-30 05:18:26 --> Loader Class Initialized
INFO - 2018-10-30 05:18:26 --> Helper loaded: url_helper
INFO - 2018-10-30 05:18:26 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:26 --> Helper loaded: form_helper
INFO - 2018-10-30 05:18:26 --> Form Validation Class Initialized
INFO - 2018-10-30 05:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:18:26 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:18:26 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:18:26 --> Email Class Initialized
INFO - 2018-10-30 05:18:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:18:26 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:18:26 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:18:26 --> Helper loaded: date_helper
INFO - 2018-10-30 05:18:26 --> Database Driver Class Initialized
INFO - 2018-10-30 05:18:26 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:18:26 --> Controller Class Initialized
INFO - 2018-10-30 05:18:26 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:18:26 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:18:26 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:18:26 --> Final output sent to browser
DEBUG - 2018-10-30 05:18:26 --> Total execution time: 0.5548
INFO - 2018-10-30 05:20:45 --> Config Class Initialized
INFO - 2018-10-30 05:20:45 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:20:45 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:20:45 --> Utf8 Class Initialized
INFO - 2018-10-30 05:20:45 --> URI Class Initialized
INFO - 2018-10-30 05:20:45 --> Router Class Initialized
INFO - 2018-10-30 05:20:45 --> Output Class Initialized
INFO - 2018-10-30 05:20:45 --> Security Class Initialized
DEBUG - 2018-10-30 05:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:20:45 --> Input Class Initialized
INFO - 2018-10-30 05:20:45 --> Language Class Initialized
INFO - 2018-10-30 05:20:45 --> Loader Class Initialized
INFO - 2018-10-30 05:20:45 --> Helper loaded: url_helper
INFO - 2018-10-30 05:20:45 --> Database Driver Class Initialized
INFO - 2018-10-30 05:20:45 --> Helper loaded: form_helper
INFO - 2018-10-30 05:20:45 --> Form Validation Class Initialized
INFO - 2018-10-30 05:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:20:45 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:20:45 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:20:45 --> Email Class Initialized
INFO - 2018-10-30 05:20:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:20:45 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:20:45 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:20:45 --> Helper loaded: date_helper
INFO - 2018-10-30 05:20:45 --> Database Driver Class Initialized
INFO - 2018-10-30 05:20:45 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:20:45 --> Controller Class Initialized
INFO - 2018-10-30 05:20:45 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:20:45 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 05:20:45 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 68
ERROR - 2018-10-30 05:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 05:20:45 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 68
ERROR - 2018-10-30 05:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
ERROR - 2018-10-30 05:20:45 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 68
ERROR - 2018-10-30 05:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 69
INFO - 2018-10-30 05:20:45 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:20:45 --> Final output sent to browser
DEBUG - 2018-10-30 05:20:45 --> Total execution time: 0.6238
INFO - 2018-10-30 05:21:41 --> Config Class Initialized
INFO - 2018-10-30 05:21:41 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:21:41 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:21:41 --> Utf8 Class Initialized
INFO - 2018-10-30 05:21:41 --> URI Class Initialized
INFO - 2018-10-30 05:21:41 --> Router Class Initialized
INFO - 2018-10-30 05:21:41 --> Output Class Initialized
INFO - 2018-10-30 05:21:41 --> Security Class Initialized
DEBUG - 2018-10-30 05:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:21:41 --> Input Class Initialized
INFO - 2018-10-30 05:21:41 --> Language Class Initialized
INFO - 2018-10-30 05:21:41 --> Loader Class Initialized
INFO - 2018-10-30 05:21:41 --> Helper loaded: url_helper
INFO - 2018-10-30 05:21:41 --> Database Driver Class Initialized
INFO - 2018-10-30 05:21:41 --> Helper loaded: form_helper
INFO - 2018-10-30 05:21:41 --> Form Validation Class Initialized
INFO - 2018-10-30 05:21:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:21:41 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:21:41 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:21:41 --> Email Class Initialized
INFO - 2018-10-30 05:21:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:21:41 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:21:41 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:21:41 --> Helper loaded: date_helper
INFO - 2018-10-30 05:21:41 --> Database Driver Class Initialized
INFO - 2018-10-30 05:21:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:21:41 --> Controller Class Initialized
INFO - 2018-10-30 05:21:41 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:21:41 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 05:21:41 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 75
ERROR - 2018-10-30 05:21:41 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 75
ERROR - 2018-10-30 05:21:41 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 75
INFO - 2018-10-30 05:21:41 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:21:41 --> Final output sent to browser
DEBUG - 2018-10-30 05:21:41 --> Total execution time: 0.5771
INFO - 2018-10-30 05:21:50 --> Config Class Initialized
INFO - 2018-10-30 05:21:50 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:21:50 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:21:50 --> Utf8 Class Initialized
INFO - 2018-10-30 05:21:50 --> URI Class Initialized
INFO - 2018-10-30 05:21:50 --> Router Class Initialized
INFO - 2018-10-30 05:21:50 --> Output Class Initialized
INFO - 2018-10-30 05:21:50 --> Security Class Initialized
DEBUG - 2018-10-30 05:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:21:50 --> Input Class Initialized
INFO - 2018-10-30 05:21:50 --> Language Class Initialized
INFO - 2018-10-30 05:21:50 --> Loader Class Initialized
INFO - 2018-10-30 05:21:50 --> Helper loaded: url_helper
INFO - 2018-10-30 05:21:50 --> Database Driver Class Initialized
INFO - 2018-10-30 05:21:50 --> Helper loaded: form_helper
INFO - 2018-10-30 05:21:50 --> Form Validation Class Initialized
INFO - 2018-10-30 05:21:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:21:50 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:21:50 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:21:50 --> Email Class Initialized
INFO - 2018-10-30 05:21:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:21:50 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:21:50 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:21:50 --> Helper loaded: date_helper
INFO - 2018-10-30 05:21:50 --> Database Driver Class Initialized
INFO - 2018-10-30 05:21:50 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:21:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:21:50 --> Controller Class Initialized
INFO - 2018-10-30 05:21:50 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:21:50 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 05:21:50 --> Severity: Notice --> Undefined index: no_nota D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 75
ERROR - 2018-10-30 05:21:50 --> Severity: Notice --> Undefined index: no_nota D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 75
ERROR - 2018-10-30 05:21:50 --> Severity: Notice --> Undefined index: no_nota D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 75
INFO - 2018-10-30 05:21:50 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:21:50 --> Final output sent to browser
DEBUG - 2018-10-30 05:21:51 --> Total execution time: 0.5908
INFO - 2018-10-30 05:21:59 --> Config Class Initialized
INFO - 2018-10-30 05:21:59 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:21:59 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:21:59 --> Utf8 Class Initialized
INFO - 2018-10-30 05:21:59 --> URI Class Initialized
INFO - 2018-10-30 05:21:59 --> Router Class Initialized
INFO - 2018-10-30 05:21:59 --> Output Class Initialized
INFO - 2018-10-30 05:21:59 --> Security Class Initialized
DEBUG - 2018-10-30 05:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:21:59 --> Input Class Initialized
INFO - 2018-10-30 05:21:59 --> Language Class Initialized
INFO - 2018-10-30 05:21:59 --> Loader Class Initialized
INFO - 2018-10-30 05:21:59 --> Helper loaded: url_helper
INFO - 2018-10-30 05:21:59 --> Database Driver Class Initialized
INFO - 2018-10-30 05:21:59 --> Helper loaded: form_helper
INFO - 2018-10-30 05:21:59 --> Form Validation Class Initialized
INFO - 2018-10-30 05:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:21:59 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:21:59 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:21:59 --> Email Class Initialized
INFO - 2018-10-30 05:21:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:21:59 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:21:59 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:21:59 --> Helper loaded: date_helper
INFO - 2018-10-30 05:21:59 --> Database Driver Class Initialized
INFO - 2018-10-30 05:21:59 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:21:59 --> Controller Class Initialized
INFO - 2018-10-30 05:21:59 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:21:59 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:21:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:21:59 --> Final output sent to browser
DEBUG - 2018-10-30 05:21:59 --> Total execution time: 0.5349
INFO - 2018-10-30 05:24:42 --> Config Class Initialized
INFO - 2018-10-30 05:24:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:24:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:24:42 --> Utf8 Class Initialized
INFO - 2018-10-30 05:24:42 --> URI Class Initialized
INFO - 2018-10-30 05:24:42 --> Router Class Initialized
INFO - 2018-10-30 05:24:42 --> Output Class Initialized
INFO - 2018-10-30 05:24:42 --> Security Class Initialized
DEBUG - 2018-10-30 05:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:24:42 --> Input Class Initialized
INFO - 2018-10-30 05:24:42 --> Language Class Initialized
INFO - 2018-10-30 05:24:42 --> Loader Class Initialized
INFO - 2018-10-30 05:24:42 --> Helper loaded: url_helper
INFO - 2018-10-30 05:24:42 --> Database Driver Class Initialized
INFO - 2018-10-30 05:24:42 --> Helper loaded: form_helper
INFO - 2018-10-30 05:24:42 --> Form Validation Class Initialized
INFO - 2018-10-30 05:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:24:43 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:24:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:24:43 --> Email Class Initialized
INFO - 2018-10-30 05:24:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:24:43 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:24:43 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:24:43 --> Helper loaded: date_helper
INFO - 2018-10-30 05:24:43 --> Database Driver Class Initialized
INFO - 2018-10-30 05:24:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:24:43 --> Controller Class Initialized
INFO - 2018-10-30 05:24:43 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:24:43 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 05:24:43 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 78
ERROR - 2018-10-30 05:24:43 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 79
ERROR - 2018-10-30 05:24:43 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 78
ERROR - 2018-10-30 05:24:43 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 79
ERROR - 2018-10-30 05:24:43 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 78
ERROR - 2018-10-30 05:24:43 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 79
INFO - 2018-10-30 05:24:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:24:43 --> Final output sent to browser
DEBUG - 2018-10-30 05:24:43 --> Total execution time: 0.6625
INFO - 2018-10-30 05:26:18 --> Config Class Initialized
INFO - 2018-10-30 05:26:18 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:26:18 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:26:18 --> Utf8 Class Initialized
INFO - 2018-10-30 05:26:18 --> URI Class Initialized
INFO - 2018-10-30 05:26:18 --> Router Class Initialized
INFO - 2018-10-30 05:26:18 --> Output Class Initialized
INFO - 2018-10-30 05:26:18 --> Security Class Initialized
DEBUG - 2018-10-30 05:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:26:18 --> Input Class Initialized
INFO - 2018-10-30 05:26:18 --> Language Class Initialized
INFO - 2018-10-30 05:26:18 --> Loader Class Initialized
INFO - 2018-10-30 05:26:18 --> Helper loaded: url_helper
INFO - 2018-10-30 05:26:18 --> Database Driver Class Initialized
INFO - 2018-10-30 05:26:18 --> Helper loaded: form_helper
INFO - 2018-10-30 05:26:18 --> Form Validation Class Initialized
INFO - 2018-10-30 05:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:26:18 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:26:18 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:26:18 --> Email Class Initialized
INFO - 2018-10-30 05:26:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:26:18 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:26:18 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:26:18 --> Helper loaded: date_helper
INFO - 2018-10-30 05:26:18 --> Database Driver Class Initialized
INFO - 2018-10-30 05:26:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:26:18 --> Controller Class Initialized
INFO - 2018-10-30 05:26:18 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:26:18 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:26:18 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:26:18 --> Final output sent to browser
DEBUG - 2018-10-30 05:26:18 --> Total execution time: 0.5463
INFO - 2018-10-30 05:26:59 --> Config Class Initialized
INFO - 2018-10-30 05:26:59 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:26:59 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:26:59 --> Utf8 Class Initialized
INFO - 2018-10-30 05:26:59 --> URI Class Initialized
INFO - 2018-10-30 05:26:59 --> Router Class Initialized
INFO - 2018-10-30 05:26:59 --> Output Class Initialized
INFO - 2018-10-30 05:26:59 --> Security Class Initialized
DEBUG - 2018-10-30 05:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:26:59 --> Input Class Initialized
INFO - 2018-10-30 05:26:59 --> Language Class Initialized
INFO - 2018-10-30 05:26:59 --> Loader Class Initialized
INFO - 2018-10-30 05:27:00 --> Helper loaded: url_helper
INFO - 2018-10-30 05:27:00 --> Database Driver Class Initialized
INFO - 2018-10-30 05:27:00 --> Helper loaded: form_helper
INFO - 2018-10-30 05:27:00 --> Form Validation Class Initialized
INFO - 2018-10-30 05:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:27:00 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:27:00 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:27:00 --> Email Class Initialized
INFO - 2018-10-30 05:27:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:27:00 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:27:00 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:27:00 --> Helper loaded: date_helper
INFO - 2018-10-30 05:27:00 --> Database Driver Class Initialized
INFO - 2018-10-30 05:27:00 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:27:00 --> Controller Class Initialized
INFO - 2018-10-30 05:27:00 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:27:00 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:27:00 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:27:00 --> Final output sent to browser
DEBUG - 2018-10-30 05:27:00 --> Total execution time: 0.5509
INFO - 2018-10-30 05:28:43 --> Config Class Initialized
INFO - 2018-10-30 05:28:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:28:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:28:43 --> Utf8 Class Initialized
INFO - 2018-10-30 05:28:43 --> URI Class Initialized
INFO - 2018-10-30 05:28:43 --> Router Class Initialized
INFO - 2018-10-30 05:28:43 --> Output Class Initialized
INFO - 2018-10-30 05:28:43 --> Security Class Initialized
DEBUG - 2018-10-30 05:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:28:43 --> Input Class Initialized
INFO - 2018-10-30 05:28:43 --> Language Class Initialized
INFO - 2018-10-30 05:28:43 --> Loader Class Initialized
INFO - 2018-10-30 05:28:43 --> Helper loaded: url_helper
INFO - 2018-10-30 05:28:43 --> Database Driver Class Initialized
INFO - 2018-10-30 05:28:44 --> Helper loaded: form_helper
INFO - 2018-10-30 05:28:44 --> Form Validation Class Initialized
INFO - 2018-10-30 05:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:28:44 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:28:44 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:28:44 --> Email Class Initialized
INFO - 2018-10-30 05:28:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:28:44 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:28:44 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:28:44 --> Helper loaded: date_helper
INFO - 2018-10-30 05:28:44 --> Database Driver Class Initialized
INFO - 2018-10-30 05:28:44 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:28:44 --> Controller Class Initialized
INFO - 2018-10-30 05:28:44 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:28:44 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:28:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:28:44 --> Final output sent to browser
DEBUG - 2018-10-30 05:28:44 --> Total execution time: 0.5469
INFO - 2018-10-30 05:29:00 --> Config Class Initialized
INFO - 2018-10-30 05:29:00 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:29:00 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:29:00 --> Utf8 Class Initialized
INFO - 2018-10-30 05:29:00 --> URI Class Initialized
INFO - 2018-10-30 05:29:00 --> Router Class Initialized
INFO - 2018-10-30 05:29:00 --> Output Class Initialized
INFO - 2018-10-30 05:29:00 --> Security Class Initialized
DEBUG - 2018-10-30 05:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:29:00 --> Input Class Initialized
INFO - 2018-10-30 05:29:00 --> Language Class Initialized
INFO - 2018-10-30 05:29:00 --> Loader Class Initialized
INFO - 2018-10-30 05:29:00 --> Helper loaded: url_helper
INFO - 2018-10-30 05:29:00 --> Database Driver Class Initialized
INFO - 2018-10-30 05:29:00 --> Helper loaded: form_helper
INFO - 2018-10-30 05:29:00 --> Form Validation Class Initialized
INFO - 2018-10-30 05:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:29:00 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:29:00 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:29:00 --> Email Class Initialized
INFO - 2018-10-30 05:29:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:29:00 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:29:00 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:29:00 --> Helper loaded: date_helper
INFO - 2018-10-30 05:29:00 --> Database Driver Class Initialized
INFO - 2018-10-30 05:29:00 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:29:00 --> Controller Class Initialized
INFO - 2018-10-30 05:29:00 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:29:00 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:29:00 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:29:00 --> Final output sent to browser
DEBUG - 2018-10-30 05:29:00 --> Total execution time: 0.5873
INFO - 2018-10-30 05:29:51 --> Config Class Initialized
INFO - 2018-10-30 05:29:51 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:29:51 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:29:51 --> Utf8 Class Initialized
INFO - 2018-10-30 05:29:51 --> URI Class Initialized
INFO - 2018-10-30 05:29:51 --> Router Class Initialized
INFO - 2018-10-30 05:29:51 --> Output Class Initialized
INFO - 2018-10-30 05:29:51 --> Security Class Initialized
DEBUG - 2018-10-30 05:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:29:51 --> Input Class Initialized
INFO - 2018-10-30 05:29:51 --> Language Class Initialized
INFO - 2018-10-30 05:29:51 --> Loader Class Initialized
INFO - 2018-10-30 05:29:51 --> Helper loaded: url_helper
INFO - 2018-10-30 05:29:51 --> Database Driver Class Initialized
INFO - 2018-10-30 05:29:51 --> Helper loaded: form_helper
INFO - 2018-10-30 05:29:51 --> Form Validation Class Initialized
INFO - 2018-10-30 05:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:29:51 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:29:51 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:29:51 --> Email Class Initialized
INFO - 2018-10-30 05:29:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:29:51 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:29:51 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:29:51 --> Helper loaded: date_helper
INFO - 2018-10-30 05:29:51 --> Database Driver Class Initialized
INFO - 2018-10-30 05:29:51 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:29:51 --> Controller Class Initialized
INFO - 2018-10-30 05:29:51 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:29:51 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:29:51 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:29:51 --> Final output sent to browser
DEBUG - 2018-10-30 05:29:51 --> Total execution time: 0.5274
INFO - 2018-10-30 05:30:25 --> Config Class Initialized
INFO - 2018-10-30 05:30:25 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:30:25 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:30:25 --> Utf8 Class Initialized
INFO - 2018-10-30 05:30:25 --> URI Class Initialized
INFO - 2018-10-30 05:30:25 --> Router Class Initialized
INFO - 2018-10-30 05:30:25 --> Output Class Initialized
INFO - 2018-10-30 05:30:25 --> Security Class Initialized
DEBUG - 2018-10-30 05:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:30:25 --> Input Class Initialized
INFO - 2018-10-30 05:30:25 --> Language Class Initialized
INFO - 2018-10-30 05:30:25 --> Loader Class Initialized
INFO - 2018-10-30 05:30:25 --> Helper loaded: url_helper
INFO - 2018-10-30 05:30:25 --> Database Driver Class Initialized
INFO - 2018-10-30 05:30:25 --> Helper loaded: form_helper
INFO - 2018-10-30 05:30:25 --> Form Validation Class Initialized
INFO - 2018-10-30 05:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:30:25 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:30:25 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:30:25 --> Email Class Initialized
INFO - 2018-10-30 05:30:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:30:25 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:30:25 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:30:25 --> Helper loaded: date_helper
INFO - 2018-10-30 05:30:25 --> Database Driver Class Initialized
INFO - 2018-10-30 05:30:25 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:30:25 --> Controller Class Initialized
INFO - 2018-10-30 05:30:25 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:30:25 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:30:25 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:30:25 --> Final output sent to browser
DEBUG - 2018-10-30 05:30:26 --> Total execution time: 0.5583
INFO - 2018-10-30 05:30:27 --> Config Class Initialized
INFO - 2018-10-30 05:30:27 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:30:27 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:30:27 --> Utf8 Class Initialized
INFO - 2018-10-30 05:30:27 --> URI Class Initialized
INFO - 2018-10-30 05:30:27 --> Router Class Initialized
INFO - 2018-10-30 05:30:27 --> Output Class Initialized
INFO - 2018-10-30 05:30:27 --> Security Class Initialized
DEBUG - 2018-10-30 05:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:30:27 --> Input Class Initialized
INFO - 2018-10-30 05:30:27 --> Language Class Initialized
INFO - 2018-10-30 05:30:27 --> Loader Class Initialized
INFO - 2018-10-30 05:30:27 --> Helper loaded: url_helper
INFO - 2018-10-30 05:30:27 --> Database Driver Class Initialized
INFO - 2018-10-30 05:30:27 --> Helper loaded: form_helper
INFO - 2018-10-30 05:30:27 --> Form Validation Class Initialized
INFO - 2018-10-30 05:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:30:27 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:30:27 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:30:27 --> Email Class Initialized
INFO - 2018-10-30 05:30:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:30:27 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:30:27 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:30:27 --> Helper loaded: date_helper
INFO - 2018-10-30 05:30:27 --> Database Driver Class Initialized
INFO - 2018-10-30 05:30:27 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:30:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:30:27 --> Controller Class Initialized
INFO - 2018-10-30 05:30:27 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:30:27 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:30:27 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:30:27 --> Final output sent to browser
DEBUG - 2018-10-30 05:30:27 --> Total execution time: 0.5722
INFO - 2018-10-30 05:33:27 --> Config Class Initialized
INFO - 2018-10-30 05:33:27 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:33:27 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:33:27 --> Utf8 Class Initialized
INFO - 2018-10-30 05:33:27 --> URI Class Initialized
INFO - 2018-10-30 05:33:27 --> Router Class Initialized
INFO - 2018-10-30 05:33:27 --> Output Class Initialized
INFO - 2018-10-30 05:33:27 --> Security Class Initialized
DEBUG - 2018-10-30 05:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:33:27 --> Input Class Initialized
INFO - 2018-10-30 05:33:27 --> Language Class Initialized
INFO - 2018-10-30 05:33:27 --> Loader Class Initialized
INFO - 2018-10-30 05:33:27 --> Helper loaded: url_helper
INFO - 2018-10-30 05:33:27 --> Database Driver Class Initialized
INFO - 2018-10-30 05:33:27 --> Helper loaded: form_helper
INFO - 2018-10-30 05:33:27 --> Form Validation Class Initialized
INFO - 2018-10-30 05:33:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:33:27 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:33:27 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:33:27 --> Email Class Initialized
INFO - 2018-10-30 05:33:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:33:27 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:33:27 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:33:27 --> Helper loaded: date_helper
INFO - 2018-10-30 05:33:27 --> Database Driver Class Initialized
INFO - 2018-10-30 05:33:27 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:33:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:33:27 --> Controller Class Initialized
INFO - 2018-10-30 05:33:27 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:33:27 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:33:27 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:33:27 --> Final output sent to browser
DEBUG - 2018-10-30 05:33:27 --> Total execution time: 0.5650
INFO - 2018-10-30 05:34:08 --> Config Class Initialized
INFO - 2018-10-30 05:34:08 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:34:08 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:34:08 --> Utf8 Class Initialized
INFO - 2018-10-30 05:34:08 --> URI Class Initialized
INFO - 2018-10-30 05:34:08 --> Router Class Initialized
INFO - 2018-10-30 05:34:08 --> Output Class Initialized
INFO - 2018-10-30 05:34:08 --> Security Class Initialized
DEBUG - 2018-10-30 05:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:34:08 --> Input Class Initialized
INFO - 2018-10-30 05:34:08 --> Language Class Initialized
INFO - 2018-10-30 05:34:08 --> Loader Class Initialized
INFO - 2018-10-30 05:34:08 --> Helper loaded: url_helper
INFO - 2018-10-30 05:34:08 --> Database Driver Class Initialized
INFO - 2018-10-30 05:34:08 --> Helper loaded: form_helper
INFO - 2018-10-30 05:34:08 --> Form Validation Class Initialized
INFO - 2018-10-30 05:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:34:08 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:34:08 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:34:08 --> Email Class Initialized
INFO - 2018-10-30 05:34:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:34:08 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:34:08 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:34:08 --> Helper loaded: date_helper
INFO - 2018-10-30 05:34:08 --> Database Driver Class Initialized
INFO - 2018-10-30 05:34:08 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:34:08 --> Controller Class Initialized
INFO - 2018-10-30 05:34:08 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:34:08 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:34:08 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:34:08 --> Final output sent to browser
DEBUG - 2018-10-30 05:34:08 --> Total execution time: 0.5668
INFO - 2018-10-30 05:34:09 --> Config Class Initialized
INFO - 2018-10-30 05:34:09 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:34:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:34:10 --> Utf8 Class Initialized
INFO - 2018-10-30 05:34:10 --> URI Class Initialized
INFO - 2018-10-30 05:34:10 --> Router Class Initialized
INFO - 2018-10-30 05:34:10 --> Output Class Initialized
INFO - 2018-10-30 05:34:10 --> Security Class Initialized
DEBUG - 2018-10-30 05:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:34:10 --> Input Class Initialized
INFO - 2018-10-30 05:34:10 --> Language Class Initialized
INFO - 2018-10-30 05:34:10 --> Loader Class Initialized
INFO - 2018-10-30 05:34:10 --> Helper loaded: url_helper
INFO - 2018-10-30 05:34:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:34:10 --> Helper loaded: form_helper
INFO - 2018-10-30 05:34:10 --> Form Validation Class Initialized
INFO - 2018-10-30 05:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:34:10 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:34:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:34:10 --> Email Class Initialized
INFO - 2018-10-30 05:34:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:34:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:34:10 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:34:10 --> Helper loaded: date_helper
INFO - 2018-10-30 05:34:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:34:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:34:10 --> Controller Class Initialized
INFO - 2018-10-30 05:34:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:34:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:34:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:34:10 --> Final output sent to browser
DEBUG - 2018-10-30 05:34:10 --> Total execution time: 0.5882
INFO - 2018-10-30 05:35:34 --> Config Class Initialized
INFO - 2018-10-30 05:35:34 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:35:34 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:35:34 --> Utf8 Class Initialized
INFO - 2018-10-30 05:35:34 --> URI Class Initialized
INFO - 2018-10-30 05:35:34 --> Router Class Initialized
INFO - 2018-10-30 05:35:34 --> Output Class Initialized
INFO - 2018-10-30 05:35:34 --> Security Class Initialized
DEBUG - 2018-10-30 05:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:35:34 --> Input Class Initialized
INFO - 2018-10-30 05:35:34 --> Language Class Initialized
INFO - 2018-10-30 05:35:34 --> Loader Class Initialized
INFO - 2018-10-30 05:35:34 --> Helper loaded: url_helper
INFO - 2018-10-30 05:35:34 --> Database Driver Class Initialized
INFO - 2018-10-30 05:35:34 --> Helper loaded: form_helper
INFO - 2018-10-30 05:35:34 --> Form Validation Class Initialized
INFO - 2018-10-30 05:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:35:34 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:35:34 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:35:34 --> Email Class Initialized
INFO - 2018-10-30 05:35:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:35:34 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:35:34 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:35:34 --> Helper loaded: date_helper
INFO - 2018-10-30 05:35:34 --> Database Driver Class Initialized
INFO - 2018-10-30 05:35:34 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:35:35 --> Controller Class Initialized
INFO - 2018-10-30 05:35:35 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:35:35 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:35:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:35:35 --> Final output sent to browser
DEBUG - 2018-10-30 05:35:35 --> Total execution time: 0.5570
INFO - 2018-10-30 05:36:30 --> Config Class Initialized
INFO - 2018-10-30 05:36:30 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:36:30 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:36:30 --> Utf8 Class Initialized
INFO - 2018-10-30 05:36:30 --> URI Class Initialized
INFO - 2018-10-30 05:36:30 --> Router Class Initialized
INFO - 2018-10-30 05:36:30 --> Output Class Initialized
INFO - 2018-10-30 05:36:30 --> Security Class Initialized
DEBUG - 2018-10-30 05:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:36:30 --> Input Class Initialized
INFO - 2018-10-30 05:36:30 --> Language Class Initialized
INFO - 2018-10-30 05:36:30 --> Loader Class Initialized
INFO - 2018-10-30 05:36:30 --> Helper loaded: url_helper
INFO - 2018-10-30 05:36:30 --> Database Driver Class Initialized
INFO - 2018-10-30 05:36:30 --> Helper loaded: form_helper
INFO - 2018-10-30 05:36:30 --> Form Validation Class Initialized
INFO - 2018-10-30 05:36:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:36:30 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:36:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:36:30 --> Email Class Initialized
INFO - 2018-10-30 05:36:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:36:30 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:36:30 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:36:30 --> Helper loaded: date_helper
INFO - 2018-10-30 05:36:30 --> Database Driver Class Initialized
INFO - 2018-10-30 05:36:30 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:36:31 --> Controller Class Initialized
INFO - 2018-10-30 05:36:31 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:36:31 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:36:31 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:36:31 --> Final output sent to browser
DEBUG - 2018-10-30 05:36:31 --> Total execution time: 0.5708
INFO - 2018-10-30 05:37:19 --> Config Class Initialized
INFO - 2018-10-30 05:37:19 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:37:19 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:37:19 --> Utf8 Class Initialized
INFO - 2018-10-30 05:37:19 --> URI Class Initialized
INFO - 2018-10-30 05:37:19 --> Router Class Initialized
INFO - 2018-10-30 05:37:19 --> Output Class Initialized
INFO - 2018-10-30 05:37:19 --> Security Class Initialized
DEBUG - 2018-10-30 05:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:37:19 --> Input Class Initialized
INFO - 2018-10-30 05:37:19 --> Language Class Initialized
INFO - 2018-10-30 05:37:19 --> Loader Class Initialized
INFO - 2018-10-30 05:37:19 --> Helper loaded: url_helper
INFO - 2018-10-30 05:37:19 --> Database Driver Class Initialized
INFO - 2018-10-30 05:37:19 --> Helper loaded: form_helper
INFO - 2018-10-30 05:37:19 --> Form Validation Class Initialized
INFO - 2018-10-30 05:37:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:37:19 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:37:19 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:37:19 --> Email Class Initialized
INFO - 2018-10-30 05:37:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:37:19 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:37:19 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:37:19 --> Helper loaded: date_helper
INFO - 2018-10-30 05:37:19 --> Database Driver Class Initialized
INFO - 2018-10-30 05:37:19 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:37:19 --> Controller Class Initialized
INFO - 2018-10-30 05:37:19 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:37:19 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:37:20 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:37:20 --> Final output sent to browser
DEBUG - 2018-10-30 05:37:20 --> Total execution time: 0.5299
INFO - 2018-10-30 05:38:48 --> Config Class Initialized
INFO - 2018-10-30 05:38:48 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:38:48 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:38:48 --> Utf8 Class Initialized
INFO - 2018-10-30 05:38:48 --> URI Class Initialized
INFO - 2018-10-30 05:38:48 --> Router Class Initialized
INFO - 2018-10-30 05:38:48 --> Output Class Initialized
INFO - 2018-10-30 05:38:48 --> Security Class Initialized
DEBUG - 2018-10-30 05:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:38:48 --> Input Class Initialized
INFO - 2018-10-30 05:38:48 --> Language Class Initialized
INFO - 2018-10-30 05:38:48 --> Loader Class Initialized
INFO - 2018-10-30 05:38:48 --> Helper loaded: url_helper
INFO - 2018-10-30 05:38:48 --> Database Driver Class Initialized
INFO - 2018-10-30 05:38:48 --> Helper loaded: form_helper
INFO - 2018-10-30 05:38:48 --> Form Validation Class Initialized
INFO - 2018-10-30 05:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:38:48 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:38:48 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:38:48 --> Email Class Initialized
INFO - 2018-10-30 05:38:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:38:48 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:38:48 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:38:48 --> Helper loaded: date_helper
INFO - 2018-10-30 05:38:48 --> Database Driver Class Initialized
INFO - 2018-10-30 05:38:48 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:38:48 --> Controller Class Initialized
INFO - 2018-10-30 05:38:49 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:38:49 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:38:49 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:38:49 --> Final output sent to browser
DEBUG - 2018-10-30 05:38:49 --> Total execution time: 0.5650
INFO - 2018-10-30 05:39:05 --> Config Class Initialized
INFO - 2018-10-30 05:39:05 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:39:05 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:39:05 --> Utf8 Class Initialized
INFO - 2018-10-30 05:39:05 --> URI Class Initialized
INFO - 2018-10-30 05:39:05 --> Router Class Initialized
INFO - 2018-10-30 05:39:05 --> Output Class Initialized
INFO - 2018-10-30 05:39:05 --> Security Class Initialized
DEBUG - 2018-10-30 05:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:39:05 --> Input Class Initialized
INFO - 2018-10-30 05:39:05 --> Language Class Initialized
INFO - 2018-10-30 05:39:05 --> Loader Class Initialized
INFO - 2018-10-30 05:39:05 --> Helper loaded: url_helper
INFO - 2018-10-30 05:39:05 --> Database Driver Class Initialized
INFO - 2018-10-30 05:39:05 --> Helper loaded: form_helper
INFO - 2018-10-30 05:39:05 --> Form Validation Class Initialized
INFO - 2018-10-30 05:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:39:06 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:39:06 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:39:06 --> Email Class Initialized
INFO - 2018-10-30 05:39:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:39:06 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:39:06 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:39:06 --> Helper loaded: date_helper
INFO - 2018-10-30 05:39:06 --> Database Driver Class Initialized
INFO - 2018-10-30 05:39:06 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:39:06 --> Controller Class Initialized
INFO - 2018-10-30 05:39:06 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:39:06 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:39:06 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:39:06 --> Final output sent to browser
DEBUG - 2018-10-30 05:39:06 --> Total execution time: 0.5691
INFO - 2018-10-30 05:39:17 --> Config Class Initialized
INFO - 2018-10-30 05:39:17 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:39:17 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:39:17 --> Utf8 Class Initialized
INFO - 2018-10-30 05:39:17 --> URI Class Initialized
INFO - 2018-10-30 05:39:17 --> Router Class Initialized
INFO - 2018-10-30 05:39:17 --> Output Class Initialized
INFO - 2018-10-30 05:39:17 --> Security Class Initialized
DEBUG - 2018-10-30 05:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:39:18 --> Input Class Initialized
INFO - 2018-10-30 05:39:18 --> Language Class Initialized
INFO - 2018-10-30 05:39:18 --> Loader Class Initialized
INFO - 2018-10-30 05:39:18 --> Helper loaded: url_helper
INFO - 2018-10-30 05:39:18 --> Database Driver Class Initialized
INFO - 2018-10-30 05:39:18 --> Helper loaded: form_helper
INFO - 2018-10-30 05:39:18 --> Form Validation Class Initialized
INFO - 2018-10-30 05:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:39:18 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:39:18 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:39:18 --> Email Class Initialized
INFO - 2018-10-30 05:39:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:39:18 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:39:18 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:39:18 --> Helper loaded: date_helper
INFO - 2018-10-30 05:39:18 --> Database Driver Class Initialized
INFO - 2018-10-30 05:39:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:39:18 --> Controller Class Initialized
INFO - 2018-10-30 05:39:18 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:39:18 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:39:18 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:39:18 --> Final output sent to browser
DEBUG - 2018-10-30 05:39:18 --> Total execution time: 0.6349
INFO - 2018-10-30 05:40:17 --> Config Class Initialized
INFO - 2018-10-30 05:40:18 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:40:18 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:40:18 --> Utf8 Class Initialized
INFO - 2018-10-30 05:40:18 --> URI Class Initialized
INFO - 2018-10-30 05:40:18 --> Router Class Initialized
INFO - 2018-10-30 05:40:18 --> Output Class Initialized
INFO - 2018-10-30 05:40:18 --> Security Class Initialized
DEBUG - 2018-10-30 05:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:40:18 --> Input Class Initialized
INFO - 2018-10-30 05:40:18 --> Language Class Initialized
INFO - 2018-10-30 05:40:18 --> Loader Class Initialized
INFO - 2018-10-30 05:40:18 --> Helper loaded: url_helper
INFO - 2018-10-30 05:40:18 --> Database Driver Class Initialized
INFO - 2018-10-30 05:40:18 --> Helper loaded: form_helper
INFO - 2018-10-30 05:40:18 --> Form Validation Class Initialized
INFO - 2018-10-30 05:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:40:18 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:40:18 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:40:18 --> Email Class Initialized
INFO - 2018-10-30 05:40:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:40:18 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:40:18 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:40:18 --> Helper loaded: date_helper
INFO - 2018-10-30 05:40:18 --> Database Driver Class Initialized
INFO - 2018-10-30 05:40:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:40:18 --> Controller Class Initialized
INFO - 2018-10-30 05:40:18 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:40:18 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:40:18 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:40:18 --> Final output sent to browser
DEBUG - 2018-10-30 05:40:18 --> Total execution time: 0.5517
INFO - 2018-10-30 05:40:56 --> Config Class Initialized
INFO - 2018-10-30 05:40:56 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:40:56 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:40:56 --> Utf8 Class Initialized
INFO - 2018-10-30 05:40:56 --> URI Class Initialized
INFO - 2018-10-30 05:40:56 --> Router Class Initialized
INFO - 2018-10-30 05:40:56 --> Output Class Initialized
INFO - 2018-10-30 05:40:56 --> Security Class Initialized
DEBUG - 2018-10-30 05:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:40:56 --> Input Class Initialized
INFO - 2018-10-30 05:40:56 --> Language Class Initialized
INFO - 2018-10-30 05:40:56 --> Loader Class Initialized
INFO - 2018-10-30 05:40:56 --> Helper loaded: url_helper
INFO - 2018-10-30 05:40:56 --> Database Driver Class Initialized
INFO - 2018-10-30 05:40:56 --> Helper loaded: form_helper
INFO - 2018-10-30 05:40:56 --> Form Validation Class Initialized
INFO - 2018-10-30 05:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:40:56 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:40:56 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:40:56 --> Email Class Initialized
INFO - 2018-10-30 05:40:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:40:56 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:40:56 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:40:56 --> Helper loaded: date_helper
INFO - 2018-10-30 05:40:56 --> Database Driver Class Initialized
INFO - 2018-10-30 05:40:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:40:56 --> Controller Class Initialized
INFO - 2018-10-30 05:40:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:40:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:40:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:40:56 --> Final output sent to browser
DEBUG - 2018-10-30 05:40:56 --> Total execution time: 0.6178
INFO - 2018-10-30 05:41:09 --> Config Class Initialized
INFO - 2018-10-30 05:41:09 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:41:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:41:09 --> Utf8 Class Initialized
INFO - 2018-10-30 05:41:09 --> URI Class Initialized
INFO - 2018-10-30 05:41:09 --> Router Class Initialized
INFO - 2018-10-30 05:41:09 --> Output Class Initialized
INFO - 2018-10-30 05:41:09 --> Security Class Initialized
DEBUG - 2018-10-30 05:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:41:09 --> Input Class Initialized
INFO - 2018-10-30 05:41:10 --> Language Class Initialized
INFO - 2018-10-30 05:41:10 --> Loader Class Initialized
INFO - 2018-10-30 05:41:10 --> Helper loaded: url_helper
INFO - 2018-10-30 05:41:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:41:10 --> Helper loaded: form_helper
INFO - 2018-10-30 05:41:10 --> Form Validation Class Initialized
INFO - 2018-10-30 05:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:41:10 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:41:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:41:10 --> Email Class Initialized
INFO - 2018-10-30 05:41:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:41:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:41:10 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:41:10 --> Helper loaded: date_helper
INFO - 2018-10-30 05:41:10 --> Database Driver Class Initialized
INFO - 2018-10-30 05:41:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:41:10 --> Controller Class Initialized
INFO - 2018-10-30 05:41:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:41:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:41:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:41:10 --> Final output sent to browser
DEBUG - 2018-10-30 05:41:10 --> Total execution time: 0.5881
INFO - 2018-10-30 05:41:43 --> Config Class Initialized
INFO - 2018-10-30 05:41:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:41:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:41:43 --> Utf8 Class Initialized
INFO - 2018-10-30 05:41:43 --> URI Class Initialized
INFO - 2018-10-30 05:41:43 --> Router Class Initialized
INFO - 2018-10-30 05:41:43 --> Output Class Initialized
INFO - 2018-10-30 05:41:43 --> Security Class Initialized
DEBUG - 2018-10-30 05:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:41:43 --> Input Class Initialized
INFO - 2018-10-30 05:41:44 --> Language Class Initialized
INFO - 2018-10-30 05:41:44 --> Loader Class Initialized
INFO - 2018-10-30 05:41:44 --> Helper loaded: url_helper
INFO - 2018-10-30 05:41:44 --> Database Driver Class Initialized
INFO - 2018-10-30 05:41:44 --> Helper loaded: form_helper
INFO - 2018-10-30 05:41:44 --> Form Validation Class Initialized
INFO - 2018-10-30 05:41:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:41:44 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:41:44 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:41:44 --> Email Class Initialized
INFO - 2018-10-30 05:41:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:41:44 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:41:44 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:41:44 --> Helper loaded: date_helper
INFO - 2018-10-30 05:41:44 --> Database Driver Class Initialized
INFO - 2018-10-30 05:41:44 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:41:44 --> Controller Class Initialized
INFO - 2018-10-30 05:41:44 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:41:44 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:41:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:41:44 --> Final output sent to browser
DEBUG - 2018-10-30 05:41:44 --> Total execution time: 0.6062
INFO - 2018-10-30 05:41:50 --> Config Class Initialized
INFO - 2018-10-30 05:41:50 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:41:50 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:41:50 --> Utf8 Class Initialized
INFO - 2018-10-30 05:41:51 --> URI Class Initialized
INFO - 2018-10-30 05:41:51 --> Router Class Initialized
INFO - 2018-10-30 05:41:51 --> Output Class Initialized
INFO - 2018-10-30 05:41:51 --> Security Class Initialized
DEBUG - 2018-10-30 05:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:41:51 --> Input Class Initialized
INFO - 2018-10-30 05:41:51 --> Language Class Initialized
INFO - 2018-10-30 05:41:51 --> Loader Class Initialized
INFO - 2018-10-30 05:41:51 --> Helper loaded: url_helper
INFO - 2018-10-30 05:41:51 --> Database Driver Class Initialized
INFO - 2018-10-30 05:41:51 --> Helper loaded: form_helper
INFO - 2018-10-30 05:41:51 --> Form Validation Class Initialized
INFO - 2018-10-30 05:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:41:51 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:41:51 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:41:51 --> Email Class Initialized
INFO - 2018-10-30 05:41:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:41:51 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:41:51 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:41:51 --> Helper loaded: date_helper
INFO - 2018-10-30 05:41:51 --> Database Driver Class Initialized
INFO - 2018-10-30 05:41:51 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:41:51 --> Controller Class Initialized
INFO - 2018-10-30 05:41:51 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:41:51 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:41:51 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:41:51 --> Final output sent to browser
DEBUG - 2018-10-30 05:41:51 --> Total execution time: 0.5828
INFO - 2018-10-30 05:42:14 --> Config Class Initialized
INFO - 2018-10-30 05:42:14 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:42:14 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:42:14 --> Utf8 Class Initialized
INFO - 2018-10-30 05:42:14 --> URI Class Initialized
INFO - 2018-10-30 05:42:14 --> Router Class Initialized
INFO - 2018-10-30 05:42:14 --> Output Class Initialized
INFO - 2018-10-30 05:42:14 --> Security Class Initialized
DEBUG - 2018-10-30 05:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:42:14 --> Input Class Initialized
INFO - 2018-10-30 05:42:15 --> Language Class Initialized
INFO - 2018-10-30 05:42:15 --> Loader Class Initialized
INFO - 2018-10-30 05:42:15 --> Helper loaded: url_helper
INFO - 2018-10-30 05:42:15 --> Database Driver Class Initialized
INFO - 2018-10-30 05:42:15 --> Helper loaded: form_helper
INFO - 2018-10-30 05:42:15 --> Form Validation Class Initialized
INFO - 2018-10-30 05:42:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:42:15 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:42:15 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:42:15 --> Email Class Initialized
INFO - 2018-10-30 05:42:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:42:15 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:42:15 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:42:15 --> Helper loaded: date_helper
INFO - 2018-10-30 05:42:15 --> Database Driver Class Initialized
INFO - 2018-10-30 05:42:15 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:42:15 --> Controller Class Initialized
INFO - 2018-10-30 05:42:15 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:42:15 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:42:15 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:42:15 --> Final output sent to browser
DEBUG - 2018-10-30 05:42:15 --> Total execution time: 0.5844
INFO - 2018-10-30 05:43:38 --> Config Class Initialized
INFO - 2018-10-30 05:43:38 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:43:38 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:43:38 --> Utf8 Class Initialized
INFO - 2018-10-30 05:43:38 --> URI Class Initialized
INFO - 2018-10-30 05:43:38 --> Router Class Initialized
INFO - 2018-10-30 05:43:38 --> Output Class Initialized
INFO - 2018-10-30 05:43:38 --> Security Class Initialized
DEBUG - 2018-10-30 05:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:43:38 --> Input Class Initialized
INFO - 2018-10-30 05:43:38 --> Language Class Initialized
INFO - 2018-10-30 05:43:38 --> Loader Class Initialized
INFO - 2018-10-30 05:43:38 --> Helper loaded: url_helper
INFO - 2018-10-30 05:43:38 --> Database Driver Class Initialized
INFO - 2018-10-30 05:43:38 --> Helper loaded: form_helper
INFO - 2018-10-30 05:43:38 --> Form Validation Class Initialized
INFO - 2018-10-30 05:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:43:38 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:43:38 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:43:38 --> Email Class Initialized
INFO - 2018-10-30 05:43:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:43:38 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:43:38 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:43:38 --> Helper loaded: date_helper
INFO - 2018-10-30 05:43:38 --> Database Driver Class Initialized
INFO - 2018-10-30 05:43:38 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:43:38 --> Controller Class Initialized
INFO - 2018-10-30 05:43:38 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:43:38 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:43:38 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:43:39 --> Final output sent to browser
DEBUG - 2018-10-30 05:43:39 --> Total execution time: 0.5532
INFO - 2018-10-30 05:43:46 --> Config Class Initialized
INFO - 2018-10-30 05:43:46 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:43:46 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:43:46 --> Utf8 Class Initialized
INFO - 2018-10-30 05:43:46 --> URI Class Initialized
INFO - 2018-10-30 05:43:46 --> Router Class Initialized
INFO - 2018-10-30 05:43:46 --> Output Class Initialized
INFO - 2018-10-30 05:43:46 --> Security Class Initialized
DEBUG - 2018-10-30 05:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:43:46 --> Input Class Initialized
INFO - 2018-10-30 05:43:46 --> Language Class Initialized
INFO - 2018-10-30 05:43:46 --> Loader Class Initialized
INFO - 2018-10-30 05:43:46 --> Helper loaded: url_helper
INFO - 2018-10-30 05:43:46 --> Database Driver Class Initialized
INFO - 2018-10-30 05:43:46 --> Helper loaded: form_helper
INFO - 2018-10-30 05:43:46 --> Form Validation Class Initialized
INFO - 2018-10-30 05:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:43:46 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:43:46 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:43:46 --> Email Class Initialized
INFO - 2018-10-30 05:43:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:43:46 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:43:46 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:43:46 --> Helper loaded: date_helper
INFO - 2018-10-30 05:43:46 --> Database Driver Class Initialized
INFO - 2018-10-30 05:43:46 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:43:46 --> Controller Class Initialized
INFO - 2018-10-30 05:43:46 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:43:46 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:43:46 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:43:46 --> Final output sent to browser
DEBUG - 2018-10-30 05:43:46 --> Total execution time: 0.5958
INFO - 2018-10-30 05:44:26 --> Config Class Initialized
INFO - 2018-10-30 05:44:26 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:44:26 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:44:26 --> Utf8 Class Initialized
INFO - 2018-10-30 05:44:26 --> URI Class Initialized
INFO - 2018-10-30 05:44:26 --> Router Class Initialized
INFO - 2018-10-30 05:44:26 --> Output Class Initialized
INFO - 2018-10-30 05:44:26 --> Security Class Initialized
DEBUG - 2018-10-30 05:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:44:26 --> Input Class Initialized
INFO - 2018-10-30 05:44:26 --> Language Class Initialized
INFO - 2018-10-30 05:44:26 --> Loader Class Initialized
INFO - 2018-10-30 05:44:26 --> Helper loaded: url_helper
INFO - 2018-10-30 05:44:26 --> Database Driver Class Initialized
INFO - 2018-10-30 05:44:27 --> Helper loaded: form_helper
INFO - 2018-10-30 05:44:27 --> Form Validation Class Initialized
INFO - 2018-10-30 05:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:44:27 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:44:27 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:44:27 --> Email Class Initialized
INFO - 2018-10-30 05:44:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:44:27 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:44:27 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:44:27 --> Helper loaded: date_helper
INFO - 2018-10-30 05:44:27 --> Database Driver Class Initialized
INFO - 2018-10-30 05:44:27 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:44:27 --> Controller Class Initialized
INFO - 2018-10-30 05:44:27 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:44:27 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 05:44:27 --> Severity: Notice --> Undefined variable: data2 D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 86
INFO - 2018-10-30 05:44:27 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:44:27 --> Final output sent to browser
DEBUG - 2018-10-30 05:44:27 --> Total execution time: 0.6211
INFO - 2018-10-30 05:44:47 --> Config Class Initialized
INFO - 2018-10-30 05:44:47 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:44:48 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:44:48 --> Utf8 Class Initialized
INFO - 2018-10-30 05:44:48 --> URI Class Initialized
INFO - 2018-10-30 05:44:48 --> Router Class Initialized
INFO - 2018-10-30 05:44:48 --> Output Class Initialized
INFO - 2018-10-30 05:44:48 --> Security Class Initialized
DEBUG - 2018-10-30 05:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:44:48 --> Input Class Initialized
INFO - 2018-10-30 05:44:48 --> Language Class Initialized
INFO - 2018-10-30 05:44:48 --> Loader Class Initialized
INFO - 2018-10-30 05:44:48 --> Helper loaded: url_helper
INFO - 2018-10-30 05:44:48 --> Database Driver Class Initialized
INFO - 2018-10-30 05:44:48 --> Helper loaded: form_helper
INFO - 2018-10-30 05:44:48 --> Form Validation Class Initialized
INFO - 2018-10-30 05:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:44:48 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:44:48 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:44:48 --> Email Class Initialized
INFO - 2018-10-30 05:44:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:44:48 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:44:48 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:44:48 --> Helper loaded: date_helper
INFO - 2018-10-30 05:44:48 --> Database Driver Class Initialized
INFO - 2018-10-30 05:44:48 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:44:48 --> Controller Class Initialized
INFO - 2018-10-30 05:44:48 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:44:48 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:44:48 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:44:48 --> Final output sent to browser
DEBUG - 2018-10-30 05:44:48 --> Total execution time: 0.6032
INFO - 2018-10-30 05:45:32 --> Config Class Initialized
INFO - 2018-10-30 05:45:32 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:45:32 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:45:32 --> Utf8 Class Initialized
INFO - 2018-10-30 05:45:32 --> URI Class Initialized
INFO - 2018-10-30 05:45:32 --> Router Class Initialized
INFO - 2018-10-30 05:45:32 --> Output Class Initialized
INFO - 2018-10-30 05:45:32 --> Security Class Initialized
DEBUG - 2018-10-30 05:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:45:32 --> Input Class Initialized
INFO - 2018-10-30 05:45:32 --> Language Class Initialized
INFO - 2018-10-30 05:45:32 --> Loader Class Initialized
INFO - 2018-10-30 05:45:32 --> Helper loaded: url_helper
INFO - 2018-10-30 05:45:32 --> Database Driver Class Initialized
INFO - 2018-10-30 05:45:32 --> Helper loaded: form_helper
INFO - 2018-10-30 05:45:32 --> Form Validation Class Initialized
INFO - 2018-10-30 05:45:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:45:32 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:45:32 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:45:32 --> Email Class Initialized
INFO - 2018-10-30 05:45:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:45:32 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:45:32 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:45:32 --> Helper loaded: date_helper
INFO - 2018-10-30 05:45:32 --> Database Driver Class Initialized
INFO - 2018-10-30 05:45:32 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:45:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:45:32 --> Controller Class Initialized
INFO - 2018-10-30 05:45:32 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:45:32 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:45:32 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:45:32 --> Final output sent to browser
DEBUG - 2018-10-30 05:45:32 --> Total execution time: 0.5797
INFO - 2018-10-30 05:46:31 --> Config Class Initialized
INFO - 2018-10-30 05:46:31 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:46:31 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:46:31 --> Utf8 Class Initialized
INFO - 2018-10-30 05:46:31 --> URI Class Initialized
INFO - 2018-10-30 05:46:31 --> Router Class Initialized
INFO - 2018-10-30 05:46:31 --> Output Class Initialized
INFO - 2018-10-30 05:46:31 --> Security Class Initialized
DEBUG - 2018-10-30 05:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:46:31 --> Input Class Initialized
INFO - 2018-10-30 05:46:31 --> Language Class Initialized
INFO - 2018-10-30 05:46:31 --> Loader Class Initialized
INFO - 2018-10-30 05:46:31 --> Helper loaded: url_helper
INFO - 2018-10-30 05:46:31 --> Database Driver Class Initialized
INFO - 2018-10-30 05:46:31 --> Helper loaded: form_helper
INFO - 2018-10-30 05:46:31 --> Form Validation Class Initialized
INFO - 2018-10-30 05:46:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:46:31 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:46:31 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:46:31 --> Email Class Initialized
INFO - 2018-10-30 05:46:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:46:31 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:46:31 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:46:32 --> Helper loaded: date_helper
INFO - 2018-10-30 05:46:32 --> Database Driver Class Initialized
INFO - 2018-10-30 05:46:32 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:46:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:46:32 --> Controller Class Initialized
INFO - 2018-10-30 05:46:32 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:46:32 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:46:32 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:46:32 --> Final output sent to browser
DEBUG - 2018-10-30 05:46:32 --> Total execution time: 0.6256
INFO - 2018-10-30 05:46:54 --> Config Class Initialized
INFO - 2018-10-30 05:46:54 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:46:54 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:46:54 --> Utf8 Class Initialized
INFO - 2018-10-30 05:46:54 --> URI Class Initialized
INFO - 2018-10-30 05:46:54 --> Router Class Initialized
INFO - 2018-10-30 05:46:54 --> Output Class Initialized
INFO - 2018-10-30 05:46:54 --> Security Class Initialized
DEBUG - 2018-10-30 05:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:46:54 --> Input Class Initialized
INFO - 2018-10-30 05:46:54 --> Language Class Initialized
INFO - 2018-10-30 05:46:54 --> Loader Class Initialized
INFO - 2018-10-30 05:46:54 --> Helper loaded: url_helper
INFO - 2018-10-30 05:46:54 --> Database Driver Class Initialized
INFO - 2018-10-30 05:46:54 --> Helper loaded: form_helper
INFO - 2018-10-30 05:46:54 --> Form Validation Class Initialized
INFO - 2018-10-30 05:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:46:54 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:46:54 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:46:54 --> Email Class Initialized
INFO - 2018-10-30 05:46:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:46:54 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:46:54 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:46:54 --> Helper loaded: date_helper
INFO - 2018-10-30 05:46:55 --> Database Driver Class Initialized
INFO - 2018-10-30 05:46:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:46:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:46:55 --> Controller Class Initialized
INFO - 2018-10-30 05:46:55 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:46:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:46:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:46:55 --> Final output sent to browser
DEBUG - 2018-10-30 05:46:55 --> Total execution time: 0.6172
INFO - 2018-10-30 05:46:55 --> Config Class Initialized
INFO - 2018-10-30 05:46:56 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:46:56 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:46:56 --> Utf8 Class Initialized
INFO - 2018-10-30 05:46:56 --> URI Class Initialized
INFO - 2018-10-30 05:46:56 --> Router Class Initialized
INFO - 2018-10-30 05:46:56 --> Output Class Initialized
INFO - 2018-10-30 05:46:56 --> Security Class Initialized
DEBUG - 2018-10-30 05:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:46:56 --> Input Class Initialized
INFO - 2018-10-30 05:46:56 --> Language Class Initialized
INFO - 2018-10-30 05:46:56 --> Loader Class Initialized
INFO - 2018-10-30 05:46:56 --> Helper loaded: url_helper
INFO - 2018-10-30 05:46:56 --> Database Driver Class Initialized
INFO - 2018-10-30 05:46:56 --> Helper loaded: form_helper
INFO - 2018-10-30 05:46:56 --> Form Validation Class Initialized
INFO - 2018-10-30 05:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:46:56 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:46:56 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:46:56 --> Email Class Initialized
INFO - 2018-10-30 05:46:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:46:56 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:46:56 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:46:56 --> Helper loaded: date_helper
INFO - 2018-10-30 05:46:56 --> Database Driver Class Initialized
INFO - 2018-10-30 05:46:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:46:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:46:56 --> Controller Class Initialized
INFO - 2018-10-30 05:46:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:46:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:46:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:46:56 --> Final output sent to browser
DEBUG - 2018-10-30 05:46:56 --> Total execution time: 0.5790
INFO - 2018-10-30 05:46:56 --> Config Class Initialized
INFO - 2018-10-30 05:46:56 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:46:57 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:46:57 --> Utf8 Class Initialized
INFO - 2018-10-30 05:46:57 --> URI Class Initialized
INFO - 2018-10-30 05:46:57 --> Router Class Initialized
INFO - 2018-10-30 05:46:57 --> Output Class Initialized
INFO - 2018-10-30 05:46:57 --> Security Class Initialized
DEBUG - 2018-10-30 05:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:46:57 --> Input Class Initialized
INFO - 2018-10-30 05:46:57 --> Language Class Initialized
INFO - 2018-10-30 05:46:57 --> Loader Class Initialized
INFO - 2018-10-30 05:46:57 --> Helper loaded: url_helper
INFO - 2018-10-30 05:46:57 --> Database Driver Class Initialized
INFO - 2018-10-30 05:46:57 --> Helper loaded: form_helper
INFO - 2018-10-30 05:46:57 --> Form Validation Class Initialized
INFO - 2018-10-30 05:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:46:57 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:46:57 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:46:57 --> Email Class Initialized
INFO - 2018-10-30 05:46:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:46:57 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:46:57 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:46:57 --> Helper loaded: date_helper
INFO - 2018-10-30 05:46:57 --> Database Driver Class Initialized
INFO - 2018-10-30 05:46:57 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:46:57 --> Controller Class Initialized
INFO - 2018-10-30 05:46:57 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:46:57 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:46:57 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:46:57 --> Final output sent to browser
DEBUG - 2018-10-30 05:46:57 --> Total execution time: 0.5758
INFO - 2018-10-30 05:47:03 --> Config Class Initialized
INFO - 2018-10-30 05:47:03 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:47:03 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:47:03 --> Utf8 Class Initialized
INFO - 2018-10-30 05:47:03 --> URI Class Initialized
INFO - 2018-10-30 05:47:03 --> Router Class Initialized
INFO - 2018-10-30 05:47:03 --> Output Class Initialized
INFO - 2018-10-30 05:47:03 --> Security Class Initialized
DEBUG - 2018-10-30 05:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:47:03 --> Input Class Initialized
INFO - 2018-10-30 05:47:03 --> Language Class Initialized
INFO - 2018-10-30 05:47:03 --> Loader Class Initialized
INFO - 2018-10-30 05:47:03 --> Helper loaded: url_helper
INFO - 2018-10-30 05:47:03 --> Database Driver Class Initialized
INFO - 2018-10-30 05:47:04 --> Helper loaded: form_helper
INFO - 2018-10-30 05:47:04 --> Form Validation Class Initialized
INFO - 2018-10-30 05:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:47:04 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:47:04 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:47:04 --> Email Class Initialized
INFO - 2018-10-30 05:47:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:47:04 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:47:04 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:47:04 --> Helper loaded: date_helper
INFO - 2018-10-30 05:47:04 --> Database Driver Class Initialized
INFO - 2018-10-30 05:47:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:47:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:47:04 --> Controller Class Initialized
INFO - 2018-10-30 05:47:04 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:47:04 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:47:04 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:47:04 --> Final output sent to browser
DEBUG - 2018-10-30 05:47:04 --> Total execution time: 0.5967
INFO - 2018-10-30 05:56:19 --> Config Class Initialized
INFO - 2018-10-30 05:56:19 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:56:19 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:56:19 --> Utf8 Class Initialized
INFO - 2018-10-30 05:56:19 --> URI Class Initialized
INFO - 2018-10-30 05:56:19 --> Router Class Initialized
INFO - 2018-10-30 05:56:19 --> Output Class Initialized
INFO - 2018-10-30 05:56:19 --> Security Class Initialized
DEBUG - 2018-10-30 05:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:56:19 --> Input Class Initialized
INFO - 2018-10-30 05:56:19 --> Language Class Initialized
INFO - 2018-10-30 05:56:19 --> Loader Class Initialized
INFO - 2018-10-30 05:56:19 --> Helper loaded: url_helper
INFO - 2018-10-30 05:56:19 --> Database Driver Class Initialized
INFO - 2018-10-30 05:56:19 --> Helper loaded: form_helper
INFO - 2018-10-30 05:56:19 --> Form Validation Class Initialized
INFO - 2018-10-30 05:56:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:56:20 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:56:20 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:56:20 --> Email Class Initialized
INFO - 2018-10-30 05:56:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:56:20 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:56:20 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:56:20 --> Helper loaded: date_helper
INFO - 2018-10-30 05:56:20 --> Database Driver Class Initialized
INFO - 2018-10-30 05:56:20 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:56:20 --> Controller Class Initialized
INFO - 2018-10-30 05:56:20 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:56:20 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:56:20 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:56:20 --> Final output sent to browser
DEBUG - 2018-10-30 05:56:20 --> Total execution time: 0.5973
INFO - 2018-10-30 05:56:21 --> Config Class Initialized
INFO - 2018-10-30 05:56:21 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:56:21 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:56:21 --> Utf8 Class Initialized
INFO - 2018-10-30 05:56:21 --> URI Class Initialized
INFO - 2018-10-30 05:56:21 --> Router Class Initialized
INFO - 2018-10-30 05:56:21 --> Output Class Initialized
INFO - 2018-10-30 05:56:21 --> Security Class Initialized
DEBUG - 2018-10-30 05:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:56:21 --> Input Class Initialized
INFO - 2018-10-30 05:56:21 --> Language Class Initialized
INFO - 2018-10-30 05:56:21 --> Loader Class Initialized
INFO - 2018-10-30 05:56:21 --> Helper loaded: url_helper
INFO - 2018-10-30 05:56:21 --> Config Class Initialized
INFO - 2018-10-30 05:56:21 --> Database Driver Class Initialized
INFO - 2018-10-30 05:56:21 --> Hooks Class Initialized
INFO - 2018-10-30 05:56:21 --> Helper loaded: form_helper
DEBUG - 2018-10-30 05:56:21 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:56:21 --> Form Validation Class Initialized
INFO - 2018-10-30 05:56:21 --> Utf8 Class Initialized
INFO - 2018-10-30 05:56:21 --> URI Class Initialized
INFO - 2018-10-30 05:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:56:21 --> Pagination Class Initialized
INFO - 2018-10-30 05:56:21 --> Router Class Initialized
INFO - 2018-10-30 05:56:21 --> Output Class Initialized
DEBUG - 2018-10-30 05:56:21 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:56:21 --> Security Class Initialized
INFO - 2018-10-30 05:56:21 --> Email Class Initialized
INFO - 2018-10-30 05:56:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2018-10-30 05:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:56:21 --> Input Class Initialized
INFO - 2018-10-30 05:56:21 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:56:21 --> Language Class Initialized
INFO - 2018-10-30 05:56:21 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:56:22 --> Loader Class Initialized
INFO - 2018-10-30 05:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:56:22 --> Helper loaded: url_helper
INFO - 2018-10-30 05:56:22 --> Helper loaded: date_helper
INFO - 2018-10-30 05:56:22 --> Database Driver Class Initialized
INFO - 2018-10-30 05:56:22 --> Database Driver Class Initialized
INFO - 2018-10-30 05:56:22 --> Helper loaded: form_helper
INFO - 2018-10-30 05:56:22 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 05:56:22 --> Form Validation Class Initialized
DEBUG - 2018-10-30 05:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:56:22 --> Controller Class Initialized
INFO - 2018-10-30 05:56:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:56:22 --> Pagination Class Initialized
INFO - 2018-10-30 05:56:22 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:56:22 --> Model "Notadetail_model" initialized
DEBUG - 2018-10-30 05:56:22 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:56:22 --> Email Class Initialized
INFO - 2018-10-30 05:56:22 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:56:22 --> Final output sent to browser
INFO - 2018-10-30 05:56:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2018-10-30 05:56:22 --> Total execution time: 0.5899
INFO - 2018-10-30 05:56:22 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:56:22 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:56:22 --> Helper loaded: date_helper
INFO - 2018-10-30 05:56:22 --> Database Driver Class Initialized
INFO - 2018-10-30 05:56:22 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:56:22 --> Controller Class Initialized
INFO - 2018-10-30 05:56:22 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:56:22 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:56:22 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:56:22 --> Final output sent to browser
DEBUG - 2018-10-30 05:56:22 --> Total execution time: 0.5888
INFO - 2018-10-30 05:56:23 --> Config Class Initialized
INFO - 2018-10-30 05:56:23 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:56:23 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:56:24 --> Utf8 Class Initialized
INFO - 2018-10-30 05:56:24 --> URI Class Initialized
INFO - 2018-10-30 05:56:24 --> Router Class Initialized
INFO - 2018-10-30 05:56:24 --> Output Class Initialized
INFO - 2018-10-30 05:56:24 --> Security Class Initialized
DEBUG - 2018-10-30 05:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:56:24 --> Input Class Initialized
INFO - 2018-10-30 05:56:24 --> Language Class Initialized
INFO - 2018-10-30 05:56:24 --> Loader Class Initialized
INFO - 2018-10-30 05:56:24 --> Helper loaded: url_helper
INFO - 2018-10-30 05:56:24 --> Database Driver Class Initialized
INFO - 2018-10-30 05:56:24 --> Helper loaded: form_helper
INFO - 2018-10-30 05:56:24 --> Form Validation Class Initialized
INFO - 2018-10-30 05:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:56:24 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:56:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:56:24 --> Email Class Initialized
INFO - 2018-10-30 05:56:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:56:24 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:56:24 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:56:24 --> Helper loaded: date_helper
INFO - 2018-10-30 05:56:24 --> Database Driver Class Initialized
INFO - 2018-10-30 05:56:24 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:56:24 --> Controller Class Initialized
INFO - 2018-10-30 05:56:24 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:56:24 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:56:24 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:56:24 --> Final output sent to browser
DEBUG - 2018-10-30 05:56:24 --> Total execution time: 0.5875
INFO - 2018-10-30 05:57:37 --> Config Class Initialized
INFO - 2018-10-30 05:57:37 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:57:37 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:57:37 --> Utf8 Class Initialized
INFO - 2018-10-30 05:57:37 --> URI Class Initialized
INFO - 2018-10-30 05:57:37 --> Router Class Initialized
INFO - 2018-10-30 05:57:37 --> Output Class Initialized
INFO - 2018-10-30 05:57:37 --> Security Class Initialized
DEBUG - 2018-10-30 05:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:57:37 --> Input Class Initialized
INFO - 2018-10-30 05:57:37 --> Language Class Initialized
INFO - 2018-10-30 05:57:37 --> Loader Class Initialized
INFO - 2018-10-30 05:57:37 --> Helper loaded: url_helper
INFO - 2018-10-30 05:57:37 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:37 --> Helper loaded: form_helper
INFO - 2018-10-30 05:57:37 --> Form Validation Class Initialized
INFO - 2018-10-30 05:57:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:57:37 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:57:37 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:57:37 --> Email Class Initialized
INFO - 2018-10-30 05:57:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:57:37 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:57:37 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:57:37 --> Helper loaded: date_helper
INFO - 2018-10-30 05:57:37 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:38 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:57:38 --> Controller Class Initialized
INFO - 2018-10-30 05:57:38 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:57:38 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:57:38 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:57:38 --> Final output sent to browser
DEBUG - 2018-10-30 05:57:38 --> Total execution time: 0.5920
INFO - 2018-10-30 05:57:39 --> Config Class Initialized
INFO - 2018-10-30 05:57:39 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:57:39 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:57:39 --> Utf8 Class Initialized
INFO - 2018-10-30 05:57:39 --> URI Class Initialized
INFO - 2018-10-30 05:57:39 --> Router Class Initialized
INFO - 2018-10-30 05:57:39 --> Output Class Initialized
INFO - 2018-10-30 05:57:39 --> Security Class Initialized
DEBUG - 2018-10-30 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:57:39 --> Input Class Initialized
INFO - 2018-10-30 05:57:39 --> Language Class Initialized
INFO - 2018-10-30 05:57:39 --> Loader Class Initialized
INFO - 2018-10-30 05:57:39 --> Helper loaded: url_helper
INFO - 2018-10-30 05:57:39 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:39 --> Helper loaded: form_helper
INFO - 2018-10-30 05:57:39 --> Form Validation Class Initialized
INFO - 2018-10-30 05:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:57:39 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:57:39 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:57:39 --> Email Class Initialized
INFO - 2018-10-30 05:57:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:57:39 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:57:39 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:57:39 --> Helper loaded: date_helper
INFO - 2018-10-30 05:57:39 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:39 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:57:39 --> Controller Class Initialized
INFO - 2018-10-30 05:57:40 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:57:40 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:57:40 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:57:40 --> Final output sent to browser
DEBUG - 2018-10-30 05:57:40 --> Total execution time: 0.5804
INFO - 2018-10-30 05:57:40 --> Config Class Initialized
INFO - 2018-10-30 05:57:40 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:57:40 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:57:40 --> Utf8 Class Initialized
INFO - 2018-10-30 05:57:40 --> URI Class Initialized
INFO - 2018-10-30 05:57:40 --> Router Class Initialized
INFO - 2018-10-30 05:57:40 --> Output Class Initialized
INFO - 2018-10-30 05:57:40 --> Security Class Initialized
DEBUG - 2018-10-30 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:57:40 --> Config Class Initialized
INFO - 2018-10-30 05:57:40 --> Hooks Class Initialized
INFO - 2018-10-30 05:57:40 --> Input Class Initialized
INFO - 2018-10-30 05:57:40 --> Language Class Initialized
DEBUG - 2018-10-30 05:57:40 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:57:40 --> Utf8 Class Initialized
INFO - 2018-10-30 05:57:40 --> Loader Class Initialized
INFO - 2018-10-30 05:57:40 --> URI Class Initialized
INFO - 2018-10-30 05:57:40 --> Helper loaded: url_helper
INFO - 2018-10-30 05:57:40 --> Router Class Initialized
INFO - 2018-10-30 05:57:40 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:40 --> Output Class Initialized
INFO - 2018-10-30 05:57:40 --> Security Class Initialized
INFO - 2018-10-30 05:57:40 --> Helper loaded: form_helper
INFO - 2018-10-30 05:57:40 --> Form Validation Class Initialized
DEBUG - 2018-10-30 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:57:40 --> Input Class Initialized
INFO - 2018-10-30 05:57:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:57:40 --> Pagination Class Initialized
INFO - 2018-10-30 05:57:40 --> Language Class Initialized
DEBUG - 2018-10-30 05:57:40 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:57:40 --> Loader Class Initialized
INFO - 2018-10-30 05:57:40 --> Helper loaded: url_helper
INFO - 2018-10-30 05:57:40 --> Email Class Initialized
INFO - 2018-10-30 05:57:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:57:40 --> Config Class Initialized
INFO - 2018-10-30 05:57:40 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:40 --> Hooks Class Initialized
INFO - 2018-10-30 05:57:40 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:57:40 --> Helper loaded: form_helper
INFO - 2018-10-30 05:57:40 --> Form Validation Class Initialized
INFO - 2018-10-30 05:57:40 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:57:40 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:57:40 --> Utf8 Class Initialized
INFO - 2018-10-30 05:57:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2018-10-30 05:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:57:40 --> Pagination Class Initialized
INFO - 2018-10-30 05:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:57:40 --> URI Class Initialized
INFO - 2018-10-30 05:57:40 --> Router Class Initialized
DEBUG - 2018-10-30 05:57:40 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:57:40 --> Helper loaded: date_helper
INFO - 2018-10-30 05:57:41 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:41 --> Output Class Initialized
INFO - 2018-10-30 05:57:41 --> Email Class Initialized
INFO - 2018-10-30 05:57:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:57:41 --> Security Class Initialized
INFO - 2018-10-30 05:57:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:57:41 --> Helper loaded: cookie_helper
DEBUG - 2018-10-30 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:57:41 --> Input Class Initialized
INFO - 2018-10-30 05:57:41 --> Controller Class Initialized
INFO - 2018-10-30 05:57:41 --> Helper loaded: language_helper
INFO - 2018-10-30 05:57:41 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:57:41 --> Language Class Initialized
DEBUG - 2018-10-30 05:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:57:41 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:57:41 --> Loader Class Initialized
INFO - 2018-10-30 05:57:41 --> Helper loaded: url_helper
INFO - 2018-10-30 05:57:41 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:57:41 --> Final output sent to browser
INFO - 2018-10-30 05:57:41 --> Database Driver Class Initialized
DEBUG - 2018-10-30 05:57:41 --> Total execution time: 0.6131
INFO - 2018-10-30 05:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:57:41 --> Helper loaded: form_helper
INFO - 2018-10-30 05:57:41 --> Form Validation Class Initialized
INFO - 2018-10-30 05:57:41 --> Helper loaded: date_helper
INFO - 2018-10-30 05:57:41 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:57:41 --> Pagination Class Initialized
INFO - 2018-10-30 05:57:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:57:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2018-10-30 05:57:41 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:57:41 --> Controller Class Initialized
INFO - 2018-10-30 05:57:41 --> Email Class Initialized
INFO - 2018-10-30 05:57:41 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:57:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:57:41 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:57:41 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:57:41 --> Helper loaded: language_helper
INFO - 2018-10-30 05:57:41 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:57:41 --> Final output sent to browser
DEBUG - 2018-10-30 05:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-10-30 05:57:41 --> Total execution time: 0.6290
INFO - 2018-10-30 05:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:57:41 --> Helper loaded: date_helper
INFO - 2018-10-30 05:57:41 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:57:41 --> Controller Class Initialized
INFO - 2018-10-30 05:57:41 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:57:41 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:57:41 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:57:41 --> Final output sent to browser
DEBUG - 2018-10-30 05:57:41 --> Total execution time: 0.6190
INFO - 2018-10-30 05:57:42 --> Config Class Initialized
INFO - 2018-10-30 05:57:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:57:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:57:42 --> Utf8 Class Initialized
INFO - 2018-10-30 05:57:42 --> URI Class Initialized
INFO - 2018-10-30 05:57:42 --> Router Class Initialized
INFO - 2018-10-30 05:57:42 --> Output Class Initialized
INFO - 2018-10-30 05:57:42 --> Security Class Initialized
DEBUG - 2018-10-30 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:57:42 --> Input Class Initialized
INFO - 2018-10-30 05:57:42 --> Language Class Initialized
INFO - 2018-10-30 05:57:42 --> Config Class Initialized
INFO - 2018-10-30 05:57:42 --> Loader Class Initialized
INFO - 2018-10-30 05:57:42 --> Hooks Class Initialized
INFO - 2018-10-30 05:57:42 --> Helper loaded: url_helper
DEBUG - 2018-10-30 05:57:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:57:42 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:42 --> Utf8 Class Initialized
INFO - 2018-10-30 05:57:42 --> Helper loaded: form_helper
INFO - 2018-10-30 05:57:42 --> Form Validation Class Initialized
INFO - 2018-10-30 05:57:42 --> URI Class Initialized
INFO - 2018-10-30 05:57:42 --> Router Class Initialized
INFO - 2018-10-30 05:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:57:42 --> Pagination Class Initialized
INFO - 2018-10-30 05:57:42 --> Output Class Initialized
INFO - 2018-10-30 05:57:42 --> Security Class Initialized
DEBUG - 2018-10-30 05:57:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
DEBUG - 2018-10-30 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:57:42 --> Email Class Initialized
INFO - 2018-10-30 05:57:42 --> Input Class Initialized
INFO - 2018-10-30 05:57:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:57:42 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:57:42 --> Language Class Initialized
INFO - 2018-10-30 05:57:42 --> Helper loaded: language_helper
INFO - 2018-10-30 05:57:42 --> Config Class Initialized
INFO - 2018-10-30 05:57:42 --> Loader Class Initialized
INFO - 2018-10-30 05:57:42 --> Hooks Class Initialized
INFO - 2018-10-30 05:57:42 --> Helper loaded: url_helper
DEBUG - 2018-10-30 05:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:57:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-30 05:57:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:57:42 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:42 --> Utf8 Class Initialized
INFO - 2018-10-30 05:57:42 --> Helper loaded: date_helper
INFO - 2018-10-30 05:57:42 --> Helper loaded: form_helper
INFO - 2018-10-30 05:57:42 --> Form Validation Class Initialized
INFO - 2018-10-30 05:57:42 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:42 --> URI Class Initialized
INFO - 2018-10-30 05:57:42 --> Router Class Initialized
INFO - 2018-10-30 05:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:57:42 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 05:57:42 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:57:42 --> Output Class Initialized
INFO - 2018-10-30 05:57:42 --> Controller Class Initialized
INFO - 2018-10-30 05:57:42 --> Security Class Initialized
DEBUG - 2018-10-30 05:57:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:57:42 --> Model "Nota_model" initialized
DEBUG - 2018-10-30 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:57:42 --> Email Class Initialized
INFO - 2018-10-30 05:57:42 --> Input Class Initialized
INFO - 2018-10-30 05:57:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:57:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:57:42 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:57:42 --> Language Class Initialized
INFO - 2018-10-30 05:57:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:57:42 --> Final output sent to browser
INFO - 2018-10-30 05:57:42 --> Helper loaded: language_helper
INFO - 2018-10-30 05:57:42 --> Loader Class Initialized
INFO - 2018-10-30 05:57:42 --> Config Class Initialized
INFO - 2018-10-30 05:57:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:57:42 --> Total execution time: 0.6075
INFO - 2018-10-30 05:57:42 --> Helper loaded: url_helper
DEBUG - 2018-10-30 05:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:57:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-30 05:57:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:57:42 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:42 --> Utf8 Class Initialized
INFO - 2018-10-30 05:57:42 --> Helper loaded: date_helper
INFO - 2018-10-30 05:57:42 --> Helper loaded: form_helper
INFO - 2018-10-30 05:57:42 --> Form Validation Class Initialized
INFO - 2018-10-30 05:57:42 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:42 --> URI Class Initialized
INFO - 2018-10-30 05:57:42 --> Router Class Initialized
INFO - 2018-10-30 05:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:57:42 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 05:57:42 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:57:42 --> Output Class Initialized
INFO - 2018-10-30 05:57:42 --> Controller Class Initialized
INFO - 2018-10-30 05:57:42 --> Security Class Initialized
DEBUG - 2018-10-30 05:57:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:57:42 --> Model "Nota_model" initialized
DEBUG - 2018-10-30 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:57:42 --> Email Class Initialized
INFO - 2018-10-30 05:57:42 --> Input Class Initialized
INFO - 2018-10-30 05:57:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:57:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:57:42 --> Language Class Initialized
INFO - 2018-10-30 05:57:42 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:57:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:57:42 --> Final output sent to browser
INFO - 2018-10-30 05:57:42 --> Helper loaded: language_helper
INFO - 2018-10-30 05:57:42 --> Loader Class Initialized
DEBUG - 2018-10-30 05:57:42 --> Total execution time: 0.6114
INFO - 2018-10-30 05:57:42 --> Helper loaded: url_helper
DEBUG - 2018-10-30 05:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:57:42 --> Config Class Initialized
INFO - 2018-10-30 05:57:42 --> Hooks Class Initialized
INFO - 2018-10-30 05:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:57:42 --> Database Driver Class Initialized
DEBUG - 2018-10-30 05:57:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:57:42 --> Helper loaded: date_helper
INFO - 2018-10-30 05:57:42 --> Helper loaded: form_helper
INFO - 2018-10-30 05:57:42 --> Utf8 Class Initialized
INFO - 2018-10-30 05:57:42 --> Form Validation Class Initialized
INFO - 2018-10-30 05:57:42 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:42 --> URI Class Initialized
INFO - 2018-10-30 05:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:57:42 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 05:57:42 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:57:42 --> Router Class Initialized
INFO - 2018-10-30 05:57:42 --> Controller Class Initialized
INFO - 2018-10-30 05:57:42 --> Output Class Initialized
DEBUG - 2018-10-30 05:57:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:57:42 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:57:42 --> Security Class Initialized
INFO - 2018-10-30 05:57:42 --> Email Class Initialized
INFO - 2018-10-30 05:57:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:57:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2018-10-30 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:57:42 --> Input Class Initialized
INFO - 2018-10-30 05:57:42 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:57:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:57:43 --> Final output sent to browser
INFO - 2018-10-30 05:57:43 --> Helper loaded: language_helper
INFO - 2018-10-30 05:57:43 --> Language Class Initialized
DEBUG - 2018-10-30 05:57:43 --> Total execution time: 0.5932
DEBUG - 2018-10-30 05:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:57:43 --> Loader Class Initialized
INFO - 2018-10-30 05:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:57:43 --> Helper loaded: url_helper
INFO - 2018-10-30 05:57:43 --> Helper loaded: date_helper
INFO - 2018-10-30 05:57:43 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:43 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:43 --> Helper loaded: form_helper
INFO - 2018-10-30 05:57:43 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 05:57:43 --> Form Validation Class Initialized
DEBUG - 2018-10-30 05:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:57:43 --> Controller Class Initialized
INFO - 2018-10-30 05:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:57:43 --> Pagination Class Initialized
INFO - 2018-10-30 05:57:43 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:57:43 --> Model "Notadetail_model" initialized
DEBUG - 2018-10-30 05:57:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:57:43 --> Email Class Initialized
INFO - 2018-10-30 05:57:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:57:43 --> Final output sent to browser
INFO - 2018-10-30 05:57:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2018-10-30 05:57:43 --> Total execution time: 0.5880
INFO - 2018-10-30 05:57:43 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:57:43 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:57:43 --> Helper loaded: date_helper
INFO - 2018-10-30 05:57:43 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:57:43 --> Controller Class Initialized
INFO - 2018-10-30 05:57:43 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:57:43 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:57:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:57:43 --> Final output sent to browser
DEBUG - 2018-10-30 05:57:43 --> Total execution time: 0.6093
INFO - 2018-10-30 05:57:55 --> Config Class Initialized
INFO - 2018-10-30 05:57:55 --> Hooks Class Initialized
DEBUG - 2018-10-30 05:57:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 05:57:55 --> Utf8 Class Initialized
INFO - 2018-10-30 05:57:55 --> URI Class Initialized
INFO - 2018-10-30 05:57:55 --> Router Class Initialized
INFO - 2018-10-30 05:57:55 --> Output Class Initialized
INFO - 2018-10-30 05:57:55 --> Security Class Initialized
DEBUG - 2018-10-30 05:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 05:57:55 --> Input Class Initialized
INFO - 2018-10-30 05:57:55 --> Language Class Initialized
INFO - 2018-10-30 05:57:55 --> Loader Class Initialized
INFO - 2018-10-30 05:57:55 --> Helper loaded: url_helper
INFO - 2018-10-30 05:57:55 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:55 --> Helper loaded: form_helper
INFO - 2018-10-30 05:57:55 --> Form Validation Class Initialized
INFO - 2018-10-30 05:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 05:57:55 --> Pagination Class Initialized
DEBUG - 2018-10-30 05:57:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 05:57:55 --> Email Class Initialized
INFO - 2018-10-30 05:57:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 05:57:55 --> Helper loaded: cookie_helper
INFO - 2018-10-30 05:57:55 --> Helper loaded: language_helper
DEBUG - 2018-10-30 05:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 05:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 05:57:55 --> Helper loaded: date_helper
INFO - 2018-10-30 05:57:55 --> Database Driver Class Initialized
INFO - 2018-10-30 05:57:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 05:57:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 05:57:55 --> Controller Class Initialized
INFO - 2018-10-30 05:57:55 --> Model "Nota_model" initialized
INFO - 2018-10-30 05:57:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 05:57:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 05:57:55 --> Final output sent to browser
DEBUG - 2018-10-30 05:57:55 --> Total execution time: 0.6017
INFO - 2018-10-30 06:01:15 --> Config Class Initialized
INFO - 2018-10-30 06:01:15 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:01:15 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:01:15 --> Utf8 Class Initialized
INFO - 2018-10-30 06:01:15 --> URI Class Initialized
INFO - 2018-10-30 06:01:15 --> Router Class Initialized
INFO - 2018-10-30 06:01:15 --> Output Class Initialized
INFO - 2018-10-30 06:01:15 --> Security Class Initialized
DEBUG - 2018-10-30 06:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:01:15 --> Input Class Initialized
INFO - 2018-10-30 06:01:15 --> Language Class Initialized
INFO - 2018-10-30 06:01:15 --> Loader Class Initialized
INFO - 2018-10-30 06:01:15 --> Helper loaded: url_helper
INFO - 2018-10-30 06:01:15 --> Database Driver Class Initialized
INFO - 2018-10-30 06:01:15 --> Helper loaded: form_helper
INFO - 2018-10-30 06:01:15 --> Form Validation Class Initialized
INFO - 2018-10-30 06:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:01:15 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:01:15 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:01:15 --> Email Class Initialized
INFO - 2018-10-30 06:01:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:01:15 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:01:15 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:01:15 --> Helper loaded: date_helper
INFO - 2018-10-30 06:01:15 --> Database Driver Class Initialized
INFO - 2018-10-30 06:01:15 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:01:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:01:16 --> Controller Class Initialized
INFO - 2018-10-30 06:01:16 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:01:16 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:01:16 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:01:16 --> Final output sent to browser
DEBUG - 2018-10-30 06:01:16 --> Total execution time: 0.6000
INFO - 2018-10-30 06:01:58 --> Config Class Initialized
INFO - 2018-10-30 06:01:58 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:01:58 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:01:58 --> Utf8 Class Initialized
INFO - 2018-10-30 06:01:58 --> URI Class Initialized
INFO - 2018-10-30 06:01:58 --> Router Class Initialized
INFO - 2018-10-30 06:01:58 --> Output Class Initialized
INFO - 2018-10-30 06:01:58 --> Security Class Initialized
DEBUG - 2018-10-30 06:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:01:58 --> Input Class Initialized
INFO - 2018-10-30 06:01:58 --> Language Class Initialized
INFO - 2018-10-30 06:01:58 --> Loader Class Initialized
INFO - 2018-10-30 06:01:58 --> Helper loaded: url_helper
INFO - 2018-10-30 06:01:58 --> Database Driver Class Initialized
INFO - 2018-10-30 06:01:58 --> Helper loaded: form_helper
INFO - 2018-10-30 06:01:58 --> Form Validation Class Initialized
INFO - 2018-10-30 06:01:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:01:58 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:01:58 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:01:58 --> Email Class Initialized
INFO - 2018-10-30 06:01:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:01:58 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:01:58 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:01:58 --> Helper loaded: date_helper
INFO - 2018-10-30 06:01:58 --> Database Driver Class Initialized
INFO - 2018-10-30 06:01:58 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:01:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:01:58 --> Controller Class Initialized
INFO - 2018-10-30 06:01:58 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:01:58 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:01:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:01:58 --> Final output sent to browser
DEBUG - 2018-10-30 06:01:58 --> Total execution time: 0.6606
INFO - 2018-10-30 06:02:17 --> Config Class Initialized
INFO - 2018-10-30 06:02:17 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:02:17 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:02:17 --> Utf8 Class Initialized
INFO - 2018-10-30 06:02:17 --> URI Class Initialized
INFO - 2018-10-30 06:02:17 --> Router Class Initialized
INFO - 2018-10-30 06:02:17 --> Output Class Initialized
INFO - 2018-10-30 06:02:17 --> Security Class Initialized
DEBUG - 2018-10-30 06:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:02:17 --> Input Class Initialized
INFO - 2018-10-30 06:02:17 --> Language Class Initialized
INFO - 2018-10-30 06:02:17 --> Loader Class Initialized
INFO - 2018-10-30 06:02:17 --> Helper loaded: url_helper
INFO - 2018-10-30 06:02:17 --> Database Driver Class Initialized
INFO - 2018-10-30 06:02:17 --> Helper loaded: form_helper
INFO - 2018-10-30 06:02:17 --> Form Validation Class Initialized
INFO - 2018-10-30 06:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:02:17 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:02:17 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:02:17 --> Email Class Initialized
INFO - 2018-10-30 06:02:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:02:17 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:02:17 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:02:17 --> Helper loaded: date_helper
INFO - 2018-10-30 06:02:17 --> Database Driver Class Initialized
INFO - 2018-10-30 06:02:17 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:02:17 --> Controller Class Initialized
INFO - 2018-10-30 06:02:17 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:02:17 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:02:17 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:02:17 --> Final output sent to browser
DEBUG - 2018-10-30 06:02:17 --> Total execution time: 0.6224
INFO - 2018-10-30 06:08:53 --> Config Class Initialized
INFO - 2018-10-30 06:08:53 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:08:53 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:08:53 --> Utf8 Class Initialized
INFO - 2018-10-30 06:08:53 --> URI Class Initialized
INFO - 2018-10-30 06:08:53 --> Router Class Initialized
INFO - 2018-10-30 06:08:53 --> Output Class Initialized
INFO - 2018-10-30 06:08:53 --> Security Class Initialized
DEBUG - 2018-10-30 06:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:08:53 --> Input Class Initialized
INFO - 2018-10-30 06:08:53 --> Language Class Initialized
INFO - 2018-10-30 06:08:53 --> Loader Class Initialized
INFO - 2018-10-30 06:08:53 --> Helper loaded: url_helper
INFO - 2018-10-30 06:08:53 --> Database Driver Class Initialized
INFO - 2018-10-30 06:08:53 --> Helper loaded: form_helper
INFO - 2018-10-30 06:08:53 --> Form Validation Class Initialized
INFO - 2018-10-30 06:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:08:53 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:08:53 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:08:53 --> Email Class Initialized
INFO - 2018-10-30 06:08:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:08:53 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:08:53 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:08:53 --> Helper loaded: date_helper
INFO - 2018-10-30 06:08:53 --> Database Driver Class Initialized
INFO - 2018-10-30 06:08:53 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:08:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:08:53 --> Controller Class Initialized
INFO - 2018-10-30 06:08:53 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:08:53 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:08:53 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:08:53 --> Final output sent to browser
DEBUG - 2018-10-30 06:08:53 --> Total execution time: 0.6728
INFO - 2018-10-30 06:09:10 --> Config Class Initialized
INFO - 2018-10-30 06:09:10 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:09:10 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:09:10 --> Utf8 Class Initialized
INFO - 2018-10-30 06:09:10 --> URI Class Initialized
INFO - 2018-10-30 06:09:10 --> Router Class Initialized
INFO - 2018-10-30 06:09:10 --> Output Class Initialized
INFO - 2018-10-30 06:09:10 --> Security Class Initialized
DEBUG - 2018-10-30 06:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:09:10 --> Input Class Initialized
INFO - 2018-10-30 06:09:10 --> Language Class Initialized
INFO - 2018-10-30 06:09:10 --> Loader Class Initialized
INFO - 2018-10-30 06:09:10 --> Helper loaded: url_helper
INFO - 2018-10-30 06:09:10 --> Database Driver Class Initialized
INFO - 2018-10-30 06:09:11 --> Helper loaded: form_helper
INFO - 2018-10-30 06:09:11 --> Form Validation Class Initialized
INFO - 2018-10-30 06:09:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:09:11 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:09:11 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:09:11 --> Email Class Initialized
INFO - 2018-10-30 06:09:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:09:11 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:09:11 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:09:11 --> Helper loaded: date_helper
INFO - 2018-10-30 06:09:11 --> Database Driver Class Initialized
INFO - 2018-10-30 06:09:11 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:09:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:09:11 --> Controller Class Initialized
INFO - 2018-10-30 06:09:11 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:09:11 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:09:11 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:09:11 --> Final output sent to browser
DEBUG - 2018-10-30 06:09:11 --> Total execution time: 0.6209
INFO - 2018-10-30 06:09:13 --> Config Class Initialized
INFO - 2018-10-30 06:09:13 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:09:13 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:09:13 --> Utf8 Class Initialized
INFO - 2018-10-30 06:09:13 --> URI Class Initialized
INFO - 2018-10-30 06:09:13 --> Router Class Initialized
INFO - 2018-10-30 06:09:13 --> Output Class Initialized
INFO - 2018-10-30 06:09:13 --> Security Class Initialized
DEBUG - 2018-10-30 06:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:09:13 --> Input Class Initialized
INFO - 2018-10-30 06:09:13 --> Language Class Initialized
INFO - 2018-10-30 06:09:13 --> Loader Class Initialized
INFO - 2018-10-30 06:09:13 --> Helper loaded: url_helper
INFO - 2018-10-30 06:09:13 --> Database Driver Class Initialized
INFO - 2018-10-30 06:09:13 --> Helper loaded: form_helper
INFO - 2018-10-30 06:09:13 --> Form Validation Class Initialized
INFO - 2018-10-30 06:09:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:09:13 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:09:13 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:09:14 --> Email Class Initialized
INFO - 2018-10-30 06:09:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:09:14 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:09:14 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:09:14 --> Helper loaded: date_helper
INFO - 2018-10-30 06:09:14 --> Database Driver Class Initialized
INFO - 2018-10-30 06:09:14 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:09:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:09:14 --> Controller Class Initialized
INFO - 2018-10-30 06:09:14 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:09:14 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:09:14 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:09:14 --> Final output sent to browser
DEBUG - 2018-10-30 06:09:14 --> Total execution time: 0.6179
INFO - 2018-10-30 06:09:24 --> Config Class Initialized
INFO - 2018-10-30 06:09:24 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:09:24 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:09:24 --> Utf8 Class Initialized
INFO - 2018-10-30 06:09:24 --> URI Class Initialized
INFO - 2018-10-30 06:09:24 --> Router Class Initialized
INFO - 2018-10-30 06:09:24 --> Output Class Initialized
INFO - 2018-10-30 06:09:24 --> Security Class Initialized
DEBUG - 2018-10-30 06:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:09:24 --> Input Class Initialized
INFO - 2018-10-30 06:09:24 --> Language Class Initialized
INFO - 2018-10-30 06:09:24 --> Loader Class Initialized
INFO - 2018-10-30 06:09:24 --> Helper loaded: url_helper
INFO - 2018-10-30 06:09:24 --> Database Driver Class Initialized
INFO - 2018-10-30 06:09:24 --> Helper loaded: form_helper
INFO - 2018-10-30 06:09:24 --> Form Validation Class Initialized
INFO - 2018-10-30 06:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:09:24 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:09:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:09:24 --> Email Class Initialized
INFO - 2018-10-30 06:09:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:09:24 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:09:24 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:09:24 --> Helper loaded: date_helper
INFO - 2018-10-30 06:09:24 --> Database Driver Class Initialized
INFO - 2018-10-30 06:09:24 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:09:24 --> Controller Class Initialized
INFO - 2018-10-30 06:09:24 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:09:24 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:09:24 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:09:24 --> Final output sent to browser
DEBUG - 2018-10-30 06:09:25 --> Total execution time: 0.6243
INFO - 2018-10-30 06:09:51 --> Config Class Initialized
INFO - 2018-10-30 06:09:51 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:09:51 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:09:51 --> Utf8 Class Initialized
INFO - 2018-10-30 06:09:51 --> URI Class Initialized
INFO - 2018-10-30 06:09:51 --> Router Class Initialized
INFO - 2018-10-30 06:09:51 --> Output Class Initialized
INFO - 2018-10-30 06:09:51 --> Security Class Initialized
DEBUG - 2018-10-30 06:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:09:51 --> Input Class Initialized
INFO - 2018-10-30 06:09:51 --> Language Class Initialized
INFO - 2018-10-30 06:09:51 --> Loader Class Initialized
INFO - 2018-10-30 06:09:51 --> Helper loaded: url_helper
INFO - 2018-10-30 06:09:51 --> Database Driver Class Initialized
INFO - 2018-10-30 06:09:51 --> Helper loaded: form_helper
INFO - 2018-10-30 06:09:51 --> Form Validation Class Initialized
INFO - 2018-10-30 06:09:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:09:51 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:09:51 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:09:51 --> Email Class Initialized
INFO - 2018-10-30 06:09:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:09:51 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:09:51 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:09:51 --> Helper loaded: date_helper
INFO - 2018-10-30 06:09:51 --> Database Driver Class Initialized
INFO - 2018-10-30 06:09:51 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:09:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:09:51 --> Controller Class Initialized
INFO - 2018-10-30 06:09:51 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:09:51 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:09:52 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:09:52 --> Final output sent to browser
DEBUG - 2018-10-30 06:09:52 --> Total execution time: 0.6396
INFO - 2018-10-30 06:10:16 --> Config Class Initialized
INFO - 2018-10-30 06:10:16 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:10:16 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:10:16 --> Utf8 Class Initialized
INFO - 2018-10-30 06:10:16 --> URI Class Initialized
INFO - 2018-10-30 06:10:16 --> Router Class Initialized
INFO - 2018-10-30 06:10:16 --> Output Class Initialized
INFO - 2018-10-30 06:10:16 --> Security Class Initialized
DEBUG - 2018-10-30 06:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:10:16 --> Input Class Initialized
INFO - 2018-10-30 06:10:16 --> Language Class Initialized
INFO - 2018-10-30 06:10:16 --> Loader Class Initialized
INFO - 2018-10-30 06:10:16 --> Helper loaded: url_helper
INFO - 2018-10-30 06:10:16 --> Database Driver Class Initialized
INFO - 2018-10-30 06:10:16 --> Helper loaded: form_helper
INFO - 2018-10-30 06:10:16 --> Form Validation Class Initialized
INFO - 2018-10-30 06:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:10:16 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:10:16 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:10:16 --> Email Class Initialized
INFO - 2018-10-30 06:10:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:10:16 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:10:16 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:10:16 --> Helper loaded: date_helper
INFO - 2018-10-30 06:10:16 --> Database Driver Class Initialized
INFO - 2018-10-30 06:10:16 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:10:16 --> Controller Class Initialized
INFO - 2018-10-30 06:10:16 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:10:16 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:10:16 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:10:16 --> Final output sent to browser
DEBUG - 2018-10-30 06:10:16 --> Total execution time: 0.6190
INFO - 2018-10-30 06:12:15 --> Config Class Initialized
INFO - 2018-10-30 06:12:15 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:12:15 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:12:15 --> Utf8 Class Initialized
INFO - 2018-10-30 06:12:15 --> URI Class Initialized
INFO - 2018-10-30 06:12:15 --> Router Class Initialized
INFO - 2018-10-30 06:12:15 --> Output Class Initialized
INFO - 2018-10-30 06:12:15 --> Security Class Initialized
DEBUG - 2018-10-30 06:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:12:15 --> Input Class Initialized
INFO - 2018-10-30 06:12:15 --> Language Class Initialized
INFO - 2018-10-30 06:12:15 --> Loader Class Initialized
INFO - 2018-10-30 06:12:15 --> Helper loaded: url_helper
INFO - 2018-10-30 06:12:15 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:15 --> Helper loaded: form_helper
INFO - 2018-10-30 06:12:15 --> Form Validation Class Initialized
INFO - 2018-10-30 06:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:12:15 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:12:15 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:12:15 --> Email Class Initialized
INFO - 2018-10-30 06:12:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:12:15 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:12:15 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:12:15 --> Helper loaded: date_helper
INFO - 2018-10-30 06:12:15 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:15 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:12:16 --> Controller Class Initialized
INFO - 2018-10-30 06:12:16 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:12:16 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:12:16 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:12:16 --> Final output sent to browser
DEBUG - 2018-10-30 06:12:16 --> Total execution time: 0.6117
INFO - 2018-10-30 06:12:23 --> Config Class Initialized
INFO - 2018-10-30 06:12:23 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:12:23 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:12:23 --> Utf8 Class Initialized
INFO - 2018-10-30 06:12:23 --> URI Class Initialized
INFO - 2018-10-30 06:12:23 --> Router Class Initialized
INFO - 2018-10-30 06:12:23 --> Output Class Initialized
INFO - 2018-10-30 06:12:23 --> Security Class Initialized
DEBUG - 2018-10-30 06:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:12:23 --> Input Class Initialized
INFO - 2018-10-30 06:12:23 --> Language Class Initialized
INFO - 2018-10-30 06:12:23 --> Loader Class Initialized
INFO - 2018-10-30 06:12:23 --> Helper loaded: url_helper
INFO - 2018-10-30 06:12:23 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:23 --> Helper loaded: form_helper
INFO - 2018-10-30 06:12:23 --> Form Validation Class Initialized
INFO - 2018-10-30 06:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:12:23 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:12:23 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:12:23 --> Email Class Initialized
INFO - 2018-10-30 06:12:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:12:23 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:12:23 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:12:23 --> Helper loaded: date_helper
INFO - 2018-10-30 06:12:24 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:24 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:12:24 --> Controller Class Initialized
INFO - 2018-10-30 06:12:24 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:12:24 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:12:24 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:12:24 --> Final output sent to browser
DEBUG - 2018-10-30 06:12:24 --> Total execution time: 0.6365
INFO - 2018-10-30 06:12:24 --> Config Class Initialized
INFO - 2018-10-30 06:12:24 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:12:24 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:12:24 --> Utf8 Class Initialized
INFO - 2018-10-30 06:12:24 --> URI Class Initialized
INFO - 2018-10-30 06:12:24 --> Router Class Initialized
INFO - 2018-10-30 06:12:24 --> Output Class Initialized
INFO - 2018-10-30 06:12:24 --> Security Class Initialized
DEBUG - 2018-10-30 06:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:12:24 --> Input Class Initialized
INFO - 2018-10-30 06:12:24 --> Language Class Initialized
INFO - 2018-10-30 06:12:24 --> Loader Class Initialized
INFO - 2018-10-30 06:12:24 --> Helper loaded: url_helper
INFO - 2018-10-30 06:12:24 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:24 --> Helper loaded: form_helper
INFO - 2018-10-30 06:12:24 --> Form Validation Class Initialized
INFO - 2018-10-30 06:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:12:24 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:12:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:12:24 --> Email Class Initialized
INFO - 2018-10-30 06:12:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:12:25 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:12:25 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:12:25 --> Helper loaded: date_helper
INFO - 2018-10-30 06:12:25 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:25 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:12:25 --> Controller Class Initialized
INFO - 2018-10-30 06:12:25 --> Config Class Initialized
INFO - 2018-10-30 06:12:25 --> Hooks Class Initialized
INFO - 2018-10-30 06:12:25 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:12:25 --> Model "Notadetail_model" initialized
DEBUG - 2018-10-30 06:12:25 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:12:25 --> Utf8 Class Initialized
INFO - 2018-10-30 06:12:25 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:12:25 --> Final output sent to browser
INFO - 2018-10-30 06:12:25 --> URI Class Initialized
DEBUG - 2018-10-30 06:12:25 --> Total execution time: 0.6426
INFO - 2018-10-30 06:12:25 --> Router Class Initialized
INFO - 2018-10-30 06:12:25 --> Output Class Initialized
INFO - 2018-10-30 06:12:25 --> Security Class Initialized
DEBUG - 2018-10-30 06:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:12:25 --> Input Class Initialized
INFO - 2018-10-30 06:12:25 --> Language Class Initialized
INFO - 2018-10-30 06:12:25 --> Loader Class Initialized
INFO - 2018-10-30 06:12:25 --> Helper loaded: url_helper
INFO - 2018-10-30 06:12:25 --> Config Class Initialized
INFO - 2018-10-30 06:12:25 --> Hooks Class Initialized
INFO - 2018-10-30 06:12:25 --> Database Driver Class Initialized
DEBUG - 2018-10-30 06:12:25 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:12:25 --> Helper loaded: form_helper
INFO - 2018-10-30 06:12:25 --> Utf8 Class Initialized
INFO - 2018-10-30 06:12:25 --> Form Validation Class Initialized
INFO - 2018-10-30 06:12:25 --> URI Class Initialized
INFO - 2018-10-30 06:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:12:25 --> Pagination Class Initialized
INFO - 2018-10-30 06:12:25 --> Router Class Initialized
INFO - 2018-10-30 06:12:25 --> Output Class Initialized
DEBUG - 2018-10-30 06:12:25 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:12:25 --> Security Class Initialized
INFO - 2018-10-30 06:12:25 --> Email Class Initialized
INFO - 2018-10-30 06:12:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2018-10-30 06:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:12:25 --> Input Class Initialized
INFO - 2018-10-30 06:12:25 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:12:25 --> Helper loaded: language_helper
INFO - 2018-10-30 06:12:25 --> Language Class Initialized
INFO - 2018-10-30 06:12:25 --> Config Class Initialized
INFO - 2018-10-30 06:12:25 --> Hooks Class Initialized
INFO - 2018-10-30 06:12:25 --> Loader Class Initialized
DEBUG - 2018-10-30 06:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:12:25 --> Helper loaded: url_helper
DEBUG - 2018-10-30 06:12:25 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:12:25 --> Utf8 Class Initialized
INFO - 2018-10-30 06:12:25 --> Helper loaded: date_helper
INFO - 2018-10-30 06:12:25 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:25 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:25 --> URI Class Initialized
INFO - 2018-10-30 06:12:25 --> Helper loaded: form_helper
INFO - 2018-10-30 06:12:25 --> Form Validation Class Initialized
INFO - 2018-10-30 06:12:25 --> Router Class Initialized
INFO - 2018-10-30 06:12:25 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:12:25 --> Output Class Initialized
INFO - 2018-10-30 06:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:12:25 --> Pagination Class Initialized
INFO - 2018-10-30 06:12:25 --> Controller Class Initialized
INFO - 2018-10-30 06:12:25 --> Security Class Initialized
INFO - 2018-10-30 06:12:25 --> Model "Nota_model" initialized
DEBUG - 2018-10-30 06:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-30 06:12:25 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:12:25 --> Input Class Initialized
INFO - 2018-10-30 06:12:25 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:12:25 --> Email Class Initialized
INFO - 2018-10-30 06:12:25 --> Config Class Initialized
INFO - 2018-10-30 06:12:25 --> Hooks Class Initialized
INFO - 2018-10-30 06:12:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:12:25 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:12:25 --> Language Class Initialized
INFO - 2018-10-30 06:12:25 --> Final output sent to browser
INFO - 2018-10-30 06:12:25 --> Helper loaded: cookie_helper
DEBUG - 2018-10-30 06:12:25 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:12:25 --> Loader Class Initialized
DEBUG - 2018-10-30 06:12:25 --> Total execution time: 0.6142
INFO - 2018-10-30 06:12:25 --> Utf8 Class Initialized
INFO - 2018-10-30 06:12:25 --> Helper loaded: language_helper
INFO - 2018-10-30 06:12:25 --> Helper loaded: url_helper
INFO - 2018-10-30 06:12:25 --> URI Class Initialized
DEBUG - 2018-10-30 06:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:12:25 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:12:25 --> Router Class Initialized
INFO - 2018-10-30 06:12:25 --> Helper loaded: form_helper
INFO - 2018-10-30 06:12:25 --> Form Validation Class Initialized
INFO - 2018-10-30 06:12:25 --> Output Class Initialized
INFO - 2018-10-30 06:12:25 --> Helper loaded: date_helper
INFO - 2018-10-30 06:12:25 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:25 --> Security Class Initialized
INFO - 2018-10-30 06:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:12:25 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:12:25 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 06:12:25 --> Input Class Initialized
DEBUG - 2018-10-30 06:12:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2018-10-30 06:12:25 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:12:25 --> Controller Class Initialized
INFO - 2018-10-30 06:12:25 --> Language Class Initialized
INFO - 2018-10-30 06:12:25 --> Email Class Initialized
INFO - 2018-10-30 06:12:25 --> Config Class Initialized
INFO - 2018-10-30 06:12:25 --> Hooks Class Initialized
INFO - 2018-10-30 06:12:25 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:12:25 --> Loader Class Initialized
INFO - 2018-10-30 06:12:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:12:25 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:12:25 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:12:25 --> Helper loaded: url_helper
DEBUG - 2018-10-30 06:12:25 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:12:25 --> Utf8 Class Initialized
INFO - 2018-10-30 06:12:25 --> Helper loaded: language_helper
INFO - 2018-10-30 06:12:25 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:12:25 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:26 --> Final output sent to browser
INFO - 2018-10-30 06:12:26 --> URI Class Initialized
DEBUG - 2018-10-30 06:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:12:26 --> Helper loaded: form_helper
DEBUG - 2018-10-30 06:12:26 --> Total execution time: 0.6194
INFO - 2018-10-30 06:12:26 --> Form Validation Class Initialized
INFO - 2018-10-30 06:12:26 --> Router Class Initialized
INFO - 2018-10-30 06:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:12:26 --> Output Class Initialized
INFO - 2018-10-30 06:12:26 --> Pagination Class Initialized
INFO - 2018-10-30 06:12:26 --> Security Class Initialized
INFO - 2018-10-30 06:12:26 --> Helper loaded: date_helper
INFO - 2018-10-30 06:12:26 --> Database Driver Class Initialized
DEBUG - 2018-10-30 06:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-30 06:12:26 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:12:26 --> Input Class Initialized
INFO - 2018-10-30 06:12:26 --> Model "Ion_auth_model" initialized
INFO - 2018-10-30 06:12:26 --> Email Class Initialized
DEBUG - 2018-10-30 06:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:12:26 --> Language Class Initialized
INFO - 2018-10-30 06:12:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:12:26 --> Controller Class Initialized
INFO - 2018-10-30 06:12:26 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:12:26 --> Loader Class Initialized
INFO - 2018-10-30 06:12:26 --> Helper loaded: language_helper
INFO - 2018-10-30 06:12:26 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:12:26 --> Helper loaded: url_helper
INFO - 2018-10-30 06:12:26 --> Model "Notadetail_model" initialized
DEBUG - 2018-10-30 06:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:12:26 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:26 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:12:26 --> Final output sent to browser
INFO - 2018-10-30 06:12:26 --> Helper loaded: form_helper
DEBUG - 2018-10-30 06:12:26 --> Total execution time: 0.6342
INFO - 2018-10-30 06:12:26 --> Form Validation Class Initialized
INFO - 2018-10-30 06:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:12:26 --> Pagination Class Initialized
INFO - 2018-10-30 06:12:26 --> Helper loaded: date_helper
INFO - 2018-10-30 06:12:26 --> Database Driver Class Initialized
DEBUG - 2018-10-30 06:12:26 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:12:26 --> Email Class Initialized
INFO - 2018-10-30 06:12:26 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:12:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:12:26 --> Controller Class Initialized
INFO - 2018-10-30 06:12:26 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:12:26 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:12:26 --> Helper loaded: language_helper
INFO - 2018-10-30 06:12:26 --> Model "Notadetail_model" initialized
DEBUG - 2018-10-30 06:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:12:26 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:12:26 --> Final output sent to browser
DEBUG - 2018-10-30 06:12:26 --> Total execution time: 0.6706
INFO - 2018-10-30 06:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:12:26 --> Helper loaded: date_helper
INFO - 2018-10-30 06:12:26 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:26 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:12:26 --> Controller Class Initialized
INFO - 2018-10-30 06:12:26 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:12:26 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:12:26 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:12:26 --> Final output sent to browser
DEBUG - 2018-10-30 06:12:26 --> Total execution time: 0.6971
INFO - 2018-10-30 06:12:34 --> Config Class Initialized
INFO - 2018-10-30 06:12:34 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:12:34 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:12:34 --> Utf8 Class Initialized
INFO - 2018-10-30 06:12:34 --> URI Class Initialized
INFO - 2018-10-30 06:12:35 --> Router Class Initialized
INFO - 2018-10-30 06:12:35 --> Output Class Initialized
INFO - 2018-10-30 06:12:35 --> Security Class Initialized
DEBUG - 2018-10-30 06:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:12:35 --> Input Class Initialized
INFO - 2018-10-30 06:12:35 --> Language Class Initialized
INFO - 2018-10-30 06:12:35 --> Loader Class Initialized
INFO - 2018-10-30 06:12:35 --> Helper loaded: url_helper
INFO - 2018-10-30 06:12:35 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:35 --> Helper loaded: form_helper
INFO - 2018-10-30 06:12:35 --> Form Validation Class Initialized
INFO - 2018-10-30 06:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:12:35 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:12:35 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:12:35 --> Email Class Initialized
INFO - 2018-10-30 06:12:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:12:35 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:12:35 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:12:35 --> Helper loaded: date_helper
INFO - 2018-10-30 06:12:35 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:35 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:12:35 --> Controller Class Initialized
INFO - 2018-10-30 06:12:35 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:12:35 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:12:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:12:35 --> Final output sent to browser
DEBUG - 2018-10-30 06:12:35 --> Total execution time: 0.6389
INFO - 2018-10-30 06:12:50 --> Config Class Initialized
INFO - 2018-10-30 06:12:50 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:12:50 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:12:50 --> Utf8 Class Initialized
INFO - 2018-10-30 06:12:50 --> URI Class Initialized
INFO - 2018-10-30 06:12:50 --> Router Class Initialized
INFO - 2018-10-30 06:12:50 --> Output Class Initialized
INFO - 2018-10-30 06:12:50 --> Security Class Initialized
DEBUG - 2018-10-30 06:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:12:50 --> Input Class Initialized
INFO - 2018-10-30 06:12:50 --> Language Class Initialized
INFO - 2018-10-30 06:12:50 --> Loader Class Initialized
INFO - 2018-10-30 06:12:50 --> Helper loaded: url_helper
INFO - 2018-10-30 06:12:50 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:50 --> Helper loaded: form_helper
INFO - 2018-10-30 06:12:50 --> Form Validation Class Initialized
INFO - 2018-10-30 06:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:12:50 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:12:50 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:12:50 --> Email Class Initialized
INFO - 2018-10-30 06:12:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:12:50 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:12:50 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:12:50 --> Helper loaded: date_helper
INFO - 2018-10-30 06:12:50 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:50 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:12:50 --> Controller Class Initialized
INFO - 2018-10-30 06:12:50 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:12:50 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:12:50 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:12:50 --> Final output sent to browser
DEBUG - 2018-10-30 06:12:50 --> Total execution time: 0.6139
INFO - 2018-10-30 06:12:55 --> Config Class Initialized
INFO - 2018-10-30 06:12:55 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:12:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:12:55 --> Utf8 Class Initialized
INFO - 2018-10-30 06:12:55 --> URI Class Initialized
INFO - 2018-10-30 06:12:55 --> Router Class Initialized
INFO - 2018-10-30 06:12:55 --> Output Class Initialized
INFO - 2018-10-30 06:12:55 --> Security Class Initialized
DEBUG - 2018-10-30 06:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:12:55 --> Input Class Initialized
INFO - 2018-10-30 06:12:55 --> Language Class Initialized
INFO - 2018-10-30 06:12:55 --> Loader Class Initialized
INFO - 2018-10-30 06:12:55 --> Helper loaded: url_helper
INFO - 2018-10-30 06:12:55 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:55 --> Helper loaded: form_helper
INFO - 2018-10-30 06:12:55 --> Form Validation Class Initialized
INFO - 2018-10-30 06:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:12:55 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:12:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:12:55 --> Email Class Initialized
INFO - 2018-10-30 06:12:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:12:55 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:12:55 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:12:55 --> Helper loaded: date_helper
INFO - 2018-10-30 06:12:55 --> Database Driver Class Initialized
INFO - 2018-10-30 06:12:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:12:55 --> Controller Class Initialized
INFO - 2018-10-30 06:12:55 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:12:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:12:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:12:55 --> Final output sent to browser
DEBUG - 2018-10-30 06:12:56 --> Total execution time: 0.6337
INFO - 2018-10-30 06:13:28 --> Config Class Initialized
INFO - 2018-10-30 06:13:28 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:13:29 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:13:29 --> Utf8 Class Initialized
INFO - 2018-10-30 06:13:29 --> URI Class Initialized
INFO - 2018-10-30 06:13:29 --> Router Class Initialized
INFO - 2018-10-30 06:13:29 --> Output Class Initialized
INFO - 2018-10-30 06:13:29 --> Security Class Initialized
DEBUG - 2018-10-30 06:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:13:29 --> Input Class Initialized
INFO - 2018-10-30 06:13:29 --> Language Class Initialized
INFO - 2018-10-30 06:13:29 --> Loader Class Initialized
INFO - 2018-10-30 06:13:29 --> Helper loaded: url_helper
INFO - 2018-10-30 06:13:29 --> Database Driver Class Initialized
INFO - 2018-10-30 06:13:29 --> Helper loaded: form_helper
INFO - 2018-10-30 06:13:29 --> Form Validation Class Initialized
INFO - 2018-10-30 06:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:13:29 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:13:29 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:13:29 --> Email Class Initialized
INFO - 2018-10-30 06:13:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:13:29 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:13:29 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:13:29 --> Helper loaded: date_helper
INFO - 2018-10-30 06:13:29 --> Database Driver Class Initialized
INFO - 2018-10-30 06:13:29 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:13:29 --> Controller Class Initialized
INFO - 2018-10-30 06:13:29 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:13:29 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 06:13:29 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 61
INFO - 2018-10-30 06:13:49 --> Config Class Initialized
INFO - 2018-10-30 06:13:49 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:13:49 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:13:49 --> Utf8 Class Initialized
INFO - 2018-10-30 06:13:49 --> URI Class Initialized
INFO - 2018-10-30 06:13:49 --> Router Class Initialized
INFO - 2018-10-30 06:13:49 --> Output Class Initialized
INFO - 2018-10-30 06:13:49 --> Security Class Initialized
DEBUG - 2018-10-30 06:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:13:49 --> Input Class Initialized
INFO - 2018-10-30 06:13:49 --> Language Class Initialized
INFO - 2018-10-30 06:13:49 --> Loader Class Initialized
INFO - 2018-10-30 06:13:49 --> Helper loaded: url_helper
INFO - 2018-10-30 06:13:49 --> Database Driver Class Initialized
INFO - 2018-10-30 06:13:49 --> Helper loaded: form_helper
INFO - 2018-10-30 06:13:49 --> Form Validation Class Initialized
INFO - 2018-10-30 06:13:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:13:49 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:13:49 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:13:49 --> Email Class Initialized
INFO - 2018-10-30 06:13:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:13:49 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:13:50 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:13:50 --> Helper loaded: date_helper
INFO - 2018-10-30 06:13:50 --> Database Driver Class Initialized
INFO - 2018-10-30 06:13:50 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:13:50 --> Controller Class Initialized
INFO - 2018-10-30 06:13:50 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:13:50 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:13:50 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:13:50 --> Final output sent to browser
DEBUG - 2018-10-30 06:13:50 --> Total execution time: 0.6888
INFO - 2018-10-30 06:14:09 --> Config Class Initialized
INFO - 2018-10-30 06:14:09 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:14:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:14:09 --> Utf8 Class Initialized
INFO - 2018-10-30 06:14:09 --> URI Class Initialized
INFO - 2018-10-30 06:14:10 --> Router Class Initialized
INFO - 2018-10-30 06:14:10 --> Output Class Initialized
INFO - 2018-10-30 06:14:10 --> Security Class Initialized
DEBUG - 2018-10-30 06:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:14:10 --> Input Class Initialized
INFO - 2018-10-30 06:14:10 --> Language Class Initialized
INFO - 2018-10-30 06:14:10 --> Loader Class Initialized
INFO - 2018-10-30 06:14:10 --> Helper loaded: url_helper
INFO - 2018-10-30 06:14:10 --> Database Driver Class Initialized
INFO - 2018-10-30 06:14:10 --> Helper loaded: form_helper
INFO - 2018-10-30 06:14:10 --> Form Validation Class Initialized
INFO - 2018-10-30 06:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:14:10 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:14:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:14:10 --> Email Class Initialized
INFO - 2018-10-30 06:14:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:14:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:14:10 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:14:10 --> Helper loaded: date_helper
INFO - 2018-10-30 06:14:10 --> Database Driver Class Initialized
INFO - 2018-10-30 06:14:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:14:10 --> Controller Class Initialized
INFO - 2018-10-30 06:14:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:14:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:14:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:14:10 --> Final output sent to browser
DEBUG - 2018-10-30 06:14:10 --> Total execution time: 0.6320
INFO - 2018-10-30 06:14:49 --> Config Class Initialized
INFO - 2018-10-30 06:14:49 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:14:49 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:14:49 --> Utf8 Class Initialized
INFO - 2018-10-30 06:14:49 --> URI Class Initialized
INFO - 2018-10-30 06:14:49 --> Router Class Initialized
INFO - 2018-10-30 06:14:49 --> Output Class Initialized
INFO - 2018-10-30 06:14:49 --> Security Class Initialized
DEBUG - 2018-10-30 06:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:14:49 --> Input Class Initialized
INFO - 2018-10-30 06:14:49 --> Language Class Initialized
INFO - 2018-10-30 06:14:49 --> Loader Class Initialized
INFO - 2018-10-30 06:14:49 --> Helper loaded: url_helper
INFO - 2018-10-30 06:14:49 --> Database Driver Class Initialized
INFO - 2018-10-30 06:14:49 --> Helper loaded: form_helper
INFO - 2018-10-30 06:14:49 --> Form Validation Class Initialized
INFO - 2018-10-30 06:14:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:14:49 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:14:49 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:14:49 --> Email Class Initialized
INFO - 2018-10-30 06:14:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:14:49 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:14:49 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:14:49 --> Helper loaded: date_helper
INFO - 2018-10-30 06:14:49 --> Database Driver Class Initialized
INFO - 2018-10-30 06:14:49 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:14:49 --> Controller Class Initialized
INFO - 2018-10-30 06:14:49 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:14:49 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:14:49 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:14:49 --> Final output sent to browser
DEBUG - 2018-10-30 06:14:49 --> Total execution time: 0.6297
INFO - 2018-10-30 06:17:39 --> Config Class Initialized
INFO - 2018-10-30 06:17:39 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:17:39 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:17:39 --> Utf8 Class Initialized
INFO - 2018-10-30 06:17:39 --> URI Class Initialized
INFO - 2018-10-30 06:17:39 --> Router Class Initialized
INFO - 2018-10-30 06:17:39 --> Output Class Initialized
INFO - 2018-10-30 06:17:39 --> Security Class Initialized
DEBUG - 2018-10-30 06:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:17:39 --> Input Class Initialized
INFO - 2018-10-30 06:17:39 --> Language Class Initialized
INFO - 2018-10-30 06:17:39 --> Loader Class Initialized
INFO - 2018-10-30 06:17:39 --> Helper loaded: url_helper
INFO - 2018-10-30 06:17:39 --> Database Driver Class Initialized
INFO - 2018-10-30 06:17:39 --> Helper loaded: form_helper
INFO - 2018-10-30 06:17:39 --> Form Validation Class Initialized
INFO - 2018-10-30 06:17:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:17:39 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:17:39 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:17:39 --> Email Class Initialized
INFO - 2018-10-30 06:17:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:17:39 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:17:39 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:17:39 --> Helper loaded: date_helper
INFO - 2018-10-30 06:17:39 --> Database Driver Class Initialized
INFO - 2018-10-30 06:17:39 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:17:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:17:39 --> Controller Class Initialized
INFO - 2018-10-30 06:17:40 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:17:40 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 06:17:40 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 104
INFO - 2018-10-30 06:19:07 --> Config Class Initialized
INFO - 2018-10-30 06:19:07 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:19:07 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:19:07 --> Utf8 Class Initialized
INFO - 2018-10-30 06:19:07 --> URI Class Initialized
INFO - 2018-10-30 06:19:07 --> Router Class Initialized
INFO - 2018-10-30 06:19:07 --> Output Class Initialized
INFO - 2018-10-30 06:19:07 --> Security Class Initialized
DEBUG - 2018-10-30 06:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:19:07 --> Input Class Initialized
INFO - 2018-10-30 06:19:07 --> Language Class Initialized
INFO - 2018-10-30 06:19:07 --> Loader Class Initialized
INFO - 2018-10-30 06:19:07 --> Helper loaded: url_helper
INFO - 2018-10-30 06:19:07 --> Database Driver Class Initialized
INFO - 2018-10-30 06:19:07 --> Helper loaded: form_helper
INFO - 2018-10-30 06:19:07 --> Form Validation Class Initialized
INFO - 2018-10-30 06:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:19:07 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:19:08 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:19:08 --> Email Class Initialized
INFO - 2018-10-30 06:19:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:19:08 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:19:08 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:19:08 --> Helper loaded: date_helper
INFO - 2018-10-30 06:19:08 --> Database Driver Class Initialized
INFO - 2018-10-30 06:19:08 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:19:08 --> Controller Class Initialized
INFO - 2018-10-30 06:19:08 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:19:08 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 06:19:08 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 90
INFO - 2018-10-30 06:20:13 --> Config Class Initialized
INFO - 2018-10-30 06:20:13 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:20:13 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:20:13 --> Utf8 Class Initialized
INFO - 2018-10-30 06:20:13 --> URI Class Initialized
INFO - 2018-10-30 06:20:13 --> Router Class Initialized
INFO - 2018-10-30 06:20:13 --> Output Class Initialized
INFO - 2018-10-30 06:20:13 --> Security Class Initialized
DEBUG - 2018-10-30 06:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:20:13 --> Input Class Initialized
INFO - 2018-10-30 06:20:13 --> Language Class Initialized
INFO - 2018-10-30 06:20:13 --> Loader Class Initialized
INFO - 2018-10-30 06:20:13 --> Helper loaded: url_helper
INFO - 2018-10-30 06:20:13 --> Database Driver Class Initialized
INFO - 2018-10-30 06:20:13 --> Helper loaded: form_helper
INFO - 2018-10-30 06:20:13 --> Form Validation Class Initialized
INFO - 2018-10-30 06:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:20:13 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:20:13 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:20:13 --> Email Class Initialized
INFO - 2018-10-30 06:20:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:20:13 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:20:13 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:20:13 --> Helper loaded: date_helper
INFO - 2018-10-30 06:20:13 --> Database Driver Class Initialized
INFO - 2018-10-30 06:20:13 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:20:13 --> Controller Class Initialized
INFO - 2018-10-30 06:20:13 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:20:13 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:20:13 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:20:13 --> Final output sent to browser
DEBUG - 2018-10-30 06:20:13 --> Total execution time: 0.6413
INFO - 2018-10-30 06:20:43 --> Config Class Initialized
INFO - 2018-10-30 06:20:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:20:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:20:44 --> Utf8 Class Initialized
INFO - 2018-10-30 06:20:44 --> URI Class Initialized
INFO - 2018-10-30 06:20:44 --> Router Class Initialized
INFO - 2018-10-30 06:20:44 --> Output Class Initialized
INFO - 2018-10-30 06:20:44 --> Security Class Initialized
DEBUG - 2018-10-30 06:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:20:44 --> Input Class Initialized
INFO - 2018-10-30 06:20:44 --> Language Class Initialized
INFO - 2018-10-30 06:20:44 --> Loader Class Initialized
INFO - 2018-10-30 06:20:44 --> Helper loaded: url_helper
INFO - 2018-10-30 06:20:44 --> Database Driver Class Initialized
INFO - 2018-10-30 06:20:44 --> Helper loaded: form_helper
INFO - 2018-10-30 06:20:44 --> Form Validation Class Initialized
INFO - 2018-10-30 06:20:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:20:44 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:20:44 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:20:44 --> Email Class Initialized
INFO - 2018-10-30 06:20:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:20:44 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:20:44 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:20:44 --> Helper loaded: date_helper
INFO - 2018-10-30 06:20:44 --> Database Driver Class Initialized
INFO - 2018-10-30 06:20:44 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:20:44 --> Controller Class Initialized
INFO - 2018-10-30 06:20:44 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:20:44 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:20:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:20:44 --> Final output sent to browser
DEBUG - 2018-10-30 06:20:44 --> Total execution time: 0.6444
INFO - 2018-10-30 06:21:10 --> Config Class Initialized
INFO - 2018-10-30 06:21:10 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:21:10 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:21:10 --> Utf8 Class Initialized
INFO - 2018-10-30 06:21:10 --> URI Class Initialized
INFO - 2018-10-30 06:21:10 --> Router Class Initialized
INFO - 2018-10-30 06:21:10 --> Output Class Initialized
INFO - 2018-10-30 06:21:10 --> Security Class Initialized
DEBUG - 2018-10-30 06:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:21:10 --> Input Class Initialized
INFO - 2018-10-30 06:21:10 --> Language Class Initialized
INFO - 2018-10-30 06:21:10 --> Loader Class Initialized
INFO - 2018-10-30 06:21:10 --> Helper loaded: url_helper
INFO - 2018-10-30 06:21:10 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:10 --> Helper loaded: form_helper
INFO - 2018-10-30 06:21:10 --> Form Validation Class Initialized
INFO - 2018-10-30 06:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:21:10 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:21:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:21:10 --> Email Class Initialized
INFO - 2018-10-30 06:21:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:21:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:21:10 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:21:10 --> Helper loaded: date_helper
INFO - 2018-10-30 06:21:10 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:21:10 --> Controller Class Initialized
INFO - 2018-10-30 06:21:11 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:21:11 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:21:11 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:21:11 --> Final output sent to browser
DEBUG - 2018-10-30 06:21:11 --> Total execution time: 0.6427
INFO - 2018-10-30 06:21:18 --> Config Class Initialized
INFO - 2018-10-30 06:21:18 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:21:18 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:21:18 --> Utf8 Class Initialized
INFO - 2018-10-30 06:21:18 --> URI Class Initialized
INFO - 2018-10-30 06:21:18 --> Router Class Initialized
INFO - 2018-10-30 06:21:18 --> Output Class Initialized
INFO - 2018-10-30 06:21:18 --> Security Class Initialized
DEBUG - 2018-10-30 06:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:21:18 --> Input Class Initialized
INFO - 2018-10-30 06:21:18 --> Language Class Initialized
INFO - 2018-10-30 06:21:18 --> Loader Class Initialized
INFO - 2018-10-30 06:21:18 --> Helper loaded: url_helper
INFO - 2018-10-30 06:21:18 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:18 --> Helper loaded: form_helper
INFO - 2018-10-30 06:21:18 --> Form Validation Class Initialized
INFO - 2018-10-30 06:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:21:18 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:21:18 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:21:18 --> Email Class Initialized
INFO - 2018-10-30 06:21:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:21:18 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:21:18 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:21:18 --> Helper loaded: date_helper
INFO - 2018-10-30 06:21:18 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:21:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:21:18 --> Controller Class Initialized
INFO - 2018-10-30 06:21:18 --> Model "Item_model" initialized
INFO - 2018-10-30 06:21:18 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:21:18 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:21:19 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:21:19 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:21:19 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:21:19 --> Final output sent to browser
DEBUG - 2018-10-30 06:21:19 --> Total execution time: 0.6947
INFO - 2018-10-30 06:21:23 --> Config Class Initialized
INFO - 2018-10-30 06:21:23 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:21:23 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:21:23 --> Utf8 Class Initialized
INFO - 2018-10-30 06:21:23 --> URI Class Initialized
INFO - 2018-10-30 06:21:23 --> Router Class Initialized
INFO - 2018-10-30 06:21:23 --> Output Class Initialized
INFO - 2018-10-30 06:21:23 --> Security Class Initialized
DEBUG - 2018-10-30 06:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:21:23 --> Input Class Initialized
INFO - 2018-10-30 06:21:23 --> Language Class Initialized
INFO - 2018-10-30 06:21:23 --> Loader Class Initialized
INFO - 2018-10-30 06:21:23 --> Helper loaded: url_helper
INFO - 2018-10-30 06:21:23 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:23 --> Helper loaded: form_helper
INFO - 2018-10-30 06:21:23 --> Form Validation Class Initialized
INFO - 2018-10-30 06:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:21:23 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:21:23 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:21:23 --> Email Class Initialized
INFO - 2018-10-30 06:21:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:21:23 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:21:23 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:21:23 --> Helper loaded: date_helper
INFO - 2018-10-30 06:21:23 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:23 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:21:23 --> Controller Class Initialized
INFO - 2018-10-30 06:21:23 --> Model "Item_model" initialized
INFO - 2018-10-30 06:21:23 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:21:23 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:21:23 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:21:23 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:21:23 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 06:21:23 --> Final output sent to browser
DEBUG - 2018-10-30 06:21:23 --> Total execution time: 0.7061
INFO - 2018-10-30 06:21:23 --> Config Class Initialized
INFO - 2018-10-30 06:21:23 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:21:23 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:21:23 --> Utf8 Class Initialized
INFO - 2018-10-30 06:21:23 --> URI Class Initialized
INFO - 2018-10-30 06:21:23 --> Router Class Initialized
INFO - 2018-10-30 06:21:23 --> Output Class Initialized
INFO - 2018-10-30 06:21:23 --> Security Class Initialized
DEBUG - 2018-10-30 06:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:21:24 --> Input Class Initialized
INFO - 2018-10-30 06:21:24 --> Language Class Initialized
ERROR - 2018-10-30 06:21:24 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:21:25 --> Config Class Initialized
INFO - 2018-10-30 06:21:25 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:21:25 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:21:25 --> Utf8 Class Initialized
INFO - 2018-10-30 06:21:25 --> URI Class Initialized
INFO - 2018-10-30 06:21:25 --> Router Class Initialized
INFO - 2018-10-30 06:21:25 --> Output Class Initialized
INFO - 2018-10-30 06:21:25 --> Security Class Initialized
DEBUG - 2018-10-30 06:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:21:25 --> Input Class Initialized
INFO - 2018-10-30 06:21:25 --> Language Class Initialized
INFO - 2018-10-30 06:21:25 --> Loader Class Initialized
INFO - 2018-10-30 06:21:25 --> Helper loaded: url_helper
INFO - 2018-10-30 06:21:25 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:25 --> Helper loaded: form_helper
INFO - 2018-10-30 06:21:25 --> Form Validation Class Initialized
INFO - 2018-10-30 06:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:21:25 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:21:25 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:21:25 --> Email Class Initialized
INFO - 2018-10-30 06:21:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:21:25 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:21:25 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:21:25 --> Helper loaded: date_helper
INFO - 2018-10-30 06:21:25 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:25 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:21:25 --> Controller Class Initialized
INFO - 2018-10-30 06:21:25 --> Model "Item_model" initialized
INFO - 2018-10-30 06:21:25 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:21:25 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:21:25 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:21:25 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:21:25 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 06:21:25 --> Final output sent to browser
DEBUG - 2018-10-30 06:21:26 --> Total execution time: 0.7132
INFO - 2018-10-30 06:21:26 --> Config Class Initialized
INFO - 2018-10-30 06:21:26 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:21:26 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:21:26 --> Utf8 Class Initialized
INFO - 2018-10-30 06:21:26 --> URI Class Initialized
INFO - 2018-10-30 06:21:26 --> Router Class Initialized
INFO - 2018-10-30 06:21:26 --> Output Class Initialized
INFO - 2018-10-30 06:21:26 --> Security Class Initialized
DEBUG - 2018-10-30 06:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:21:26 --> Input Class Initialized
INFO - 2018-10-30 06:21:26 --> Language Class Initialized
ERROR - 2018-10-30 06:21:26 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:21:28 --> Config Class Initialized
INFO - 2018-10-30 06:21:28 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:21:28 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:21:28 --> Utf8 Class Initialized
INFO - 2018-10-30 06:21:28 --> URI Class Initialized
INFO - 2018-10-30 06:21:28 --> Router Class Initialized
INFO - 2018-10-30 06:21:28 --> Output Class Initialized
INFO - 2018-10-30 06:21:28 --> Security Class Initialized
DEBUG - 2018-10-30 06:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:21:28 --> Input Class Initialized
INFO - 2018-10-30 06:21:28 --> Language Class Initialized
INFO - 2018-10-30 06:21:28 --> Loader Class Initialized
INFO - 2018-10-30 06:21:28 --> Helper loaded: url_helper
INFO - 2018-10-30 06:21:28 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:28 --> Helper loaded: form_helper
INFO - 2018-10-30 06:21:28 --> Form Validation Class Initialized
INFO - 2018-10-30 06:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:21:29 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:21:29 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:21:29 --> Email Class Initialized
INFO - 2018-10-30 06:21:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:21:29 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:21:29 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:21:29 --> Helper loaded: date_helper
INFO - 2018-10-30 06:21:29 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:29 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:21:29 --> Controller Class Initialized
INFO - 2018-10-30 06:21:29 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:21:29 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:21:29 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:21:29 --> Final output sent to browser
DEBUG - 2018-10-30 06:21:29 --> Total execution time: 0.6449
INFO - 2018-10-30 06:21:42 --> Config Class Initialized
INFO - 2018-10-30 06:21:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:21:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:21:42 --> Utf8 Class Initialized
INFO - 2018-10-30 06:21:42 --> URI Class Initialized
INFO - 2018-10-30 06:21:42 --> Router Class Initialized
INFO - 2018-10-30 06:21:42 --> Output Class Initialized
INFO - 2018-10-30 06:21:42 --> Security Class Initialized
DEBUG - 2018-10-30 06:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:21:42 --> Input Class Initialized
INFO - 2018-10-30 06:21:42 --> Language Class Initialized
INFO - 2018-10-30 06:21:42 --> Loader Class Initialized
INFO - 2018-10-30 06:21:42 --> Helper loaded: url_helper
INFO - 2018-10-30 06:21:42 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:42 --> Helper loaded: form_helper
INFO - 2018-10-30 06:21:42 --> Form Validation Class Initialized
INFO - 2018-10-30 06:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:21:42 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:21:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:21:42 --> Email Class Initialized
INFO - 2018-10-30 06:21:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:21:42 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:21:42 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:21:42 --> Helper loaded: date_helper
INFO - 2018-10-30 06:21:42 --> Database Driver Class Initialized
INFO - 2018-10-30 06:21:42 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:21:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:21:42 --> Controller Class Initialized
INFO - 2018-10-30 06:21:42 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:21:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:21:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:21:42 --> Final output sent to browser
DEBUG - 2018-10-30 06:21:42 --> Total execution time: 0.6541
INFO - 2018-10-30 06:22:32 --> Config Class Initialized
INFO - 2018-10-30 06:22:32 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:22:32 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:22:32 --> Utf8 Class Initialized
INFO - 2018-10-30 06:22:32 --> URI Class Initialized
INFO - 2018-10-30 06:22:32 --> Router Class Initialized
INFO - 2018-10-30 06:22:32 --> Output Class Initialized
INFO - 2018-10-30 06:22:32 --> Security Class Initialized
DEBUG - 2018-10-30 06:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:22:32 --> Input Class Initialized
INFO - 2018-10-30 06:22:32 --> Language Class Initialized
INFO - 2018-10-30 06:22:32 --> Loader Class Initialized
INFO - 2018-10-30 06:22:32 --> Helper loaded: url_helper
INFO - 2018-10-30 06:22:32 --> Database Driver Class Initialized
INFO - 2018-10-30 06:22:32 --> Helper loaded: form_helper
INFO - 2018-10-30 06:22:32 --> Form Validation Class Initialized
INFO - 2018-10-30 06:22:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:22:32 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:22:32 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:22:32 --> Email Class Initialized
INFO - 2018-10-30 06:22:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:22:32 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:22:32 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:22:32 --> Helper loaded: date_helper
INFO - 2018-10-30 06:22:32 --> Database Driver Class Initialized
INFO - 2018-10-30 06:22:32 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:22:32 --> Controller Class Initialized
INFO - 2018-10-30 06:22:32 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:22:32 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:22:32 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:22:32 --> Final output sent to browser
DEBUG - 2018-10-30 06:22:32 --> Total execution time: 0.6558
INFO - 2018-10-30 06:23:17 --> Config Class Initialized
INFO - 2018-10-30 06:23:17 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:23:17 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:23:17 --> Utf8 Class Initialized
INFO - 2018-10-30 06:23:17 --> URI Class Initialized
INFO - 2018-10-30 06:23:17 --> Router Class Initialized
INFO - 2018-10-30 06:23:17 --> Output Class Initialized
INFO - 2018-10-30 06:23:17 --> Security Class Initialized
DEBUG - 2018-10-30 06:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:23:17 --> Input Class Initialized
INFO - 2018-10-30 06:23:17 --> Language Class Initialized
INFO - 2018-10-30 06:23:17 --> Loader Class Initialized
INFO - 2018-10-30 06:23:17 --> Helper loaded: url_helper
INFO - 2018-10-30 06:23:17 --> Database Driver Class Initialized
INFO - 2018-10-30 06:23:17 --> Helper loaded: form_helper
INFO - 2018-10-30 06:23:17 --> Form Validation Class Initialized
INFO - 2018-10-30 06:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:23:17 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:23:17 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:23:17 --> Email Class Initialized
INFO - 2018-10-30 06:23:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:23:17 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:23:17 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:23:17 --> Helper loaded: date_helper
INFO - 2018-10-30 06:23:17 --> Database Driver Class Initialized
INFO - 2018-10-30 06:23:17 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:23:17 --> Controller Class Initialized
INFO - 2018-10-30 06:23:17 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:23:17 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:23:17 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:23:17 --> Final output sent to browser
DEBUG - 2018-10-30 06:23:17 --> Total execution time: 0.6514
INFO - 2018-10-30 06:23:37 --> Config Class Initialized
INFO - 2018-10-30 06:23:37 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:23:37 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:23:37 --> Utf8 Class Initialized
INFO - 2018-10-30 06:23:37 --> URI Class Initialized
INFO - 2018-10-30 06:23:37 --> Router Class Initialized
INFO - 2018-10-30 06:23:37 --> Output Class Initialized
INFO - 2018-10-30 06:23:37 --> Security Class Initialized
DEBUG - 2018-10-30 06:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:23:37 --> Input Class Initialized
INFO - 2018-10-30 06:23:37 --> Language Class Initialized
INFO - 2018-10-30 06:23:37 --> Loader Class Initialized
INFO - 2018-10-30 06:23:38 --> Helper loaded: url_helper
INFO - 2018-10-30 06:23:38 --> Database Driver Class Initialized
INFO - 2018-10-30 06:23:38 --> Helper loaded: form_helper
INFO - 2018-10-30 06:23:38 --> Form Validation Class Initialized
INFO - 2018-10-30 06:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:23:38 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:23:38 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:23:38 --> Email Class Initialized
INFO - 2018-10-30 06:23:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:23:38 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:23:38 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:23:38 --> Helper loaded: date_helper
INFO - 2018-10-30 06:23:38 --> Database Driver Class Initialized
INFO - 2018-10-30 06:23:38 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:23:38 --> Controller Class Initialized
INFO - 2018-10-30 06:23:38 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:23:38 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:23:38 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:23:38 --> Final output sent to browser
DEBUG - 2018-10-30 06:23:38 --> Total execution time: 0.6662
INFO - 2018-10-30 06:24:09 --> Config Class Initialized
INFO - 2018-10-30 06:24:09 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:24:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:24:09 --> Utf8 Class Initialized
INFO - 2018-10-30 06:24:09 --> URI Class Initialized
INFO - 2018-10-30 06:24:09 --> Router Class Initialized
INFO - 2018-10-30 06:24:09 --> Output Class Initialized
INFO - 2018-10-30 06:24:09 --> Security Class Initialized
DEBUG - 2018-10-30 06:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:24:09 --> Input Class Initialized
INFO - 2018-10-30 06:24:09 --> Language Class Initialized
INFO - 2018-10-30 06:24:09 --> Loader Class Initialized
INFO - 2018-10-30 06:24:09 --> Helper loaded: url_helper
INFO - 2018-10-30 06:24:09 --> Database Driver Class Initialized
INFO - 2018-10-30 06:24:09 --> Helper loaded: form_helper
INFO - 2018-10-30 06:24:09 --> Form Validation Class Initialized
INFO - 2018-10-30 06:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:24:09 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:24:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:24:09 --> Email Class Initialized
INFO - 2018-10-30 06:24:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:24:09 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:24:09 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:24:09 --> Helper loaded: date_helper
INFO - 2018-10-30 06:24:09 --> Database Driver Class Initialized
INFO - 2018-10-30 06:24:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:24:09 --> Controller Class Initialized
INFO - 2018-10-30 06:24:09 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:24:09 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:24:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:24:09 --> Final output sent to browser
DEBUG - 2018-10-30 06:24:09 --> Total execution time: 0.6468
INFO - 2018-10-30 06:33:53 --> Config Class Initialized
INFO - 2018-10-30 06:33:54 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:33:54 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:33:54 --> Utf8 Class Initialized
INFO - 2018-10-30 06:33:54 --> URI Class Initialized
INFO - 2018-10-30 06:33:54 --> Router Class Initialized
INFO - 2018-10-30 06:33:54 --> Output Class Initialized
INFO - 2018-10-30 06:33:54 --> Security Class Initialized
DEBUG - 2018-10-30 06:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:33:54 --> Input Class Initialized
INFO - 2018-10-30 06:33:54 --> Language Class Initialized
INFO - 2018-10-30 06:33:54 --> Loader Class Initialized
INFO - 2018-10-30 06:33:54 --> Helper loaded: url_helper
INFO - 2018-10-30 06:33:54 --> Database Driver Class Initialized
INFO - 2018-10-30 06:33:54 --> Helper loaded: form_helper
INFO - 2018-10-30 06:33:54 --> Form Validation Class Initialized
INFO - 2018-10-30 06:33:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:33:54 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:33:54 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:33:54 --> Email Class Initialized
INFO - 2018-10-30 06:33:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:33:54 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:33:54 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:33:54 --> Helper loaded: date_helper
INFO - 2018-10-30 06:33:54 --> Database Driver Class Initialized
INFO - 2018-10-30 06:33:54 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:33:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:33:54 --> Controller Class Initialized
INFO - 2018-10-30 06:33:54 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:33:54 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 06:33:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
ERROR - 2018-10-30 06:33:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
INFO - 2018-10-30 06:33:54 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:33:54 --> Final output sent to browser
DEBUG - 2018-10-30 06:33:54 --> Total execution time: 0.7064
INFO - 2018-10-30 06:34:41 --> Config Class Initialized
INFO - 2018-10-30 06:34:41 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:34:41 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:34:41 --> Utf8 Class Initialized
INFO - 2018-10-30 06:34:41 --> URI Class Initialized
INFO - 2018-10-30 06:34:41 --> Router Class Initialized
INFO - 2018-10-30 06:34:41 --> Output Class Initialized
INFO - 2018-10-30 06:34:41 --> Security Class Initialized
DEBUG - 2018-10-30 06:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:34:42 --> Input Class Initialized
INFO - 2018-10-30 06:34:42 --> Language Class Initialized
INFO - 2018-10-30 06:34:42 --> Loader Class Initialized
INFO - 2018-10-30 06:34:42 --> Helper loaded: url_helper
INFO - 2018-10-30 06:34:42 --> Database Driver Class Initialized
INFO - 2018-10-30 06:34:42 --> Helper loaded: form_helper
INFO - 2018-10-30 06:34:42 --> Form Validation Class Initialized
INFO - 2018-10-30 06:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:34:42 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:34:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:34:42 --> Email Class Initialized
INFO - 2018-10-30 06:34:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:34:42 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:34:42 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:34:42 --> Helper loaded: date_helper
INFO - 2018-10-30 06:34:42 --> Database Driver Class Initialized
INFO - 2018-10-30 06:34:42 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:34:42 --> Controller Class Initialized
INFO - 2018-10-30 06:34:42 --> Model "Item_model" initialized
INFO - 2018-10-30 06:34:42 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:34:42 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:34:42 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:34:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:34:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:34:42 --> Final output sent to browser
DEBUG - 2018-10-30 06:34:42 --> Total execution time: 0.7535
INFO - 2018-10-30 06:34:43 --> Config Class Initialized
INFO - 2018-10-30 06:34:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:34:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:34:43 --> Utf8 Class Initialized
INFO - 2018-10-30 06:34:43 --> URI Class Initialized
INFO - 2018-10-30 06:34:43 --> Router Class Initialized
INFO - 2018-10-30 06:34:43 --> Output Class Initialized
INFO - 2018-10-30 06:34:43 --> Security Class Initialized
DEBUG - 2018-10-30 06:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:34:43 --> Input Class Initialized
INFO - 2018-10-30 06:34:43 --> Language Class Initialized
INFO - 2018-10-30 06:34:43 --> Loader Class Initialized
INFO - 2018-10-30 06:34:43 --> Helper loaded: url_helper
INFO - 2018-10-30 06:34:43 --> Database Driver Class Initialized
INFO - 2018-10-30 06:34:43 --> Helper loaded: form_helper
INFO - 2018-10-30 06:34:43 --> Form Validation Class Initialized
INFO - 2018-10-30 06:34:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:34:43 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:34:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:34:43 --> Email Class Initialized
INFO - 2018-10-30 06:34:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:34:43 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:34:43 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:34:43 --> Helper loaded: date_helper
INFO - 2018-10-30 06:34:43 --> Database Driver Class Initialized
INFO - 2018-10-30 06:34:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:34:44 --> Controller Class Initialized
INFO - 2018-10-30 06:34:44 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:34:44 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:34:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:34:44 --> Final output sent to browser
DEBUG - 2018-10-30 06:34:44 --> Total execution time: 0.7004
INFO - 2018-10-30 06:34:50 --> Config Class Initialized
INFO - 2018-10-30 06:34:50 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:34:50 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:34:50 --> Utf8 Class Initialized
INFO - 2018-10-30 06:34:50 --> URI Class Initialized
INFO - 2018-10-30 06:34:50 --> Router Class Initialized
INFO - 2018-10-30 06:34:50 --> Output Class Initialized
INFO - 2018-10-30 06:34:50 --> Security Class Initialized
DEBUG - 2018-10-30 06:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:34:50 --> Input Class Initialized
INFO - 2018-10-30 06:34:50 --> Language Class Initialized
INFO - 2018-10-30 06:34:50 --> Loader Class Initialized
INFO - 2018-10-30 06:34:50 --> Helper loaded: url_helper
INFO - 2018-10-30 06:34:50 --> Database Driver Class Initialized
INFO - 2018-10-30 06:34:50 --> Helper loaded: form_helper
INFO - 2018-10-30 06:34:50 --> Form Validation Class Initialized
INFO - 2018-10-30 06:34:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:34:50 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:34:50 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:34:50 --> Email Class Initialized
INFO - 2018-10-30 06:34:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:34:50 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:34:50 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:34:50 --> Helper loaded: date_helper
INFO - 2018-10-30 06:34:50 --> Database Driver Class Initialized
INFO - 2018-10-30 06:34:50 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:34:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:34:50 --> Controller Class Initialized
INFO - 2018-10-30 06:34:50 --> Model "Item_model" initialized
INFO - 2018-10-30 06:34:50 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:34:50 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:34:50 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:34:50 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:34:50 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:34:50 --> Final output sent to browser
DEBUG - 2018-10-30 06:34:50 --> Total execution time: 0.7176
INFO - 2018-10-30 06:34:55 --> Config Class Initialized
INFO - 2018-10-30 06:34:55 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:34:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:34:55 --> Utf8 Class Initialized
INFO - 2018-10-30 06:34:55 --> URI Class Initialized
INFO - 2018-10-30 06:34:55 --> Router Class Initialized
INFO - 2018-10-30 06:34:55 --> Output Class Initialized
INFO - 2018-10-30 06:34:55 --> Security Class Initialized
DEBUG - 2018-10-30 06:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:34:55 --> Input Class Initialized
INFO - 2018-10-30 06:34:55 --> Language Class Initialized
INFO - 2018-10-30 06:34:55 --> Loader Class Initialized
INFO - 2018-10-30 06:34:55 --> Helper loaded: url_helper
INFO - 2018-10-30 06:34:55 --> Database Driver Class Initialized
INFO - 2018-10-30 06:34:55 --> Helper loaded: form_helper
INFO - 2018-10-30 06:34:55 --> Form Validation Class Initialized
INFO - 2018-10-30 06:34:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:34:55 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:34:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:34:55 --> Email Class Initialized
INFO - 2018-10-30 06:34:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:34:55 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:34:55 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:34:55 --> Helper loaded: date_helper
INFO - 2018-10-30 06:34:55 --> Database Driver Class Initialized
INFO - 2018-10-30 06:34:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:34:55 --> Controller Class Initialized
INFO - 2018-10-30 06:34:55 --> Model "Item_model" initialized
INFO - 2018-10-30 06:34:55 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:34:55 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:34:55 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:34:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:34:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 06:34:55 --> Final output sent to browser
DEBUG - 2018-10-30 06:34:55 --> Total execution time: 0.7034
INFO - 2018-10-30 06:34:55 --> Config Class Initialized
INFO - 2018-10-30 06:34:55 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:34:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:34:55 --> Utf8 Class Initialized
INFO - 2018-10-30 06:34:55 --> URI Class Initialized
INFO - 2018-10-30 06:34:55 --> Router Class Initialized
INFO - 2018-10-30 06:34:56 --> Output Class Initialized
INFO - 2018-10-30 06:34:56 --> Security Class Initialized
DEBUG - 2018-10-30 06:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:34:56 --> Input Class Initialized
INFO - 2018-10-30 06:34:56 --> Language Class Initialized
ERROR - 2018-10-30 06:34:56 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:34:58 --> Config Class Initialized
INFO - 2018-10-30 06:34:58 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:34:58 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:34:58 --> Utf8 Class Initialized
INFO - 2018-10-30 06:34:58 --> URI Class Initialized
INFO - 2018-10-30 06:34:58 --> Router Class Initialized
INFO - 2018-10-30 06:34:58 --> Output Class Initialized
INFO - 2018-10-30 06:34:58 --> Security Class Initialized
DEBUG - 2018-10-30 06:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:34:58 --> Input Class Initialized
INFO - 2018-10-30 06:34:58 --> Language Class Initialized
INFO - 2018-10-30 06:34:58 --> Loader Class Initialized
INFO - 2018-10-30 06:34:58 --> Helper loaded: url_helper
INFO - 2018-10-30 06:34:58 --> Database Driver Class Initialized
INFO - 2018-10-30 06:34:58 --> Helper loaded: form_helper
INFO - 2018-10-30 06:34:58 --> Form Validation Class Initialized
INFO - 2018-10-30 06:34:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:34:58 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:34:58 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:34:58 --> Email Class Initialized
INFO - 2018-10-30 06:34:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:34:58 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:34:58 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:34:58 --> Helper loaded: date_helper
INFO - 2018-10-30 06:34:58 --> Database Driver Class Initialized
INFO - 2018-10-30 06:34:58 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:34:59 --> Controller Class Initialized
INFO - 2018-10-30 06:34:59 --> Model "Item_model" initialized
INFO - 2018-10-30 06:34:59 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:34:59 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:34:59 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:34:59 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:34:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 06:34:59 --> Final output sent to browser
DEBUG - 2018-10-30 06:34:59 --> Total execution time: 0.7280
INFO - 2018-10-30 06:34:59 --> Config Class Initialized
INFO - 2018-10-30 06:34:59 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:34:59 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:34:59 --> Utf8 Class Initialized
INFO - 2018-10-30 06:34:59 --> URI Class Initialized
INFO - 2018-10-30 06:34:59 --> Router Class Initialized
INFO - 2018-10-30 06:34:59 --> Output Class Initialized
INFO - 2018-10-30 06:34:59 --> Security Class Initialized
DEBUG - 2018-10-30 06:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:34:59 --> Input Class Initialized
INFO - 2018-10-30 06:34:59 --> Language Class Initialized
ERROR - 2018-10-30 06:34:59 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:35:03 --> Config Class Initialized
INFO - 2018-10-30 06:35:03 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:35:03 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:35:03 --> Utf8 Class Initialized
INFO - 2018-10-30 06:35:03 --> URI Class Initialized
INFO - 2018-10-30 06:35:03 --> Router Class Initialized
INFO - 2018-10-30 06:35:03 --> Output Class Initialized
INFO - 2018-10-30 06:35:03 --> Security Class Initialized
DEBUG - 2018-10-30 06:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:35:03 --> Input Class Initialized
INFO - 2018-10-30 06:35:03 --> Language Class Initialized
INFO - 2018-10-30 06:35:03 --> Loader Class Initialized
INFO - 2018-10-30 06:35:03 --> Helper loaded: url_helper
INFO - 2018-10-30 06:35:03 --> Database Driver Class Initialized
INFO - 2018-10-30 06:35:03 --> Helper loaded: form_helper
INFO - 2018-10-30 06:35:03 --> Form Validation Class Initialized
INFO - 2018-10-30 06:35:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:35:03 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:35:03 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:35:03 --> Email Class Initialized
INFO - 2018-10-30 06:35:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:35:03 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:35:03 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:35:03 --> Helper loaded: date_helper
INFO - 2018-10-30 06:35:03 --> Database Driver Class Initialized
INFO - 2018-10-30 06:35:03 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:35:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:35:03 --> Controller Class Initialized
INFO - 2018-10-30 06:35:03 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:35:03 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:35:03 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:35:03 --> Final output sent to browser
DEBUG - 2018-10-30 06:35:03 --> Total execution time: 0.6713
INFO - 2018-10-30 06:35:06 --> Config Class Initialized
INFO - 2018-10-30 06:35:06 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:35:06 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:35:07 --> Utf8 Class Initialized
INFO - 2018-10-30 06:35:07 --> URI Class Initialized
INFO - 2018-10-30 06:35:07 --> Router Class Initialized
INFO - 2018-10-30 06:35:07 --> Output Class Initialized
INFO - 2018-10-30 06:35:07 --> Security Class Initialized
DEBUG - 2018-10-30 06:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:35:07 --> Input Class Initialized
INFO - 2018-10-30 06:35:07 --> Language Class Initialized
INFO - 2018-10-30 06:35:07 --> Loader Class Initialized
INFO - 2018-10-30 06:35:07 --> Helper loaded: url_helper
INFO - 2018-10-30 06:35:07 --> Database Driver Class Initialized
INFO - 2018-10-30 06:35:07 --> Helper loaded: form_helper
INFO - 2018-10-30 06:35:07 --> Form Validation Class Initialized
INFO - 2018-10-30 06:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:35:07 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:35:07 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:35:07 --> Email Class Initialized
INFO - 2018-10-30 06:35:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:35:07 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:35:07 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:35:07 --> Helper loaded: date_helper
INFO - 2018-10-30 06:35:07 --> Database Driver Class Initialized
INFO - 2018-10-30 06:35:07 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:35:07 --> Controller Class Initialized
INFO - 2018-10-30 06:35:07 --> Model "Item_model" initialized
INFO - 2018-10-30 06:35:07 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:35:07 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:35:07 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:35:07 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:35:07 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:35:07 --> Final output sent to browser
DEBUG - 2018-10-30 06:35:07 --> Total execution time: 0.7243
INFO - 2018-10-30 06:35:10 --> Config Class Initialized
INFO - 2018-10-30 06:35:10 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:35:10 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:35:10 --> Utf8 Class Initialized
INFO - 2018-10-30 06:35:10 --> URI Class Initialized
INFO - 2018-10-30 06:35:10 --> Router Class Initialized
INFO - 2018-10-30 06:35:10 --> Output Class Initialized
INFO - 2018-10-30 06:35:10 --> Security Class Initialized
DEBUG - 2018-10-30 06:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:35:10 --> Input Class Initialized
INFO - 2018-10-30 06:35:10 --> Language Class Initialized
INFO - 2018-10-30 06:35:10 --> Loader Class Initialized
INFO - 2018-10-30 06:35:10 --> Helper loaded: url_helper
INFO - 2018-10-30 06:35:10 --> Database Driver Class Initialized
INFO - 2018-10-30 06:35:10 --> Helper loaded: form_helper
INFO - 2018-10-30 06:35:10 --> Form Validation Class Initialized
INFO - 2018-10-30 06:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:35:10 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:35:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:35:10 --> Email Class Initialized
INFO - 2018-10-30 06:35:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:35:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:35:10 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:35:10 --> Helper loaded: date_helper
INFO - 2018-10-30 06:35:10 --> Database Driver Class Initialized
INFO - 2018-10-30 06:35:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:35:10 --> Controller Class Initialized
INFO - 2018-10-30 06:35:10 --> Model "Item_model" initialized
INFO - 2018-10-30 06:35:10 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:35:10 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:35:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:35:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:35:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 06:35:10 --> Final output sent to browser
INFO - 2018-10-30 06:35:10 --> Config Class Initialized
DEBUG - 2018-10-30 06:35:10 --> Total execution time: 0.7295
INFO - 2018-10-30 06:35:10 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:35:10 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:35:10 --> Utf8 Class Initialized
INFO - 2018-10-30 06:35:10 --> URI Class Initialized
INFO - 2018-10-30 06:35:10 --> Router Class Initialized
INFO - 2018-10-30 06:35:10 --> Output Class Initialized
INFO - 2018-10-30 06:35:10 --> Security Class Initialized
DEBUG - 2018-10-30 06:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:35:11 --> Input Class Initialized
INFO - 2018-10-30 06:35:11 --> Language Class Initialized
ERROR - 2018-10-30 06:35:11 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:35:12 --> Config Class Initialized
INFO - 2018-10-30 06:35:12 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:35:12 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:35:12 --> Utf8 Class Initialized
INFO - 2018-10-30 06:35:12 --> URI Class Initialized
INFO - 2018-10-30 06:35:12 --> Router Class Initialized
INFO - 2018-10-30 06:35:12 --> Output Class Initialized
INFO - 2018-10-30 06:35:12 --> Security Class Initialized
DEBUG - 2018-10-30 06:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:35:12 --> Input Class Initialized
INFO - 2018-10-30 06:35:12 --> Language Class Initialized
INFO - 2018-10-30 06:35:12 --> Loader Class Initialized
INFO - 2018-10-30 06:35:12 --> Helper loaded: url_helper
INFO - 2018-10-30 06:35:12 --> Database Driver Class Initialized
INFO - 2018-10-30 06:35:12 --> Helper loaded: form_helper
INFO - 2018-10-30 06:35:12 --> Form Validation Class Initialized
INFO - 2018-10-30 06:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:35:12 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:35:12 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:35:12 --> Email Class Initialized
INFO - 2018-10-30 06:35:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:35:12 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:35:12 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:35:12 --> Helper loaded: date_helper
INFO - 2018-10-30 06:35:12 --> Database Driver Class Initialized
INFO - 2018-10-30 06:35:12 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:35:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:35:12 --> Controller Class Initialized
INFO - 2018-10-30 06:35:12 --> Model "Item_model" initialized
INFO - 2018-10-30 06:35:12 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:35:12 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:35:12 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:35:12 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:35:12 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 06:35:12 --> Final output sent to browser
DEBUG - 2018-10-30 06:35:12 --> Total execution time: 0.7331
INFO - 2018-10-30 06:35:13 --> Config Class Initialized
INFO - 2018-10-30 06:35:13 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:35:13 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:35:13 --> Utf8 Class Initialized
INFO - 2018-10-30 06:35:13 --> URI Class Initialized
INFO - 2018-10-30 06:35:13 --> Router Class Initialized
INFO - 2018-10-30 06:35:13 --> Output Class Initialized
INFO - 2018-10-30 06:35:13 --> Security Class Initialized
DEBUG - 2018-10-30 06:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:35:13 --> Input Class Initialized
INFO - 2018-10-30 06:35:13 --> Language Class Initialized
ERROR - 2018-10-30 06:35:13 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:35:16 --> Config Class Initialized
INFO - 2018-10-30 06:35:16 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:35:16 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:35:16 --> Utf8 Class Initialized
INFO - 2018-10-30 06:35:16 --> URI Class Initialized
INFO - 2018-10-30 06:35:16 --> Router Class Initialized
INFO - 2018-10-30 06:35:16 --> Output Class Initialized
INFO - 2018-10-30 06:35:16 --> Security Class Initialized
DEBUG - 2018-10-30 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:35:16 --> Input Class Initialized
INFO - 2018-10-30 06:35:16 --> Language Class Initialized
INFO - 2018-10-30 06:35:16 --> Loader Class Initialized
INFO - 2018-10-30 06:35:16 --> Helper loaded: url_helper
INFO - 2018-10-30 06:35:16 --> Database Driver Class Initialized
INFO - 2018-10-30 06:35:16 --> Helper loaded: form_helper
INFO - 2018-10-30 06:35:16 --> Form Validation Class Initialized
INFO - 2018-10-30 06:35:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:35:16 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:35:16 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:35:16 --> Email Class Initialized
INFO - 2018-10-30 06:35:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:35:16 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:35:16 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:35:16 --> Helper loaded: date_helper
INFO - 2018-10-30 06:35:16 --> Database Driver Class Initialized
INFO - 2018-10-30 06:35:16 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:35:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:35:16 --> Controller Class Initialized
INFO - 2018-10-30 06:35:16 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:35:16 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:35:16 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:35:16 --> Final output sent to browser
DEBUG - 2018-10-30 06:35:16 --> Total execution time: 0.6842
INFO - 2018-10-30 06:37:16 --> Config Class Initialized
INFO - 2018-10-30 06:37:16 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:37:16 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:37:16 --> Utf8 Class Initialized
INFO - 2018-10-30 06:37:16 --> URI Class Initialized
INFO - 2018-10-30 06:37:16 --> Router Class Initialized
INFO - 2018-10-30 06:37:16 --> Output Class Initialized
INFO - 2018-10-30 06:37:16 --> Security Class Initialized
DEBUG - 2018-10-30 06:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:37:16 --> Input Class Initialized
INFO - 2018-10-30 06:37:16 --> Language Class Initialized
INFO - 2018-10-30 06:37:16 --> Loader Class Initialized
INFO - 2018-10-30 06:37:16 --> Helper loaded: url_helper
INFO - 2018-10-30 06:37:16 --> Database Driver Class Initialized
INFO - 2018-10-30 06:37:16 --> Helper loaded: form_helper
INFO - 2018-10-30 06:37:16 --> Form Validation Class Initialized
INFO - 2018-10-30 06:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:37:16 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:37:16 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:37:16 --> Email Class Initialized
INFO - 2018-10-30 06:37:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:37:16 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:37:16 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:37:16 --> Helper loaded: date_helper
INFO - 2018-10-30 06:37:16 --> Database Driver Class Initialized
INFO - 2018-10-30 06:37:16 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:37:16 --> Controller Class Initialized
INFO - 2018-10-30 06:37:16 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:37:16 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:37:16 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:37:16 --> Final output sent to browser
DEBUG - 2018-10-30 06:37:16 --> Total execution time: 0.6802
INFO - 2018-10-30 06:37:59 --> Config Class Initialized
INFO - 2018-10-30 06:37:59 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:37:59 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:37:59 --> Utf8 Class Initialized
INFO - 2018-10-30 06:37:59 --> URI Class Initialized
INFO - 2018-10-30 06:37:59 --> Router Class Initialized
INFO - 2018-10-30 06:37:59 --> Output Class Initialized
INFO - 2018-10-30 06:37:59 --> Security Class Initialized
DEBUG - 2018-10-30 06:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:37:59 --> Input Class Initialized
INFO - 2018-10-30 06:37:59 --> Language Class Initialized
INFO - 2018-10-30 06:37:59 --> Loader Class Initialized
INFO - 2018-10-30 06:37:59 --> Helper loaded: url_helper
INFO - 2018-10-30 06:37:59 --> Database Driver Class Initialized
INFO - 2018-10-30 06:37:59 --> Helper loaded: form_helper
INFO - 2018-10-30 06:37:59 --> Form Validation Class Initialized
INFO - 2018-10-30 06:37:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:37:59 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:37:59 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:37:59 --> Email Class Initialized
INFO - 2018-10-30 06:37:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:37:59 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:37:59 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:37:59 --> Helper loaded: date_helper
INFO - 2018-10-30 06:37:59 --> Database Driver Class Initialized
INFO - 2018-10-30 06:37:59 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:37:59 --> Controller Class Initialized
INFO - 2018-10-30 06:37:59 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:37:59 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:37:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:37:59 --> Final output sent to browser
DEBUG - 2018-10-30 06:37:59 --> Total execution time: 0.6906
INFO - 2018-10-30 06:38:03 --> Config Class Initialized
INFO - 2018-10-30 06:38:03 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:38:03 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:38:03 --> Utf8 Class Initialized
INFO - 2018-10-30 06:38:03 --> URI Class Initialized
INFO - 2018-10-30 06:38:03 --> Router Class Initialized
INFO - 2018-10-30 06:38:03 --> Output Class Initialized
INFO - 2018-10-30 06:38:03 --> Security Class Initialized
DEBUG - 2018-10-30 06:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:38:03 --> Input Class Initialized
INFO - 2018-10-30 06:38:03 --> Language Class Initialized
INFO - 2018-10-30 06:38:03 --> Loader Class Initialized
INFO - 2018-10-30 06:38:03 --> Helper loaded: url_helper
INFO - 2018-10-30 06:38:03 --> Database Driver Class Initialized
INFO - 2018-10-30 06:38:04 --> Helper loaded: form_helper
INFO - 2018-10-30 06:38:04 --> Form Validation Class Initialized
INFO - 2018-10-30 06:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:38:04 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:38:04 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:38:04 --> Email Class Initialized
INFO - 2018-10-30 06:38:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:38:04 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:38:04 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:38:04 --> Helper loaded: date_helper
INFO - 2018-10-30 06:38:04 --> Database Driver Class Initialized
INFO - 2018-10-30 06:38:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:38:04 --> Controller Class Initialized
INFO - 2018-10-30 06:38:04 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:38:04 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:38:04 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:38:04 --> Final output sent to browser
DEBUG - 2018-10-30 06:38:04 --> Total execution time: 0.6800
INFO - 2018-10-30 06:38:28 --> Config Class Initialized
INFO - 2018-10-30 06:38:28 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:38:28 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:38:28 --> Utf8 Class Initialized
INFO - 2018-10-30 06:38:28 --> URI Class Initialized
INFO - 2018-10-30 06:38:28 --> Router Class Initialized
INFO - 2018-10-30 06:38:28 --> Output Class Initialized
INFO - 2018-10-30 06:38:28 --> Security Class Initialized
DEBUG - 2018-10-30 06:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:38:28 --> Input Class Initialized
INFO - 2018-10-30 06:38:28 --> Language Class Initialized
INFO - 2018-10-30 06:38:28 --> Loader Class Initialized
INFO - 2018-10-30 06:38:28 --> Helper loaded: url_helper
INFO - 2018-10-30 06:38:28 --> Database Driver Class Initialized
INFO - 2018-10-30 06:38:28 --> Helper loaded: form_helper
INFO - 2018-10-30 06:38:28 --> Form Validation Class Initialized
INFO - 2018-10-30 06:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:38:28 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:38:28 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:38:28 --> Email Class Initialized
INFO - 2018-10-30 06:38:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:38:28 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:38:28 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:38:29 --> Helper loaded: date_helper
INFO - 2018-10-30 06:38:29 --> Database Driver Class Initialized
INFO - 2018-10-30 06:38:29 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:38:29 --> Controller Class Initialized
INFO - 2018-10-30 06:38:29 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:38:29 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 06:38:29 --> Severity: Notice --> Undefined variable: data2 D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 65
ERROR - 2018-10-30 06:38:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
ERROR - 2018-10-30 06:38:29 --> Severity: Notice --> Undefined variable: data2 D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 65
ERROR - 2018-10-30 06:38:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
INFO - 2018-10-30 06:38:29 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:38:29 --> Final output sent to browser
DEBUG - 2018-10-30 06:38:29 --> Total execution time: 0.7581
INFO - 2018-10-30 06:38:35 --> Config Class Initialized
INFO - 2018-10-30 06:38:35 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:38:35 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:38:35 --> Utf8 Class Initialized
INFO - 2018-10-30 06:38:35 --> URI Class Initialized
INFO - 2018-10-30 06:38:35 --> Router Class Initialized
INFO - 2018-10-30 06:38:35 --> Output Class Initialized
INFO - 2018-10-30 06:38:35 --> Security Class Initialized
DEBUG - 2018-10-30 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:38:35 --> Input Class Initialized
INFO - 2018-10-30 06:38:35 --> Language Class Initialized
INFO - 2018-10-30 06:38:35 --> Loader Class Initialized
INFO - 2018-10-30 06:38:35 --> Helper loaded: url_helper
INFO - 2018-10-30 06:38:35 --> Database Driver Class Initialized
INFO - 2018-10-30 06:38:35 --> Helper loaded: form_helper
INFO - 2018-10-30 06:38:35 --> Form Validation Class Initialized
INFO - 2018-10-30 06:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:38:35 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:38:35 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:38:35 --> Email Class Initialized
INFO - 2018-10-30 06:38:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:38:35 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:38:35 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:38:35 --> Helper loaded: date_helper
INFO - 2018-10-30 06:38:35 --> Database Driver Class Initialized
INFO - 2018-10-30 06:38:35 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:38:35 --> Controller Class Initialized
INFO - 2018-10-30 06:38:35 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:38:35 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 06:38:35 --> Severity: Notice --> Undefined variable: data2 D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 65
ERROR - 2018-10-30 06:38:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
ERROR - 2018-10-30 06:38:35 --> Severity: Notice --> Undefined variable: data2 D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 65
ERROR - 2018-10-30 06:38:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
INFO - 2018-10-30 06:38:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:38:35 --> Final output sent to browser
DEBUG - 2018-10-30 06:38:35 --> Total execution time: 0.7237
INFO - 2018-10-30 06:38:37 --> Config Class Initialized
INFO - 2018-10-30 06:38:37 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:38:37 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:38:37 --> Utf8 Class Initialized
INFO - 2018-10-30 06:38:37 --> URI Class Initialized
INFO - 2018-10-30 06:38:37 --> Router Class Initialized
INFO - 2018-10-30 06:38:37 --> Output Class Initialized
INFO - 2018-10-30 06:38:37 --> Security Class Initialized
DEBUG - 2018-10-30 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:38:37 --> Input Class Initialized
INFO - 2018-10-30 06:38:37 --> Language Class Initialized
INFO - 2018-10-30 06:38:37 --> Loader Class Initialized
INFO - 2018-10-30 06:38:37 --> Helper loaded: url_helper
INFO - 2018-10-30 06:38:37 --> Database Driver Class Initialized
INFO - 2018-10-30 06:38:37 --> Helper loaded: form_helper
INFO - 2018-10-30 06:38:37 --> Form Validation Class Initialized
INFO - 2018-10-30 06:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:38:37 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:38:37 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:38:37 --> Email Class Initialized
INFO - 2018-10-30 06:38:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:38:37 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:38:37 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:38:37 --> Helper loaded: date_helper
INFO - 2018-10-30 06:38:37 --> Database Driver Class Initialized
INFO - 2018-10-30 06:38:37 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:38:37 --> Controller Class Initialized
INFO - 2018-10-30 06:38:37 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:38:37 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 06:38:37 --> Severity: Notice --> Undefined variable: data2 D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 65
ERROR - 2018-10-30 06:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
ERROR - 2018-10-30 06:38:37 --> Severity: Notice --> Undefined variable: data2 D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 65
ERROR - 2018-10-30 06:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
INFO - 2018-10-30 06:38:37 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:38:37 --> Final output sent to browser
DEBUG - 2018-10-30 06:38:37 --> Total execution time: 0.7708
INFO - 2018-10-30 06:38:43 --> Config Class Initialized
INFO - 2018-10-30 06:38:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:38:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:38:43 --> Utf8 Class Initialized
INFO - 2018-10-30 06:38:43 --> URI Class Initialized
INFO - 2018-10-30 06:38:43 --> Router Class Initialized
INFO - 2018-10-30 06:38:43 --> Output Class Initialized
INFO - 2018-10-30 06:38:43 --> Security Class Initialized
DEBUG - 2018-10-30 06:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:38:43 --> Input Class Initialized
INFO - 2018-10-30 06:38:43 --> Language Class Initialized
INFO - 2018-10-30 06:38:43 --> Loader Class Initialized
INFO - 2018-10-30 06:38:43 --> Helper loaded: url_helper
INFO - 2018-10-30 06:38:43 --> Database Driver Class Initialized
INFO - 2018-10-30 06:38:43 --> Helper loaded: form_helper
INFO - 2018-10-30 06:38:43 --> Form Validation Class Initialized
INFO - 2018-10-30 06:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:38:43 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:38:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:38:43 --> Email Class Initialized
INFO - 2018-10-30 06:38:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:38:43 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:38:43 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:38:43 --> Helper loaded: date_helper
INFO - 2018-10-30 06:38:43 --> Database Driver Class Initialized
INFO - 2018-10-30 06:38:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:38:43 --> Controller Class Initialized
INFO - 2018-10-30 06:38:43 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:38:44 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 06:38:44 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 65
ERROR - 2018-10-30 06:38:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
ERROR - 2018-10-30 06:38:44 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 65
ERROR - 2018-10-30 06:38:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
INFO - 2018-10-30 06:38:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:38:44 --> Final output sent to browser
DEBUG - 2018-10-30 06:38:44 --> Total execution time: 0.7422
INFO - 2018-10-30 06:39:49 --> Config Class Initialized
INFO - 2018-10-30 06:39:49 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:39:49 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:39:49 --> Utf8 Class Initialized
INFO - 2018-10-30 06:39:49 --> URI Class Initialized
INFO - 2018-10-30 06:39:49 --> Router Class Initialized
INFO - 2018-10-30 06:39:49 --> Output Class Initialized
INFO - 2018-10-30 06:39:49 --> Security Class Initialized
DEBUG - 2018-10-30 06:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:39:49 --> Input Class Initialized
INFO - 2018-10-30 06:39:49 --> Language Class Initialized
INFO - 2018-10-30 06:39:49 --> Loader Class Initialized
INFO - 2018-10-30 06:39:49 --> Helper loaded: url_helper
INFO - 2018-10-30 06:39:49 --> Database Driver Class Initialized
INFO - 2018-10-30 06:39:49 --> Helper loaded: form_helper
INFO - 2018-10-30 06:39:49 --> Form Validation Class Initialized
INFO - 2018-10-30 06:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:39:49 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:39:49 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:39:49 --> Email Class Initialized
INFO - 2018-10-30 06:39:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:39:49 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:39:49 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:39:49 --> Helper loaded: date_helper
INFO - 2018-10-30 06:39:49 --> Database Driver Class Initialized
INFO - 2018-10-30 06:39:49 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:39:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:39:49 --> Controller Class Initialized
INFO - 2018-10-30 06:39:49 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:39:49 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 06:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
ERROR - 2018-10-30 06:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\masterwedding\application\views\laporan\index.php 66
INFO - 2018-10-30 06:39:49 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:39:49 --> Final output sent to browser
DEBUG - 2018-10-30 06:39:49 --> Total execution time: 0.6976
INFO - 2018-10-30 06:39:58 --> Config Class Initialized
INFO - 2018-10-30 06:39:58 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:39:58 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:39:58 --> Utf8 Class Initialized
INFO - 2018-10-30 06:39:58 --> URI Class Initialized
INFO - 2018-10-30 06:39:58 --> Router Class Initialized
INFO - 2018-10-30 06:39:58 --> Output Class Initialized
INFO - 2018-10-30 06:39:58 --> Security Class Initialized
DEBUG - 2018-10-30 06:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:39:58 --> Input Class Initialized
INFO - 2018-10-30 06:39:58 --> Language Class Initialized
INFO - 2018-10-30 06:39:58 --> Loader Class Initialized
INFO - 2018-10-30 06:39:58 --> Helper loaded: url_helper
INFO - 2018-10-30 06:39:58 --> Database Driver Class Initialized
INFO - 2018-10-30 06:39:58 --> Helper loaded: form_helper
INFO - 2018-10-30 06:39:58 --> Form Validation Class Initialized
INFO - 2018-10-30 06:39:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:39:58 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:39:58 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:39:58 --> Email Class Initialized
INFO - 2018-10-30 06:39:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:39:58 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:39:58 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:39:58 --> Helper loaded: date_helper
INFO - 2018-10-30 06:39:58 --> Database Driver Class Initialized
INFO - 2018-10-30 06:39:58 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:39:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:39:58 --> Controller Class Initialized
INFO - 2018-10-30 06:39:58 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:39:58 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:39:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:39:58 --> Final output sent to browser
DEBUG - 2018-10-30 06:39:58 --> Total execution time: 0.6926
INFO - 2018-10-30 06:40:35 --> Config Class Initialized
INFO - 2018-10-30 06:40:35 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:40:35 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:40:35 --> Utf8 Class Initialized
INFO - 2018-10-30 06:40:35 --> URI Class Initialized
INFO - 2018-10-30 06:40:35 --> Router Class Initialized
INFO - 2018-10-30 06:40:35 --> Output Class Initialized
INFO - 2018-10-30 06:40:35 --> Security Class Initialized
DEBUG - 2018-10-30 06:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:40:35 --> Input Class Initialized
INFO - 2018-10-30 06:40:35 --> Language Class Initialized
INFO - 2018-10-30 06:40:35 --> Loader Class Initialized
INFO - 2018-10-30 06:40:35 --> Helper loaded: url_helper
INFO - 2018-10-30 06:40:35 --> Database Driver Class Initialized
INFO - 2018-10-30 06:40:35 --> Helper loaded: form_helper
INFO - 2018-10-30 06:40:35 --> Form Validation Class Initialized
INFO - 2018-10-30 06:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:40:36 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:40:36 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:40:36 --> Email Class Initialized
INFO - 2018-10-30 06:40:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:40:36 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:40:36 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:40:36 --> Helper loaded: date_helper
INFO - 2018-10-30 06:40:36 --> Database Driver Class Initialized
INFO - 2018-10-30 06:40:36 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:40:36 --> Controller Class Initialized
INFO - 2018-10-30 06:40:36 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:40:36 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:40:36 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:40:36 --> Final output sent to browser
DEBUG - 2018-10-30 06:40:36 --> Total execution time: 0.6772
INFO - 2018-10-30 06:41:01 --> Config Class Initialized
INFO - 2018-10-30 06:41:01 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:41:01 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:41:01 --> Utf8 Class Initialized
INFO - 2018-10-30 06:41:01 --> URI Class Initialized
INFO - 2018-10-30 06:41:01 --> Router Class Initialized
INFO - 2018-10-30 06:41:01 --> Output Class Initialized
INFO - 2018-10-30 06:41:01 --> Security Class Initialized
DEBUG - 2018-10-30 06:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:41:01 --> Input Class Initialized
INFO - 2018-10-30 06:41:01 --> Language Class Initialized
INFO - 2018-10-30 06:41:01 --> Loader Class Initialized
INFO - 2018-10-30 06:41:01 --> Helper loaded: url_helper
INFO - 2018-10-30 06:41:01 --> Database Driver Class Initialized
INFO - 2018-10-30 06:41:01 --> Helper loaded: form_helper
INFO - 2018-10-30 06:41:01 --> Form Validation Class Initialized
INFO - 2018-10-30 06:41:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:41:01 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:41:02 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:41:02 --> Email Class Initialized
INFO - 2018-10-30 06:41:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:41:02 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:41:02 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:41:02 --> Helper loaded: date_helper
INFO - 2018-10-30 06:41:02 --> Database Driver Class Initialized
INFO - 2018-10-30 06:41:02 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:41:02 --> Controller Class Initialized
INFO - 2018-10-30 06:41:02 --> Model "Item_model" initialized
INFO - 2018-10-30 06:41:02 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:41:02 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:41:02 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:41:02 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:41:02 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:41:02 --> Final output sent to browser
DEBUG - 2018-10-30 06:41:02 --> Total execution time: 0.7253
INFO - 2018-10-30 06:41:06 --> Config Class Initialized
INFO - 2018-10-30 06:41:06 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:41:06 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:41:06 --> Utf8 Class Initialized
INFO - 2018-10-30 06:41:06 --> URI Class Initialized
INFO - 2018-10-30 06:41:06 --> Router Class Initialized
INFO - 2018-10-30 06:41:06 --> Output Class Initialized
INFO - 2018-10-30 06:41:06 --> Security Class Initialized
DEBUG - 2018-10-30 06:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:41:06 --> Input Class Initialized
INFO - 2018-10-30 06:41:06 --> Language Class Initialized
INFO - 2018-10-30 06:41:06 --> Loader Class Initialized
INFO - 2018-10-30 06:41:06 --> Helper loaded: url_helper
INFO - 2018-10-30 06:41:06 --> Database Driver Class Initialized
INFO - 2018-10-30 06:41:06 --> Helper loaded: form_helper
INFO - 2018-10-30 06:41:06 --> Form Validation Class Initialized
INFO - 2018-10-30 06:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:41:06 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:41:06 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:41:06 --> Email Class Initialized
INFO - 2018-10-30 06:41:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:41:06 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:41:06 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:41:06 --> Helper loaded: date_helper
INFO - 2018-10-30 06:41:06 --> Database Driver Class Initialized
INFO - 2018-10-30 06:41:06 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:41:06 --> Controller Class Initialized
INFO - 2018-10-30 06:41:06 --> Model "Item_model" initialized
INFO - 2018-10-30 06:41:06 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:41:06 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:41:06 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:41:06 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:41:06 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 06:41:06 --> Final output sent to browser
DEBUG - 2018-10-30 06:41:06 --> Total execution time: 0.7315
INFO - 2018-10-30 06:41:07 --> Config Class Initialized
INFO - 2018-10-30 06:41:07 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:41:07 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:41:07 --> Utf8 Class Initialized
INFO - 2018-10-30 06:41:07 --> URI Class Initialized
INFO - 2018-10-30 06:41:07 --> Router Class Initialized
INFO - 2018-10-30 06:41:07 --> Output Class Initialized
INFO - 2018-10-30 06:41:07 --> Security Class Initialized
DEBUG - 2018-10-30 06:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:41:07 --> Input Class Initialized
INFO - 2018-10-30 06:41:07 --> Language Class Initialized
ERROR - 2018-10-30 06:41:07 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:41:08 --> Config Class Initialized
INFO - 2018-10-30 06:41:08 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:41:08 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:41:08 --> Utf8 Class Initialized
INFO - 2018-10-30 06:41:08 --> URI Class Initialized
INFO - 2018-10-30 06:41:08 --> Router Class Initialized
INFO - 2018-10-30 06:41:08 --> Output Class Initialized
INFO - 2018-10-30 06:41:08 --> Security Class Initialized
DEBUG - 2018-10-30 06:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:41:08 --> Input Class Initialized
INFO - 2018-10-30 06:41:08 --> Language Class Initialized
INFO - 2018-10-30 06:41:08 --> Loader Class Initialized
INFO - 2018-10-30 06:41:08 --> Helper loaded: url_helper
INFO - 2018-10-30 06:41:08 --> Database Driver Class Initialized
INFO - 2018-10-30 06:41:08 --> Helper loaded: form_helper
INFO - 2018-10-30 06:41:08 --> Form Validation Class Initialized
INFO - 2018-10-30 06:41:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:41:08 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:41:08 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:41:08 --> Email Class Initialized
INFO - 2018-10-30 06:41:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:41:08 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:41:08 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:41:08 --> Helper loaded: date_helper
INFO - 2018-10-30 06:41:08 --> Database Driver Class Initialized
INFO - 2018-10-30 06:41:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:41:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:41:09 --> Controller Class Initialized
INFO - 2018-10-30 06:41:09 --> Model "Item_model" initialized
INFO - 2018-10-30 06:41:09 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:41:09 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:41:09 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:41:09 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:41:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 06:41:09 --> Final output sent to browser
DEBUG - 2018-10-30 06:41:09 --> Total execution time: 0.8018
INFO - 2018-10-30 06:41:09 --> Config Class Initialized
INFO - 2018-10-30 06:41:09 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:41:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:41:09 --> Utf8 Class Initialized
INFO - 2018-10-30 06:41:09 --> URI Class Initialized
INFO - 2018-10-30 06:41:09 --> Router Class Initialized
INFO - 2018-10-30 06:41:09 --> Output Class Initialized
INFO - 2018-10-30 06:41:09 --> Security Class Initialized
DEBUG - 2018-10-30 06:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:41:09 --> Input Class Initialized
INFO - 2018-10-30 06:41:09 --> Language Class Initialized
ERROR - 2018-10-30 06:41:09 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:41:11 --> Config Class Initialized
INFO - 2018-10-30 06:41:11 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:41:11 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:41:11 --> Utf8 Class Initialized
INFO - 2018-10-30 06:41:11 --> URI Class Initialized
INFO - 2018-10-30 06:41:11 --> Router Class Initialized
INFO - 2018-10-30 06:41:11 --> Output Class Initialized
INFO - 2018-10-30 06:41:11 --> Security Class Initialized
DEBUG - 2018-10-30 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:41:11 --> Input Class Initialized
INFO - 2018-10-30 06:41:11 --> Language Class Initialized
INFO - 2018-10-30 06:41:11 --> Loader Class Initialized
INFO - 2018-10-30 06:41:11 --> Helper loaded: url_helper
INFO - 2018-10-30 06:41:11 --> Database Driver Class Initialized
INFO - 2018-10-30 06:41:11 --> Helper loaded: form_helper
INFO - 2018-10-30 06:41:11 --> Form Validation Class Initialized
INFO - 2018-10-30 06:41:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:41:11 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:41:11 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:41:11 --> Email Class Initialized
INFO - 2018-10-30 06:41:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:41:11 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:41:11 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:41:11 --> Helper loaded: date_helper
INFO - 2018-10-30 06:41:11 --> Database Driver Class Initialized
INFO - 2018-10-30 06:41:11 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:41:11 --> Controller Class Initialized
INFO - 2018-10-30 06:41:11 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:41:11 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:41:11 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:41:11 --> Final output sent to browser
DEBUG - 2018-10-30 06:41:11 --> Total execution time: 0.6981
INFO - 2018-10-30 06:44:10 --> Config Class Initialized
INFO - 2018-10-30 06:44:10 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:44:10 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:44:10 --> Utf8 Class Initialized
INFO - 2018-10-30 06:44:10 --> URI Class Initialized
INFO - 2018-10-30 06:44:10 --> Router Class Initialized
INFO - 2018-10-30 06:44:10 --> Output Class Initialized
INFO - 2018-10-30 06:44:10 --> Security Class Initialized
DEBUG - 2018-10-30 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:44:10 --> Input Class Initialized
INFO - 2018-10-30 06:44:10 --> Language Class Initialized
INFO - 2018-10-30 06:44:10 --> Loader Class Initialized
INFO - 2018-10-30 06:44:10 --> Helper loaded: url_helper
INFO - 2018-10-30 06:44:10 --> Database Driver Class Initialized
INFO - 2018-10-30 06:44:10 --> Helper loaded: form_helper
INFO - 2018-10-30 06:44:10 --> Form Validation Class Initialized
INFO - 2018-10-30 06:44:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:44:10 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:44:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:44:10 --> Email Class Initialized
INFO - 2018-10-30 06:44:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:44:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:44:10 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:44:10 --> Helper loaded: date_helper
INFO - 2018-10-30 06:44:10 --> Database Driver Class Initialized
INFO - 2018-10-30 06:44:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:44:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:44:10 --> Controller Class Initialized
INFO - 2018-10-30 06:44:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:44:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:44:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:44:10 --> Final output sent to browser
DEBUG - 2018-10-30 06:44:10 --> Total execution time: 0.6925
INFO - 2018-10-30 06:45:33 --> Config Class Initialized
INFO - 2018-10-30 06:45:33 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:45:33 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:45:33 --> Utf8 Class Initialized
INFO - 2018-10-30 06:45:33 --> URI Class Initialized
INFO - 2018-10-30 06:45:33 --> Router Class Initialized
INFO - 2018-10-30 06:45:33 --> Output Class Initialized
INFO - 2018-10-30 06:45:33 --> Security Class Initialized
DEBUG - 2018-10-30 06:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:45:33 --> Input Class Initialized
INFO - 2018-10-30 06:45:33 --> Language Class Initialized
INFO - 2018-10-30 06:45:33 --> Loader Class Initialized
INFO - 2018-10-30 06:45:33 --> Helper loaded: url_helper
INFO - 2018-10-30 06:45:33 --> Database Driver Class Initialized
INFO - 2018-10-30 06:45:33 --> Helper loaded: form_helper
INFO - 2018-10-30 06:45:33 --> Form Validation Class Initialized
INFO - 2018-10-30 06:45:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:45:33 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:45:33 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:45:33 --> Email Class Initialized
INFO - 2018-10-30 06:45:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:45:33 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:45:33 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:45:33 --> Helper loaded: date_helper
INFO - 2018-10-30 06:45:33 --> Database Driver Class Initialized
INFO - 2018-10-30 06:45:33 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:45:33 --> Controller Class Initialized
INFO - 2018-10-30 06:45:33 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:45:33 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:45:33 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:45:33 --> Final output sent to browser
DEBUG - 2018-10-30 06:45:33 --> Total execution time: 0.6990
INFO - 2018-10-30 06:45:35 --> Config Class Initialized
INFO - 2018-10-30 06:45:35 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:45:35 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:45:35 --> Utf8 Class Initialized
INFO - 2018-10-30 06:45:35 --> URI Class Initialized
INFO - 2018-10-30 06:45:35 --> Router Class Initialized
INFO - 2018-10-30 06:45:35 --> Output Class Initialized
INFO - 2018-10-30 06:45:35 --> Security Class Initialized
DEBUG - 2018-10-30 06:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:45:35 --> Input Class Initialized
INFO - 2018-10-30 06:45:35 --> Language Class Initialized
INFO - 2018-10-30 06:45:35 --> Loader Class Initialized
INFO - 2018-10-30 06:45:35 --> Helper loaded: url_helper
INFO - 2018-10-30 06:45:35 --> Database Driver Class Initialized
INFO - 2018-10-30 06:45:35 --> Helper loaded: form_helper
INFO - 2018-10-30 06:45:35 --> Form Validation Class Initialized
INFO - 2018-10-30 06:45:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:45:36 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:45:36 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:45:36 --> Email Class Initialized
INFO - 2018-10-30 06:45:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:45:36 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:45:36 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:45:36 --> Helper loaded: date_helper
INFO - 2018-10-30 06:45:36 --> Database Driver Class Initialized
INFO - 2018-10-30 06:45:36 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:45:36 --> Controller Class Initialized
INFO - 2018-10-30 06:45:36 --> Model "Item_model" initialized
INFO - 2018-10-30 06:45:36 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:45:36 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:45:36 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:45:36 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:45:36 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:45:36 --> Final output sent to browser
DEBUG - 2018-10-30 06:45:36 --> Total execution time: 0.8031
INFO - 2018-10-30 06:45:40 --> Config Class Initialized
INFO - 2018-10-30 06:45:40 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:45:40 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:45:40 --> Utf8 Class Initialized
INFO - 2018-10-30 06:45:40 --> URI Class Initialized
INFO - 2018-10-30 06:45:40 --> Router Class Initialized
INFO - 2018-10-30 06:45:40 --> Output Class Initialized
INFO - 2018-10-30 06:45:40 --> Security Class Initialized
DEBUG - 2018-10-30 06:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:45:40 --> Input Class Initialized
INFO - 2018-10-30 06:45:40 --> Language Class Initialized
INFO - 2018-10-30 06:45:41 --> Loader Class Initialized
INFO - 2018-10-30 06:45:41 --> Helper loaded: url_helper
INFO - 2018-10-30 06:45:41 --> Database Driver Class Initialized
INFO - 2018-10-30 06:45:41 --> Helper loaded: form_helper
INFO - 2018-10-30 06:45:41 --> Form Validation Class Initialized
INFO - 2018-10-30 06:45:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:45:41 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:45:41 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:45:41 --> Email Class Initialized
INFO - 2018-10-30 06:45:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:45:41 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:45:41 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:45:41 --> Helper loaded: date_helper
INFO - 2018-10-30 06:45:41 --> Database Driver Class Initialized
INFO - 2018-10-30 06:45:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:45:41 --> Controller Class Initialized
INFO - 2018-10-30 06:45:41 --> Model "Item_model" initialized
INFO - 2018-10-30 06:45:41 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:45:41 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:45:41 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:45:41 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:45:41 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 06:45:41 --> Final output sent to browser
INFO - 2018-10-30 06:45:41 --> Config Class Initialized
INFO - 2018-10-30 06:45:41 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:45:41 --> Total execution time: 0.7774
DEBUG - 2018-10-30 06:45:41 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:45:41 --> Utf8 Class Initialized
INFO - 2018-10-30 06:45:41 --> URI Class Initialized
INFO - 2018-10-30 06:45:41 --> Router Class Initialized
INFO - 2018-10-30 06:45:41 --> Output Class Initialized
INFO - 2018-10-30 06:45:41 --> Security Class Initialized
DEBUG - 2018-10-30 06:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:45:41 --> Input Class Initialized
INFO - 2018-10-30 06:45:41 --> Language Class Initialized
ERROR - 2018-10-30 06:45:41 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:45:44 --> Config Class Initialized
INFO - 2018-10-30 06:45:44 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:45:44 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:45:44 --> Utf8 Class Initialized
INFO - 2018-10-30 06:45:44 --> URI Class Initialized
INFO - 2018-10-30 06:45:44 --> Router Class Initialized
INFO - 2018-10-30 06:45:44 --> Output Class Initialized
INFO - 2018-10-30 06:45:44 --> Security Class Initialized
DEBUG - 2018-10-30 06:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:45:44 --> Input Class Initialized
INFO - 2018-10-30 06:45:44 --> Language Class Initialized
INFO - 2018-10-30 06:45:44 --> Loader Class Initialized
INFO - 2018-10-30 06:45:44 --> Helper loaded: url_helper
INFO - 2018-10-30 06:45:44 --> Database Driver Class Initialized
INFO - 2018-10-30 06:45:44 --> Helper loaded: form_helper
INFO - 2018-10-30 06:45:44 --> Form Validation Class Initialized
INFO - 2018-10-30 06:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:45:44 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:45:44 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:45:44 --> Email Class Initialized
INFO - 2018-10-30 06:45:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:45:44 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:45:44 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:45:44 --> Helper loaded: date_helper
INFO - 2018-10-30 06:45:44 --> Database Driver Class Initialized
INFO - 2018-10-30 06:45:45 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:45:45 --> Controller Class Initialized
INFO - 2018-10-30 06:45:45 --> Model "Item_model" initialized
INFO - 2018-10-30 06:45:45 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:45:45 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:45:45 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:45:45 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:45:45 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 06:45:45 --> Final output sent to browser
DEBUG - 2018-10-30 06:45:45 --> Total execution time: 0.7675
INFO - 2018-10-30 06:45:45 --> Config Class Initialized
INFO - 2018-10-30 06:45:45 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:45:45 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:45:45 --> Utf8 Class Initialized
INFO - 2018-10-30 06:45:45 --> URI Class Initialized
INFO - 2018-10-30 06:45:45 --> Router Class Initialized
INFO - 2018-10-30 06:45:45 --> Output Class Initialized
INFO - 2018-10-30 06:45:45 --> Security Class Initialized
DEBUG - 2018-10-30 06:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:45:45 --> Input Class Initialized
INFO - 2018-10-30 06:45:45 --> Language Class Initialized
ERROR - 2018-10-30 06:45:45 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:45:59 --> Config Class Initialized
INFO - 2018-10-30 06:45:59 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:45:59 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:45:59 --> Utf8 Class Initialized
INFO - 2018-10-30 06:45:59 --> URI Class Initialized
INFO - 2018-10-30 06:45:59 --> Router Class Initialized
INFO - 2018-10-30 06:45:59 --> Output Class Initialized
INFO - 2018-10-30 06:45:59 --> Security Class Initialized
DEBUG - 2018-10-30 06:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:45:59 --> Input Class Initialized
INFO - 2018-10-30 06:45:59 --> Language Class Initialized
INFO - 2018-10-30 06:45:59 --> Loader Class Initialized
INFO - 2018-10-30 06:45:59 --> Helper loaded: url_helper
INFO - 2018-10-30 06:45:59 --> Database Driver Class Initialized
INFO - 2018-10-30 06:45:59 --> Helper loaded: form_helper
INFO - 2018-10-30 06:45:59 --> Form Validation Class Initialized
INFO - 2018-10-30 06:45:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:45:59 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:45:59 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:45:59 --> Email Class Initialized
INFO - 2018-10-30 06:45:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:45:59 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:45:59 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:45:59 --> Helper loaded: date_helper
INFO - 2018-10-30 06:45:59 --> Database Driver Class Initialized
INFO - 2018-10-30 06:45:59 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:45:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:45:59 --> Controller Class Initialized
INFO - 2018-10-30 06:45:59 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:45:59 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:45:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:46:00 --> Final output sent to browser
DEBUG - 2018-10-30 06:46:00 --> Total execution time: 0.6916
INFO - 2018-10-30 06:47:36 --> Config Class Initialized
INFO - 2018-10-30 06:47:36 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:47:36 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:47:36 --> Utf8 Class Initialized
INFO - 2018-10-30 06:47:36 --> URI Class Initialized
INFO - 2018-10-30 06:47:36 --> Router Class Initialized
INFO - 2018-10-30 06:47:36 --> Output Class Initialized
INFO - 2018-10-30 06:47:36 --> Security Class Initialized
DEBUG - 2018-10-30 06:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:47:36 --> Input Class Initialized
INFO - 2018-10-30 06:47:36 --> Language Class Initialized
INFO - 2018-10-30 06:47:36 --> Loader Class Initialized
INFO - 2018-10-30 06:47:36 --> Helper loaded: url_helper
INFO - 2018-10-30 06:47:36 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:36 --> Helper loaded: form_helper
INFO - 2018-10-30 06:47:36 --> Form Validation Class Initialized
INFO - 2018-10-30 06:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:47:36 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:47:36 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:47:36 --> Email Class Initialized
INFO - 2018-10-30 06:47:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:47:36 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:47:36 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:47:36 --> Helper loaded: date_helper
INFO - 2018-10-30 06:47:36 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:36 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:47:37 --> Controller Class Initialized
INFO - 2018-10-30 06:47:37 --> Model "Item_model" initialized
INFO - 2018-10-30 06:47:37 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:47:37 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:47:37 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:47:37 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:47:37 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:47:37 --> Final output sent to browser
DEBUG - 2018-10-30 06:47:37 --> Total execution time: 0.8250
INFO - 2018-10-30 06:47:40 --> Config Class Initialized
INFO - 2018-10-30 06:47:40 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:47:40 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:47:40 --> Utf8 Class Initialized
INFO - 2018-10-30 06:47:40 --> URI Class Initialized
INFO - 2018-10-30 06:47:40 --> Router Class Initialized
INFO - 2018-10-30 06:47:40 --> Output Class Initialized
INFO - 2018-10-30 06:47:40 --> Security Class Initialized
DEBUG - 2018-10-30 06:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:47:40 --> Input Class Initialized
INFO - 2018-10-30 06:47:40 --> Language Class Initialized
INFO - 2018-10-30 06:47:40 --> Loader Class Initialized
INFO - 2018-10-30 06:47:40 --> Helper loaded: url_helper
INFO - 2018-10-30 06:47:40 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:40 --> Helper loaded: form_helper
INFO - 2018-10-30 06:47:40 --> Form Validation Class Initialized
INFO - 2018-10-30 06:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:47:40 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:47:40 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:47:41 --> Email Class Initialized
INFO - 2018-10-30 06:47:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:47:41 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:47:41 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:47:41 --> Helper loaded: date_helper
INFO - 2018-10-30 06:47:41 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:47:41 --> Controller Class Initialized
INFO - 2018-10-30 06:47:41 --> Model "Item_model" initialized
INFO - 2018-10-30 06:47:41 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:47:41 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:47:41 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:47:41 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:47:41 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 06:47:41 --> Final output sent to browser
INFO - 2018-10-30 06:47:41 --> Config Class Initialized
INFO - 2018-10-30 06:47:41 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:47:41 --> Total execution time: 0.8179
DEBUG - 2018-10-30 06:47:41 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:47:41 --> Utf8 Class Initialized
INFO - 2018-10-30 06:47:41 --> URI Class Initialized
INFO - 2018-10-30 06:47:41 --> Router Class Initialized
INFO - 2018-10-30 06:47:41 --> Output Class Initialized
INFO - 2018-10-30 06:47:41 --> Security Class Initialized
DEBUG - 2018-10-30 06:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:47:41 --> Input Class Initialized
INFO - 2018-10-30 06:47:41 --> Language Class Initialized
ERROR - 2018-10-30 06:47:41 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:47:42 --> Config Class Initialized
INFO - 2018-10-30 06:47:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:47:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:47:42 --> Utf8 Class Initialized
INFO - 2018-10-30 06:47:42 --> URI Class Initialized
INFO - 2018-10-30 06:47:42 --> Router Class Initialized
INFO - 2018-10-30 06:47:42 --> Output Class Initialized
INFO - 2018-10-30 06:47:42 --> Security Class Initialized
DEBUG - 2018-10-30 06:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:47:43 --> Input Class Initialized
INFO - 2018-10-30 06:47:43 --> Language Class Initialized
INFO - 2018-10-30 06:47:43 --> Loader Class Initialized
INFO - 2018-10-30 06:47:43 --> Helper loaded: url_helper
INFO - 2018-10-30 06:47:43 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:43 --> Helper loaded: form_helper
INFO - 2018-10-30 06:47:43 --> Form Validation Class Initialized
INFO - 2018-10-30 06:47:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:47:43 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:47:43 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:47:43 --> Email Class Initialized
INFO - 2018-10-30 06:47:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:47:43 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:47:43 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:47:43 --> Helper loaded: date_helper
INFO - 2018-10-30 06:47:43 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:47:43 --> Controller Class Initialized
INFO - 2018-10-30 06:47:43 --> Model "Item_model" initialized
INFO - 2018-10-30 06:47:43 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:47:43 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:47:43 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:47:43 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:47:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 06:47:43 --> Final output sent to browser
DEBUG - 2018-10-30 06:47:43 --> Total execution time: 0.7494
INFO - 2018-10-30 06:47:43 --> Config Class Initialized
INFO - 2018-10-30 06:47:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:47:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:47:43 --> Utf8 Class Initialized
INFO - 2018-10-30 06:47:43 --> URI Class Initialized
INFO - 2018-10-30 06:47:43 --> Router Class Initialized
INFO - 2018-10-30 06:47:43 --> Output Class Initialized
INFO - 2018-10-30 06:47:43 --> Security Class Initialized
DEBUG - 2018-10-30 06:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:47:43 --> Input Class Initialized
INFO - 2018-10-30 06:47:43 --> Language Class Initialized
ERROR - 2018-10-30 06:47:43 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:47:47 --> Config Class Initialized
INFO - 2018-10-30 06:47:47 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:47:47 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:47:47 --> Utf8 Class Initialized
INFO - 2018-10-30 06:47:47 --> URI Class Initialized
INFO - 2018-10-30 06:47:47 --> Router Class Initialized
INFO - 2018-10-30 06:47:47 --> Output Class Initialized
INFO - 2018-10-30 06:47:47 --> Security Class Initialized
DEBUG - 2018-10-30 06:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:47:47 --> Input Class Initialized
INFO - 2018-10-30 06:47:47 --> Language Class Initialized
INFO - 2018-10-30 06:47:47 --> Loader Class Initialized
INFO - 2018-10-30 06:47:47 --> Helper loaded: url_helper
INFO - 2018-10-30 06:47:47 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:47 --> Helper loaded: form_helper
INFO - 2018-10-30 06:47:47 --> Form Validation Class Initialized
INFO - 2018-10-30 06:47:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:47:47 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:47:47 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:47:47 --> Email Class Initialized
INFO - 2018-10-30 06:47:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:47:47 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:47:47 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:47:47 --> Helper loaded: date_helper
INFO - 2018-10-30 06:47:47 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:47 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:47:47 --> Controller Class Initialized
INFO - 2018-10-30 06:47:47 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:47:47 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:47:47 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:47:47 --> Final output sent to browser
DEBUG - 2018-10-30 06:47:47 --> Total execution time: 0.7004
INFO - 2018-10-30 06:47:55 --> Config Class Initialized
INFO - 2018-10-30 06:47:55 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:47:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:47:55 --> Utf8 Class Initialized
INFO - 2018-10-30 06:47:55 --> URI Class Initialized
INFO - 2018-10-30 06:47:55 --> Router Class Initialized
INFO - 2018-10-30 06:47:55 --> Output Class Initialized
INFO - 2018-10-30 06:47:55 --> Security Class Initialized
DEBUG - 2018-10-30 06:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:47:55 --> Input Class Initialized
INFO - 2018-10-30 06:47:55 --> Language Class Initialized
INFO - 2018-10-30 06:47:55 --> Loader Class Initialized
INFO - 2018-10-30 06:47:55 --> Helper loaded: url_helper
INFO - 2018-10-30 06:47:55 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:55 --> Helper loaded: form_helper
INFO - 2018-10-30 06:47:55 --> Form Validation Class Initialized
INFO - 2018-10-30 06:47:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:47:55 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:47:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:47:55 --> Email Class Initialized
INFO - 2018-10-30 06:47:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:47:55 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:47:55 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:47:55 --> Helper loaded: date_helper
INFO - 2018-10-30 06:47:56 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:47:56 --> Controller Class Initialized
INFO - 2018-10-30 06:47:56 --> Model "Item_model" initialized
INFO - 2018-10-30 06:47:56 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:47:56 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:47:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:47:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:47:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:47:56 --> Final output sent to browser
DEBUG - 2018-10-30 06:47:56 --> Total execution time: 0.7604
INFO - 2018-10-30 06:47:58 --> Config Class Initialized
INFO - 2018-10-30 06:47:58 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:47:58 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:47:58 --> Utf8 Class Initialized
INFO - 2018-10-30 06:47:58 --> URI Class Initialized
INFO - 2018-10-30 06:47:59 --> Router Class Initialized
INFO - 2018-10-30 06:47:59 --> Output Class Initialized
INFO - 2018-10-30 06:47:59 --> Security Class Initialized
DEBUG - 2018-10-30 06:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:47:59 --> Input Class Initialized
INFO - 2018-10-30 06:47:59 --> Language Class Initialized
INFO - 2018-10-30 06:47:59 --> Loader Class Initialized
INFO - 2018-10-30 06:47:59 --> Helper loaded: url_helper
INFO - 2018-10-30 06:47:59 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:59 --> Helper loaded: form_helper
INFO - 2018-10-30 06:47:59 --> Form Validation Class Initialized
INFO - 2018-10-30 06:47:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:47:59 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:47:59 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:47:59 --> Email Class Initialized
INFO - 2018-10-30 06:47:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:47:59 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:47:59 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:47:59 --> Helper loaded: date_helper
INFO - 2018-10-30 06:47:59 --> Database Driver Class Initialized
INFO - 2018-10-30 06:47:59 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:47:59 --> Controller Class Initialized
INFO - 2018-10-30 06:47:59 --> Model "Item_model" initialized
INFO - 2018-10-30 06:47:59 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:47:59 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:47:59 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:47:59 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:47:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 06:47:59 --> Final output sent to browser
INFO - 2018-10-30 06:47:59 --> Config Class Initialized
DEBUG - 2018-10-30 06:47:59 --> Total execution time: 0.7785
INFO - 2018-10-30 06:47:59 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:47:59 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:47:59 --> Utf8 Class Initialized
INFO - 2018-10-30 06:47:59 --> URI Class Initialized
INFO - 2018-10-30 06:47:59 --> Router Class Initialized
INFO - 2018-10-30 06:47:59 --> Output Class Initialized
INFO - 2018-10-30 06:47:59 --> Security Class Initialized
DEBUG - 2018-10-30 06:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:47:59 --> Input Class Initialized
INFO - 2018-10-30 06:47:59 --> Language Class Initialized
ERROR - 2018-10-30 06:47:59 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:48:00 --> Config Class Initialized
INFO - 2018-10-30 06:48:01 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:48:01 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:48:01 --> Utf8 Class Initialized
INFO - 2018-10-30 06:48:01 --> URI Class Initialized
INFO - 2018-10-30 06:48:01 --> Router Class Initialized
INFO - 2018-10-30 06:48:01 --> Output Class Initialized
INFO - 2018-10-30 06:48:01 --> Security Class Initialized
DEBUG - 2018-10-30 06:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:48:01 --> Input Class Initialized
INFO - 2018-10-30 06:48:01 --> Language Class Initialized
INFO - 2018-10-30 06:48:01 --> Loader Class Initialized
INFO - 2018-10-30 06:48:01 --> Helper loaded: url_helper
INFO - 2018-10-30 06:48:01 --> Database Driver Class Initialized
INFO - 2018-10-30 06:48:01 --> Helper loaded: form_helper
INFO - 2018-10-30 06:48:01 --> Form Validation Class Initialized
INFO - 2018-10-30 06:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:48:01 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:48:01 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:48:01 --> Email Class Initialized
INFO - 2018-10-30 06:48:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:48:01 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:48:01 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:48:01 --> Helper loaded: date_helper
INFO - 2018-10-30 06:48:01 --> Database Driver Class Initialized
INFO - 2018-10-30 06:48:01 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:48:01 --> Controller Class Initialized
INFO - 2018-10-30 06:48:01 --> Model "Item_model" initialized
INFO - 2018-10-30 06:48:01 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:48:01 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:48:01 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:48:01 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:48:01 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 06:48:01 --> Final output sent to browser
DEBUG - 2018-10-30 06:48:01 --> Total execution time: 0.7778
INFO - 2018-10-30 06:48:01 --> Config Class Initialized
INFO - 2018-10-30 06:48:01 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:48:01 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:48:01 --> Utf8 Class Initialized
INFO - 2018-10-30 06:48:01 --> URI Class Initialized
INFO - 2018-10-30 06:48:01 --> Router Class Initialized
INFO - 2018-10-30 06:48:01 --> Output Class Initialized
INFO - 2018-10-30 06:48:01 --> Security Class Initialized
DEBUG - 2018-10-30 06:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:48:02 --> Input Class Initialized
INFO - 2018-10-30 06:48:02 --> Language Class Initialized
ERROR - 2018-10-30 06:48:02 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:48:16 --> Config Class Initialized
INFO - 2018-10-30 06:48:16 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:48:16 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:48:16 --> Utf8 Class Initialized
INFO - 2018-10-30 06:48:16 --> URI Class Initialized
INFO - 2018-10-30 06:48:16 --> Router Class Initialized
INFO - 2018-10-30 06:48:16 --> Output Class Initialized
INFO - 2018-10-30 06:48:16 --> Security Class Initialized
DEBUG - 2018-10-30 06:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:48:17 --> Input Class Initialized
INFO - 2018-10-30 06:48:17 --> Language Class Initialized
INFO - 2018-10-30 06:48:17 --> Loader Class Initialized
INFO - 2018-10-30 06:48:17 --> Helper loaded: url_helper
INFO - 2018-10-30 06:48:17 --> Database Driver Class Initialized
INFO - 2018-10-30 06:48:17 --> Helper loaded: form_helper
INFO - 2018-10-30 06:48:17 --> Form Validation Class Initialized
INFO - 2018-10-30 06:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:48:17 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:48:17 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:48:17 --> Email Class Initialized
INFO - 2018-10-30 06:48:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:48:17 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:48:17 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:48:17 --> Helper loaded: date_helper
INFO - 2018-10-30 06:48:17 --> Database Driver Class Initialized
INFO - 2018-10-30 06:48:17 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:48:17 --> Controller Class Initialized
INFO - 2018-10-30 06:48:17 --> Model "Item_model" initialized
INFO - 2018-10-30 06:48:17 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:48:17 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:48:17 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:48:17 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:48:17 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:48:17 --> Final output sent to browser
DEBUG - 2018-10-30 06:48:17 --> Total execution time: 0.7620
INFO - 2018-10-30 06:48:21 --> Config Class Initialized
INFO - 2018-10-30 06:48:21 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:48:21 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:48:21 --> Utf8 Class Initialized
INFO - 2018-10-30 06:48:21 --> URI Class Initialized
INFO - 2018-10-30 06:48:21 --> Router Class Initialized
INFO - 2018-10-30 06:48:22 --> Output Class Initialized
INFO - 2018-10-30 06:48:22 --> Security Class Initialized
DEBUG - 2018-10-30 06:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:48:22 --> Input Class Initialized
INFO - 2018-10-30 06:48:22 --> Language Class Initialized
INFO - 2018-10-30 06:48:22 --> Loader Class Initialized
INFO - 2018-10-30 06:48:22 --> Helper loaded: url_helper
INFO - 2018-10-30 06:48:22 --> Database Driver Class Initialized
INFO - 2018-10-30 06:48:22 --> Helper loaded: form_helper
INFO - 2018-10-30 06:48:22 --> Form Validation Class Initialized
INFO - 2018-10-30 06:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:48:22 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:48:22 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:48:22 --> Email Class Initialized
INFO - 2018-10-30 06:48:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:48:22 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:48:22 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:48:22 --> Helper loaded: date_helper
INFO - 2018-10-30 06:48:22 --> Database Driver Class Initialized
INFO - 2018-10-30 06:48:22 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:48:22 --> Controller Class Initialized
INFO - 2018-10-30 06:48:22 --> Model "Item_model" initialized
INFO - 2018-10-30 06:48:22 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:48:22 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:48:22 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:48:22 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:48:22 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 06:48:22 --> Final output sent to browser
DEBUG - 2018-10-30 06:48:22 --> Total execution time: 0.7375
INFO - 2018-10-30 06:48:22 --> Config Class Initialized
INFO - 2018-10-30 06:48:22 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:48:22 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:48:22 --> Utf8 Class Initialized
INFO - 2018-10-30 06:48:22 --> URI Class Initialized
INFO - 2018-10-30 06:48:22 --> Router Class Initialized
INFO - 2018-10-30 06:48:22 --> Output Class Initialized
INFO - 2018-10-30 06:48:22 --> Security Class Initialized
DEBUG - 2018-10-30 06:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:48:22 --> Input Class Initialized
INFO - 2018-10-30 06:48:22 --> Language Class Initialized
ERROR - 2018-10-30 06:48:22 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:48:25 --> Config Class Initialized
INFO - 2018-10-30 06:48:25 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:48:25 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:48:25 --> Utf8 Class Initialized
INFO - 2018-10-30 06:48:25 --> URI Class Initialized
INFO - 2018-10-30 06:48:25 --> Router Class Initialized
INFO - 2018-10-30 06:48:25 --> Output Class Initialized
INFO - 2018-10-30 06:48:25 --> Security Class Initialized
DEBUG - 2018-10-30 06:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:48:25 --> Input Class Initialized
INFO - 2018-10-30 06:48:25 --> Language Class Initialized
INFO - 2018-10-30 06:48:25 --> Loader Class Initialized
INFO - 2018-10-30 06:48:25 --> Helper loaded: url_helper
INFO - 2018-10-30 06:48:25 --> Database Driver Class Initialized
INFO - 2018-10-30 06:48:25 --> Helper loaded: form_helper
INFO - 2018-10-30 06:48:25 --> Form Validation Class Initialized
INFO - 2018-10-30 06:48:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:48:25 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:48:25 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:48:25 --> Email Class Initialized
INFO - 2018-10-30 06:48:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:48:25 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:48:25 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:48:26 --> Helper loaded: date_helper
INFO - 2018-10-30 06:48:26 --> Database Driver Class Initialized
INFO - 2018-10-30 06:48:26 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:48:26 --> Controller Class Initialized
INFO - 2018-10-30 06:48:26 --> Model "Item_model" initialized
INFO - 2018-10-30 06:48:26 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:48:26 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:48:26 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:48:26 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:48:26 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 06:48:26 --> Final output sent to browser
DEBUG - 2018-10-30 06:48:26 --> Total execution time: 0.7668
INFO - 2018-10-30 06:48:26 --> Config Class Initialized
INFO - 2018-10-30 06:48:26 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:48:26 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:48:26 --> Utf8 Class Initialized
INFO - 2018-10-30 06:48:26 --> URI Class Initialized
INFO - 2018-10-30 06:48:26 --> Router Class Initialized
INFO - 2018-10-30 06:48:26 --> Output Class Initialized
INFO - 2018-10-30 06:48:26 --> Security Class Initialized
DEBUG - 2018-10-30 06:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:48:26 --> Input Class Initialized
INFO - 2018-10-30 06:48:26 --> Language Class Initialized
ERROR - 2018-10-30 06:48:26 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:48:30 --> Config Class Initialized
INFO - 2018-10-30 06:48:30 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:48:30 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:48:30 --> Utf8 Class Initialized
INFO - 2018-10-30 06:48:30 --> URI Class Initialized
INFO - 2018-10-30 06:48:30 --> Router Class Initialized
INFO - 2018-10-30 06:48:30 --> Output Class Initialized
INFO - 2018-10-30 06:48:30 --> Security Class Initialized
DEBUG - 2018-10-30 06:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:48:30 --> Input Class Initialized
INFO - 2018-10-30 06:48:30 --> Language Class Initialized
INFO - 2018-10-30 06:48:30 --> Loader Class Initialized
INFO - 2018-10-30 06:48:30 --> Helper loaded: url_helper
INFO - 2018-10-30 06:48:30 --> Database Driver Class Initialized
INFO - 2018-10-30 06:48:30 --> Helper loaded: form_helper
INFO - 2018-10-30 06:48:30 --> Form Validation Class Initialized
INFO - 2018-10-30 06:48:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:48:30 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:48:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:48:30 --> Email Class Initialized
INFO - 2018-10-30 06:48:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:48:30 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:48:30 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:48:31 --> Helper loaded: date_helper
INFO - 2018-10-30 06:48:31 --> Database Driver Class Initialized
INFO - 2018-10-30 06:48:31 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:48:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:48:31 --> Controller Class Initialized
INFO - 2018-10-30 06:48:31 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:48:31 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:48:31 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:48:31 --> Final output sent to browser
DEBUG - 2018-10-30 06:48:31 --> Total execution time: 0.7070
INFO - 2018-10-30 06:52:47 --> Config Class Initialized
INFO - 2018-10-30 06:52:47 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:52:47 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:52:47 --> Utf8 Class Initialized
INFO - 2018-10-30 06:52:47 --> URI Class Initialized
INFO - 2018-10-30 06:52:47 --> Router Class Initialized
INFO - 2018-10-30 06:52:47 --> Output Class Initialized
INFO - 2018-10-30 06:52:47 --> Security Class Initialized
DEBUG - 2018-10-30 06:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:52:47 --> Input Class Initialized
INFO - 2018-10-30 06:52:47 --> Language Class Initialized
INFO - 2018-10-30 06:52:47 --> Loader Class Initialized
INFO - 2018-10-30 06:52:47 --> Helper loaded: url_helper
INFO - 2018-10-30 06:52:47 --> Database Driver Class Initialized
INFO - 2018-10-30 06:52:47 --> Helper loaded: form_helper
INFO - 2018-10-30 06:52:47 --> Form Validation Class Initialized
INFO - 2018-10-30 06:52:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:52:47 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:52:47 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:52:47 --> Email Class Initialized
INFO - 2018-10-30 06:52:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:52:47 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:52:47 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:52:47 --> Helper loaded: date_helper
INFO - 2018-10-30 06:52:47 --> Database Driver Class Initialized
INFO - 2018-10-30 06:52:47 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:52:47 --> Controller Class Initialized
INFO - 2018-10-30 06:52:47 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:52:47 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:52:47 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:52:47 --> Final output sent to browser
DEBUG - 2018-10-30 06:52:47 --> Total execution time: 0.7747
INFO - 2018-10-30 06:52:49 --> Config Class Initialized
INFO - 2018-10-30 06:52:49 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:52:49 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:52:49 --> Utf8 Class Initialized
INFO - 2018-10-30 06:52:49 --> URI Class Initialized
INFO - 2018-10-30 06:52:49 --> Router Class Initialized
INFO - 2018-10-30 06:52:49 --> Output Class Initialized
INFO - 2018-10-30 06:52:49 --> Security Class Initialized
DEBUG - 2018-10-30 06:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:52:49 --> Input Class Initialized
INFO - 2018-10-30 06:52:49 --> Language Class Initialized
INFO - 2018-10-30 06:52:49 --> Loader Class Initialized
INFO - 2018-10-30 06:52:49 --> Helper loaded: url_helper
INFO - 2018-10-30 06:52:49 --> Database Driver Class Initialized
INFO - 2018-10-30 06:52:49 --> Helper loaded: form_helper
INFO - 2018-10-30 06:52:49 --> Form Validation Class Initialized
INFO - 2018-10-30 06:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:52:49 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:52:49 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:52:49 --> Email Class Initialized
INFO - 2018-10-30 06:52:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:52:49 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:52:49 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:52:49 --> Helper loaded: date_helper
INFO - 2018-10-30 06:52:49 --> Database Driver Class Initialized
INFO - 2018-10-30 06:52:49 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:52:49 --> Controller Class Initialized
INFO - 2018-10-30 06:52:49 --> Model "Item_model" initialized
INFO - 2018-10-30 06:52:49 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:52:49 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:52:49 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:52:49 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:52:50 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:52:50 --> Final output sent to browser
DEBUG - 2018-10-30 06:52:50 --> Total execution time: 0.8312
INFO - 2018-10-30 06:52:54 --> Config Class Initialized
INFO - 2018-10-30 06:52:54 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:52:54 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:52:54 --> Utf8 Class Initialized
INFO - 2018-10-30 06:52:54 --> URI Class Initialized
INFO - 2018-10-30 06:52:54 --> Router Class Initialized
INFO - 2018-10-30 06:52:54 --> Output Class Initialized
INFO - 2018-10-30 06:52:54 --> Security Class Initialized
DEBUG - 2018-10-30 06:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:52:54 --> Input Class Initialized
INFO - 2018-10-30 06:52:54 --> Language Class Initialized
INFO - 2018-10-30 06:52:54 --> Loader Class Initialized
INFO - 2018-10-30 06:52:54 --> Helper loaded: url_helper
INFO - 2018-10-30 06:52:54 --> Database Driver Class Initialized
INFO - 2018-10-30 06:52:54 --> Helper loaded: form_helper
INFO - 2018-10-30 06:52:54 --> Form Validation Class Initialized
INFO - 2018-10-30 06:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:52:55 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:52:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:52:55 --> Email Class Initialized
INFO - 2018-10-30 06:52:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:52:55 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:52:55 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:52:55 --> Helper loaded: date_helper
INFO - 2018-10-30 06:52:55 --> Database Driver Class Initialized
INFO - 2018-10-30 06:52:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:52:55 --> Controller Class Initialized
INFO - 2018-10-30 06:52:55 --> Model "Item_model" initialized
INFO - 2018-10-30 06:52:55 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:52:55 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:52:55 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:52:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:52:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 06:52:55 --> Final output sent to browser
DEBUG - 2018-10-30 06:52:55 --> Total execution time: 0.7752
INFO - 2018-10-30 06:52:55 --> Config Class Initialized
INFO - 2018-10-30 06:52:55 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:52:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:52:55 --> Utf8 Class Initialized
INFO - 2018-10-30 06:52:55 --> URI Class Initialized
INFO - 2018-10-30 06:52:55 --> Router Class Initialized
INFO - 2018-10-30 06:52:55 --> Output Class Initialized
INFO - 2018-10-30 06:52:55 --> Security Class Initialized
DEBUG - 2018-10-30 06:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:52:55 --> Input Class Initialized
INFO - 2018-10-30 06:52:55 --> Language Class Initialized
ERROR - 2018-10-30 06:52:55 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:52:57 --> Config Class Initialized
INFO - 2018-10-30 06:52:57 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:52:57 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:52:57 --> Utf8 Class Initialized
INFO - 2018-10-30 06:52:57 --> URI Class Initialized
INFO - 2018-10-30 06:52:57 --> Router Class Initialized
INFO - 2018-10-30 06:52:57 --> Output Class Initialized
INFO - 2018-10-30 06:52:57 --> Security Class Initialized
DEBUG - 2018-10-30 06:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:52:57 --> Input Class Initialized
INFO - 2018-10-30 06:52:57 --> Language Class Initialized
INFO - 2018-10-30 06:52:57 --> Loader Class Initialized
INFO - 2018-10-30 06:52:57 --> Helper loaded: url_helper
INFO - 2018-10-30 06:52:57 --> Database Driver Class Initialized
INFO - 2018-10-30 06:52:57 --> Helper loaded: form_helper
INFO - 2018-10-30 06:52:57 --> Form Validation Class Initialized
INFO - 2018-10-30 06:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:52:57 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:52:57 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:52:57 --> Email Class Initialized
INFO - 2018-10-30 06:52:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:52:57 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:52:57 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:52:57 --> Helper loaded: date_helper
INFO - 2018-10-30 06:52:57 --> Database Driver Class Initialized
INFO - 2018-10-30 06:52:57 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:52:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:52:57 --> Controller Class Initialized
INFO - 2018-10-30 06:52:57 --> Model "Item_model" initialized
INFO - 2018-10-30 06:52:57 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:52:57 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:52:57 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:52:57 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:52:57 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 06:52:58 --> Final output sent to browser
DEBUG - 2018-10-30 06:52:58 --> Total execution time: 0.8092
INFO - 2018-10-30 06:52:58 --> Config Class Initialized
INFO - 2018-10-30 06:52:58 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:52:58 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:52:58 --> Utf8 Class Initialized
INFO - 2018-10-30 06:52:58 --> URI Class Initialized
INFO - 2018-10-30 06:52:58 --> Router Class Initialized
INFO - 2018-10-30 06:52:58 --> Output Class Initialized
INFO - 2018-10-30 06:52:58 --> Security Class Initialized
DEBUG - 2018-10-30 06:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:52:58 --> Input Class Initialized
INFO - 2018-10-30 06:52:58 --> Language Class Initialized
ERROR - 2018-10-30 06:52:58 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:53:00 --> Config Class Initialized
INFO - 2018-10-30 06:53:00 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:53:00 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:53:00 --> Utf8 Class Initialized
INFO - 2018-10-30 06:53:00 --> URI Class Initialized
INFO - 2018-10-30 06:53:00 --> Router Class Initialized
INFO - 2018-10-30 06:53:00 --> Output Class Initialized
INFO - 2018-10-30 06:53:00 --> Security Class Initialized
DEBUG - 2018-10-30 06:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:53:00 --> Input Class Initialized
INFO - 2018-10-30 06:53:00 --> Language Class Initialized
INFO - 2018-10-30 06:53:00 --> Loader Class Initialized
INFO - 2018-10-30 06:53:00 --> Helper loaded: url_helper
INFO - 2018-10-30 06:53:00 --> Database Driver Class Initialized
INFO - 2018-10-30 06:53:00 --> Helper loaded: form_helper
INFO - 2018-10-30 06:53:00 --> Form Validation Class Initialized
INFO - 2018-10-30 06:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:53:00 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:53:00 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:53:00 --> Email Class Initialized
INFO - 2018-10-30 06:53:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:53:00 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:53:00 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:53:00 --> Helper loaded: date_helper
INFO - 2018-10-30 06:53:00 --> Database Driver Class Initialized
INFO - 2018-10-30 06:53:00 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:53:00 --> Controller Class Initialized
INFO - 2018-10-30 06:53:00 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:53:00 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:53:00 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:53:00 --> Final output sent to browser
DEBUG - 2018-10-30 06:53:00 --> Total execution time: 0.7367
INFO - 2018-10-30 06:53:37 --> Config Class Initialized
INFO - 2018-10-30 06:53:37 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:53:37 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:53:37 --> Utf8 Class Initialized
INFO - 2018-10-30 06:53:37 --> URI Class Initialized
INFO - 2018-10-30 06:53:37 --> Router Class Initialized
INFO - 2018-10-30 06:53:37 --> Output Class Initialized
INFO - 2018-10-30 06:53:37 --> Security Class Initialized
DEBUG - 2018-10-30 06:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:53:37 --> Input Class Initialized
INFO - 2018-10-30 06:53:37 --> Language Class Initialized
INFO - 2018-10-30 06:53:37 --> Loader Class Initialized
INFO - 2018-10-30 06:53:37 --> Helper loaded: url_helper
INFO - 2018-10-30 06:53:37 --> Database Driver Class Initialized
INFO - 2018-10-30 06:53:37 --> Helper loaded: form_helper
INFO - 2018-10-30 06:53:37 --> Form Validation Class Initialized
INFO - 2018-10-30 06:53:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:53:37 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:53:37 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:53:37 --> Email Class Initialized
INFO - 2018-10-30 06:53:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:53:37 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:53:37 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:53:37 --> Helper loaded: date_helper
INFO - 2018-10-30 06:53:37 --> Database Driver Class Initialized
INFO - 2018-10-30 06:53:38 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:53:38 --> Controller Class Initialized
INFO - 2018-10-30 06:53:38 --> Model "Item_model" initialized
INFO - 2018-10-30 06:53:38 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:53:38 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:53:38 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:53:38 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:53:38 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:53:38 --> Final output sent to browser
DEBUG - 2018-10-30 06:53:38 --> Total execution time: 0.7562
INFO - 2018-10-30 06:53:41 --> Config Class Initialized
INFO - 2018-10-30 06:53:41 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:53:41 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:53:41 --> Utf8 Class Initialized
INFO - 2018-10-30 06:53:41 --> URI Class Initialized
INFO - 2018-10-30 06:53:41 --> Router Class Initialized
INFO - 2018-10-30 06:53:41 --> Output Class Initialized
INFO - 2018-10-30 06:53:41 --> Security Class Initialized
DEBUG - 2018-10-30 06:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:53:41 --> Input Class Initialized
INFO - 2018-10-30 06:53:41 --> Language Class Initialized
INFO - 2018-10-30 06:53:41 --> Loader Class Initialized
INFO - 2018-10-30 06:53:41 --> Helper loaded: url_helper
INFO - 2018-10-30 06:53:41 --> Database Driver Class Initialized
INFO - 2018-10-30 06:53:41 --> Helper loaded: form_helper
INFO - 2018-10-30 06:53:41 --> Form Validation Class Initialized
INFO - 2018-10-30 06:53:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:53:41 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:53:41 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:53:41 --> Email Class Initialized
INFO - 2018-10-30 06:53:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:53:41 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:53:41 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:53:41 --> Helper loaded: date_helper
INFO - 2018-10-30 06:53:42 --> Database Driver Class Initialized
INFO - 2018-10-30 06:53:42 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:53:42 --> Controller Class Initialized
INFO - 2018-10-30 06:53:42 --> Model "Item_model" initialized
INFO - 2018-10-30 06:53:42 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:53:42 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:53:42 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:53:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:53:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 06:53:42 --> Final output sent to browser
INFO - 2018-10-30 06:53:42 --> Config Class Initialized
INFO - 2018-10-30 06:53:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:53:42 --> Total execution time: 0.7919
DEBUG - 2018-10-30 06:53:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:53:42 --> Utf8 Class Initialized
INFO - 2018-10-30 06:53:42 --> URI Class Initialized
INFO - 2018-10-30 06:53:42 --> Router Class Initialized
INFO - 2018-10-30 06:53:42 --> Output Class Initialized
INFO - 2018-10-30 06:53:42 --> Security Class Initialized
DEBUG - 2018-10-30 06:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:53:42 --> Input Class Initialized
INFO - 2018-10-30 06:53:42 --> Language Class Initialized
ERROR - 2018-10-30 06:53:42 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:53:43 --> Config Class Initialized
INFO - 2018-10-30 06:53:43 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:53:43 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:53:43 --> Utf8 Class Initialized
INFO - 2018-10-30 06:53:43 --> URI Class Initialized
INFO - 2018-10-30 06:53:43 --> Router Class Initialized
INFO - 2018-10-30 06:53:43 --> Output Class Initialized
INFO - 2018-10-30 06:53:43 --> Security Class Initialized
DEBUG - 2018-10-30 06:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:53:43 --> Input Class Initialized
INFO - 2018-10-30 06:53:43 --> Language Class Initialized
INFO - 2018-10-30 06:53:43 --> Loader Class Initialized
INFO - 2018-10-30 06:53:43 --> Helper loaded: url_helper
INFO - 2018-10-30 06:53:44 --> Database Driver Class Initialized
INFO - 2018-10-30 06:53:44 --> Helper loaded: form_helper
INFO - 2018-10-30 06:53:44 --> Form Validation Class Initialized
INFO - 2018-10-30 06:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:53:44 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:53:44 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:53:44 --> Email Class Initialized
INFO - 2018-10-30 06:53:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:53:44 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:53:44 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:53:44 --> Helper loaded: date_helper
INFO - 2018-10-30 06:53:44 --> Database Driver Class Initialized
INFO - 2018-10-30 06:53:44 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:53:44 --> Controller Class Initialized
INFO - 2018-10-30 06:53:44 --> Model "Item_model" initialized
INFO - 2018-10-30 06:53:44 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:53:44 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:53:44 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:53:44 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:53:44 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 06:53:44 --> Final output sent to browser
DEBUG - 2018-10-30 06:53:44 --> Total execution time: 0.7842
INFO - 2018-10-30 06:53:44 --> Config Class Initialized
INFO - 2018-10-30 06:53:44 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:53:44 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:53:44 --> Utf8 Class Initialized
INFO - 2018-10-30 06:53:44 --> URI Class Initialized
INFO - 2018-10-30 06:53:44 --> Router Class Initialized
INFO - 2018-10-30 06:53:44 --> Output Class Initialized
INFO - 2018-10-30 06:53:44 --> Security Class Initialized
DEBUG - 2018-10-30 06:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:53:44 --> Input Class Initialized
INFO - 2018-10-30 06:53:44 --> Language Class Initialized
ERROR - 2018-10-30 06:53:44 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 06:53:47 --> Config Class Initialized
INFO - 2018-10-30 06:53:47 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:53:47 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:53:47 --> Utf8 Class Initialized
INFO - 2018-10-30 06:53:47 --> URI Class Initialized
INFO - 2018-10-30 06:53:47 --> Router Class Initialized
INFO - 2018-10-30 06:53:47 --> Output Class Initialized
INFO - 2018-10-30 06:53:47 --> Security Class Initialized
DEBUG - 2018-10-30 06:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:53:47 --> Input Class Initialized
INFO - 2018-10-30 06:53:47 --> Language Class Initialized
INFO - 2018-10-30 06:53:47 --> Loader Class Initialized
INFO - 2018-10-30 06:53:47 --> Helper loaded: url_helper
INFO - 2018-10-30 06:53:47 --> Database Driver Class Initialized
INFO - 2018-10-30 06:53:47 --> Helper loaded: form_helper
INFO - 2018-10-30 06:53:47 --> Form Validation Class Initialized
INFO - 2018-10-30 06:53:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:53:47 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:53:47 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:53:47 --> Email Class Initialized
INFO - 2018-10-30 06:53:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:53:47 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:53:47 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:53:47 --> Helper loaded: date_helper
INFO - 2018-10-30 06:53:47 --> Database Driver Class Initialized
INFO - 2018-10-30 06:53:47 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:53:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:53:47 --> Controller Class Initialized
INFO - 2018-10-30 06:53:47 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:53:47 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:53:47 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:53:47 --> Final output sent to browser
DEBUG - 2018-10-30 06:53:47 --> Total execution time: 0.7128
INFO - 2018-10-30 06:55:11 --> Config Class Initialized
INFO - 2018-10-30 06:55:11 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:55:11 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:55:11 --> Utf8 Class Initialized
INFO - 2018-10-30 06:55:11 --> URI Class Initialized
INFO - 2018-10-30 06:55:11 --> Router Class Initialized
INFO - 2018-10-30 06:55:11 --> Output Class Initialized
INFO - 2018-10-30 06:55:11 --> Security Class Initialized
DEBUG - 2018-10-30 06:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:55:11 --> Input Class Initialized
INFO - 2018-10-30 06:55:11 --> Language Class Initialized
INFO - 2018-10-30 06:55:11 --> Loader Class Initialized
INFO - 2018-10-30 06:55:11 --> Helper loaded: url_helper
INFO - 2018-10-30 06:55:11 --> Database Driver Class Initialized
INFO - 2018-10-30 06:55:11 --> Helper loaded: form_helper
INFO - 2018-10-30 06:55:11 --> Form Validation Class Initialized
INFO - 2018-10-30 06:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:55:11 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:55:11 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:55:11 --> Email Class Initialized
INFO - 2018-10-30 06:55:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:55:11 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:55:11 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:55:11 --> Helper loaded: date_helper
INFO - 2018-10-30 06:55:11 --> Database Driver Class Initialized
INFO - 2018-10-30 06:55:11 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:55:11 --> Controller Class Initialized
INFO - 2018-10-30 06:55:11 --> Model "Item_model" initialized
INFO - 2018-10-30 06:55:11 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:55:11 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:55:11 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:55:11 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:55:11 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:55:11 --> Final output sent to browser
DEBUG - 2018-10-30 06:55:11 --> Total execution time: 0.8073
INFO - 2018-10-30 06:55:40 --> Config Class Initialized
INFO - 2018-10-30 06:55:40 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:55:40 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:55:40 --> Utf8 Class Initialized
INFO - 2018-10-30 06:55:40 --> URI Class Initialized
INFO - 2018-10-30 06:55:40 --> Router Class Initialized
INFO - 2018-10-30 06:55:40 --> Output Class Initialized
INFO - 2018-10-30 06:55:40 --> Security Class Initialized
DEBUG - 2018-10-30 06:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:55:40 --> Input Class Initialized
INFO - 2018-10-30 06:55:40 --> Language Class Initialized
INFO - 2018-10-30 06:55:40 --> Loader Class Initialized
INFO - 2018-10-30 06:55:40 --> Helper loaded: url_helper
INFO - 2018-10-30 06:55:40 --> Database Driver Class Initialized
INFO - 2018-10-30 06:55:40 --> Helper loaded: form_helper
INFO - 2018-10-30 06:55:40 --> Form Validation Class Initialized
INFO - 2018-10-30 06:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:55:40 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:55:40 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:55:40 --> Email Class Initialized
INFO - 2018-10-30 06:55:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:55:40 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:55:40 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:55:40 --> Helper loaded: date_helper
INFO - 2018-10-30 06:55:40 --> Database Driver Class Initialized
INFO - 2018-10-30 06:55:40 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:55:40 --> Controller Class Initialized
INFO - 2018-10-30 06:55:40 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:55:40 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:55:40 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:55:40 --> Final output sent to browser
DEBUG - 2018-10-30 06:55:41 --> Total execution time: 0.7153
INFO - 2018-10-30 06:55:54 --> Config Class Initialized
INFO - 2018-10-30 06:55:54 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:55:54 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:55:54 --> Utf8 Class Initialized
INFO - 2018-10-30 06:55:54 --> URI Class Initialized
INFO - 2018-10-30 06:55:54 --> Router Class Initialized
INFO - 2018-10-30 06:55:54 --> Output Class Initialized
INFO - 2018-10-30 06:55:54 --> Security Class Initialized
DEBUG - 2018-10-30 06:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:55:54 --> Input Class Initialized
INFO - 2018-10-30 06:55:55 --> Language Class Initialized
INFO - 2018-10-30 06:55:55 --> Loader Class Initialized
INFO - 2018-10-30 06:55:55 --> Helper loaded: url_helper
INFO - 2018-10-30 06:55:55 --> Database Driver Class Initialized
INFO - 2018-10-30 06:55:55 --> Helper loaded: form_helper
INFO - 2018-10-30 06:55:55 --> Form Validation Class Initialized
INFO - 2018-10-30 06:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:55:55 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:55:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:55:55 --> Email Class Initialized
INFO - 2018-10-30 06:55:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:55:55 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:55:55 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:55:55 --> Helper loaded: date_helper
INFO - 2018-10-30 06:55:55 --> Database Driver Class Initialized
INFO - 2018-10-30 06:55:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:55:55 --> Controller Class Initialized
INFO - 2018-10-30 06:55:55 --> Model "Item_model" initialized
INFO - 2018-10-30 06:55:55 --> Model "Jenis_model" initialized
INFO - 2018-10-30 06:55:55 --> Model "Vendor_model" initialized
INFO - 2018-10-30 06:55:55 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:55:55 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:55:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 06:55:55 --> Final output sent to browser
DEBUG - 2018-10-30 06:55:55 --> Total execution time: 0.8075
INFO - 2018-10-30 06:56:03 --> Config Class Initialized
INFO - 2018-10-30 06:56:03 --> Hooks Class Initialized
DEBUG - 2018-10-30 06:56:03 --> UTF-8 Support Enabled
INFO - 2018-10-30 06:56:03 --> Utf8 Class Initialized
INFO - 2018-10-30 06:56:03 --> URI Class Initialized
INFO - 2018-10-30 06:56:03 --> Router Class Initialized
INFO - 2018-10-30 06:56:04 --> Output Class Initialized
INFO - 2018-10-30 06:56:04 --> Security Class Initialized
DEBUG - 2018-10-30 06:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 06:56:04 --> Input Class Initialized
INFO - 2018-10-30 06:56:04 --> Language Class Initialized
INFO - 2018-10-30 06:56:04 --> Loader Class Initialized
INFO - 2018-10-30 06:56:04 --> Helper loaded: url_helper
INFO - 2018-10-30 06:56:04 --> Database Driver Class Initialized
INFO - 2018-10-30 06:56:04 --> Helper loaded: form_helper
INFO - 2018-10-30 06:56:04 --> Form Validation Class Initialized
INFO - 2018-10-30 06:56:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 06:56:04 --> Pagination Class Initialized
DEBUG - 2018-10-30 06:56:04 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 06:56:04 --> Email Class Initialized
INFO - 2018-10-30 06:56:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 06:56:04 --> Helper loaded: cookie_helper
INFO - 2018-10-30 06:56:04 --> Helper loaded: language_helper
DEBUG - 2018-10-30 06:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 06:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 06:56:04 --> Helper loaded: date_helper
INFO - 2018-10-30 06:56:04 --> Database Driver Class Initialized
INFO - 2018-10-30 06:56:04 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 06:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 06:56:04 --> Controller Class Initialized
INFO - 2018-10-30 06:56:04 --> Model "Nota_model" initialized
INFO - 2018-10-30 06:56:04 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 06:56:04 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 06:56:04 --> Final output sent to browser
DEBUG - 2018-10-30 06:56:04 --> Total execution time: 0.7509
INFO - 2018-10-30 07:12:52 --> Config Class Initialized
INFO - 2018-10-30 07:12:52 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:12:52 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:12:52 --> Utf8 Class Initialized
INFO - 2018-10-30 07:12:52 --> URI Class Initialized
INFO - 2018-10-30 07:12:53 --> Router Class Initialized
INFO - 2018-10-30 07:12:53 --> Output Class Initialized
INFO - 2018-10-30 07:12:53 --> Security Class Initialized
DEBUG - 2018-10-30 07:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:12:53 --> Input Class Initialized
INFO - 2018-10-30 07:12:53 --> Language Class Initialized
INFO - 2018-10-30 07:12:53 --> Loader Class Initialized
INFO - 2018-10-30 07:12:53 --> Helper loaded: url_helper
INFO - 2018-10-30 07:12:53 --> Database Driver Class Initialized
INFO - 2018-10-30 07:12:53 --> Helper loaded: form_helper
INFO - 2018-10-30 07:12:53 --> Form Validation Class Initialized
INFO - 2018-10-30 07:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:12:53 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:12:53 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:12:53 --> Email Class Initialized
INFO - 2018-10-30 07:12:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:12:53 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:12:53 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:12:53 --> Helper loaded: date_helper
INFO - 2018-10-30 07:12:53 --> Database Driver Class Initialized
INFO - 2018-10-30 07:12:53 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:12:53 --> Controller Class Initialized
INFO - 2018-10-30 07:12:53 --> Model "Item_model" initialized
INFO - 2018-10-30 07:12:53 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:12:53 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:12:53 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:12:53 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:12:53 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 07:12:53 --> Final output sent to browser
DEBUG - 2018-10-30 07:12:53 --> Total execution time: 0.8109
INFO - 2018-10-30 07:12:56 --> Config Class Initialized
INFO - 2018-10-30 07:12:56 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:12:56 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:12:56 --> Utf8 Class Initialized
INFO - 2018-10-30 07:12:56 --> URI Class Initialized
INFO - 2018-10-30 07:12:56 --> Router Class Initialized
INFO - 2018-10-30 07:12:56 --> Output Class Initialized
INFO - 2018-10-30 07:12:56 --> Security Class Initialized
DEBUG - 2018-10-30 07:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:12:56 --> Input Class Initialized
INFO - 2018-10-30 07:12:56 --> Language Class Initialized
INFO - 2018-10-30 07:12:56 --> Loader Class Initialized
INFO - 2018-10-30 07:12:57 --> Helper loaded: url_helper
INFO - 2018-10-30 07:12:57 --> Database Driver Class Initialized
INFO - 2018-10-30 07:12:57 --> Helper loaded: form_helper
INFO - 2018-10-30 07:12:57 --> Form Validation Class Initialized
INFO - 2018-10-30 07:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:12:57 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:12:57 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:12:57 --> Email Class Initialized
INFO - 2018-10-30 07:12:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:12:57 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:12:57 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:12:57 --> Helper loaded: date_helper
INFO - 2018-10-30 07:12:57 --> Database Driver Class Initialized
INFO - 2018-10-30 07:12:57 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:12:57 --> Controller Class Initialized
INFO - 2018-10-30 07:12:57 --> Model "Item_model" initialized
INFO - 2018-10-30 07:12:57 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:12:57 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:12:57 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:12:57 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 07:12:57 --> Severity: error --> Exception: syntax error, unexpected '$sql' (T_VARIABLE) D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 64
INFO - 2018-10-30 07:15:10 --> Config Class Initialized
INFO - 2018-10-30 07:15:10 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:15:10 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:15:10 --> Utf8 Class Initialized
INFO - 2018-10-30 07:15:10 --> URI Class Initialized
INFO - 2018-10-30 07:15:10 --> Router Class Initialized
INFO - 2018-10-30 07:15:10 --> Output Class Initialized
INFO - 2018-10-30 07:15:10 --> Security Class Initialized
DEBUG - 2018-10-30 07:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:15:10 --> Input Class Initialized
INFO - 2018-10-30 07:15:10 --> Language Class Initialized
INFO - 2018-10-30 07:15:10 --> Loader Class Initialized
INFO - 2018-10-30 07:15:10 --> Helper loaded: url_helper
INFO - 2018-10-30 07:15:10 --> Database Driver Class Initialized
INFO - 2018-10-30 07:15:10 --> Helper loaded: form_helper
INFO - 2018-10-30 07:15:10 --> Form Validation Class Initialized
INFO - 2018-10-30 07:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:15:10 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:15:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:15:10 --> Email Class Initialized
INFO - 2018-10-30 07:15:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:15:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:15:10 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:15:10 --> Helper loaded: date_helper
INFO - 2018-10-30 07:15:10 --> Database Driver Class Initialized
INFO - 2018-10-30 07:15:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:15:10 --> Controller Class Initialized
INFO - 2018-10-30 07:15:10 --> Model "Item_model" initialized
INFO - 2018-10-30 07:15:10 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:15:10 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:15:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:15:10 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 07:15:10 --> Severity: error --> Exception: syntax error, unexpected '$sql' (T_VARIABLE) D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 64
INFO - 2018-10-30 07:15:20 --> Config Class Initialized
INFO - 2018-10-30 07:15:20 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:15:20 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:15:20 --> Utf8 Class Initialized
INFO - 2018-10-30 07:15:20 --> URI Class Initialized
INFO - 2018-10-30 07:15:20 --> Router Class Initialized
INFO - 2018-10-30 07:15:20 --> Output Class Initialized
INFO - 2018-10-30 07:15:20 --> Security Class Initialized
DEBUG - 2018-10-30 07:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:15:20 --> Input Class Initialized
INFO - 2018-10-30 07:15:20 --> Language Class Initialized
INFO - 2018-10-30 07:15:20 --> Loader Class Initialized
INFO - 2018-10-30 07:15:20 --> Helper loaded: url_helper
INFO - 2018-10-30 07:15:20 --> Database Driver Class Initialized
INFO - 2018-10-30 07:15:20 --> Helper loaded: form_helper
INFO - 2018-10-30 07:15:20 --> Form Validation Class Initialized
INFO - 2018-10-30 07:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:15:21 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:15:21 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:15:21 --> Email Class Initialized
INFO - 2018-10-30 07:15:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:15:21 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:15:21 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:15:21 --> Helper loaded: date_helper
INFO - 2018-10-30 07:15:21 --> Database Driver Class Initialized
INFO - 2018-10-30 07:15:21 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:15:21 --> Controller Class Initialized
INFO - 2018-10-30 07:15:21 --> Model "Item_model" initialized
INFO - 2018-10-30 07:15:21 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:15:21 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:15:21 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:15:21 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 07:15:21 --> Severity: error --> Exception: syntax error, unexpected '$sql' (T_VARIABLE) D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 64
INFO - 2018-10-30 07:15:33 --> Config Class Initialized
INFO - 2018-10-30 07:15:33 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:15:34 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:15:34 --> Utf8 Class Initialized
INFO - 2018-10-30 07:15:34 --> URI Class Initialized
INFO - 2018-10-30 07:15:34 --> Router Class Initialized
INFO - 2018-10-30 07:15:34 --> Output Class Initialized
INFO - 2018-10-30 07:15:34 --> Security Class Initialized
DEBUG - 2018-10-30 07:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:15:34 --> Input Class Initialized
INFO - 2018-10-30 07:15:34 --> Language Class Initialized
INFO - 2018-10-30 07:15:34 --> Loader Class Initialized
INFO - 2018-10-30 07:15:34 --> Helper loaded: url_helper
INFO - 2018-10-30 07:15:34 --> Database Driver Class Initialized
INFO - 2018-10-30 07:15:34 --> Helper loaded: form_helper
INFO - 2018-10-30 07:15:34 --> Form Validation Class Initialized
INFO - 2018-10-30 07:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:15:34 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:15:34 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:15:34 --> Email Class Initialized
INFO - 2018-10-30 07:15:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:15:34 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:15:34 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:15:34 --> Helper loaded: date_helper
INFO - 2018-10-30 07:15:34 --> Database Driver Class Initialized
INFO - 2018-10-30 07:15:34 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:15:34 --> Controller Class Initialized
INFO - 2018-10-30 07:15:34 --> Model "Item_model" initialized
INFO - 2018-10-30 07:15:34 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:15:34 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:15:34 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:15:34 --> Model "Notadetail_model" initialized
ERROR - 2018-10-30 07:15:34 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\masterwedding\application\views\item\pesan.php 64
INFO - 2018-10-30 07:15:47 --> Config Class Initialized
INFO - 2018-10-30 07:15:47 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:15:47 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:15:47 --> Utf8 Class Initialized
INFO - 2018-10-30 07:15:47 --> URI Class Initialized
INFO - 2018-10-30 07:15:47 --> Router Class Initialized
INFO - 2018-10-30 07:15:47 --> Output Class Initialized
INFO - 2018-10-30 07:15:47 --> Security Class Initialized
DEBUG - 2018-10-30 07:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:15:47 --> Input Class Initialized
INFO - 2018-10-30 07:15:47 --> Language Class Initialized
INFO - 2018-10-30 07:15:47 --> Loader Class Initialized
INFO - 2018-10-30 07:15:47 --> Helper loaded: url_helper
INFO - 2018-10-30 07:15:47 --> Database Driver Class Initialized
INFO - 2018-10-30 07:15:47 --> Helper loaded: form_helper
INFO - 2018-10-30 07:15:47 --> Form Validation Class Initialized
INFO - 2018-10-30 07:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:15:47 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:15:47 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:15:47 --> Email Class Initialized
INFO - 2018-10-30 07:15:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:15:47 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:15:47 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:15:47 --> Helper loaded: date_helper
INFO - 2018-10-30 07:15:47 --> Database Driver Class Initialized
INFO - 2018-10-30 07:15:47 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:15:47 --> Controller Class Initialized
INFO - 2018-10-30 07:15:48 --> Model "Item_model" initialized
INFO - 2018-10-30 07:15:48 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:15:48 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:15:48 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:15:48 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:15:48 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 07:15:48 --> Final output sent to browser
DEBUG - 2018-10-30 07:15:48 --> Total execution time: 0.7810
INFO - 2018-10-30 07:15:48 --> Config Class Initialized
INFO - 2018-10-30 07:15:48 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:15:48 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:15:48 --> Utf8 Class Initialized
INFO - 2018-10-30 07:15:48 --> URI Class Initialized
INFO - 2018-10-30 07:15:48 --> Router Class Initialized
INFO - 2018-10-30 07:15:48 --> Output Class Initialized
INFO - 2018-10-30 07:15:48 --> Security Class Initialized
DEBUG - 2018-10-30 07:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:15:48 --> Input Class Initialized
INFO - 2018-10-30 07:15:48 --> Language Class Initialized
ERROR - 2018-10-30 07:15:48 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:15:53 --> Config Class Initialized
INFO - 2018-10-30 07:15:53 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:15:53 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:15:53 --> Utf8 Class Initialized
INFO - 2018-10-30 07:15:53 --> URI Class Initialized
INFO - 2018-10-30 07:15:53 --> Router Class Initialized
INFO - 2018-10-30 07:15:53 --> Output Class Initialized
INFO - 2018-10-30 07:15:53 --> Security Class Initialized
DEBUG - 2018-10-30 07:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:15:53 --> Input Class Initialized
INFO - 2018-10-30 07:15:53 --> Language Class Initialized
INFO - 2018-10-30 07:15:53 --> Loader Class Initialized
INFO - 2018-10-30 07:15:53 --> Helper loaded: url_helper
INFO - 2018-10-30 07:15:53 --> Database Driver Class Initialized
INFO - 2018-10-30 07:15:53 --> Helper loaded: form_helper
INFO - 2018-10-30 07:15:53 --> Form Validation Class Initialized
INFO - 2018-10-30 07:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:15:53 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:15:53 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:15:53 --> Email Class Initialized
INFO - 2018-10-30 07:15:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:15:54 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:15:54 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:15:54 --> Helper loaded: date_helper
INFO - 2018-10-30 07:15:54 --> Database Driver Class Initialized
INFO - 2018-10-30 07:15:54 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:15:54 --> Controller Class Initialized
INFO - 2018-10-30 07:15:54 --> Model "Item_model" initialized
INFO - 2018-10-30 07:15:54 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:15:54 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:15:54 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:15:54 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:17:06 --> Config Class Initialized
INFO - 2018-10-30 07:17:06 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:17:06 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:17:06 --> Utf8 Class Initialized
INFO - 2018-10-30 07:17:06 --> URI Class Initialized
INFO - 2018-10-30 07:17:06 --> Router Class Initialized
INFO - 2018-10-30 07:17:06 --> Output Class Initialized
INFO - 2018-10-30 07:17:06 --> Security Class Initialized
DEBUG - 2018-10-30 07:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:17:06 --> Input Class Initialized
INFO - 2018-10-30 07:17:06 --> Language Class Initialized
INFO - 2018-10-30 07:17:06 --> Loader Class Initialized
INFO - 2018-10-30 07:17:06 --> Helper loaded: url_helper
INFO - 2018-10-30 07:17:06 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:06 --> Helper loaded: form_helper
INFO - 2018-10-30 07:17:06 --> Form Validation Class Initialized
INFO - 2018-10-30 07:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:17:06 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:17:06 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:17:06 --> Email Class Initialized
INFO - 2018-10-30 07:17:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:17:06 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:17:06 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:17:06 --> Helper loaded: date_helper
INFO - 2018-10-30 07:17:06 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:06 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:17:06 --> Controller Class Initialized
INFO - 2018-10-30 07:17:06 --> Model "Item_model" initialized
INFO - 2018-10-30 07:17:06 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:17:06 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:17:06 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:17:06 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:17:09 --> Config Class Initialized
INFO - 2018-10-30 07:17:09 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:17:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:17:09 --> Utf8 Class Initialized
INFO - 2018-10-30 07:17:09 --> URI Class Initialized
INFO - 2018-10-30 07:17:09 --> Router Class Initialized
INFO - 2018-10-30 07:17:09 --> Output Class Initialized
INFO - 2018-10-30 07:17:09 --> Security Class Initialized
DEBUG - 2018-10-30 07:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:17:09 --> Input Class Initialized
INFO - 2018-10-30 07:17:09 --> Language Class Initialized
INFO - 2018-10-30 07:17:09 --> Loader Class Initialized
INFO - 2018-10-30 07:17:09 --> Helper loaded: url_helper
INFO - 2018-10-30 07:17:09 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:09 --> Helper loaded: form_helper
INFO - 2018-10-30 07:17:09 --> Form Validation Class Initialized
INFO - 2018-10-30 07:17:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:17:09 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:17:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:17:09 --> Email Class Initialized
INFO - 2018-10-30 07:17:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:17:09 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:17:09 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:17:09 --> Helper loaded: date_helper
INFO - 2018-10-30 07:17:10 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:17:10 --> Controller Class Initialized
INFO - 2018-10-30 07:17:10 --> Model "Item_model" initialized
INFO - 2018-10-30 07:17:10 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:17:10 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:17:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:17:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:17:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 07:17:10 --> Final output sent to browser
DEBUG - 2018-10-30 07:17:10 --> Total execution time: 0.8314
INFO - 2018-10-30 07:17:13 --> Config Class Initialized
INFO - 2018-10-30 07:17:13 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:17:13 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:17:13 --> Utf8 Class Initialized
INFO - 2018-10-30 07:17:13 --> URI Class Initialized
INFO - 2018-10-30 07:17:13 --> Router Class Initialized
INFO - 2018-10-30 07:17:13 --> Output Class Initialized
INFO - 2018-10-30 07:17:13 --> Security Class Initialized
DEBUG - 2018-10-30 07:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:17:13 --> Input Class Initialized
INFO - 2018-10-30 07:17:13 --> Language Class Initialized
INFO - 2018-10-30 07:17:13 --> Loader Class Initialized
INFO - 2018-10-30 07:17:13 --> Helper loaded: url_helper
INFO - 2018-10-30 07:17:13 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:13 --> Helper loaded: form_helper
INFO - 2018-10-30 07:17:13 --> Form Validation Class Initialized
INFO - 2018-10-30 07:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:17:13 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:17:14 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:17:14 --> Email Class Initialized
INFO - 2018-10-30 07:17:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:17:14 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:17:14 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:17:14 --> Helper loaded: date_helper
INFO - 2018-10-30 07:17:14 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:14 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:17:14 --> Controller Class Initialized
INFO - 2018-10-30 07:17:14 --> Model "Item_model" initialized
INFO - 2018-10-30 07:17:14 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:17:14 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:17:14 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:17:14 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:17:14 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 07:17:14 --> Final output sent to browser
DEBUG - 2018-10-30 07:17:14 --> Total execution time: 0.8218
INFO - 2018-10-30 07:17:14 --> Config Class Initialized
INFO - 2018-10-30 07:17:14 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:17:14 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:17:14 --> Utf8 Class Initialized
INFO - 2018-10-30 07:17:14 --> URI Class Initialized
INFO - 2018-10-30 07:17:14 --> Router Class Initialized
INFO - 2018-10-30 07:17:14 --> Output Class Initialized
INFO - 2018-10-30 07:17:14 --> Security Class Initialized
DEBUG - 2018-10-30 07:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:17:14 --> Input Class Initialized
INFO - 2018-10-30 07:17:14 --> Language Class Initialized
ERROR - 2018-10-30 07:17:14 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:17:16 --> Config Class Initialized
INFO - 2018-10-30 07:17:16 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:17:16 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:17:16 --> Utf8 Class Initialized
INFO - 2018-10-30 07:17:16 --> URI Class Initialized
INFO - 2018-10-30 07:17:16 --> Router Class Initialized
INFO - 2018-10-30 07:17:16 --> Output Class Initialized
INFO - 2018-10-30 07:17:16 --> Security Class Initialized
DEBUG - 2018-10-30 07:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:17:16 --> Input Class Initialized
INFO - 2018-10-30 07:17:16 --> Language Class Initialized
INFO - 2018-10-30 07:17:16 --> Loader Class Initialized
INFO - 2018-10-30 07:17:16 --> Helper loaded: url_helper
INFO - 2018-10-30 07:17:16 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:16 --> Helper loaded: form_helper
INFO - 2018-10-30 07:17:16 --> Form Validation Class Initialized
INFO - 2018-10-30 07:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:17:16 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:17:16 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:17:16 --> Email Class Initialized
INFO - 2018-10-30 07:17:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:17:16 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:17:16 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:17:17 --> Helper loaded: date_helper
INFO - 2018-10-30 07:17:17 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:17 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:17:17 --> Controller Class Initialized
INFO - 2018-10-30 07:17:17 --> Model "Item_model" initialized
INFO - 2018-10-30 07:17:17 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:17:17 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:17:17 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:17:17 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:17:41 --> Config Class Initialized
INFO - 2018-10-30 07:17:41 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:17:41 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:17:41 --> Utf8 Class Initialized
INFO - 2018-10-30 07:17:41 --> URI Class Initialized
INFO - 2018-10-30 07:17:41 --> Router Class Initialized
INFO - 2018-10-30 07:17:41 --> Output Class Initialized
INFO - 2018-10-30 07:17:41 --> Security Class Initialized
DEBUG - 2018-10-30 07:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:17:41 --> Input Class Initialized
INFO - 2018-10-30 07:17:41 --> Language Class Initialized
INFO - 2018-10-30 07:17:41 --> Loader Class Initialized
INFO - 2018-10-30 07:17:41 --> Helper loaded: url_helper
INFO - 2018-10-30 07:17:41 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:41 --> Helper loaded: form_helper
INFO - 2018-10-30 07:17:41 --> Form Validation Class Initialized
INFO - 2018-10-30 07:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:17:41 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:17:41 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:17:41 --> Email Class Initialized
INFO - 2018-10-30 07:17:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:17:41 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:17:41 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:17:41 --> Helper loaded: date_helper
INFO - 2018-10-30 07:17:41 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:41 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:17:42 --> Controller Class Initialized
INFO - 2018-10-30 07:17:42 --> Model "Item_model" initialized
INFO - 2018-10-30 07:17:42 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:17:42 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:17:42 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:17:42 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:17:42 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 07:17:42 --> Final output sent to browser
DEBUG - 2018-10-30 07:17:42 --> Total execution time: 0.8338
INFO - 2018-10-30 07:17:47 --> Config Class Initialized
INFO - 2018-10-30 07:17:47 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:17:47 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:17:47 --> Utf8 Class Initialized
INFO - 2018-10-30 07:17:47 --> URI Class Initialized
INFO - 2018-10-30 07:17:47 --> Router Class Initialized
INFO - 2018-10-30 07:17:47 --> Output Class Initialized
INFO - 2018-10-30 07:17:47 --> Security Class Initialized
DEBUG - 2018-10-30 07:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:17:47 --> Input Class Initialized
INFO - 2018-10-30 07:17:47 --> Language Class Initialized
INFO - 2018-10-30 07:17:47 --> Loader Class Initialized
INFO - 2018-10-30 07:17:47 --> Helper loaded: url_helper
INFO - 2018-10-30 07:17:47 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:47 --> Helper loaded: form_helper
INFO - 2018-10-30 07:17:47 --> Form Validation Class Initialized
INFO - 2018-10-30 07:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:17:47 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:17:47 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:17:47 --> Email Class Initialized
INFO - 2018-10-30 07:17:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:17:47 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:17:47 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:17:47 --> Helper loaded: date_helper
INFO - 2018-10-30 07:17:47 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:47 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:17:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:17:47 --> Controller Class Initialized
INFO - 2018-10-30 07:17:47 --> Model "Item_model" initialized
INFO - 2018-10-30 07:17:47 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:17:47 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:17:47 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:17:47 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:17:47 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 07:17:47 --> Final output sent to browser
DEBUG - 2018-10-30 07:17:47 --> Total execution time: 0.8218
INFO - 2018-10-30 07:17:47 --> Config Class Initialized
INFO - 2018-10-30 07:17:48 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:17:48 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:17:48 --> Utf8 Class Initialized
INFO - 2018-10-30 07:17:48 --> URI Class Initialized
INFO - 2018-10-30 07:17:48 --> Router Class Initialized
INFO - 2018-10-30 07:17:48 --> Output Class Initialized
INFO - 2018-10-30 07:17:48 --> Security Class Initialized
DEBUG - 2018-10-30 07:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:17:48 --> Input Class Initialized
INFO - 2018-10-30 07:17:48 --> Language Class Initialized
ERROR - 2018-10-30 07:17:48 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:17:50 --> Config Class Initialized
INFO - 2018-10-30 07:17:50 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:17:50 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:17:51 --> Utf8 Class Initialized
INFO - 2018-10-30 07:17:51 --> URI Class Initialized
INFO - 2018-10-30 07:17:51 --> Router Class Initialized
INFO - 2018-10-30 07:17:51 --> Output Class Initialized
INFO - 2018-10-30 07:17:51 --> Security Class Initialized
DEBUG - 2018-10-30 07:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:17:51 --> Input Class Initialized
INFO - 2018-10-30 07:17:51 --> Language Class Initialized
INFO - 2018-10-30 07:17:51 --> Loader Class Initialized
INFO - 2018-10-30 07:17:51 --> Helper loaded: url_helper
INFO - 2018-10-30 07:17:51 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:51 --> Helper loaded: form_helper
INFO - 2018-10-30 07:17:51 --> Form Validation Class Initialized
INFO - 2018-10-30 07:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:17:51 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:17:51 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:17:51 --> Email Class Initialized
INFO - 2018-10-30 07:17:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:17:51 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:17:51 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:17:51 --> Helper loaded: date_helper
INFO - 2018-10-30 07:17:51 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:51 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:17:51 --> Controller Class Initialized
INFO - 2018-10-30 07:17:51 --> Model "Item_model" initialized
INFO - 2018-10-30 07:17:51 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:17:51 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:17:51 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:17:51 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:17:57 --> Config Class Initialized
INFO - 2018-10-30 07:17:57 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:17:57 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:17:57 --> Utf8 Class Initialized
INFO - 2018-10-30 07:17:57 --> URI Class Initialized
INFO - 2018-10-30 07:17:57 --> Router Class Initialized
INFO - 2018-10-30 07:17:57 --> Output Class Initialized
INFO - 2018-10-30 07:17:57 --> Security Class Initialized
DEBUG - 2018-10-30 07:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:17:57 --> Input Class Initialized
INFO - 2018-10-30 07:17:57 --> Language Class Initialized
INFO - 2018-10-30 07:17:57 --> Loader Class Initialized
INFO - 2018-10-30 07:17:57 --> Helper loaded: url_helper
INFO - 2018-10-30 07:17:57 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:57 --> Helper loaded: form_helper
INFO - 2018-10-30 07:17:57 --> Form Validation Class Initialized
INFO - 2018-10-30 07:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:17:57 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:17:57 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:17:57 --> Email Class Initialized
INFO - 2018-10-30 07:17:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:17:57 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:17:57 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:17:58 --> Helper loaded: date_helper
INFO - 2018-10-30 07:17:58 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:58 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:17:58 --> Controller Class Initialized
INFO - 2018-10-30 07:17:58 --> Model "Item_model" initialized
INFO - 2018-10-30 07:17:58 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:17:58 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:17:58 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:17:58 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:17:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 07:17:58 --> Final output sent to browser
INFO - 2018-10-30 07:17:58 --> Config Class Initialized
DEBUG - 2018-10-30 07:17:58 --> Total execution time: 0.8237
INFO - 2018-10-30 07:17:58 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:17:58 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:17:58 --> Utf8 Class Initialized
INFO - 2018-10-30 07:17:58 --> URI Class Initialized
INFO - 2018-10-30 07:17:58 --> Router Class Initialized
INFO - 2018-10-30 07:17:58 --> Output Class Initialized
INFO - 2018-10-30 07:17:58 --> Security Class Initialized
DEBUG - 2018-10-30 07:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:17:58 --> Input Class Initialized
INFO - 2018-10-30 07:17:58 --> Language Class Initialized
INFO - 2018-10-30 07:17:58 --> Loader Class Initialized
INFO - 2018-10-30 07:17:58 --> Helper loaded: url_helper
INFO - 2018-10-30 07:17:58 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:58 --> Helper loaded: form_helper
INFO - 2018-10-30 07:17:58 --> Form Validation Class Initialized
INFO - 2018-10-30 07:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:17:58 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:17:58 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:17:58 --> Email Class Initialized
INFO - 2018-10-30 07:17:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:17:58 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:17:58 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:17:58 --> Helper loaded: date_helper
INFO - 2018-10-30 07:17:58 --> Database Driver Class Initialized
INFO - 2018-10-30 07:17:58 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:17:58 --> Controller Class Initialized
INFO - 2018-10-30 07:17:58 --> Model "Item_model" initialized
INFO - 2018-10-30 07:17:58 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:17:58 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:17:59 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:17:59 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:17:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 07:17:59 --> Final output sent to browser
DEBUG - 2018-10-30 07:17:59 --> Total execution time: 0.7904
INFO - 2018-10-30 07:18:05 --> Config Class Initialized
INFO - 2018-10-30 07:18:05 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:18:05 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:18:05 --> Utf8 Class Initialized
INFO - 2018-10-30 07:18:05 --> URI Class Initialized
INFO - 2018-10-30 07:18:05 --> Router Class Initialized
INFO - 2018-10-30 07:18:05 --> Output Class Initialized
INFO - 2018-10-30 07:18:05 --> Security Class Initialized
DEBUG - 2018-10-30 07:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:18:06 --> Input Class Initialized
INFO - 2018-10-30 07:18:06 --> Language Class Initialized
INFO - 2018-10-30 07:18:06 --> Loader Class Initialized
INFO - 2018-10-30 07:18:06 --> Helper loaded: url_helper
INFO - 2018-10-30 07:18:06 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:06 --> Helper loaded: form_helper
INFO - 2018-10-30 07:18:06 --> Form Validation Class Initialized
INFO - 2018-10-30 07:18:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:18:06 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:18:06 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:18:06 --> Email Class Initialized
INFO - 2018-10-30 07:18:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:18:06 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:18:06 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:18:06 --> Helper loaded: date_helper
INFO - 2018-10-30 07:18:06 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:06 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:18:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:18:06 --> Controller Class Initialized
INFO - 2018-10-30 07:18:06 --> Model "Item_model" initialized
INFO - 2018-10-30 07:18:06 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:18:06 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:18:06 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:18:06 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:18:06 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 07:18:06 --> Final output sent to browser
DEBUG - 2018-10-30 07:18:06 --> Total execution time: 0.8822
INFO - 2018-10-30 07:18:06 --> Config Class Initialized
INFO - 2018-10-30 07:18:06 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:18:06 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:18:06 --> Utf8 Class Initialized
INFO - 2018-10-30 07:18:06 --> URI Class Initialized
INFO - 2018-10-30 07:18:06 --> Router Class Initialized
INFO - 2018-10-30 07:18:06 --> Output Class Initialized
INFO - 2018-10-30 07:18:06 --> Security Class Initialized
DEBUG - 2018-10-30 07:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:18:06 --> Input Class Initialized
INFO - 2018-10-30 07:18:06 --> Language Class Initialized
ERROR - 2018-10-30 07:18:06 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:18:09 --> Config Class Initialized
INFO - 2018-10-30 07:18:09 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:18:09 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:18:09 --> Utf8 Class Initialized
INFO - 2018-10-30 07:18:09 --> URI Class Initialized
INFO - 2018-10-30 07:18:09 --> Router Class Initialized
INFO - 2018-10-30 07:18:09 --> Output Class Initialized
INFO - 2018-10-30 07:18:09 --> Security Class Initialized
DEBUG - 2018-10-30 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:18:09 --> Input Class Initialized
INFO - 2018-10-30 07:18:09 --> Language Class Initialized
INFO - 2018-10-30 07:18:09 --> Loader Class Initialized
INFO - 2018-10-30 07:18:10 --> Helper loaded: url_helper
INFO - 2018-10-30 07:18:10 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:10 --> Helper loaded: form_helper
INFO - 2018-10-30 07:18:10 --> Form Validation Class Initialized
INFO - 2018-10-30 07:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:18:10 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:18:10 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:18:10 --> Email Class Initialized
INFO - 2018-10-30 07:18:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:18:10 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:18:10 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:18:10 --> Helper loaded: date_helper
INFO - 2018-10-30 07:18:10 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:18:10 --> Controller Class Initialized
INFO - 2018-10-30 07:18:10 --> Model "Item_model" initialized
INFO - 2018-10-30 07:18:10 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:18:10 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:18:10 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:18:10 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:18:42 --> Config Class Initialized
INFO - 2018-10-30 07:18:42 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:18:42 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:18:42 --> Utf8 Class Initialized
INFO - 2018-10-30 07:18:42 --> URI Class Initialized
INFO - 2018-10-30 07:18:42 --> Router Class Initialized
INFO - 2018-10-30 07:18:42 --> Output Class Initialized
INFO - 2018-10-30 07:18:42 --> Security Class Initialized
DEBUG - 2018-10-30 07:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:18:42 --> Input Class Initialized
INFO - 2018-10-30 07:18:42 --> Language Class Initialized
INFO - 2018-10-30 07:18:42 --> Loader Class Initialized
INFO - 2018-10-30 07:18:42 --> Helper loaded: url_helper
INFO - 2018-10-30 07:18:42 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:42 --> Helper loaded: form_helper
INFO - 2018-10-30 07:18:42 --> Form Validation Class Initialized
INFO - 2018-10-30 07:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:18:42 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:18:42 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:18:42 --> Email Class Initialized
INFO - 2018-10-30 07:18:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:18:42 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:18:42 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:18:43 --> Helper loaded: date_helper
INFO - 2018-10-30 07:18:43 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:43 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:18:43 --> Controller Class Initialized
INFO - 2018-10-30 07:18:43 --> Model "Item_model" initialized
INFO - 2018-10-30 07:18:43 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:18:43 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:18:43 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:18:43 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:18:43 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 07:18:43 --> Final output sent to browser
DEBUG - 2018-10-30 07:18:43 --> Total execution time: 0.8538
INFO - 2018-10-30 07:18:46 --> Config Class Initialized
INFO - 2018-10-30 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:18:46 --> Utf8 Class Initialized
INFO - 2018-10-30 07:18:46 --> URI Class Initialized
INFO - 2018-10-30 07:18:46 --> Router Class Initialized
INFO - 2018-10-30 07:18:46 --> Output Class Initialized
INFO - 2018-10-30 07:18:46 --> Security Class Initialized
DEBUG - 2018-10-30 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:18:46 --> Input Class Initialized
INFO - 2018-10-30 07:18:46 --> Language Class Initialized
INFO - 2018-10-30 07:18:46 --> Loader Class Initialized
INFO - 2018-10-30 07:18:46 --> Helper loaded: url_helper
INFO - 2018-10-30 07:18:46 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:46 --> Helper loaded: form_helper
INFO - 2018-10-30 07:18:46 --> Form Validation Class Initialized
INFO - 2018-10-30 07:18:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:18:46 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:18:46 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:18:46 --> Email Class Initialized
INFO - 2018-10-30 07:18:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:18:46 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:18:47 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:18:47 --> Helper loaded: date_helper
INFO - 2018-10-30 07:18:47 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:47 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:18:47 --> Controller Class Initialized
INFO - 2018-10-30 07:18:47 --> Model "Item_model" initialized
INFO - 2018-10-30 07:18:47 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:18:47 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:18:47 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:18:47 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:18:47 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 07:18:47 --> Final output sent to browser
DEBUG - 2018-10-30 07:18:47 --> Total execution time: 0.8747
INFO - 2018-10-30 07:18:47 --> Config Class Initialized
INFO - 2018-10-30 07:18:47 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:18:47 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:18:47 --> Utf8 Class Initialized
INFO - 2018-10-30 07:18:47 --> URI Class Initialized
INFO - 2018-10-30 07:18:47 --> Router Class Initialized
INFO - 2018-10-30 07:18:47 --> Output Class Initialized
INFO - 2018-10-30 07:18:47 --> Security Class Initialized
DEBUG - 2018-10-30 07:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:18:47 --> Input Class Initialized
INFO - 2018-10-30 07:18:47 --> Language Class Initialized
ERROR - 2018-10-30 07:18:47 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:18:49 --> Config Class Initialized
INFO - 2018-10-30 07:18:49 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:18:49 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:18:49 --> Utf8 Class Initialized
INFO - 2018-10-30 07:18:49 --> URI Class Initialized
INFO - 2018-10-30 07:18:49 --> Router Class Initialized
INFO - 2018-10-30 07:18:49 --> Output Class Initialized
INFO - 2018-10-30 07:18:49 --> Security Class Initialized
DEBUG - 2018-10-30 07:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:18:49 --> Input Class Initialized
INFO - 2018-10-30 07:18:49 --> Language Class Initialized
INFO - 2018-10-30 07:18:49 --> Loader Class Initialized
INFO - 2018-10-30 07:18:49 --> Helper loaded: url_helper
INFO - 2018-10-30 07:18:49 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:49 --> Helper loaded: form_helper
INFO - 2018-10-30 07:18:49 --> Form Validation Class Initialized
INFO - 2018-10-30 07:18:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:18:49 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:18:49 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:18:49 --> Email Class Initialized
INFO - 2018-10-30 07:18:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:18:49 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:18:49 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:18:49 --> Helper loaded: date_helper
INFO - 2018-10-30 07:18:49 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:49 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:18:49 --> Controller Class Initialized
INFO - 2018-10-30 07:18:49 --> Model "Item_model" initialized
INFO - 2018-10-30 07:18:49 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:18:50 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:18:50 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:18:50 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:18:58 --> Config Class Initialized
INFO - 2018-10-30 07:18:58 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:18:58 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:18:58 --> Utf8 Class Initialized
INFO - 2018-10-30 07:18:59 --> URI Class Initialized
INFO - 2018-10-30 07:18:59 --> Router Class Initialized
INFO - 2018-10-30 07:18:59 --> Output Class Initialized
INFO - 2018-10-30 07:18:59 --> Security Class Initialized
DEBUG - 2018-10-30 07:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:18:59 --> Input Class Initialized
INFO - 2018-10-30 07:18:59 --> Language Class Initialized
INFO - 2018-10-30 07:18:59 --> Loader Class Initialized
INFO - 2018-10-30 07:18:59 --> Helper loaded: url_helper
INFO - 2018-10-30 07:18:59 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:59 --> Helper loaded: form_helper
INFO - 2018-10-30 07:18:59 --> Form Validation Class Initialized
INFO - 2018-10-30 07:18:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:18:59 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:18:59 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:18:59 --> Email Class Initialized
INFO - 2018-10-30 07:18:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:18:59 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:18:59 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:18:59 --> Helper loaded: date_helper
INFO - 2018-10-30 07:18:59 --> Database Driver Class Initialized
INFO - 2018-10-30 07:18:59 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:18:59 --> Controller Class Initialized
INFO - 2018-10-30 07:18:59 --> Model "Item_model" initialized
INFO - 2018-10-30 07:18:59 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:18:59 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:18:59 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:18:59 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:18:59 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 07:18:59 --> Final output sent to browser
DEBUG - 2018-10-30 07:18:59 --> Total execution time: 0.8909
INFO - 2018-10-30 07:19:02 --> Config Class Initialized
INFO - 2018-10-30 07:19:02 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:19:02 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:19:02 --> Utf8 Class Initialized
INFO - 2018-10-30 07:19:02 --> URI Class Initialized
INFO - 2018-10-30 07:19:02 --> Router Class Initialized
INFO - 2018-10-30 07:19:02 --> Output Class Initialized
INFO - 2018-10-30 07:19:02 --> Security Class Initialized
DEBUG - 2018-10-30 07:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:19:03 --> Input Class Initialized
INFO - 2018-10-30 07:19:03 --> Language Class Initialized
INFO - 2018-10-30 07:19:03 --> Loader Class Initialized
INFO - 2018-10-30 07:19:03 --> Helper loaded: url_helper
INFO - 2018-10-30 07:19:03 --> Database Driver Class Initialized
INFO - 2018-10-30 07:19:03 --> Helper loaded: form_helper
INFO - 2018-10-30 07:19:03 --> Form Validation Class Initialized
INFO - 2018-10-30 07:19:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:19:03 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:19:03 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:19:03 --> Email Class Initialized
INFO - 2018-10-30 07:19:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:19:03 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:19:03 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:19:03 --> Helper loaded: date_helper
INFO - 2018-10-30 07:19:03 --> Database Driver Class Initialized
INFO - 2018-10-30 07:19:03 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:19:03 --> Controller Class Initialized
INFO - 2018-10-30 07:19:03 --> Model "Item_model" initialized
INFO - 2018-10-30 07:19:03 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:19:03 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:19:03 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:19:03 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:19:03 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 07:19:03 --> Final output sent to browser
DEBUG - 2018-10-30 07:19:03 --> Total execution time: 0.9038
INFO - 2018-10-30 07:19:03 --> Config Class Initialized
INFO - 2018-10-30 07:19:03 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:19:03 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:19:03 --> Utf8 Class Initialized
INFO - 2018-10-30 07:19:03 --> URI Class Initialized
INFO - 2018-10-30 07:19:03 --> Router Class Initialized
INFO - 2018-10-30 07:19:03 --> Output Class Initialized
INFO - 2018-10-30 07:19:03 --> Security Class Initialized
DEBUG - 2018-10-30 07:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:19:03 --> Input Class Initialized
INFO - 2018-10-30 07:19:03 --> Language Class Initialized
ERROR - 2018-10-30 07:19:03 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:19:05 --> Config Class Initialized
INFO - 2018-10-30 07:19:05 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:19:05 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:19:05 --> Utf8 Class Initialized
INFO - 2018-10-30 07:19:05 --> URI Class Initialized
INFO - 2018-10-30 07:19:05 --> Router Class Initialized
INFO - 2018-10-30 07:19:05 --> Output Class Initialized
INFO - 2018-10-30 07:19:05 --> Security Class Initialized
DEBUG - 2018-10-30 07:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:19:06 --> Input Class Initialized
INFO - 2018-10-30 07:19:06 --> Language Class Initialized
INFO - 2018-10-30 07:19:06 --> Loader Class Initialized
INFO - 2018-10-30 07:19:06 --> Helper loaded: url_helper
INFO - 2018-10-30 07:19:06 --> Database Driver Class Initialized
INFO - 2018-10-30 07:19:06 --> Helper loaded: form_helper
INFO - 2018-10-30 07:19:06 --> Form Validation Class Initialized
INFO - 2018-10-30 07:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:19:06 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:19:06 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:19:06 --> Email Class Initialized
INFO - 2018-10-30 07:19:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:19:06 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:19:06 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:19:06 --> Helper loaded: date_helper
INFO - 2018-10-30 07:19:06 --> Database Driver Class Initialized
INFO - 2018-10-30 07:19:06 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:19:06 --> Controller Class Initialized
INFO - 2018-10-30 07:19:06 --> Model "Item_model" initialized
INFO - 2018-10-30 07:19:06 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:19:06 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:19:06 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:19:06 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:19:13 --> Config Class Initialized
INFO - 2018-10-30 07:19:13 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:19:13 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:19:13 --> Utf8 Class Initialized
INFO - 2018-10-30 07:19:13 --> URI Class Initialized
INFO - 2018-10-30 07:19:13 --> Router Class Initialized
INFO - 2018-10-30 07:19:13 --> Output Class Initialized
INFO - 2018-10-30 07:19:13 --> Security Class Initialized
DEBUG - 2018-10-30 07:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:19:13 --> Input Class Initialized
INFO - 2018-10-30 07:19:13 --> Language Class Initialized
INFO - 2018-10-30 07:19:13 --> Loader Class Initialized
INFO - 2018-10-30 07:19:14 --> Helper loaded: url_helper
INFO - 2018-10-30 07:19:14 --> Database Driver Class Initialized
INFO - 2018-10-30 07:19:14 --> Helper loaded: form_helper
INFO - 2018-10-30 07:19:14 --> Form Validation Class Initialized
INFO - 2018-10-30 07:19:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:19:14 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:19:14 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:19:14 --> Email Class Initialized
INFO - 2018-10-30 07:19:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:19:14 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:19:14 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:19:14 --> Helper loaded: date_helper
INFO - 2018-10-30 07:19:14 --> Database Driver Class Initialized
INFO - 2018-10-30 07:19:14 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:19:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:19:14 --> Controller Class Initialized
INFO - 2018-10-30 07:19:14 --> Model "Item_model" initialized
INFO - 2018-10-30 07:19:14 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:19:14 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:19:14 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:19:14 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:19:14 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 07:19:14 --> Final output sent to browser
DEBUG - 2018-10-30 07:19:14 --> Total execution time: 0.9107
INFO - 2018-10-30 07:19:27 --> Config Class Initialized
INFO - 2018-10-30 07:19:27 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:19:27 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:19:27 --> Utf8 Class Initialized
INFO - 2018-10-30 07:19:27 --> URI Class Initialized
INFO - 2018-10-30 07:19:27 --> Router Class Initialized
INFO - 2018-10-30 07:19:27 --> Output Class Initialized
INFO - 2018-10-30 07:19:27 --> Security Class Initialized
DEBUG - 2018-10-30 07:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:19:27 --> Input Class Initialized
INFO - 2018-10-30 07:19:27 --> Language Class Initialized
INFO - 2018-10-30 07:19:27 --> Loader Class Initialized
INFO - 2018-10-30 07:19:27 --> Helper loaded: url_helper
INFO - 2018-10-30 07:19:27 --> Database Driver Class Initialized
INFO - 2018-10-30 07:19:27 --> Helper loaded: form_helper
INFO - 2018-10-30 07:19:27 --> Form Validation Class Initialized
INFO - 2018-10-30 07:19:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:19:27 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:19:27 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:19:27 --> Email Class Initialized
INFO - 2018-10-30 07:19:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:19:28 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:19:28 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:19:28 --> Helper loaded: date_helper
INFO - 2018-10-30 07:19:28 --> Database Driver Class Initialized
INFO - 2018-10-30 07:19:28 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:19:28 --> Controller Class Initialized
INFO - 2018-10-30 07:19:28 --> Model "Item_model" initialized
INFO - 2018-10-30 07:19:28 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:19:28 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:19:28 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:19:28 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:19:28 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 07:19:28 --> Final output sent to browser
DEBUG - 2018-10-30 07:19:28 --> Total execution time: 0.8792
INFO - 2018-10-30 07:19:28 --> Config Class Initialized
INFO - 2018-10-30 07:19:28 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:19:28 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:19:28 --> Utf8 Class Initialized
INFO - 2018-10-30 07:19:28 --> URI Class Initialized
INFO - 2018-10-30 07:19:28 --> Router Class Initialized
INFO - 2018-10-30 07:19:28 --> Output Class Initialized
INFO - 2018-10-30 07:19:28 --> Security Class Initialized
DEBUG - 2018-10-30 07:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:19:28 --> Input Class Initialized
INFO - 2018-10-30 07:19:28 --> Language Class Initialized
ERROR - 2018-10-30 07:19:28 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:19:30 --> Config Class Initialized
INFO - 2018-10-30 07:19:30 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:19:30 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:19:30 --> Utf8 Class Initialized
INFO - 2018-10-30 07:19:30 --> URI Class Initialized
INFO - 2018-10-30 07:19:30 --> Router Class Initialized
INFO - 2018-10-30 07:19:30 --> Output Class Initialized
INFO - 2018-10-30 07:19:30 --> Security Class Initialized
DEBUG - 2018-10-30 07:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:19:30 --> Input Class Initialized
INFO - 2018-10-30 07:19:30 --> Language Class Initialized
INFO - 2018-10-30 07:19:30 --> Loader Class Initialized
INFO - 2018-10-30 07:19:30 --> Helper loaded: url_helper
INFO - 2018-10-30 07:19:30 --> Database Driver Class Initialized
INFO - 2018-10-30 07:19:30 --> Helper loaded: form_helper
INFO - 2018-10-30 07:19:30 --> Form Validation Class Initialized
INFO - 2018-10-30 07:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:19:30 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:19:30 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:19:30 --> Email Class Initialized
INFO - 2018-10-30 07:19:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:19:30 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:19:30 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:19:30 --> Helper loaded: date_helper
INFO - 2018-10-30 07:19:30 --> Database Driver Class Initialized
INFO - 2018-10-30 07:19:30 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:19:31 --> Controller Class Initialized
INFO - 2018-10-30 07:19:31 --> Model "Item_model" initialized
INFO - 2018-10-30 07:19:31 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:19:31 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:19:31 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:19:31 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:35:55 --> Config Class Initialized
INFO - 2018-10-30 07:35:55 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:35:55 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:35:55 --> Utf8 Class Initialized
INFO - 2018-10-30 07:35:55 --> URI Class Initialized
INFO - 2018-10-30 07:35:55 --> Router Class Initialized
INFO - 2018-10-30 07:35:55 --> Output Class Initialized
INFO - 2018-10-30 07:35:55 --> Security Class Initialized
DEBUG - 2018-10-30 07:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:35:55 --> Input Class Initialized
INFO - 2018-10-30 07:35:55 --> Language Class Initialized
INFO - 2018-10-30 07:35:55 --> Loader Class Initialized
INFO - 2018-10-30 07:35:55 --> Helper loaded: url_helper
INFO - 2018-10-30 07:35:55 --> Database Driver Class Initialized
INFO - 2018-10-30 07:35:55 --> Helper loaded: form_helper
INFO - 2018-10-30 07:35:55 --> Form Validation Class Initialized
INFO - 2018-10-30 07:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:35:55 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:35:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:35:55 --> Email Class Initialized
INFO - 2018-10-30 07:35:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:35:55 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:35:55 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:35:55 --> Helper loaded: date_helper
INFO - 2018-10-30 07:35:55 --> Database Driver Class Initialized
INFO - 2018-10-30 07:35:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:35:55 --> Controller Class Initialized
INFO - 2018-10-30 07:35:55 --> Model "Item_model" initialized
INFO - 2018-10-30 07:35:55 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:35:56 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:35:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:35:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:35:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 07:35:56 --> Final output sent to browser
INFO - 2018-10-30 07:35:56 --> Config Class Initialized
DEBUG - 2018-10-30 07:35:56 --> Total execution time: 0.8813
INFO - 2018-10-30 07:35:56 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:35:56 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:35:56 --> Utf8 Class Initialized
INFO - 2018-10-30 07:35:56 --> URI Class Initialized
INFO - 2018-10-30 07:35:56 --> Router Class Initialized
INFO - 2018-10-30 07:35:56 --> Output Class Initialized
INFO - 2018-10-30 07:35:56 --> Security Class Initialized
DEBUG - 2018-10-30 07:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:35:56 --> Input Class Initialized
INFO - 2018-10-30 07:35:56 --> Language Class Initialized
INFO - 2018-10-30 07:35:56 --> Loader Class Initialized
INFO - 2018-10-30 07:35:56 --> Helper loaded: url_helper
INFO - 2018-10-30 07:35:56 --> Database Driver Class Initialized
INFO - 2018-10-30 07:35:56 --> Helper loaded: form_helper
INFO - 2018-10-30 07:35:56 --> Form Validation Class Initialized
INFO - 2018-10-30 07:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:35:56 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:35:56 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:35:56 --> Email Class Initialized
INFO - 2018-10-30 07:35:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:35:56 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:35:56 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:35:56 --> Helper loaded: date_helper
INFO - 2018-10-30 07:35:56 --> Database Driver Class Initialized
INFO - 2018-10-30 07:35:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:35:56 --> Controller Class Initialized
INFO - 2018-10-30 07:35:56 --> Model "Item_model" initialized
INFO - 2018-10-30 07:35:56 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:35:56 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:35:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:35:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:35:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 07:35:56 --> Final output sent to browser
DEBUG - 2018-10-30 07:35:56 --> Total execution time: 0.7965
INFO - 2018-10-30 07:35:56 --> Config Class Initialized
INFO - 2018-10-30 07:35:56 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:35:56 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:35:57 --> Utf8 Class Initialized
INFO - 2018-10-30 07:35:57 --> URI Class Initialized
INFO - 2018-10-30 07:35:57 --> Router Class Initialized
INFO - 2018-10-30 07:35:57 --> Output Class Initialized
INFO - 2018-10-30 07:35:57 --> Security Class Initialized
DEBUG - 2018-10-30 07:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:35:57 --> Input Class Initialized
INFO - 2018-10-30 07:35:57 --> Language Class Initialized
ERROR - 2018-10-30 07:35:57 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:36:48 --> Config Class Initialized
INFO - 2018-10-30 07:36:48 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:36:48 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:36:48 --> Utf8 Class Initialized
INFO - 2018-10-30 07:36:48 --> URI Class Initialized
INFO - 2018-10-30 07:36:48 --> Router Class Initialized
INFO - 2018-10-30 07:36:48 --> Output Class Initialized
INFO - 2018-10-30 07:36:48 --> Security Class Initialized
DEBUG - 2018-10-30 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:36:48 --> Input Class Initialized
INFO - 2018-10-30 07:36:48 --> Language Class Initialized
INFO - 2018-10-30 07:36:48 --> Loader Class Initialized
INFO - 2018-10-30 07:36:48 --> Helper loaded: url_helper
INFO - 2018-10-30 07:36:48 --> Database Driver Class Initialized
INFO - 2018-10-30 07:36:48 --> Helper loaded: form_helper
INFO - 2018-10-30 07:36:48 --> Form Validation Class Initialized
INFO - 2018-10-30 07:36:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:36:48 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:36:48 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:36:48 --> Email Class Initialized
INFO - 2018-10-30 07:36:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:36:48 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:36:48 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:36:48 --> Helper loaded: date_helper
INFO - 2018-10-30 07:36:48 --> Database Driver Class Initialized
INFO - 2018-10-30 07:36:48 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:36:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:36:48 --> Controller Class Initialized
INFO - 2018-10-30 07:36:48 --> Model "Item_model" initialized
INFO - 2018-10-30 07:36:48 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:36:48 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:36:48 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:36:48 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:36:48 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 07:36:48 --> Final output sent to browser
INFO - 2018-10-30 07:36:48 --> Config Class Initialized
DEBUG - 2018-10-30 07:36:48 --> Total execution time: 0.8858
INFO - 2018-10-30 07:36:48 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:36:49 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:36:49 --> Utf8 Class Initialized
INFO - 2018-10-30 07:36:49 --> URI Class Initialized
INFO - 2018-10-30 07:36:49 --> Router Class Initialized
INFO - 2018-10-30 07:36:49 --> Output Class Initialized
INFO - 2018-10-30 07:36:49 --> Security Class Initialized
DEBUG - 2018-10-30 07:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:36:49 --> Input Class Initialized
INFO - 2018-10-30 07:36:49 --> Language Class Initialized
ERROR - 2018-10-30 07:36:49 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:36:50 --> Config Class Initialized
INFO - 2018-10-30 07:36:50 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:36:50 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:36:50 --> Utf8 Class Initialized
INFO - 2018-10-30 07:36:50 --> URI Class Initialized
INFO - 2018-10-30 07:36:50 --> Router Class Initialized
INFO - 2018-10-30 07:36:50 --> Output Class Initialized
INFO - 2018-10-30 07:36:50 --> Security Class Initialized
DEBUG - 2018-10-30 07:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:36:50 --> Input Class Initialized
INFO - 2018-10-30 07:36:50 --> Language Class Initialized
INFO - 2018-10-30 07:36:50 --> Loader Class Initialized
INFO - 2018-10-30 07:36:50 --> Helper loaded: url_helper
INFO - 2018-10-30 07:36:50 --> Database Driver Class Initialized
INFO - 2018-10-30 07:36:51 --> Helper loaded: form_helper
INFO - 2018-10-30 07:36:51 --> Form Validation Class Initialized
INFO - 2018-10-30 07:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:36:51 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:36:51 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:36:51 --> Email Class Initialized
INFO - 2018-10-30 07:36:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:36:51 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:36:51 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:36:51 --> Helper loaded: date_helper
INFO - 2018-10-30 07:36:51 --> Database Driver Class Initialized
INFO - 2018-10-30 07:36:51 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:36:51 --> Controller Class Initialized
INFO - 2018-10-30 07:36:51 --> Model "Item_model" initialized
INFO - 2018-10-30 07:36:51 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:36:51 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:36:51 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:36:51 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:36:51 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 07:36:51 --> Final output sent to browser
DEBUG - 2018-10-30 07:36:51 --> Total execution time: 0.8710
INFO - 2018-10-30 07:36:51 --> Config Class Initialized
INFO - 2018-10-30 07:36:51 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:36:51 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:36:51 --> Utf8 Class Initialized
INFO - 2018-10-30 07:36:51 --> URI Class Initialized
INFO - 2018-10-30 07:36:51 --> Router Class Initialized
INFO - 2018-10-30 07:36:51 --> Output Class Initialized
INFO - 2018-10-30 07:36:51 --> Security Class Initialized
DEBUG - 2018-10-30 07:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:36:51 --> Input Class Initialized
INFO - 2018-10-30 07:36:51 --> Language Class Initialized
ERROR - 2018-10-30 07:36:51 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:36:56 --> Config Class Initialized
INFO - 2018-10-30 07:36:56 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:36:56 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:36:56 --> Utf8 Class Initialized
INFO - 2018-10-30 07:36:56 --> URI Class Initialized
INFO - 2018-10-30 07:36:56 --> Router Class Initialized
INFO - 2018-10-30 07:36:56 --> Output Class Initialized
INFO - 2018-10-30 07:36:56 --> Security Class Initialized
DEBUG - 2018-10-30 07:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:36:56 --> Input Class Initialized
INFO - 2018-10-30 07:36:56 --> Language Class Initialized
INFO - 2018-10-30 07:36:56 --> Loader Class Initialized
INFO - 2018-10-30 07:36:56 --> Helper loaded: url_helper
INFO - 2018-10-30 07:36:56 --> Database Driver Class Initialized
INFO - 2018-10-30 07:36:56 --> Helper loaded: form_helper
INFO - 2018-10-30 07:36:56 --> Form Validation Class Initialized
INFO - 2018-10-30 07:36:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:36:56 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:36:56 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:36:56 --> Email Class Initialized
INFO - 2018-10-30 07:36:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:36:56 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:36:56 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:36:56 --> Helper loaded: date_helper
INFO - 2018-10-30 07:36:56 --> Database Driver Class Initialized
INFO - 2018-10-30 07:36:56 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:36:56 --> Controller Class Initialized
INFO - 2018-10-30 07:36:56 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:36:56 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:36:56 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 07:36:56 --> Final output sent to browser
DEBUG - 2018-10-30 07:36:56 --> Total execution time: 0.7836
INFO - 2018-10-30 07:37:01 --> Config Class Initialized
INFO - 2018-10-30 07:37:01 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:37:01 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:37:01 --> Utf8 Class Initialized
INFO - 2018-10-30 07:37:01 --> URI Class Initialized
INFO - 2018-10-30 07:37:01 --> Router Class Initialized
INFO - 2018-10-30 07:37:01 --> Output Class Initialized
INFO - 2018-10-30 07:37:01 --> Security Class Initialized
DEBUG - 2018-10-30 07:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:37:01 --> Input Class Initialized
INFO - 2018-10-30 07:37:02 --> Language Class Initialized
INFO - 2018-10-30 07:37:02 --> Loader Class Initialized
INFO - 2018-10-30 07:37:02 --> Helper loaded: url_helper
INFO - 2018-10-30 07:37:02 --> Database Driver Class Initialized
INFO - 2018-10-30 07:37:02 --> Helper loaded: form_helper
INFO - 2018-10-30 07:37:02 --> Form Validation Class Initialized
INFO - 2018-10-30 07:37:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:37:02 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:37:02 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:37:02 --> Email Class Initialized
INFO - 2018-10-30 07:37:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:37:02 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:37:02 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:37:02 --> Helper loaded: date_helper
INFO - 2018-10-30 07:37:02 --> Database Driver Class Initialized
INFO - 2018-10-30 07:37:02 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:37:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:37:02 --> Controller Class Initialized
INFO - 2018-10-30 07:37:02 --> Model "Item_model" initialized
INFO - 2018-10-30 07:37:02 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:37:02 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:37:02 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:37:02 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:37:02 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-30 07:37:02 --> Final output sent to browser
DEBUG - 2018-10-30 07:37:02 --> Total execution time: 0.8650
INFO - 2018-10-30 07:37:05 --> Config Class Initialized
INFO - 2018-10-30 07:37:05 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:37:05 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:37:05 --> Utf8 Class Initialized
INFO - 2018-10-30 07:37:05 --> URI Class Initialized
INFO - 2018-10-30 07:37:05 --> Router Class Initialized
INFO - 2018-10-30 07:37:05 --> Output Class Initialized
INFO - 2018-10-30 07:37:05 --> Security Class Initialized
DEBUG - 2018-10-30 07:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:37:05 --> Input Class Initialized
INFO - 2018-10-30 07:37:05 --> Language Class Initialized
INFO - 2018-10-30 07:37:05 --> Loader Class Initialized
INFO - 2018-10-30 07:37:05 --> Helper loaded: url_helper
INFO - 2018-10-30 07:37:05 --> Database Driver Class Initialized
INFO - 2018-10-30 07:37:05 --> Helper loaded: form_helper
INFO - 2018-10-30 07:37:05 --> Form Validation Class Initialized
INFO - 2018-10-30 07:37:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:37:05 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:37:05 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:37:05 --> Email Class Initialized
INFO - 2018-10-30 07:37:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:37:05 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:37:05 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:37:05 --> Helper loaded: date_helper
INFO - 2018-10-30 07:37:05 --> Database Driver Class Initialized
INFO - 2018-10-30 07:37:05 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:37:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:37:05 --> Controller Class Initialized
INFO - 2018-10-30 07:37:05 --> Model "Item_model" initialized
INFO - 2018-10-30 07:37:05 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:37:05 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:37:06 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:37:06 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:37:06 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-30 07:37:06 --> Final output sent to browser
INFO - 2018-10-30 07:37:06 --> Config Class Initialized
INFO - 2018-10-30 07:37:06 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:37:06 --> Total execution time: 0.8592
DEBUG - 2018-10-30 07:37:06 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:37:06 --> Utf8 Class Initialized
INFO - 2018-10-30 07:37:06 --> URI Class Initialized
INFO - 2018-10-30 07:37:06 --> Router Class Initialized
INFO - 2018-10-30 07:37:06 --> Output Class Initialized
INFO - 2018-10-30 07:37:06 --> Security Class Initialized
DEBUG - 2018-10-30 07:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:37:06 --> Input Class Initialized
INFO - 2018-10-30 07:37:06 --> Language Class Initialized
ERROR - 2018-10-30 07:37:06 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:37:07 --> Config Class Initialized
INFO - 2018-10-30 07:37:07 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:37:07 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:37:07 --> Utf8 Class Initialized
INFO - 2018-10-30 07:37:07 --> URI Class Initialized
INFO - 2018-10-30 07:37:07 --> Router Class Initialized
INFO - 2018-10-30 07:37:07 --> Output Class Initialized
INFO - 2018-10-30 07:37:07 --> Security Class Initialized
DEBUG - 2018-10-30 07:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:37:07 --> Input Class Initialized
INFO - 2018-10-30 07:37:07 --> Language Class Initialized
INFO - 2018-10-30 07:37:07 --> Loader Class Initialized
INFO - 2018-10-30 07:37:07 --> Helper loaded: url_helper
INFO - 2018-10-30 07:37:07 --> Database Driver Class Initialized
INFO - 2018-10-30 07:37:07 --> Helper loaded: form_helper
INFO - 2018-10-30 07:37:07 --> Form Validation Class Initialized
INFO - 2018-10-30 07:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:37:07 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:37:07 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:37:07 --> Email Class Initialized
INFO - 2018-10-30 07:37:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:37:08 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:37:08 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:37:08 --> Helper loaded: date_helper
INFO - 2018-10-30 07:37:08 --> Database Driver Class Initialized
INFO - 2018-10-30 07:37:08 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:37:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:37:08 --> Controller Class Initialized
INFO - 2018-10-30 07:37:08 --> Model "Item_model" initialized
INFO - 2018-10-30 07:37:08 --> Model "Jenis_model" initialized
INFO - 2018-10-30 07:37:08 --> Model "Vendor_model" initialized
INFO - 2018-10-30 07:37:08 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:37:08 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:37:08 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/nota.php
INFO - 2018-10-30 07:37:08 --> Final output sent to browser
DEBUG - 2018-10-30 07:37:08 --> Total execution time: 0.8616
INFO - 2018-10-30 07:37:08 --> Config Class Initialized
INFO - 2018-10-30 07:37:08 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:37:08 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:37:08 --> Utf8 Class Initialized
INFO - 2018-10-30 07:37:08 --> URI Class Initialized
INFO - 2018-10-30 07:37:08 --> Router Class Initialized
INFO - 2018-10-30 07:37:08 --> Output Class Initialized
INFO - 2018-10-30 07:37:08 --> Security Class Initialized
DEBUG - 2018-10-30 07:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:37:08 --> Input Class Initialized
INFO - 2018-10-30 07:37:08 --> Language Class Initialized
ERROR - 2018-10-30 07:37:08 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-30 07:37:13 --> Config Class Initialized
INFO - 2018-10-30 07:37:13 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:37:13 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:37:13 --> Utf8 Class Initialized
INFO - 2018-10-30 07:37:13 --> URI Class Initialized
INFO - 2018-10-30 07:37:13 --> Router Class Initialized
INFO - 2018-10-30 07:37:13 --> Output Class Initialized
INFO - 2018-10-30 07:37:13 --> Security Class Initialized
DEBUG - 2018-10-30 07:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:37:14 --> Input Class Initialized
INFO - 2018-10-30 07:37:14 --> Language Class Initialized
INFO - 2018-10-30 07:37:14 --> Loader Class Initialized
INFO - 2018-10-30 07:37:14 --> Helper loaded: url_helper
INFO - 2018-10-30 07:37:14 --> Database Driver Class Initialized
INFO - 2018-10-30 07:37:14 --> Helper loaded: form_helper
INFO - 2018-10-30 07:37:14 --> Form Validation Class Initialized
INFO - 2018-10-30 07:37:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:37:14 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:37:14 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:37:14 --> Email Class Initialized
INFO - 2018-10-30 07:37:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:37:14 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:37:14 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:37:14 --> Helper loaded: date_helper
INFO - 2018-10-30 07:37:14 --> Database Driver Class Initialized
INFO - 2018-10-30 07:37:14 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:37:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:37:14 --> Controller Class Initialized
INFO - 2018-10-30 07:37:14 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:37:14 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:37:14 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 07:37:14 --> Final output sent to browser
DEBUG - 2018-10-30 07:37:14 --> Total execution time: 0.7904
INFO - 2018-10-30 07:38:22 --> Config Class Initialized
INFO - 2018-10-30 07:38:22 --> Hooks Class Initialized
DEBUG - 2018-10-30 07:38:22 --> UTF-8 Support Enabled
INFO - 2018-10-30 07:38:22 --> Utf8 Class Initialized
INFO - 2018-10-30 07:38:22 --> URI Class Initialized
INFO - 2018-10-30 07:38:22 --> Router Class Initialized
INFO - 2018-10-30 07:38:22 --> Output Class Initialized
INFO - 2018-10-30 07:38:22 --> Security Class Initialized
DEBUG - 2018-10-30 07:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-30 07:38:23 --> Input Class Initialized
INFO - 2018-10-30 07:38:23 --> Language Class Initialized
INFO - 2018-10-30 07:38:23 --> Loader Class Initialized
INFO - 2018-10-30 07:38:23 --> Helper loaded: url_helper
INFO - 2018-10-30 07:38:23 --> Database Driver Class Initialized
INFO - 2018-10-30 07:38:23 --> Helper loaded: form_helper
INFO - 2018-10-30 07:38:23 --> Form Validation Class Initialized
INFO - 2018-10-30 07:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-30 07:38:23 --> Pagination Class Initialized
DEBUG - 2018-10-30 07:38:23 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-30 07:38:23 --> Email Class Initialized
INFO - 2018-10-30 07:38:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-30 07:38:23 --> Helper loaded: cookie_helper
INFO - 2018-10-30 07:38:23 --> Helper loaded: language_helper
DEBUG - 2018-10-30 07:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-30 07:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-30 07:38:23 --> Helper loaded: date_helper
INFO - 2018-10-30 07:38:23 --> Database Driver Class Initialized
INFO - 2018-10-30 07:38:23 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-30 07:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-30 07:38:23 --> Controller Class Initialized
INFO - 2018-10-30 07:38:23 --> Model "Nota_model" initialized
INFO - 2018-10-30 07:38:23 --> Model "Notadetail_model" initialized
INFO - 2018-10-30 07:38:23 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\laporan/index.php
INFO - 2018-10-30 07:38:23 --> Final output sent to browser
DEBUG - 2018-10-30 07:38:23 --> Total execution time: 0.7697
