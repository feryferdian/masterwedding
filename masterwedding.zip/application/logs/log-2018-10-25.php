<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-25 05:25:34 --> Config Class Initialized
INFO - 2018-10-25 05:25:34 --> Hooks Class Initialized
DEBUG - 2018-10-25 05:25:34 --> UTF-8 Support Enabled
INFO - 2018-10-25 05:25:34 --> Utf8 Class Initialized
INFO - 2018-10-25 05:25:34 --> URI Class Initialized
DEBUG - 2018-10-25 05:25:34 --> No URI present. Default controller set.
INFO - 2018-10-25 05:25:34 --> Router Class Initialized
INFO - 2018-10-25 05:25:34 --> Output Class Initialized
INFO - 2018-10-25 05:25:34 --> Security Class Initialized
DEBUG - 2018-10-25 05:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 05:25:34 --> Input Class Initialized
INFO - 2018-10-25 05:25:34 --> Language Class Initialized
INFO - 2018-10-25 05:25:34 --> Loader Class Initialized
INFO - 2018-10-25 05:25:34 --> Helper loaded: url_helper
INFO - 2018-10-25 05:25:34 --> Database Driver Class Initialized
INFO - 2018-10-25 05:25:34 --> Helper loaded: form_helper
INFO - 2018-10-25 05:25:34 --> Form Validation Class Initialized
INFO - 2018-10-25 05:25:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 05:25:34 --> Pagination Class Initialized
DEBUG - 2018-10-25 05:25:35 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 05:25:35 --> Email Class Initialized
INFO - 2018-10-25 05:25:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 05:25:35 --> Helper loaded: cookie_helper
INFO - 2018-10-25 05:25:35 --> Helper loaded: language_helper
DEBUG - 2018-10-25 05:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 05:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 05:25:35 --> Helper loaded: date_helper
INFO - 2018-10-25 05:25:35 --> Database Driver Class Initialized
INFO - 2018-10-25 05:25:35 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 05:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 05:25:35 --> Controller Class Initialized
INFO - 2018-10-25 05:25:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-25 05:25:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\index.php
INFO - 2018-10-25 05:25:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-10-25 05:25:35 --> Final output sent to browser
DEBUG - 2018-10-25 05:25:35 --> Total execution time: 1.0345
INFO - 2018-10-25 05:43:57 --> Config Class Initialized
INFO - 2018-10-25 05:43:57 --> Hooks Class Initialized
DEBUG - 2018-10-25 05:43:57 --> UTF-8 Support Enabled
INFO - 2018-10-25 05:43:57 --> Utf8 Class Initialized
INFO - 2018-10-25 05:43:57 --> URI Class Initialized
DEBUG - 2018-10-25 05:43:57 --> No URI present. Default controller set.
INFO - 2018-10-25 05:43:57 --> Router Class Initialized
INFO - 2018-10-25 05:43:57 --> Output Class Initialized
INFO - 2018-10-25 05:43:57 --> Security Class Initialized
DEBUG - 2018-10-25 05:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 05:43:57 --> Input Class Initialized
INFO - 2018-10-25 05:43:57 --> Language Class Initialized
INFO - 2018-10-25 05:43:57 --> Loader Class Initialized
INFO - 2018-10-25 05:43:57 --> Helper loaded: url_helper
INFO - 2018-10-25 05:43:57 --> Database Driver Class Initialized
INFO - 2018-10-25 05:43:57 --> Helper loaded: form_helper
INFO - 2018-10-25 05:43:58 --> Form Validation Class Initialized
INFO - 2018-10-25 05:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 05:43:58 --> Pagination Class Initialized
DEBUG - 2018-10-25 05:43:58 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 05:43:58 --> Email Class Initialized
INFO - 2018-10-25 05:43:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 05:43:58 --> Helper loaded: cookie_helper
INFO - 2018-10-25 05:43:58 --> Helper loaded: language_helper
DEBUG - 2018-10-25 05:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 05:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 05:43:58 --> Helper loaded: date_helper
INFO - 2018-10-25 05:43:58 --> Database Driver Class Initialized
INFO - 2018-10-25 05:43:58 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 05:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 05:43:58 --> Controller Class Initialized
INFO - 2018-10-25 05:43:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-25 05:43:58 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\index.php
INFO - 2018-10-25 05:43:58 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-10-25 05:43:58 --> Final output sent to browser
DEBUG - 2018-10-25 05:43:58 --> Total execution time: 0.3581
INFO - 2018-10-25 05:43:58 --> Config Class Initialized
INFO - 2018-10-25 05:43:58 --> Config Class Initialized
INFO - 2018-10-25 05:43:58 --> Config Class Initialized
INFO - 2018-10-25 05:43:58 --> Hooks Class Initialized
INFO - 2018-10-25 05:43:58 --> Hooks Class Initialized
INFO - 2018-10-25 05:43:58 --> Hooks Class Initialized
DEBUG - 2018-10-25 05:43:58 --> UTF-8 Support Enabled
DEBUG - 2018-10-25 05:43:58 --> UTF-8 Support Enabled
DEBUG - 2018-10-25 05:43:58 --> UTF-8 Support Enabled
INFO - 2018-10-25 05:43:58 --> Utf8 Class Initialized
INFO - 2018-10-25 05:43:58 --> Utf8 Class Initialized
INFO - 2018-10-25 05:43:58 --> Utf8 Class Initialized
INFO - 2018-10-25 05:43:58 --> URI Class Initialized
INFO - 2018-10-25 05:43:58 --> URI Class Initialized
INFO - 2018-10-25 05:43:58 --> URI Class Initialized
INFO - 2018-10-25 05:43:58 --> Router Class Initialized
INFO - 2018-10-25 05:43:58 --> Router Class Initialized
INFO - 2018-10-25 05:43:58 --> Router Class Initialized
INFO - 2018-10-25 05:43:58 --> Output Class Initialized
INFO - 2018-10-25 05:43:58 --> Output Class Initialized
INFO - 2018-10-25 05:43:58 --> Output Class Initialized
INFO - 2018-10-25 05:43:58 --> Security Class Initialized
INFO - 2018-10-25 05:43:58 --> Security Class Initialized
INFO - 2018-10-25 05:43:58 --> Security Class Initialized
DEBUG - 2018-10-25 05:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-25 05:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-25 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 05:43:58 --> Input Class Initialized
INFO - 2018-10-25 05:43:58 --> Input Class Initialized
INFO - 2018-10-25 05:43:58 --> Input Class Initialized
INFO - 2018-10-25 05:43:58 --> Language Class Initialized
INFO - 2018-10-25 05:43:58 --> Language Class Initialized
INFO - 2018-10-25 05:43:58 --> Language Class Initialized
ERROR - 2018-10-25 05:43:58 --> 404 Page Not Found: Application/views
ERROR - 2018-10-25 05:43:58 --> 404 Page Not Found: Application/views
ERROR - 2018-10-25 05:43:58 --> 404 Page Not Found: Application/views
INFO - 2018-10-25 05:44:01 --> Config Class Initialized
INFO - 2018-10-25 05:44:01 --> Hooks Class Initialized
DEBUG - 2018-10-25 05:44:01 --> UTF-8 Support Enabled
INFO - 2018-10-25 05:44:01 --> Utf8 Class Initialized
INFO - 2018-10-25 05:44:01 --> URI Class Initialized
INFO - 2018-10-25 05:44:01 --> Router Class Initialized
INFO - 2018-10-25 05:44:01 --> Output Class Initialized
INFO - 2018-10-25 05:44:01 --> Security Class Initialized
DEBUG - 2018-10-25 05:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 05:44:01 --> Input Class Initialized
INFO - 2018-10-25 05:44:01 --> Language Class Initialized
INFO - 2018-10-25 05:44:01 --> Loader Class Initialized
INFO - 2018-10-25 05:44:01 --> Helper loaded: url_helper
INFO - 2018-10-25 05:44:01 --> Database Driver Class Initialized
INFO - 2018-10-25 05:44:01 --> Helper loaded: form_helper
INFO - 2018-10-25 05:44:01 --> Form Validation Class Initialized
INFO - 2018-10-25 05:44:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 05:44:01 --> Pagination Class Initialized
DEBUG - 2018-10-25 05:44:01 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 05:44:01 --> Email Class Initialized
INFO - 2018-10-25 05:44:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 05:44:01 --> Helper loaded: cookie_helper
INFO - 2018-10-25 05:44:01 --> Helper loaded: language_helper
DEBUG - 2018-10-25 05:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 05:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 05:44:01 --> Helper loaded: date_helper
INFO - 2018-10-25 05:44:01 --> Database Driver Class Initialized
INFO - 2018-10-25 05:44:01 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 05:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 05:44:01 --> Controller Class Initialized
INFO - 2018-10-25 05:44:01 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-25 05:44:01 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\login.php
INFO - 2018-10-25 05:44:01 --> Final output sent to browser
DEBUG - 2018-10-25 05:44:01 --> Total execution time: 0.3843
INFO - 2018-10-25 05:44:01 --> Config Class Initialized
INFO - 2018-10-25 05:44:01 --> Config Class Initialized
INFO - 2018-10-25 05:44:01 --> Config Class Initialized
INFO - 2018-10-25 05:44:01 --> Hooks Class Initialized
INFO - 2018-10-25 05:44:01 --> Hooks Class Initialized
INFO - 2018-10-25 05:44:01 --> Hooks Class Initialized
DEBUG - 2018-10-25 05:44:01 --> UTF-8 Support Enabled
DEBUG - 2018-10-25 05:44:01 --> UTF-8 Support Enabled
DEBUG - 2018-10-25 05:44:01 --> UTF-8 Support Enabled
INFO - 2018-10-25 05:44:01 --> Utf8 Class Initialized
INFO - 2018-10-25 05:44:01 --> Utf8 Class Initialized
INFO - 2018-10-25 05:44:01 --> Utf8 Class Initialized
INFO - 2018-10-25 05:44:01 --> URI Class Initialized
INFO - 2018-10-25 05:44:01 --> URI Class Initialized
INFO - 2018-10-25 05:44:01 --> URI Class Initialized
INFO - 2018-10-25 05:44:01 --> Router Class Initialized
INFO - 2018-10-25 05:44:01 --> Router Class Initialized
INFO - 2018-10-25 05:44:01 --> Router Class Initialized
INFO - 2018-10-25 05:44:01 --> Output Class Initialized
INFO - 2018-10-25 05:44:01 --> Output Class Initialized
INFO - 2018-10-25 05:44:01 --> Output Class Initialized
INFO - 2018-10-25 05:44:01 --> Security Class Initialized
INFO - 2018-10-25 05:44:01 --> Security Class Initialized
INFO - 2018-10-25 05:44:01 --> Security Class Initialized
DEBUG - 2018-10-25 05:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-25 05:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-25 05:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 05:44:01 --> Input Class Initialized
INFO - 2018-10-25 05:44:01 --> Input Class Initialized
INFO - 2018-10-25 05:44:01 --> Input Class Initialized
INFO - 2018-10-25 05:44:01 --> Language Class Initialized
INFO - 2018-10-25 05:44:01 --> Language Class Initialized
INFO - 2018-10-25 05:44:01 --> Language Class Initialized
ERROR - 2018-10-25 05:44:01 --> 404 Page Not Found: Application/views
ERROR - 2018-10-25 05:44:01 --> 404 Page Not Found: Application/views
ERROR - 2018-10-25 05:44:01 --> 404 Page Not Found: Application/views
INFO - 2018-10-25 05:44:09 --> Config Class Initialized
INFO - 2018-10-25 05:44:09 --> Hooks Class Initialized
DEBUG - 2018-10-25 05:44:09 --> UTF-8 Support Enabled
INFO - 2018-10-25 05:44:09 --> Utf8 Class Initialized
INFO - 2018-10-25 05:44:09 --> URI Class Initialized
INFO - 2018-10-25 05:44:09 --> Router Class Initialized
INFO - 2018-10-25 05:44:09 --> Output Class Initialized
INFO - 2018-10-25 05:44:09 --> Security Class Initialized
DEBUG - 2018-10-25 05:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 05:44:09 --> Input Class Initialized
INFO - 2018-10-25 05:44:09 --> Language Class Initialized
INFO - 2018-10-25 05:44:09 --> Loader Class Initialized
INFO - 2018-10-25 05:44:09 --> Helper loaded: url_helper
INFO - 2018-10-25 05:44:09 --> Database Driver Class Initialized
INFO - 2018-10-25 05:44:09 --> Helper loaded: form_helper
INFO - 2018-10-25 05:44:09 --> Form Validation Class Initialized
INFO - 2018-10-25 05:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 05:44:09 --> Pagination Class Initialized
DEBUG - 2018-10-25 05:44:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 05:44:09 --> Email Class Initialized
INFO - 2018-10-25 05:44:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 05:44:09 --> Helper loaded: cookie_helper
INFO - 2018-10-25 05:44:09 --> Helper loaded: language_helper
DEBUG - 2018-10-25 05:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 05:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 05:44:09 --> Helper loaded: date_helper
INFO - 2018-10-25 05:44:09 --> Database Driver Class Initialized
INFO - 2018-10-25 05:44:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 05:44:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 05:44:09 --> Controller Class Initialized
INFO - 2018-10-25 05:44:09 --> Config Class Initialized
INFO - 2018-10-25 05:44:09 --> Hooks Class Initialized
DEBUG - 2018-10-25 05:44:09 --> UTF-8 Support Enabled
INFO - 2018-10-25 05:44:09 --> Utf8 Class Initialized
INFO - 2018-10-25 05:44:09 --> URI Class Initialized
INFO - 2018-10-25 05:44:09 --> Router Class Initialized
INFO - 2018-10-25 05:44:09 --> Output Class Initialized
INFO - 2018-10-25 05:44:09 --> Security Class Initialized
DEBUG - 2018-10-25 05:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 05:44:09 --> Input Class Initialized
INFO - 2018-10-25 05:44:09 --> Language Class Initialized
INFO - 2018-10-25 05:44:09 --> Loader Class Initialized
INFO - 2018-10-25 05:44:09 --> Helper loaded: url_helper
INFO - 2018-10-25 05:44:09 --> Database Driver Class Initialized
INFO - 2018-10-25 05:44:09 --> Helper loaded: form_helper
INFO - 2018-10-25 05:44:09 --> Form Validation Class Initialized
INFO - 2018-10-25 05:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 05:44:09 --> Pagination Class Initialized
DEBUG - 2018-10-25 05:44:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 05:44:09 --> Email Class Initialized
INFO - 2018-10-25 05:44:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 05:44:09 --> Helper loaded: cookie_helper
INFO - 2018-10-25 05:44:09 --> Helper loaded: language_helper
DEBUG - 2018-10-25 05:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 05:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 05:44:09 --> Helper loaded: date_helper
INFO - 2018-10-25 05:44:09 --> Database Driver Class Initialized
INFO - 2018-10-25 05:44:10 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 05:44:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 05:44:10 --> Controller Class Initialized
INFO - 2018-10-25 05:44:10 --> Model "Item_model" initialized
INFO - 2018-10-25 05:44:10 --> Model "Jenis_model" initialized
INFO - 2018-10-25 05:44:10 --> Model "Vendor_model" initialized
INFO - 2018-10-25 05:44:10 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-25 05:44:10 --> Final output sent to browser
DEBUG - 2018-10-25 05:44:10 --> Total execution time: 0.4616
INFO - 2018-10-25 05:44:10 --> Config Class Initialized
INFO - 2018-10-25 05:44:10 --> Hooks Class Initialized
DEBUG - 2018-10-25 05:44:10 --> UTF-8 Support Enabled
INFO - 2018-10-25 05:44:10 --> Utf8 Class Initialized
INFO - 2018-10-25 05:44:10 --> URI Class Initialized
INFO - 2018-10-25 05:44:10 --> Router Class Initialized
INFO - 2018-10-25 05:44:10 --> Output Class Initialized
INFO - 2018-10-25 05:44:10 --> Security Class Initialized
DEBUG - 2018-10-25 05:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 05:44:10 --> Input Class Initialized
INFO - 2018-10-25 05:44:10 --> Language Class Initialized
ERROR - 2018-10-25 05:44:10 --> 404 Page Not Found: Faviconico/index
INFO - 2018-10-25 07:09:35 --> Config Class Initialized
INFO - 2018-10-25 07:09:35 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:09:35 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:09:35 --> Utf8 Class Initialized
INFO - 2018-10-25 07:09:35 --> URI Class Initialized
DEBUG - 2018-10-25 07:09:35 --> No URI present. Default controller set.
INFO - 2018-10-25 07:09:35 --> Router Class Initialized
INFO - 2018-10-25 07:09:35 --> Output Class Initialized
INFO - 2018-10-25 07:09:35 --> Security Class Initialized
DEBUG - 2018-10-25 07:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:09:35 --> Input Class Initialized
INFO - 2018-10-25 07:09:35 --> Language Class Initialized
INFO - 2018-10-25 07:09:35 --> Loader Class Initialized
INFO - 2018-10-25 07:09:35 --> Helper loaded: url_helper
INFO - 2018-10-25 07:09:35 --> Database Driver Class Initialized
INFO - 2018-10-25 07:09:35 --> Helper loaded: form_helper
INFO - 2018-10-25 07:09:35 --> Form Validation Class Initialized
INFO - 2018-10-25 07:09:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:09:35 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:09:35 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:09:35 --> Email Class Initialized
INFO - 2018-10-25 07:09:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:09:35 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:09:35 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:09:35 --> Helper loaded: date_helper
INFO - 2018-10-25 07:09:35 --> Database Driver Class Initialized
INFO - 2018-10-25 07:09:35 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:09:35 --> Controller Class Initialized
INFO - 2018-10-25 07:09:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-25 07:09:35 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\index.php
INFO - 2018-10-25 07:09:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-10-25 07:09:35 --> Final output sent to browser
DEBUG - 2018-10-25 07:09:35 --> Total execution time: 0.5197
INFO - 2018-10-25 07:21:21 --> Config Class Initialized
INFO - 2018-10-25 07:21:21 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:21:21 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:21:21 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:21 --> URI Class Initialized
DEBUG - 2018-10-25 07:21:21 --> No URI present. Default controller set.
INFO - 2018-10-25 07:21:21 --> Router Class Initialized
INFO - 2018-10-25 07:21:21 --> Output Class Initialized
INFO - 2018-10-25 07:21:21 --> Security Class Initialized
DEBUG - 2018-10-25 07:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:21:21 --> Input Class Initialized
INFO - 2018-10-25 07:21:21 --> Language Class Initialized
INFO - 2018-10-25 07:21:21 --> Loader Class Initialized
INFO - 2018-10-25 07:21:21 --> Helper loaded: url_helper
INFO - 2018-10-25 07:21:21 --> Database Driver Class Initialized
INFO - 2018-10-25 07:21:21 --> Helper loaded: form_helper
INFO - 2018-10-25 07:21:21 --> Form Validation Class Initialized
INFO - 2018-10-25 07:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:21:21 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:21:21 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:21:21 --> Email Class Initialized
INFO - 2018-10-25 07:21:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:21:21 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:21:21 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:21:21 --> Helper loaded: date_helper
INFO - 2018-10-25 07:21:22 --> Database Driver Class Initialized
INFO - 2018-10-25 07:21:22 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:21:22 --> Controller Class Initialized
INFO - 2018-10-25 07:21:22 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-25 07:21:22 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\index.php
INFO - 2018-10-25 07:21:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2018-10-25 07:21:22 --> Final output sent to browser
DEBUG - 2018-10-25 07:21:22 --> Total execution time: 0.5138
INFO - 2018-10-25 07:21:22 --> Config Class Initialized
INFO - 2018-10-25 07:21:22 --> Config Class Initialized
INFO - 2018-10-25 07:21:22 --> Config Class Initialized
INFO - 2018-10-25 07:21:22 --> Hooks Class Initialized
INFO - 2018-10-25 07:21:22 --> Hooks Class Initialized
INFO - 2018-10-25 07:21:22 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:21:22 --> UTF-8 Support Enabled
DEBUG - 2018-10-25 07:21:22 --> UTF-8 Support Enabled
DEBUG - 2018-10-25 07:21:22 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:21:22 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:22 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:22 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:22 --> URI Class Initialized
INFO - 2018-10-25 07:21:22 --> URI Class Initialized
INFO - 2018-10-25 07:21:22 --> URI Class Initialized
INFO - 2018-10-25 07:21:22 --> Router Class Initialized
INFO - 2018-10-25 07:21:22 --> Router Class Initialized
INFO - 2018-10-25 07:21:22 --> Router Class Initialized
INFO - 2018-10-25 07:21:22 --> Output Class Initialized
INFO - 2018-10-25 07:21:22 --> Output Class Initialized
INFO - 2018-10-25 07:21:22 --> Output Class Initialized
INFO - 2018-10-25 07:21:22 --> Security Class Initialized
INFO - 2018-10-25 07:21:22 --> Security Class Initialized
INFO - 2018-10-25 07:21:22 --> Security Class Initialized
DEBUG - 2018-10-25 07:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-25 07:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-25 07:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:21:22 --> Input Class Initialized
INFO - 2018-10-25 07:21:22 --> Input Class Initialized
INFO - 2018-10-25 07:21:22 --> Input Class Initialized
INFO - 2018-10-25 07:21:22 --> Language Class Initialized
INFO - 2018-10-25 07:21:22 --> Language Class Initialized
INFO - 2018-10-25 07:21:22 --> Language Class Initialized
ERROR - 2018-10-25 07:21:22 --> 404 Page Not Found: Application/views
ERROR - 2018-10-25 07:21:22 --> 404 Page Not Found: Application/views
ERROR - 2018-10-25 07:21:22 --> 404 Page Not Found: Application/views
INFO - 2018-10-25 07:21:24 --> Config Class Initialized
INFO - 2018-10-25 07:21:24 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:21:24 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:21:24 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:24 --> URI Class Initialized
INFO - 2018-10-25 07:21:24 --> Router Class Initialized
INFO - 2018-10-25 07:21:24 --> Output Class Initialized
INFO - 2018-10-25 07:21:24 --> Security Class Initialized
DEBUG - 2018-10-25 07:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:21:24 --> Input Class Initialized
INFO - 2018-10-25 07:21:24 --> Language Class Initialized
INFO - 2018-10-25 07:21:24 --> Loader Class Initialized
INFO - 2018-10-25 07:21:24 --> Helper loaded: url_helper
INFO - 2018-10-25 07:21:24 --> Database Driver Class Initialized
INFO - 2018-10-25 07:21:24 --> Helper loaded: form_helper
INFO - 2018-10-25 07:21:24 --> Form Validation Class Initialized
INFO - 2018-10-25 07:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:21:24 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:21:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:21:24 --> Email Class Initialized
INFO - 2018-10-25 07:21:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:21:24 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:21:24 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:21:25 --> Helper loaded: date_helper
INFO - 2018-10-25 07:21:25 --> Database Driver Class Initialized
INFO - 2018-10-25 07:21:25 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:21:25 --> Controller Class Initialized
INFO - 2018-10-25 07:21:25 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\layouts/menu.php
INFO - 2018-10-25 07:21:25 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\login.php
INFO - 2018-10-25 07:21:25 --> Final output sent to browser
DEBUG - 2018-10-25 07:21:25 --> Total execution time: 0.4969
INFO - 2018-10-25 07:21:25 --> Config Class Initialized
INFO - 2018-10-25 07:21:25 --> Config Class Initialized
INFO - 2018-10-25 07:21:25 --> Config Class Initialized
INFO - 2018-10-25 07:21:25 --> Hooks Class Initialized
INFO - 2018-10-25 07:21:25 --> Hooks Class Initialized
INFO - 2018-10-25 07:21:25 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:21:25 --> UTF-8 Support Enabled
DEBUG - 2018-10-25 07:21:25 --> UTF-8 Support Enabled
DEBUG - 2018-10-25 07:21:25 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:21:25 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:25 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:25 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:25 --> URI Class Initialized
INFO - 2018-10-25 07:21:25 --> URI Class Initialized
INFO - 2018-10-25 07:21:25 --> URI Class Initialized
INFO - 2018-10-25 07:21:25 --> Router Class Initialized
INFO - 2018-10-25 07:21:25 --> Router Class Initialized
INFO - 2018-10-25 07:21:25 --> Router Class Initialized
INFO - 2018-10-25 07:21:25 --> Output Class Initialized
INFO - 2018-10-25 07:21:25 --> Output Class Initialized
INFO - 2018-10-25 07:21:25 --> Output Class Initialized
INFO - 2018-10-25 07:21:25 --> Security Class Initialized
INFO - 2018-10-25 07:21:25 --> Security Class Initialized
INFO - 2018-10-25 07:21:25 --> Security Class Initialized
DEBUG - 2018-10-25 07:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-25 07:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-25 07:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:21:25 --> Input Class Initialized
INFO - 2018-10-25 07:21:25 --> Input Class Initialized
INFO - 2018-10-25 07:21:25 --> Input Class Initialized
INFO - 2018-10-25 07:21:25 --> Language Class Initialized
INFO - 2018-10-25 07:21:25 --> Language Class Initialized
INFO - 2018-10-25 07:21:25 --> Language Class Initialized
ERROR - 2018-10-25 07:21:25 --> 404 Page Not Found: Application/views
ERROR - 2018-10-25 07:21:25 --> 404 Page Not Found: Application/views
ERROR - 2018-10-25 07:21:25 --> 404 Page Not Found: Application/views
INFO - 2018-10-25 07:21:30 --> Config Class Initialized
INFO - 2018-10-25 07:21:30 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:21:30 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:21:30 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:30 --> URI Class Initialized
INFO - 2018-10-25 07:21:30 --> Router Class Initialized
INFO - 2018-10-25 07:21:30 --> Output Class Initialized
INFO - 2018-10-25 07:21:30 --> Security Class Initialized
DEBUG - 2018-10-25 07:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:21:30 --> Input Class Initialized
INFO - 2018-10-25 07:21:30 --> Language Class Initialized
INFO - 2018-10-25 07:21:31 --> Loader Class Initialized
INFO - 2018-10-25 07:21:31 --> Helper loaded: url_helper
INFO - 2018-10-25 07:21:31 --> Database Driver Class Initialized
INFO - 2018-10-25 07:21:31 --> Helper loaded: form_helper
INFO - 2018-10-25 07:21:31 --> Form Validation Class Initialized
INFO - 2018-10-25 07:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:21:31 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:21:31 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:21:31 --> Email Class Initialized
INFO - 2018-10-25 07:21:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:21:31 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:21:31 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:21:31 --> Helper loaded: date_helper
INFO - 2018-10-25 07:21:31 --> Database Driver Class Initialized
INFO - 2018-10-25 07:21:31 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:21:31 --> Controller Class Initialized
INFO - 2018-10-25 07:21:31 --> Config Class Initialized
INFO - 2018-10-25 07:21:31 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:21:31 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:21:31 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:31 --> URI Class Initialized
INFO - 2018-10-25 07:21:31 --> Router Class Initialized
INFO - 2018-10-25 07:21:31 --> Output Class Initialized
INFO - 2018-10-25 07:21:31 --> Security Class Initialized
DEBUG - 2018-10-25 07:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:21:31 --> Input Class Initialized
INFO - 2018-10-25 07:21:31 --> Language Class Initialized
INFO - 2018-10-25 07:21:31 --> Loader Class Initialized
INFO - 2018-10-25 07:21:31 --> Helper loaded: url_helper
INFO - 2018-10-25 07:21:31 --> Database Driver Class Initialized
INFO - 2018-10-25 07:21:31 --> Helper loaded: form_helper
INFO - 2018-10-25 07:21:31 --> Form Validation Class Initialized
INFO - 2018-10-25 07:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:21:31 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:21:31 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:21:31 --> Email Class Initialized
INFO - 2018-10-25 07:21:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:21:31 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:21:31 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:21:31 --> Helper loaded: date_helper
INFO - 2018-10-25 07:21:31 --> Database Driver Class Initialized
INFO - 2018-10-25 07:21:31 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:21:31 --> Controller Class Initialized
INFO - 2018-10-25 07:21:31 --> Model "Item_model" initialized
INFO - 2018-10-25 07:21:31 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:21:31 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:21:31 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-25 07:21:31 --> Final output sent to browser
DEBUG - 2018-10-25 07:21:31 --> Total execution time: 0.5740
INFO - 2018-10-25 07:21:36 --> Config Class Initialized
INFO - 2018-10-25 07:21:36 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:21:36 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:21:36 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:36 --> URI Class Initialized
INFO - 2018-10-25 07:21:36 --> Router Class Initialized
INFO - 2018-10-25 07:21:36 --> Output Class Initialized
INFO - 2018-10-25 07:21:36 --> Security Class Initialized
DEBUG - 2018-10-25 07:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:21:36 --> Input Class Initialized
INFO - 2018-10-25 07:21:36 --> Language Class Initialized
INFO - 2018-10-25 07:21:36 --> Loader Class Initialized
INFO - 2018-10-25 07:21:36 --> Helper loaded: url_helper
INFO - 2018-10-25 07:21:36 --> Database Driver Class Initialized
INFO - 2018-10-25 07:21:36 --> Helper loaded: form_helper
INFO - 2018-10-25 07:21:36 --> Form Validation Class Initialized
INFO - 2018-10-25 07:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:21:36 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:21:36 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:21:36 --> Email Class Initialized
INFO - 2018-10-25 07:21:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:21:36 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:21:36 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:21:36 --> Helper loaded: date_helper
INFO - 2018-10-25 07:21:36 --> Database Driver Class Initialized
INFO - 2018-10-25 07:21:36 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:21:37 --> Controller Class Initialized
INFO - 2018-10-25 07:21:37 --> Model "Item_model" initialized
INFO - 2018-10-25 07:21:37 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:21:37 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:21:37 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-25 07:21:37 --> Final output sent to browser
DEBUG - 2018-10-25 07:21:37 --> Total execution time: 0.6987
INFO - 2018-10-25 07:21:37 --> Config Class Initialized
INFO - 2018-10-25 07:21:37 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:21:37 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:21:37 --> Utf8 Class Initialized
INFO - 2018-10-25 07:21:37 --> URI Class Initialized
INFO - 2018-10-25 07:21:37 --> Router Class Initialized
INFO - 2018-10-25 07:21:37 --> Output Class Initialized
INFO - 2018-10-25 07:21:37 --> Security Class Initialized
DEBUG - 2018-10-25 07:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:21:37 --> Input Class Initialized
INFO - 2018-10-25 07:21:37 --> Language Class Initialized
ERROR - 2018-10-25 07:21:37 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-25 07:25:36 --> Config Class Initialized
INFO - 2018-10-25 07:25:36 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:25:36 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:25:36 --> Utf8 Class Initialized
INFO - 2018-10-25 07:25:36 --> URI Class Initialized
INFO - 2018-10-25 07:25:36 --> Router Class Initialized
INFO - 2018-10-25 07:25:36 --> Output Class Initialized
INFO - 2018-10-25 07:25:36 --> Security Class Initialized
DEBUG - 2018-10-25 07:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:25:36 --> Input Class Initialized
INFO - 2018-10-25 07:25:36 --> Language Class Initialized
INFO - 2018-10-25 07:25:36 --> Loader Class Initialized
INFO - 2018-10-25 07:25:36 --> Helper loaded: url_helper
INFO - 2018-10-25 07:25:36 --> Database Driver Class Initialized
INFO - 2018-10-25 07:25:36 --> Helper loaded: form_helper
INFO - 2018-10-25 07:25:36 --> Form Validation Class Initialized
INFO - 2018-10-25 07:25:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:25:36 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:25:36 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:25:36 --> Email Class Initialized
INFO - 2018-10-25 07:25:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:25:36 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:25:36 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:25:36 --> Helper loaded: date_helper
INFO - 2018-10-25 07:25:37 --> Database Driver Class Initialized
INFO - 2018-10-25 07:25:37 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:25:37 --> Controller Class Initialized
INFO - 2018-10-25 07:25:37 --> Model "Item_model" initialized
INFO - 2018-10-25 07:25:37 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:25:37 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:25:37 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-25 07:25:37 --> Final output sent to browser
DEBUG - 2018-10-25 07:25:37 --> Total execution time: 0.4796
INFO - 2018-10-25 07:25:37 --> Config Class Initialized
INFO - 2018-10-25 07:25:37 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:25:37 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:25:37 --> Utf8 Class Initialized
INFO - 2018-10-25 07:25:37 --> URI Class Initialized
INFO - 2018-10-25 07:25:37 --> Router Class Initialized
INFO - 2018-10-25 07:25:37 --> Output Class Initialized
INFO - 2018-10-25 07:25:37 --> Security Class Initialized
DEBUG - 2018-10-25 07:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:25:37 --> Input Class Initialized
INFO - 2018-10-25 07:25:37 --> Language Class Initialized
ERROR - 2018-10-25 07:25:37 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-25 07:25:53 --> Config Class Initialized
INFO - 2018-10-25 07:25:53 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:25:53 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:25:53 --> Utf8 Class Initialized
INFO - 2018-10-25 07:25:53 --> URI Class Initialized
INFO - 2018-10-25 07:25:53 --> Router Class Initialized
INFO - 2018-10-25 07:25:53 --> Output Class Initialized
INFO - 2018-10-25 07:25:53 --> Security Class Initialized
DEBUG - 2018-10-25 07:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:25:53 --> Input Class Initialized
INFO - 2018-10-25 07:25:53 --> Language Class Initialized
ERROR - 2018-10-25 07:25:53 --> 404 Page Not Found: Item/nota.php
INFO - 2018-10-25 07:26:23 --> Config Class Initialized
INFO - 2018-10-25 07:26:23 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:26:23 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:26:23 --> Utf8 Class Initialized
INFO - 2018-10-25 07:26:23 --> URI Class Initialized
INFO - 2018-10-25 07:26:23 --> Router Class Initialized
INFO - 2018-10-25 07:26:23 --> Output Class Initialized
INFO - 2018-10-25 07:26:23 --> Security Class Initialized
DEBUG - 2018-10-25 07:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:26:23 --> Input Class Initialized
INFO - 2018-10-25 07:26:24 --> Language Class Initialized
INFO - 2018-10-25 07:26:24 --> Loader Class Initialized
INFO - 2018-10-25 07:26:24 --> Helper loaded: url_helper
INFO - 2018-10-25 07:26:24 --> Database Driver Class Initialized
INFO - 2018-10-25 07:26:24 --> Helper loaded: form_helper
INFO - 2018-10-25 07:26:24 --> Form Validation Class Initialized
INFO - 2018-10-25 07:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:26:24 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:26:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:26:24 --> Email Class Initialized
INFO - 2018-10-25 07:26:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:26:24 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:26:24 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:26:24 --> Helper loaded: date_helper
INFO - 2018-10-25 07:26:24 --> Database Driver Class Initialized
INFO - 2018-10-25 07:26:24 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:26:24 --> Controller Class Initialized
INFO - 2018-10-25 07:26:24 --> Model "Item_model" initialized
INFO - 2018-10-25 07:26:24 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:26:24 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:26:24 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-25 07:26:24 --> Final output sent to browser
DEBUG - 2018-10-25 07:26:24 --> Total execution time: 0.5451
INFO - 2018-10-25 07:26:24 --> Config Class Initialized
INFO - 2018-10-25 07:26:24 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:26:24 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:26:24 --> Utf8 Class Initialized
INFO - 2018-10-25 07:26:24 --> URI Class Initialized
INFO - 2018-10-25 07:26:24 --> Router Class Initialized
INFO - 2018-10-25 07:26:24 --> Output Class Initialized
INFO - 2018-10-25 07:26:24 --> Security Class Initialized
DEBUG - 2018-10-25 07:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:26:24 --> Input Class Initialized
INFO - 2018-10-25 07:26:24 --> Language Class Initialized
ERROR - 2018-10-25 07:26:24 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-25 07:26:27 --> Config Class Initialized
INFO - 2018-10-25 07:26:27 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:26:27 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:26:27 --> Utf8 Class Initialized
INFO - 2018-10-25 07:26:27 --> URI Class Initialized
INFO - 2018-10-25 07:26:27 --> Router Class Initialized
INFO - 2018-10-25 07:26:27 --> Output Class Initialized
INFO - 2018-10-25 07:26:27 --> Security Class Initialized
DEBUG - 2018-10-25 07:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:26:27 --> Input Class Initialized
INFO - 2018-10-25 07:26:27 --> Language Class Initialized
INFO - 2018-10-25 07:26:27 --> Loader Class Initialized
INFO - 2018-10-25 07:26:27 --> Helper loaded: url_helper
INFO - 2018-10-25 07:26:27 --> Database Driver Class Initialized
INFO - 2018-10-25 07:26:28 --> Helper loaded: form_helper
INFO - 2018-10-25 07:26:28 --> Form Validation Class Initialized
INFO - 2018-10-25 07:26:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:26:28 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:26:28 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:26:28 --> Email Class Initialized
INFO - 2018-10-25 07:26:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:26:28 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:26:28 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:26:28 --> Helper loaded: date_helper
INFO - 2018-10-25 07:26:28 --> Database Driver Class Initialized
INFO - 2018-10-25 07:26:28 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:26:28 --> Controller Class Initialized
INFO - 2018-10-25 07:26:28 --> Model "Item_model" initialized
INFO - 2018-10-25 07:26:28 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:26:28 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:26:28 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-25 07:26:28 --> Final output sent to browser
DEBUG - 2018-10-25 07:26:28 --> Total execution time: 0.6343
INFO - 2018-10-25 07:26:28 --> Config Class Initialized
INFO - 2018-10-25 07:26:28 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:26:28 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:26:28 --> Utf8 Class Initialized
INFO - 2018-10-25 07:26:28 --> URI Class Initialized
INFO - 2018-10-25 07:26:28 --> Router Class Initialized
INFO - 2018-10-25 07:26:28 --> Output Class Initialized
INFO - 2018-10-25 07:26:28 --> Security Class Initialized
DEBUG - 2018-10-25 07:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:26:28 --> Input Class Initialized
INFO - 2018-10-25 07:26:28 --> Language Class Initialized
ERROR - 2018-10-25 07:26:28 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-25 07:26:35 --> Config Class Initialized
INFO - 2018-10-25 07:26:35 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:26:35 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:26:35 --> Utf8 Class Initialized
INFO - 2018-10-25 07:26:35 --> URI Class Initialized
INFO - 2018-10-25 07:26:35 --> Router Class Initialized
INFO - 2018-10-25 07:26:35 --> Output Class Initialized
INFO - 2018-10-25 07:26:35 --> Security Class Initialized
DEBUG - 2018-10-25 07:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:26:35 --> Input Class Initialized
INFO - 2018-10-25 07:26:35 --> Language Class Initialized
ERROR - 2018-10-25 07:26:35 --> 404 Page Not Found: Item/nota.php
INFO - 2018-10-25 07:27:23 --> Config Class Initialized
INFO - 2018-10-25 07:27:24 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:27:24 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:27:24 --> Utf8 Class Initialized
INFO - 2018-10-25 07:27:24 --> URI Class Initialized
INFO - 2018-10-25 07:27:24 --> Router Class Initialized
INFO - 2018-10-25 07:27:24 --> Output Class Initialized
INFO - 2018-10-25 07:27:24 --> Security Class Initialized
DEBUG - 2018-10-25 07:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:27:24 --> Input Class Initialized
INFO - 2018-10-25 07:27:24 --> Language Class Initialized
INFO - 2018-10-25 07:27:24 --> Loader Class Initialized
INFO - 2018-10-25 07:27:24 --> Helper loaded: url_helper
INFO - 2018-10-25 07:27:24 --> Database Driver Class Initialized
INFO - 2018-10-25 07:27:24 --> Helper loaded: form_helper
INFO - 2018-10-25 07:27:24 --> Form Validation Class Initialized
INFO - 2018-10-25 07:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:27:24 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:27:24 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:27:24 --> Email Class Initialized
INFO - 2018-10-25 07:27:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:27:24 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:27:24 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:27:24 --> Helper loaded: date_helper
INFO - 2018-10-25 07:27:24 --> Database Driver Class Initialized
INFO - 2018-10-25 07:27:24 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:27:24 --> Controller Class Initialized
INFO - 2018-10-25 07:27:24 --> Model "Item_model" initialized
INFO - 2018-10-25 07:27:24 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:27:24 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:27:24 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-25 07:27:24 --> Final output sent to browser
DEBUG - 2018-10-25 07:27:24 --> Total execution time: 0.5882
INFO - 2018-10-25 07:27:27 --> Config Class Initialized
INFO - 2018-10-25 07:27:27 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:27:27 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:27:27 --> Utf8 Class Initialized
INFO - 2018-10-25 07:27:27 --> URI Class Initialized
INFO - 2018-10-25 07:27:27 --> Router Class Initialized
INFO - 2018-10-25 07:27:27 --> Output Class Initialized
INFO - 2018-10-25 07:27:27 --> Security Class Initialized
DEBUG - 2018-10-25 07:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:27:27 --> Input Class Initialized
INFO - 2018-10-25 07:27:27 --> Language Class Initialized
INFO - 2018-10-25 07:27:27 --> Loader Class Initialized
INFO - 2018-10-25 07:27:27 --> Helper loaded: url_helper
INFO - 2018-10-25 07:27:27 --> Database Driver Class Initialized
INFO - 2018-10-25 07:27:27 --> Helper loaded: form_helper
INFO - 2018-10-25 07:27:27 --> Form Validation Class Initialized
INFO - 2018-10-25 07:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:27:27 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:27:27 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:27:27 --> Email Class Initialized
INFO - 2018-10-25 07:27:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:27:27 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:27:27 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:27:27 --> Helper loaded: date_helper
INFO - 2018-10-25 07:27:27 --> Database Driver Class Initialized
INFO - 2018-10-25 07:27:27 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:27:27 --> Controller Class Initialized
INFO - 2018-10-25 07:27:27 --> Model "Item_model" initialized
INFO - 2018-10-25 07:27:27 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:27:28 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:27:28 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-25 07:27:28 --> Final output sent to browser
DEBUG - 2018-10-25 07:27:28 --> Total execution time: 0.6060
INFO - 2018-10-25 07:27:28 --> Config Class Initialized
INFO - 2018-10-25 07:27:28 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:27:28 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:27:28 --> Utf8 Class Initialized
INFO - 2018-10-25 07:27:28 --> URI Class Initialized
INFO - 2018-10-25 07:27:28 --> Router Class Initialized
INFO - 2018-10-25 07:27:28 --> Output Class Initialized
INFO - 2018-10-25 07:27:28 --> Security Class Initialized
DEBUG - 2018-10-25 07:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:27:28 --> Input Class Initialized
INFO - 2018-10-25 07:27:28 --> Language Class Initialized
ERROR - 2018-10-25 07:27:28 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-25 07:27:33 --> Config Class Initialized
INFO - 2018-10-25 07:27:33 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:27:33 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:27:33 --> Utf8 Class Initialized
INFO - 2018-10-25 07:27:33 --> URI Class Initialized
INFO - 2018-10-25 07:27:33 --> Router Class Initialized
INFO - 2018-10-25 07:27:33 --> Output Class Initialized
INFO - 2018-10-25 07:27:33 --> Security Class Initialized
DEBUG - 2018-10-25 07:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:27:33 --> Input Class Initialized
INFO - 2018-10-25 07:27:33 --> Language Class Initialized
ERROR - 2018-10-25 07:27:33 --> 404 Page Not Found: Item/nota
INFO - 2018-10-25 07:28:51 --> Config Class Initialized
INFO - 2018-10-25 07:28:51 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:28:51 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:28:51 --> Utf8 Class Initialized
INFO - 2018-10-25 07:28:51 --> URI Class Initialized
INFO - 2018-10-25 07:28:51 --> Router Class Initialized
INFO - 2018-10-25 07:28:51 --> Output Class Initialized
INFO - 2018-10-25 07:28:51 --> Security Class Initialized
DEBUG - 2018-10-25 07:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:28:51 --> Input Class Initialized
INFO - 2018-10-25 07:28:51 --> Language Class Initialized
INFO - 2018-10-25 07:28:51 --> Loader Class Initialized
INFO - 2018-10-25 07:28:51 --> Helper loaded: url_helper
INFO - 2018-10-25 07:28:51 --> Database Driver Class Initialized
INFO - 2018-10-25 07:28:51 --> Helper loaded: form_helper
INFO - 2018-10-25 07:28:51 --> Form Validation Class Initialized
INFO - 2018-10-25 07:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:28:51 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:28:51 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:28:51 --> Email Class Initialized
INFO - 2018-10-25 07:28:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:28:51 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:28:51 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:28:51 --> Helper loaded: date_helper
INFO - 2018-10-25 07:28:51 --> Database Driver Class Initialized
INFO - 2018-10-25 07:28:51 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:28:51 --> Controller Class Initialized
INFO - 2018-10-25 07:28:51 --> Model "Item_model" initialized
INFO - 2018-10-25 07:28:51 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:28:51 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:28:51 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-25 07:28:51 --> Final output sent to browser
DEBUG - 2018-10-25 07:28:51 --> Total execution time: 0.4755
INFO - 2018-10-25 07:28:54 --> Config Class Initialized
INFO - 2018-10-25 07:28:54 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:28:54 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:28:54 --> Utf8 Class Initialized
INFO - 2018-10-25 07:28:54 --> URI Class Initialized
INFO - 2018-10-25 07:28:54 --> Router Class Initialized
INFO - 2018-10-25 07:28:54 --> Output Class Initialized
INFO - 2018-10-25 07:28:54 --> Security Class Initialized
DEBUG - 2018-10-25 07:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:28:54 --> Input Class Initialized
INFO - 2018-10-25 07:28:54 --> Language Class Initialized
INFO - 2018-10-25 07:28:55 --> Loader Class Initialized
INFO - 2018-10-25 07:28:55 --> Helper loaded: url_helper
INFO - 2018-10-25 07:28:55 --> Database Driver Class Initialized
INFO - 2018-10-25 07:28:55 --> Helper loaded: form_helper
INFO - 2018-10-25 07:28:55 --> Form Validation Class Initialized
INFO - 2018-10-25 07:28:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:28:55 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:28:55 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:28:55 --> Email Class Initialized
INFO - 2018-10-25 07:28:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:28:55 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:28:55 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:28:55 --> Helper loaded: date_helper
INFO - 2018-10-25 07:28:55 --> Database Driver Class Initialized
INFO - 2018-10-25 07:28:55 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:28:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:28:55 --> Controller Class Initialized
INFO - 2018-10-25 07:28:55 --> Model "Item_model" initialized
INFO - 2018-10-25 07:28:55 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:28:55 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:28:55 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-25 07:28:55 --> Final output sent to browser
DEBUG - 2018-10-25 07:28:55 --> Total execution time: 0.4202
INFO - 2018-10-25 07:28:55 --> Config Class Initialized
INFO - 2018-10-25 07:28:55 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:28:55 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:28:55 --> Utf8 Class Initialized
INFO - 2018-10-25 07:28:55 --> URI Class Initialized
INFO - 2018-10-25 07:28:55 --> Router Class Initialized
INFO - 2018-10-25 07:28:55 --> Output Class Initialized
INFO - 2018-10-25 07:28:55 --> Security Class Initialized
DEBUG - 2018-10-25 07:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:28:55 --> Input Class Initialized
INFO - 2018-10-25 07:28:55 --> Language Class Initialized
ERROR - 2018-10-25 07:28:55 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-25 07:29:00 --> Config Class Initialized
INFO - 2018-10-25 07:29:00 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:29:00 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:29:00 --> Utf8 Class Initialized
INFO - 2018-10-25 07:29:00 --> URI Class Initialized
INFO - 2018-10-25 07:29:00 --> Router Class Initialized
INFO - 2018-10-25 07:29:00 --> Output Class Initialized
INFO - 2018-10-25 07:29:00 --> Security Class Initialized
DEBUG - 2018-10-25 07:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:29:00 --> Input Class Initialized
INFO - 2018-10-25 07:29:00 --> Language Class Initialized
INFO - 2018-10-25 07:29:01 --> Loader Class Initialized
INFO - 2018-10-25 07:29:01 --> Helper loaded: url_helper
INFO - 2018-10-25 07:29:01 --> Database Driver Class Initialized
INFO - 2018-10-25 07:29:01 --> Helper loaded: form_helper
INFO - 2018-10-25 07:29:01 --> Form Validation Class Initialized
INFO - 2018-10-25 07:29:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:29:01 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:29:01 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:29:01 --> Email Class Initialized
INFO - 2018-10-25 07:29:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:29:01 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:29:01 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:29:01 --> Helper loaded: date_helper
INFO - 2018-10-25 07:29:01 --> Database Driver Class Initialized
INFO - 2018-10-25 07:29:01 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:29:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:29:01 --> Controller Class Initialized
INFO - 2018-10-25 07:29:01 --> Model "Item_model" initialized
INFO - 2018-10-25 07:29:01 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:29:01 --> Model "Vendor_model" initialized
ERROR - 2018-10-25 07:29:01 --> Severity: Warning --> include(./konfigurasi/config.php): failed to open stream: No such file or directory D:\xampp\htdocs\masterwedding\application\views\item\nota.php 7
ERROR - 2018-10-25 07:29:01 --> Severity: Warning --> include(): Failed opening './konfigurasi/config.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\masterwedding\application\views\item\nota.php 7
ERROR - 2018-10-25 07:29:01 --> Severity: Warning --> include(./konfigurasi/function.php): failed to open stream: No such file or directory D:\xampp\htdocs\masterwedding\application\views\item\nota.php 8
ERROR - 2018-10-25 07:29:01 --> Severity: Warning --> include(): Failed opening './konfigurasi/function.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\masterwedding\application\views\item\nota.php 8
ERROR - 2018-10-25 07:29:01 --> Severity: Warning --> include(./fragment/header.php): failed to open stream: No such file or directory D:\xampp\htdocs\masterwedding\application\views\item\nota.php 9
ERROR - 2018-10-25 07:29:01 --> Severity: Warning --> include(): Failed opening './fragment/header.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\masterwedding\application\views\item\nota.php 9
ERROR - 2018-10-25 07:29:01 --> Severity: Warning --> include(./fragment/menu.php): failed to open stream: No such file or directory D:\xampp\htdocs\masterwedding\application\views\item\nota.php 10
ERROR - 2018-10-25 07:29:01 --> Severity: Warning --> include(): Failed opening './fragment/menu.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\masterwedding\application\views\item\nota.php 10
ERROR - 2018-10-25 07:29:01 --> Severity: error --> Exception: Call to undefined function connect_db() D:\xampp\htdocs\masterwedding\application\views\item\nota.php 11
INFO - 2018-10-25 07:29:14 --> Config Class Initialized
INFO - 2018-10-25 07:29:14 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:29:14 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:29:14 --> Utf8 Class Initialized
INFO - 2018-10-25 07:29:14 --> URI Class Initialized
INFO - 2018-10-25 07:29:14 --> Router Class Initialized
INFO - 2018-10-25 07:29:14 --> Output Class Initialized
INFO - 2018-10-25 07:29:14 --> Security Class Initialized
DEBUG - 2018-10-25 07:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:29:14 --> Input Class Initialized
INFO - 2018-10-25 07:29:14 --> Language Class Initialized
INFO - 2018-10-25 07:29:14 --> Loader Class Initialized
INFO - 2018-10-25 07:29:14 --> Helper loaded: url_helper
INFO - 2018-10-25 07:29:14 --> Database Driver Class Initialized
INFO - 2018-10-25 07:29:14 --> Helper loaded: form_helper
INFO - 2018-10-25 07:29:14 --> Form Validation Class Initialized
INFO - 2018-10-25 07:29:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:29:14 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:29:14 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:29:14 --> Email Class Initialized
INFO - 2018-10-25 07:29:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:29:14 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:29:14 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:29:14 --> Helper loaded: date_helper
INFO - 2018-10-25 07:29:14 --> Database Driver Class Initialized
INFO - 2018-10-25 07:29:14 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:29:14 --> Controller Class Initialized
INFO - 2018-10-25 07:29:14 --> Model "Item_model" initialized
INFO - 2018-10-25 07:29:14 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:29:14 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:29:15 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-25 07:29:15 --> Final output sent to browser
DEBUG - 2018-10-25 07:29:15 --> Total execution time: 0.7260
INFO - 2018-10-25 07:30:09 --> Config Class Initialized
INFO - 2018-10-25 07:30:09 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:30:09 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:30:09 --> Utf8 Class Initialized
INFO - 2018-10-25 07:30:09 --> URI Class Initialized
INFO - 2018-10-25 07:30:09 --> Router Class Initialized
INFO - 2018-10-25 07:30:09 --> Output Class Initialized
INFO - 2018-10-25 07:30:09 --> Security Class Initialized
DEBUG - 2018-10-25 07:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:30:09 --> Input Class Initialized
INFO - 2018-10-25 07:30:09 --> Language Class Initialized
INFO - 2018-10-25 07:30:09 --> Loader Class Initialized
INFO - 2018-10-25 07:30:09 --> Helper loaded: url_helper
INFO - 2018-10-25 07:30:09 --> Database Driver Class Initialized
INFO - 2018-10-25 07:30:09 --> Helper loaded: form_helper
INFO - 2018-10-25 07:30:09 --> Form Validation Class Initialized
INFO - 2018-10-25 07:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:30:09 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:30:09 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:30:09 --> Email Class Initialized
INFO - 2018-10-25 07:30:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:30:09 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:30:09 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:30:09 --> Helper loaded: date_helper
INFO - 2018-10-25 07:30:09 --> Database Driver Class Initialized
INFO - 2018-10-25 07:30:09 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:30:09 --> Controller Class Initialized
INFO - 2018-10-25 07:30:09 --> Model "Item_model" initialized
INFO - 2018-10-25 07:30:09 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:30:09 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:30:09 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-25 07:30:09 --> Final output sent to browser
DEBUG - 2018-10-25 07:30:10 --> Total execution time: 0.8575
INFO - 2018-10-25 07:30:10 --> Config Class Initialized
INFO - 2018-10-25 07:30:10 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:30:10 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:30:10 --> Utf8 Class Initialized
INFO - 2018-10-25 07:30:10 --> URI Class Initialized
INFO - 2018-10-25 07:30:10 --> Router Class Initialized
INFO - 2018-10-25 07:30:10 --> Output Class Initialized
INFO - 2018-10-25 07:30:10 --> Security Class Initialized
DEBUG - 2018-10-25 07:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:30:10 --> Input Class Initialized
INFO - 2018-10-25 07:30:10 --> Language Class Initialized
ERROR - 2018-10-25 07:30:10 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-25 07:30:12 --> Config Class Initialized
INFO - 2018-10-25 07:30:12 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:30:12 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:30:12 --> Utf8 Class Initialized
INFO - 2018-10-25 07:30:12 --> URI Class Initialized
INFO - 2018-10-25 07:30:12 --> Router Class Initialized
INFO - 2018-10-25 07:30:12 --> Output Class Initialized
INFO - 2018-10-25 07:30:12 --> Security Class Initialized
DEBUG - 2018-10-25 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:30:12 --> Input Class Initialized
INFO - 2018-10-25 07:30:12 --> Language Class Initialized
INFO - 2018-10-25 07:30:12 --> Loader Class Initialized
INFO - 2018-10-25 07:30:12 --> Helper loaded: url_helper
INFO - 2018-10-25 07:30:12 --> Database Driver Class Initialized
INFO - 2018-10-25 07:30:12 --> Helper loaded: form_helper
INFO - 2018-10-25 07:30:12 --> Form Validation Class Initialized
INFO - 2018-10-25 07:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:30:12 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:30:12 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:30:12 --> Email Class Initialized
INFO - 2018-10-25 07:30:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:30:12 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:30:12 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:30:12 --> Helper loaded: date_helper
INFO - 2018-10-25 07:30:12 --> Database Driver Class Initialized
INFO - 2018-10-25 07:30:12 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:30:12 --> Controller Class Initialized
INFO - 2018-10-25 07:30:12 --> Model "Item_model" initialized
INFO - 2018-10-25 07:30:12 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:30:12 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:30:12 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-25 07:30:12 --> Final output sent to browser
DEBUG - 2018-10-25 07:30:12 --> Total execution time: 0.5398
INFO - 2018-10-25 07:30:12 --> Config Class Initialized
INFO - 2018-10-25 07:30:12 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:30:12 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:30:12 --> Utf8 Class Initialized
INFO - 2018-10-25 07:30:12 --> URI Class Initialized
INFO - 2018-10-25 07:30:12 --> Router Class Initialized
INFO - 2018-10-25 07:30:12 --> Output Class Initialized
INFO - 2018-10-25 07:30:12 --> Security Class Initialized
DEBUG - 2018-10-25 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:30:12 --> Input Class Initialized
INFO - 2018-10-25 07:30:12 --> Language Class Initialized
ERROR - 2018-10-25 07:30:12 --> 404 Page Not Found: Item/%3C
INFO - 2018-10-25 07:30:18 --> Config Class Initialized
INFO - 2018-10-25 07:30:18 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:30:18 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:30:18 --> Utf8 Class Initialized
INFO - 2018-10-25 07:30:18 --> URI Class Initialized
INFO - 2018-10-25 07:30:18 --> Router Class Initialized
INFO - 2018-10-25 07:30:18 --> Output Class Initialized
INFO - 2018-10-25 07:30:18 --> Security Class Initialized
DEBUG - 2018-10-25 07:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:30:18 --> Input Class Initialized
INFO - 2018-10-25 07:30:18 --> Language Class Initialized
INFO - 2018-10-25 07:30:18 --> Loader Class Initialized
INFO - 2018-10-25 07:30:18 --> Helper loaded: url_helper
INFO - 2018-10-25 07:30:18 --> Database Driver Class Initialized
INFO - 2018-10-25 07:30:18 --> Helper loaded: form_helper
INFO - 2018-10-25 07:30:18 --> Form Validation Class Initialized
INFO - 2018-10-25 07:30:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:30:18 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:30:18 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:30:18 --> Email Class Initialized
INFO - 2018-10-25 07:30:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:30:18 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:30:18 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:30:18 --> Helper loaded: date_helper
INFO - 2018-10-25 07:30:18 --> Database Driver Class Initialized
INFO - 2018-10-25 07:30:18 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:30:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:30:18 --> Controller Class Initialized
INFO - 2018-10-25 07:30:18 --> Model "Item_model" initialized
INFO - 2018-10-25 07:30:18 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:30:18 --> Model "Vendor_model" initialized
ERROR - 2018-10-25 07:30:18 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\masterwedding\application\views\item\nota.php 8
INFO - 2018-10-25 07:36:07 --> Config Class Initialized
INFO - 2018-10-25 07:36:07 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:36:07 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:36:07 --> Utf8 Class Initialized
INFO - 2018-10-25 07:36:07 --> URI Class Initialized
INFO - 2018-10-25 07:36:07 --> Router Class Initialized
INFO - 2018-10-25 07:36:07 --> Output Class Initialized
INFO - 2018-10-25 07:36:07 --> Security Class Initialized
DEBUG - 2018-10-25 07:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:36:07 --> Input Class Initialized
INFO - 2018-10-25 07:36:07 --> Language Class Initialized
INFO - 2018-10-25 07:36:07 --> Loader Class Initialized
INFO - 2018-10-25 07:36:07 --> Helper loaded: url_helper
INFO - 2018-10-25 07:36:07 --> Database Driver Class Initialized
INFO - 2018-10-25 07:36:07 --> Helper loaded: form_helper
INFO - 2018-10-25 07:36:07 --> Form Validation Class Initialized
INFO - 2018-10-25 07:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:36:07 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:36:07 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:36:07 --> Email Class Initialized
INFO - 2018-10-25 07:36:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:36:07 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:36:07 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:36:07 --> Helper loaded: date_helper
INFO - 2018-10-25 07:36:07 --> Database Driver Class Initialized
INFO - 2018-10-25 07:36:07 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:36:07 --> Controller Class Initialized
INFO - 2018-10-25 07:36:07 --> Model "Item_model" initialized
INFO - 2018-10-25 07:36:07 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:36:07 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:36:07 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/index.php
INFO - 2018-10-25 07:36:07 --> Final output sent to browser
DEBUG - 2018-10-25 07:36:07 --> Total execution time: 0.5123
INFO - 2018-10-25 07:36:13 --> Config Class Initialized
INFO - 2018-10-25 07:36:13 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:36:13 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:36:13 --> Utf8 Class Initialized
INFO - 2018-10-25 07:36:13 --> URI Class Initialized
INFO - 2018-10-25 07:36:13 --> Router Class Initialized
INFO - 2018-10-25 07:36:13 --> Output Class Initialized
INFO - 2018-10-25 07:36:13 --> Security Class Initialized
DEBUG - 2018-10-25 07:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:36:13 --> Input Class Initialized
INFO - 2018-10-25 07:36:13 --> Language Class Initialized
INFO - 2018-10-25 07:36:13 --> Loader Class Initialized
INFO - 2018-10-25 07:36:13 --> Helper loaded: url_helper
INFO - 2018-10-25 07:36:13 --> Database Driver Class Initialized
INFO - 2018-10-25 07:36:13 --> Helper loaded: form_helper
INFO - 2018-10-25 07:36:13 --> Form Validation Class Initialized
INFO - 2018-10-25 07:36:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-25 07:36:13 --> Pagination Class Initialized
DEBUG - 2018-10-25 07:36:13 --> Config file loaded: D:\xampp\htdocs\masterwedding\application\config/ion_auth.php
INFO - 2018-10-25 07:36:13 --> Email Class Initialized
INFO - 2018-10-25 07:36:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2018-10-25 07:36:13 --> Helper loaded: cookie_helper
INFO - 2018-10-25 07:36:13 --> Helper loaded: language_helper
DEBUG - 2018-10-25 07:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-25 07:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-25 07:36:13 --> Helper loaded: date_helper
INFO - 2018-10-25 07:36:13 --> Database Driver Class Initialized
INFO - 2018-10-25 07:36:13 --> Model "Ion_auth_model" initialized
DEBUG - 2018-10-25 07:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-10-25 07:36:13 --> Controller Class Initialized
INFO - 2018-10-25 07:36:14 --> Model "Item_model" initialized
INFO - 2018-10-25 07:36:14 --> Model "Jenis_model" initialized
INFO - 2018-10-25 07:36:14 --> Model "Vendor_model" initialized
INFO - 2018-10-25 07:36:14 --> File loaded: D:\xampp\htdocs\masterwedding\application\views\item/pesan.php
INFO - 2018-10-25 07:36:14 --> Final output sent to browser
DEBUG - 2018-10-25 07:36:14 --> Total execution time: 0.7216
INFO - 2018-10-25 07:36:14 --> Config Class Initialized
INFO - 2018-10-25 07:36:14 --> Hooks Class Initialized
DEBUG - 2018-10-25 07:36:14 --> UTF-8 Support Enabled
INFO - 2018-10-25 07:36:14 --> Utf8 Class Initialized
INFO - 2018-10-25 07:36:14 --> URI Class Initialized
INFO - 2018-10-25 07:36:14 --> Router Class Initialized
INFO - 2018-10-25 07:36:14 --> Output Class Initialized
INFO - 2018-10-25 07:36:14 --> Security Class Initialized
DEBUG - 2018-10-25 07:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-25 07:36:14 --> Input Class Initialized
INFO - 2018-10-25 07:36:14 --> Language Class Initialized
ERROR - 2018-10-25 07:36:14 --> 404 Page Not Found: Item/%3C
