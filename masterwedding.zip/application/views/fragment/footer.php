<div class="text-center"><footer>

       <br> <small><i>Copyright &copy; 2018</i></small>

</footer></div>
</body>
</html>