<h2>Selamat datang <?php echo $nama ?></h2>
<h5>Di <?= $alamat ?></h5>